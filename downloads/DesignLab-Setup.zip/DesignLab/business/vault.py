"""
Design Lab - keeping secrets (activation keys, AI keys) locked on disk.

On Windows the secret is locked with the computer's own protection (Windows DPAPI, "this computer only"):
the file can be copied, but the key inside can't be read on another computer.
Stored form:  "dpapi:<base64>".   Older plain values still work and are locked the next time they are saved.
On other systems (tests) the value is kept as it is.
"""
import base64
import sys

PREFIX = "dpapi:"

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    class _BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    _crypt32 = ctypes.windll.crypt32
    _kernel32 = ctypes.windll.kernel32
    _LOCAL_MACHINE = 0x4       # CRYPTPROTECT_LOCAL_MACHINE: any Windows user on THIS computer (the servers may run as another user)
    _UI_FORBIDDEN = 0x1

    def _blob(data):
        buf = ctypes.create_string_buffer(data, len(data))
        return _BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    def _run(fn, data):
        inp, _keep = _blob(data)
        out = _BLOB()
        ok = fn(ctypes.byref(inp), None, None, None, None, _LOCAL_MACHINE | _UI_FORBIDDEN, ctypes.byref(out)) \
            if fn is _crypt32.CryptProtectData else \
            fn(ctypes.byref(inp), None, None, None, None, _UI_FORBIDDEN, ctypes.byref(out))
        if not ok:
            raise OSError("Windows could not lock/unlock the key")
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(out.pbData)

    def lock(secret):
        s = str(secret or "")
        if not s or s.startswith(PREFIX):
            return s
        try:
            return PREFIX + base64.b64encode(_run(_crypt32.CryptProtectData, s.encode("utf-8"))).decode()
        except Exception:
            return s

    def reveal(value):
        v = str(value or "")
        if not v.startswith(PREFIX):
            return v
        try:
            return _run(_crypt32.CryptUnprotectData, base64.b64decode(v[len(PREFIX):])).decode("utf-8")
        except Exception:
            return ""          # moved to another computer: link the studio again from Team & wallet
else:
    def lock(secret):
        return str(secret or "")

    def reveal(value):
        v = str(value or "")
        return "" if v.startswith(PREFIX) else v
