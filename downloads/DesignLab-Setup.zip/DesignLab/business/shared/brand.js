/* Design Lab brand mark — shared by the website and the owner dashboard.
   Change the lettering here and both update together. */
(function () {
  const GL = {
    D: [44, "M2 2 H30 A12 12 0 0 1 42 14 V26 A12 12 0 0 1 30 38 H2 Z"],
    E: [40, "M2 2 H38 M2 20 H30 M2 38 H38"],
    S: [44, "M42 2 H13 A9 9 0 0 0 13 20 H31 A9 9 0 0 1 31 38 H2"],
    I: [4, "M2 2 V38"],
    G: [44, "M42 2 H14 A12 12 0 0 0 2 14 V26 A12 12 0 0 0 14 38 H42 V21 H27"],
    N: [42, "M2 38 V2 L40 38 V2"],
    L: [36, "M2 2 V38 H34"],
    A: [44, "M2 38 L22 2 L42 38"],
    B: [42, "M2 2 H29 A9 9 0 0 1 29 20 H2 V2 M2 20 H31 A9 9 0 0 1 31 38 H2 V20"],
  };
  let n = 0;
  function svg(opts) {
    opts = opts || {};
    const id = "dlg" + (++n);
    let x = 0, out = "";
    for (const ch of "DESIGN LAB") {
      if (ch === " ") { x += 30; continue; }
      const [w, d] = GL[ch];
      out += `<path transform="translate(${x} 0)" d="${d}"/>`;
      x += w + 16;
    }
    const stroke = opts.color || `url(#${id})`;
    return `<svg class="${opts.cls || ""}" viewBox="-3 -3 ${x - 10} 46" role="img" aria-label="Design Lab">
      <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="40" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#ffb070"/><stop offset=".5" stop-color="#ff6a13"/><stop offset="1" stop-color="#e04e00"/></linearGradient></defs>
      <g fill="none" stroke="${stroke}" stroke-width="${opts.weight || 3.4}" stroke-linecap="square">${out}</g></svg>`;
  }
  window.DesignLabBrand = { svg };
})();
