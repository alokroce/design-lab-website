"""
Design Lab - THE COURTYARD (the community where architects, designers and vendors meet).

Lives on Design Lab's own server (business side) because people from different firms must reach it.
Studios and vendors reach it through their own Design Lab software (firm code + activation key).

Parts: Welcome wall, Feed (Gallery, New arrivals, Mood board requests, news), People directory,
Rooms (open chat; notifications off by default; language rules), Private messages (request -> reply),
Open House events (invite by city / kind, RSVP), Spotlight (Gallery of the week / month),
Magazine (made by the bot each month, with paid ad spaces).  Admin controls everything.

Data: business/data/courtyard.json  +  business/data/courtyard_files/
"""
import base64
import json
import os
import re
import secrets
import time
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "data")
CY_FILE = os.path.join(DATA_DIR, "courtyard.json")
FILES_DIR = os.path.join(DATA_DIR, "courtyard_files")
MAX_FILE = 8 * 1024 * 1024
IMG_EXT = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "application/pdf": ".pdf"}

DEFAULT_ROOMS = [
    {"id": "everyone", "name": "Everyone", "about": "Say hello, share news, ask the community", "city": ""},
    {"id": "mumbai", "name": "Mumbai", "about": "Architects and vendors in Mumbai", "city": "Mumbai"},
    {"id": "bengaluru", "name": "Bengaluru", "about": "Architects and vendors in Bengaluru", "city": "Bengaluru"},
    {"id": "stone", "name": "Marble & Stone", "about": "Marble, granite, quartz, stone", "city": ""},
    {"id": "lighting", "name": "Lighting", "about": "Decorative and architectural lighting", "city": ""},
    {"id": "hospitality", "name": "Hospitality projects", "about": "Hotels, restaurants, boutique stays", "city": ""},
]

ApiError = None   # set by cloud.py

# ---------------------------------------------------------------- house rules (open spaces only)
BAD_WORDS = ["fuck", "shit", "bitch", "bastard", "asshole", "dick", "cunt", "madarchod", "maderchod", "behenchod",
             "bhenchod", "benchod", "chutiya", "chutia", "gandu", "harami", "randi", "bhosdi", "lavde", "lodu", "kutta kamina"]
PHONE_RE = re.compile(r"(?<!\d)(\+?91[\s\-]?)?[6-9]\d{2}[\s\-]?\d{3}[\s\-]?\d{4}(?!\d)")
EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", re.I)
HIRING_RE = re.compile(r"\b(hiring|vacanc(y|ies)|job opening|openings? for|join our team|salary|resume|\bcv\b|manpower|"
                       r"labou?r supply|we need (a )?(draftsm[ae]n|designers?|staff|workers?)|looking for (a )?(draftsm[ae]n|staff|job))\b", re.I)


def check_text(text, open_space=True):
    """Returns (ok, status, message). status: 'ok' | 'held' (waits for Design Lab) | 'blocked'."""
    low = " " + re.sub(r"[^a-z\s]", " ", text.lower()) + " "
    if any(f" {w} " in low or (len(w) > 5 and w in low) for w in BAD_WORDS):
        return False, "blocked", "Please keep The Courtyard polite. That wasn't posted."
    squashed = re.sub(r"[\s\-().]", "", text)
    if open_space and (PHONE_RE.search(text) or re.search(r"(?<!\d)(?:\+?91)?[6-9]\d{9}(?!\d)", squashed) or EMAIL_RE.search(text)):
        return False, "blocked", "Phone numbers and emails go in a private message, not in open spaces."
    if open_space and HIRING_RE.search(text):
        return True, "held", "Posts about hiring or staff are checked by Design Lab before everyone sees them."
    return True, "ok", ""


# ---------------------------------------------------------------- storage

def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def load():
    try:
        with open(CY_FILE, "r", encoding="utf-8") as f:
            cy = json.load(f)
    except (OSError, ValueError):
        cy = {}
    cy.setdefault("members", {})
    cy.setdefault("posts", [])
    cy.setdefault("rooms", json.loads(json.dumps(DEFAULT_ROOMS)))
    cy.setdefault("messages", {})
    cy.setdefault("threads", [])
    cy.setdefault("events", [])
    cy.setdefault("ads", [])
    cy.setdefault("issues", [])
    cy.setdefault("prefs", {})
    cy.setdefault("flags", [])
    cy.setdefault("strikes", {})
    cy.setdefault("settings", {"hero": ""})
    cy.setdefault("saves", {})
    cy.setdefault("submissions", [])
    cy.setdefault("orders", {})
    cy.setdefault("community", [])
    cy.setdefault("editions", [])
    for r in cy["rooms"]:
        r.setdefault("by", "")
        r.setdefault("until", "")
        r.setdefault("kind", "topic")
        r.setdefault("tag", tag_of(r["name"]))
    return cy


def tag_of(text):
    """'#Marble & Stone' -> 'marbleandstone' (hashtags are kept as plain lowercase words)."""
    return re.sub(r"[^a-z0-9]+", "", str(text or "").lower().replace("&", "and"))[:40]


def hashtags(text):
    return sorted({tag_of(t) for t in re.findall(r"#([\w&\-]+)", str(text or "")) if tag_of(t)})[:12]


def save(cy):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = CY_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cy, f, ensure_ascii=False, indent=1)
    os.replace(tmp, CY_FILE)


def new_id(prefix):
    return prefix + secrets.token_hex(5)


def store_file(data_url, max_bytes=MAX_FILE):
    """Save a data: URL (photo or PDF) and return its file name."""
    if not data_url:
        return ""
    m = re.match(r"^data:([\w/+.\-]+);base64,(.+)$", data_url, re.S)
    if not m or m.group(1) not in IMG_EXT:
        raise ApiError(400, "Please add a photo (JPG, PNG) or a PDF.")
    raw = base64.b64decode(m.group(2))
    if len(raw) > max_bytes:
        raise ApiError(400, f"That file is too big (max {max_bytes // 1024 // 1024} MB).")
    os.makedirs(FILES_DIR, exist_ok=True)
    name = secrets.token_hex(10) + IMG_EXT[m.group(1)]
    with open(os.path.join(FILES_DIR, name), "wb") as f:
        f.write(raw)
    return name


DOC_EXT = (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".dwg", ".dxf", ".txt", ".csv", ".zip")


def store_doc(data_url, name, max_bytes=MAX_FILE * 2):
    """A document sent in a chat: PDF, Word, Excel, PowerPoint, AutoCAD (dwg/dxf), text, zip. Kept with its type."""
    ext = os.path.splitext(str(name or ""))[1].lower()
    if ext not in DOC_EXT:
        raise ApiError(400, "Send a PDF, Word, Excel, PowerPoint, AutoCAD (dwg/dxf), text or zip file.")
    m = re.match(r"^data:[^;,]*;base64,(.+)$", data_url or "", re.S)
    if not m:
        raise ApiError(400, "The document could not be read.")
    raw = base64.b64decode(m.group(1))
    if len(raw) > max_bytes:
        raise ApiError(400, f"That document is too big (max {max_bytes // 1024 // 1024} MB).")
    os.makedirs(FILES_DIR, exist_ok=True)
    fname = secrets.token_hex(10) + ext
    with open(os.path.join(FILES_DIR, fname), "wb") as f:
        f.write(raw)
    return fname


def take_attach(b, private=False):
    """Photos, documents, a location, and (in private / group chats only) a contact card."""
    out = []
    for a in (b.get("attach") or [])[:6]:
        k = a.get("kind")
        if k == "image" and a.get("data"):
            out.append({"kind": "image", "file": store_file(a["data"])})
        elif k == "doc" and a.get("data"):
            out.append({"kind": "doc", "file": store_doc(a["data"], a.get("name")), "name": os.path.basename(str(a.get("name") or "document"))[:80]})
        elif k == "location":
            label = str(a.get("label") or "").strip()[:80]
            try:
                lat, lng = float(a.get("lat")), float(a.get("lng"))
                if not (-90 <= lat <= 90 and -180 <= lng <= 180):
                    raise ValueError
                out.append({"kind": "location", "lat": round(lat, 6), "lng": round(lng, 6), "label": label})
            except (TypeError, ValueError):
                if label:
                    out.append({"kind": "location", "label": label})
        elif k == "contact":
            if not private:
                raise ApiError(400, "Contact cards go in private or group messages, not in the open community.")
            out.append({"kind": "contact", "name": str(a.get("name") or "")[:60], "phone": str(a.get("phone") or "")[:20],
                        "email": str(a.get("email") or "")[:80]})
    return out


def file_path(name):
    if not re.match(r"^[0-9a-f]{20}\.(jpg|png|webp|pdf|doc|docx|xls|xlsx|ppt|pptx|dwg|dxf|txt|csv|zip)$", name or ""):
        return None
    p = os.path.join(FILES_DIR, name)
    return p if os.path.isfile(p) else None


# ---------------------------------------------------------------- members

def kind_of(firm):
    return "vendor" if (firm.get("kind") == "vendor") else "architect"


def ensure_member(cy, firm):
    m = cy["members"].get(firm["code"])
    if not m:
        m = {"code": firm["code"], "name": firm["name"], "kind": kind_of(firm), "profession": firm.get("profession", ""),
             "city": (firm.get("city") or "").strip().title(), "area": "", "about": "", "website": "", "instagram": "",
             "email": "", "phone": "", "trades": [], "cover": "", "logo": "", "joined": now_iso(),
             "verified": firm.get("status") == "active", "hidden": False, "muted_until": ""}
        cy["members"][firm["code"]] = m
    else:
        m["name"] = firm["name"]
        m["verified"] = m.get("verified") or firm.get("status") == "active"
    if not any(p["type"] == "welcome" and p["firm"] == firm["code"] for p in cy["posts"]):
        what = m["profession"] or ("Vendor" if m["kind"] == "vendor" else "Architect")
        cy["posts"].insert(0, {"id": new_id("p"), "type": "welcome", "firm": firm["code"], "user": "", "who": "",
                               "title": f"Welcome {m['name']}", "text": f"{what}{', ' + m['city'] if m['city'] else ''} has joined The Courtyard.",
                               "images": [], "file": "", "city": m["city"], "tags": [], "likes": [], "comments": [],
                               "time": now_iso(), "status": "ok", "pick": ""})
    return m


def on_join(firm):
    cy = load()
    ensure_member(cy, firm)
    save(cy)


def member_public(m, full=False):
    out = {k: m.get(k) for k in ("code", "name", "kind", "profession", "city", "area", "about", "website", "instagram",
                                 "email", "phone", "trades", "cover", "logo", "joined", "verified")}
    out["intro"] = (m.get("about") or "")[:170]
    out["city_tag"] = "#" + re.sub(r"[^A-Za-z0-9]", "", m.get("city") or "") if m.get("city") else ""
    if not full:
        out.pop("about", None)
    return out


def is_muted(m):
    return bool(m.get("muted_until")) and m["muted_until"] > now_iso()


def strike(cy, code):
    n = cy["strikes"].get(code, 0) + 1
    cy["strikes"][code] = n
    if n >= 3:
        cy["members"][code]["muted_until"] = (datetime.now() + timedelta(days=7)).isoformat(timespec="seconds")
        cy["strikes"][code] = 0


# ---------------------------------------------------------------- views

def post_public(cy, p, me):
    m = cy["members"].get(p["firm"], {})
    extra = {}
    if p["type"] == "welcome":
        extra = {"instagram": m.get("instagram", ""), "speciality": ", ".join((m.get("trades") or [])[:3]) or m.get("profession", ""),
                 "joined": m.get("joined", p["time"]), "member_city": m.get("city", ""), "logo": m.get("logo", "")}
    return {**{k: p.get(k) for k in ("id", "type", "title", "text", "images", "file", "city", "time", "status", "pick", "who", "link",
                                     "place", "material", "brand", "finish")},
            **extra, "hashtags": p.get("hashtags", []), "saved": p["id"] in cy["saves"].get(me.split("/")[0], []),
            "saves": sum(1 for v in cy["saves"].values() if p["id"] in v),
            "firm": p["firm"], "firm_name": m.get("name", ""), "firm_kind": m.get("kind", ""), "firm_city": m.get("city", ""),
            "firm_logo": m.get("logo", ""), "verified": m.get("verified", False),
            "tags": [{"code": c, "name": cy["members"].get(c, {}).get("name", "")} for c in p.get("tags", []) if c in cy["members"]],
            "likes": len(p.get("likes", [])), "liked": me in p.get("likes", []),
            "welcomes": len(p.get("likes", [])) if p["type"] == "welcome" else 0,
            "comments": [c for c in p.get("comments", [])[-30:] if c.get("status", "ok") == "ok"],
            "mine": p["firm"] == me.split("/")[0]}


def visible(p, my_code):
    return p.get("status", "ok") == "ok" or p["firm"] == my_code


def city_match(item_city, city):
    return not city or city.lower() in ("all", "all of india") or (item_city or "").lower() == city.lower()


def event_public(cy, e, my_code):
    host = cy["members"].get(e["host"], {})
    out = {k: e.get(k) for k in ("id", "title", "date", "time", "place", "city", "online", "details", "image", "kind", "who", "hidden",
                                 "end", "private", "seats", "ask", "page")}
    today = datetime.now().strftime("%Y-%m-%d")
    out["over"] = (e.get("end") or e["date"]) < today
    out["status"] = "Finished" if out["over"] else ("On now" if e["date"] <= today else "Coming up")
    out["wall_count"] = len(e.get("wall", []))
    out["seats_left"] = max(0, e["seats"] - sum(r.get("count", 1) for r in e.get("rsvps", {}).values() if r["status"] == "coming")) if e.get("seats") else None
    out.update({"host": e["host"], "host_name": host.get("name", ""), "host_kind": host.get("kind", ""),
                "invited": my_code in e.get("invited", []) or bool(e.get("open")), "open": bool(e.get("open")),
                "my_rsvp": e.get("rsvps", {}).get(my_code), "coming": sum(1 for r in e.get("rsvps", {}).values() if r["status"] == "coming"),
                "maybe": sum(1 for r in e.get("rsvps", {}).values() if r["status"] == "maybe"), "mine": e["host"] == my_code})
    if e["host"] == my_code:
        out["rsvps"] = [{"code": c, "name": cy["members"].get(c, {}).get("name", c), **r} for c, r in e.get("rsvps", {}).items()]
        out["invited_count"] = len(e.get("invited", []))
    return out


def event_page(e, host):
    """Event page + reply form, written by the Open House bot (simple and free; the AI can polish it later)."""
    d1 = datetime.strptime(e["date"], "%Y-%m-%d")
    d2 = datetime.strptime(e.get("end") or e["date"], "%Y-%m-%d")
    when = d1.strftime("%A %d %B") + (f" to {d2.strftime('%A %d %B')}" if d2 > d1 else "") + (f", from {e['time']}" if e.get("time") else "")
    where = "Online" if e.get("online") else ", ".join(x for x in (e.get("place"), e.get("city")) if x)
    lines = [f"{host.get('name', '')} invites you to {e['kind'].lower() if e['kind'] != 'Open House' else 'an Open House'}: {e['title']}.",
             f"When: {when}.", f"Where: {where}." if where else "", e.get("details") or "",
             (f"Seats are limited to {e['seats']}." if e.get("seats") else ""),
             "Please confirm below so the host knows who is coming."]
    form = ["Your name", "How many people", "Phone (only the host sees it)"] + [a for a in e.get("ask") or [] if a]
    return {"text": "\n".join(l for l in lines if l), "form": form, "by": "Open House bot"}


def edition_card(x):
    return {k: x.get(k) for k in ("id", "number", "title", "month", "description", "featured", "cover", "demo", "next")} | {"pages_count": len(x.get("pages", []))}


EDITION_01_V = 2      # raise this when Edition 01's pages change; laptops that already have it get the new pages


def edition_01():
    S = "shared:perspective/"
    return {
        "id": "e01", "number": 1, "v": EDITION_01_V, "title": "Perspective", "month": datetime.now().strftime("%B %Y"),
        "published": True, "demo": False,
        "description": "Interiors, objects and the art of living — a world of colour, character and collectable design.",
        "featured": ["Rhythm in black & white", "One bold object", "Colour as architecture", "Quiet luxury above the city"],
        "next": "Edition 02 — next month",
        "cover": S + "p-cover.jpg",
        "pages": [
            {"kind": "cover", "image": S + "p-cover.jpg", "plain": True, "title": "Perspective"},
            {"kind": "letter", "title": "Welcome to Perspective",
             "text": "Perspective is the magazine of Design Lab — about interiors, objects and the art of living.\n\n"
                     "It is made for the people who imagine spaces and the people who build them. "
                     "In every edition: rooms with character, objects worth collecting, materials worth knowing, "
                     "and the conversations of The Courtyard.\n\n"
                     "This first edition looks at four ideas: rhythm, a single bold object, colour used as architecture, "
                     "and the calm of quiet luxury."},
            {"kind": "full", "image": S + "p-mono-arcade.jpg", "kicker": "Space", "title": "Rhythm in black & white",
             "text": "Striped arches, a chequered floor and a row of pendant lights turn a corridor into a sequence. "
                     "One red doorway at the far end gives the eye somewhere to arrive."},
            {"kind": "full", "image": S + "p-red-stair.jpg", "kicker": "Object", "title": "One bold object",
             "text": "In a soft, pale room, a single staircase in red becomes the sculpture. "
                     "Keep everything around it quiet and let one piece do the talking."},
            {"kind": "full", "image": S + "p-colour-arcade.jpg", "kicker": "Colour", "title": "Colour as architecture",
             "text": "Columns that curve, stack and change colour. Here paint is not a finish — it is the structure, "
                     "the wayfinding and the mood."},
            {"kind": "full", "image": S + "p-pattern.jpg", "kicker": "Pattern", "title": "Pattern study",
             "text": "Dots and dashes that read like a code. As a rug, a screen, a jaali or a wall, "
                     "a pattern like this adds texture without adding colour.", "light": True},
            {"kind": "split", "image": S + "p-suite-lounge.jpg", "kicker": "Quiet luxury", "title": "Above the city",
             "text": "Layered neutrals: bouclé, travertine, sheer linen and a warm textured wall. "
                     "A curved sofa follows the window so the view becomes part of the room."},
            {"kind": "split", "image": S + "p-suite-bed.jpg", "kicker": "Quiet luxury", "title": "The bedroom",
             "text": "A soft upholstered bed, a large textured panel instead of a headboard, "
                     "and small brass pendants for light that stays low and warm."},
            {"kind": "split", "image": S + "p-suite-dressing.jpg", "kicker": "Quiet luxury", "title": "The dressing room",
             "text": "Glass-fronted wardrobes with warm lighting, a stone island in the middle, "
                     "and one long window so the room never feels closed."},
            {"kind": "back", "title": "Be in Perspective",
             "text": "Architects and designers: send a project for a future cover story.\n\n"
                     "Makers and vendors: send a product, a material or a collection.\n\n"
                     "Open Perspective → Apply to be featured. Design Lab reads every application and gets in touch."},
        ]}


def seed_editions(cy):
    """Edition 01 of Perspective. Real later editions are added from the owner dashboard."""
    ed = next((x for x in cy["editions"] if x.get("id") == "e01"), None)
    if ed is None:
        cy["editions"].append(dict(edition_01(), pins=[], talk=[]))
    elif ed.get("v", 1) < EDITION_01_V:
        talk = ed.get("talk", [])
        ed.clear()
        ed.update(edition_01(), pins=[], talk=talk)     # new pages; old page pins no longer fit, the discussion is kept


def unread_for(cy, me, my_code):
    prefs = cy["prefs"].get(me, {})
    seen = prefs.get("seen", {})
    notify = prefs.get("notify", {})
    rooms = {}
    for r in cy["rooms"]:
        msgs = [x for x in cy["messages"].get(r["id"], []) if x.get("status", "ok") == "ok" and x["time"] > seen.get("room:" + r["id"], "")
                and x["firm"] != my_code]
        rooms[r["id"]] = len(msgs)
    threads = 0
    requests = 0
    for t in cy["threads"]:
        if my_code not in t["firms"] or notify.get("t:" + t["id"]) is False:
            continue
        last = t["messages"][-1] if t["messages"] else None
        if last and last["firm"] != my_code and last["time"] > seen.get("t:" + t["id"], ""):
            if t["status"] == "request" and t.get("to") == my_code:
                requests += 1
            elif t["status"] == "open":
                threads += 1
    invites = sum(1 for e in cy["events"] if my_code in e.get("invited", []) and my_code not in e.get("rsvps", {})
                  and e["date"] >= datetime.now().strftime("%Y-%m-%d") and not e.get("hidden"))
    loud = 0
    community = 0
    if notify.get("community") is not False:
        community = sum(1 for x in cy.get("community", [])[-200:] if x["firm"] != my_code and x["time"] > seen.get("community", "")
                        and x.get("status", "ok") == "ok")
    return {"rooms": rooms, "notify": notify, "threads": threads, "requests": requests, "invites": invites, "community": community,
            "badge": threads + requests + invites + loud + min(community, 9)}


# ---------------------------------------------------------------- API for members (called through the studio software)

def handle(method, sub, b, q, firm, uid, uname, role):
    cy = load()
    me_m = ensure_member(cy, firm)
    code = firm["code"]
    me = f"{code}/{uid}"
    owner = role == "owner"
    parts = [p for p in sub.split("/") if p]
    head = parts[0] if parts else "home"
    city = (q.get("city") or [""])[0]

    def done(out):
        save(cy)
        return out

    if head == "home" and method == "GET":
        tag = tag_of((q.get("tag") or [""])[0])
        ptype = (q.get("type") or [""])[0]
        posts = [p for p in cy["posts"] if visible(p, code) and city_match(p.get("city") or cy["members"].get(p["firm"], {}).get("city"), city)
                 and (not tag or tag in p.get("hashtags", [])) and (not ptype or p["type"] == ptype)]
        ok_posts = [p for p in cy["posts"] if p.get("status", "ok") == "ok"]
        tag_count = {}
        for p in ok_posts[:400]:
            for t in p.get("hashtags", []):
                tag_count[t] = tag_count.get(t, 0) + 1
        spotlight = [post_public(cy, p, me) for p in cy["posts"] if p.get("pick") and p.get("status", "ok") == "ok"][:2]
        events = sorted([e for e in cy["events"] if not e.get("hidden") and e["date"] >= datetime.now().strftime("%Y-%m-%d")
                         and (city_match(e.get("city"), city) or code in e.get("invited", []))], key=lambda e: e["date"])[:6]
        return done({"me": member_public(me_m, True), "role": role, "user": uname,
                     "members": {"architect": sum(1 for m in cy["members"].values() if m["kind"] == "architect" and not m.get("hidden")),
                                 "vendor": sum(1 for m in cy["members"].values() if m["kind"] == "vendor" and not m.get("hidden"))},
                     "cities": sorted({m["city"] for m in cy["members"].values() if m.get("city") and not m.get("hidden")}),
                     "feed": [post_public(cy, p, me) for p in posts if p["type"] not in ("welcome",)][:60],
                     "welcomes": [post_public(cy, p, me) for p in ok_posts if p["type"] == "welcome"][:10],
                     "postcards": [post_public(cy, p, me) for p in posts if p["type"] == "postcard"][:12],
                     "pins": [post_public(cy, p, me) for p in posts if p["type"] == "pin"][:24],
                     "tags": [t for t, _ in sorted(tag_count.items(), key=lambda kv: -kv[1])[:14]], "tag": tag,
                     "hero": cy["settings"].get("hero", ""), "v": 9,
                     "spotlight": spotlight, "events": [event_public(cy, e, code) for e in events],
                     "issues": [{"id": i["id"], "title": i["title"], "made": i["made"]} for i in cy["issues"][:6]],
                     "pulse": unread_for(cy, me, code), "muted": is_muted(me_m)})

    if head == "pulse":
        return done({"pulse": unread_for(cy, me, code)})

    # ---- posts: gallery, arrival (vendors), moodboard (request), news
    if head == "post" and method == "POST":
        kind = b.get("type")
        if kind not in ("gallery", "arrival", "moodboard", "news", "postcard", "pin"):
            raise ApiError(400, "Choose what you are posting.")
        if kind == "arrival" and me_m["kind"] != "vendor":
            raise ApiError(400, "New arrivals are for vendors. Architects can post to the Gallery or ask with a mood board.")
        if is_muted(me_m):
            raise ApiError(403, "Your studio can't post in open spaces for a few days (house rules). Private messages still work.")
        title = str(b.get("title") or "").strip()[:120]
        text = str(b.get("text") or "").strip()[:2000]
        if kind == "pin" and not title:
            title = (str(b.get("material") or "").strip() or str(b.get("brand") or "").strip())[:120]
            if not title:
                raise ApiError(400, "Add the material or the brand for this pin.")
        if kind == "postcard" and not title:
            title = "This is where I went and I loved it"
        if not title:
            raise ApiError(400, "Please give it a title.")
        ok, status, msg = check_text(title + " " + text)
        if not ok:
            strike(cy, code)
            save(cy)
            raise ApiError(400, msg)
        if kind == "arrival":
            week_ago = (datetime.now() - timedelta(days=7)).isoformat()
            if sum(1 for p in cy["posts"] if p["firm"] == code and p["type"] == "arrival" and p["time"] > week_ago) >= 3:
                raise ApiError(400, "Vendors can share 3 new arrivals a week. Featured spots are available from Design Lab.")
        imgs = [store_file(x) for x in (b.get("images") or [])[:10] if x]
        if kind in ("gallery", "arrival", "postcard", "pin") and not imgs:
            raise ApiError(400, "Please add at least one photo.")
        if kind == "postcard" and not str(b.get("place") or "").strip():
            raise ApiError(400, "Where is this place? Add the name of the place.")
        if kind == "pin" and not (str(b.get("material") or "").strip() or str(b.get("brand") or "").strip()):
            raise ApiError(400, "Add the material or the brand for this pin.")
        f = store_file(b.get("file")) if b.get("file") else ""
        tags = [c for c in (b.get("tags") or []) if c in cy["members"]][:12]
        p = {"id": new_id("p"), "type": kind, "firm": code, "user": uid, "who": uname, "title": title, "text": text,
             "images": imgs, "file": f, "city": str(b.get("city") or me_m.get("city") or "").title(), "tags": tags,
             "likes": [], "comments": [], "time": now_iso(), "status": status, "pick": "", "link": str(b.get("link") or "")[:300],
             "place": str(b.get("place") or "").strip()[:120], "material": str(b.get("material") or "").strip()[:80],
             "brand": str(b.get("brand") or "").strip()[:80], "finish": str(b.get("finish") or "").strip()[:80],
             "hashtags": hashtags(title + " " + text + " " + " ".join("#" + str(t).lstrip("#") for t in (b.get("hashtags") or [])))}
        if kind == "postcard" and p["place"]:
            p["hashtags"] = sorted(set(p["hashtags"]) | {tag_of(p["place"].split(",")[0])})
        if kind == "pin":
            p["hashtags"] = sorted(set(p["hashtags"]) | {t for t in (tag_of(p["material"]), tag_of(p["brand"])) if t})
        cy["posts"].insert(0, p)
        if status == "held":
            cy["flags"].insert(0, {"id": new_id("f"), "what": "post", "ref": p["id"], "by": code, "reason": "Hiring / staff (auto)", "time": now_iso()})
        return done({"post": post_public(cy, p, me), "note": msg})

    if head == "like" and method == "POST":
        p = next((x for x in cy["posts"] if x["id"] == b.get("id")), None)
        if not p:
            raise ApiError(404, "That post is gone.")
        if me in p["likes"]:
            p["likes"].remove(me)
        else:
            p["likes"].append(me)
        return done({"post": post_public(cy, p, me)})

    if head == "comment" and method == "POST":
        p = next((x for x in cy["posts"] if x["id"] == b.get("id")), None)
        text = str(b.get("text") or "").strip()[:600]
        if not p or not text:
            raise ApiError(400, "Write something first.")
        if is_muted(me_m):
            raise ApiError(403, "Your studio can't write in open spaces for a few days (house rules).")
        ok, status, msg = check_text(text)
        if not ok:
            strike(cy, code)
            save(cy)
            raise ApiError(400, msg)
        p["comments"].append({"id": new_id("c"), "firm": code, "firm_name": me_m["name"], "who": uname, "text": text,
                              "time": now_iso(), "status": status})
        return done({"post": post_public(cy, p, me), "note": msg})

    if head == "save" and method == "POST":
        p = next((x for x in cy["posts"] if x["id"] == b.get("id")), None)
        if not p:
            raise ApiError(404, "That pin is gone.")
        lst = cy["saves"].setdefault(code, [])
        lst.remove(p["id"]) if p["id"] in lst else lst.insert(0, p["id"])
        return done({"post": post_public(cy, p, me)})

    if head == "saved":
        ids = cy["saves"].get(code, [])
        byid = {p["id"]: p for p in cy["posts"]}
        return done({"posts": [post_public(cy, byid[i], me) for i in ids if i in byid]})

    if head == "submit" and method == "POST":         # send work to the magazine (Design Lab approves)
        kind = b.get("kind") if b.get("kind") in ("cover-story", "portfolio", "catalog", "video", "event") else "portfolio"
        title = str(b.get("title") or "").strip()[:120]
        if not title:
            raise ApiError(400, "Give it a title.")
        text = str(b.get("text") or "").strip()[:3000]
        ok, _, msg = check_text(title + " " + text, open_space=False)
        if not ok:
            raise ApiError(400, msg)
        imgs = [store_file(x) for x in (b.get("images") or [])[:8] if x]
        f = store_file(b.get("file")) if b.get("file") else ""
        cy["submissions"].insert(0, {"id": new_id("s"), "firm": code, "who": uname, "kind": kind, "title": title, "text": text,
                                     "images": imgs, "file": f, "link": str(b.get("link") or "")[:300], "status": "waiting", "time": now_iso()})
        return done({"ok": True, "note": "Sent to Design Lab. You'll see it in the magazine once it's approved."})

    if head == "submissions":
        return done({"submissions": [s for s in cy["submissions"] if s["firm"] == code][:30]})

    if head == "portfolio" and method == "POST":
        if not owner:
            raise ApiError(403, "Only the studio owner can change the portfolio.")
        pf = me_m.setdefault("portfolio", [])
        act = b.get("act")
        if act == "delete":
            me_m["portfolio"] = [x for x in pf if x["id"] != b.get("id")]
        elif act == "move":
            i = next((n for n, x in enumerate(pf) if x["id"] == b.get("id")), None)
            if i is not None and 0 <= i + int(b.get("by") or 0) < len(pf):
                j = i + int(b.get("by"))
                pf[i], pf[j] = pf[j], pf[i]
        else:
            name = str(b.get("name") or "").strip()[:100]
            if not name:
                raise ApiError(400, "Give the project a name.")
            item = next((x for x in pf if x["id"] == b.get("id")), None)
            if not item:
                item = {"id": new_id("w"), "images": [], "cover": "", "made": now_iso()}
                pf.insert(0, item)
            item.update({"name": name, "place": str(b.get("place") or "").strip()[:80], "year": str(b.get("year") or "").strip()[:10],
                         "kind": str(b.get("kind") or "").strip()[:40], "text": str(b.get("text") or "").strip()[:2000],
                         "video": str(b.get("video") or "").strip()[:300],
                         "public": b.get("public", item.get("public", True)) is not False})
            for x in (b.get("add") or [])[:12]:
                if x:
                    item["images"].append(store_file(x))
            if b.get("remove") in item["images"]:
                item["images"].remove(b["remove"])
            if b.get("cover") in item["images"]:
                item["cover"] = b["cover"]
            if item["cover"] not in item["images"]:
                item["cover"] = item["images"][0] if item["images"] else ""
            ok, _, msg = check_text(item["name"] + " " + item["text"], open_space=False)
            if not ok:
                raise ApiError(400, msg)
        if not me_m.get("slug"):
            base = tag_of(me_m["name"])[:24] or "studio"
            slug = base
            while any(m.get("slug") == slug for m in cy["members"].values()):
                slug = base + "-" + secrets.token_hex(2)
            me_m["slug"] = slug
        return done({"portfolio": me_m["portfolio"], "slug": me_m["slug"]})

    if head == "page":                                  # my portfolio page: link + small dashboard
        if not me_m.get("slug"):
            base = tag_of(me_m["name"])[:24] or "studio"
            me_m["slug"] = base if not any(m.get("slug") == base for m in cy["members"].values()) else base + "-" + secrets.token_hex(2)
        return done({"slug": me_m["slug"], "views": me_m.get("views", 0), "portfolio": me_m.get("portfolio", []),
                     "layout": me_m.get("layout", "grid"), "touches": sum(1 for t in cy["threads"] if t["to"] == code)})

    if head == "layout" and method == "POST":
        if not owner:
            raise ApiError(403, "Only the studio owner can change the page.")
        me_m["layout"] = b.get("layout") if b.get("layout") in ("grid", "large", "story") else "grid"
        return done({"ok": True})

    if head == "order-share" and method == "POST":     # vendor's software shares an order's progress with the architect
        to = str(b.get("to") or "")
        if to not in cy["members"] or to == code:
            raise ApiError(400, "That architect isn't in The Courtyard.")
        lst = cy["orders"].setdefault(to, [])
        key = code + ":" + str(b.get("ref") or "")[:40]
        o = next((x for x in lst if x["key"] == key), None)
        if not o:
            o = {"key": key, "vendor": code}
            lst.insert(0, o)
        o.update({"ref": str(b.get("ref") or "")[:40], "item": str(b.get("item") or "")[:200], "project": str(b.get("project") or "")[:120],
                  "status": str(b.get("status") or "")[:40], "eta": str(b.get("eta") or "")[:20], "history": (b.get("history") or [])[:20],
                  "dispatch": b.get("dispatch") or {}, "time": now_iso()})
        del lst[200:]
        return done({"ok": True})

    if head == "orders":
        proj = (q.get("project") or [""])[0].strip().lower()
        out = []
        for o in cy["orders"].get(code, []):
            if proj and proj not in (o.get("project") or "").lower() and (o.get("project") or "").lower() not in proj:
                continue
            out.append(dict(o, vendor_name=cy["members"].get(o["vendor"], {}).get("name", "")))
        return done({"orders": out[:60]})

    if head == "architects":                            # for a vendor: architects in The Courtyard (to link an order)
        return done({"people": sorted([{"code": m["code"], "name": m["name"], "city": m.get("city", "")} for m in cy["members"].values()
                                       if m["kind"] == "architect" and not m.get("hidden")], key=lambda x: x["name"].lower())})

    if head == "delete-post" and method == "POST":
        p = next((x for x in cy["posts"] if x["id"] == b.get("id") and x["firm"] == code), None)
        if p and p["type"] != "welcome":
            cy["posts"].remove(p)
        return done({"ok": True})

    if head == "report" and method == "POST":
        cy["flags"].insert(0, {"id": new_id("f"), "what": str(b.get("what") or "post")[:20], "ref": str(b.get("id") or "")[:40],
                               "room": str(b.get("room") or "")[:40], "by": code, "reason": str(b.get("reason") or "Reported")[:200], "time": now_iso()})
        return done({"ok": True})

    # ---- people
    if head == "people":
        kind = (q.get("kind") or [""])[0]
        text = (q.get("q") or [""])[0].lower()
        out = []
        for m in cy["members"].values():
            if m.get("hidden") or (kind and m["kind"] != kind) or not city_match(m.get("city"), city):
                continue
            hay = " ".join([m["name"], m.get("profession", ""), m.get("city", ""), m.get("area", ""), " ".join(m.get("trades", []))]).lower()
            if text and not all(w in hay for w in text.split()):
                continue
            out.append(member_public(m))
        out.sort(key=lambda m: (not m["verified"], m["name"].lower()))
        return done({"people": out})

    if head == "member" and len(parts) > 1:
        m = cy["members"].get(parts[1])
        if not m or (m.get("hidden") and parts[1] != code):
            raise ApiError(404, "Not found.")
        posts = [post_public(cy, p, me) for p in cy["posts"] if p["firm"] == m["code"] and visible(p, code) and p["type"] != "welcome"][:30]
        tagged = [post_public(cy, p, me) for p in cy["posts"] if m["code"] in p.get("tags", []) and p.get("status", "ok") == "ok"][:12]
        events = [event_public(cy, e, code) for e in cy["events"] if e["host"] == m["code"] and not e.get("hidden")][:10]
        return done({"member": member_public(m, True), "posts": posts, "tagged": tagged, "events": events, "me": m["code"] == code})

    if head == "profile" and method == "POST":
        if not owner:
            raise ApiError(403, "Only the owner can change the studio's Courtyard profile.")
        for k, n in (("about", 1500), ("area", 80), ("website", 200), ("instagram", 120), ("email", 120), ("phone", 30), ("city", 60)):
            if k in b:
                v = str(b.get(k) or "").strip()[:n]
                me_m[k] = v.title() if k == "city" else v
        if "trades" in b:
            me_m["trades"] = [str(t).strip()[:40] for t in (b.get("trades") or []) if str(t).strip()][:12]
        for k in ("cover", "logo"):
            if b.get(k):
                me_m[k] = store_file(b[k], 4 * 1024 * 1024)
            if b.get(k + "_clear"):
                me_m[k] = ""
        ok, _, msg = check_text(me_m.get("about", ""), open_space=False)
        if not ok:
            raise ApiError(400, msg)
        return done({"member": member_public(me_m, True)})

    # ---- rooms (open chat)
    if head == "rooms" and method == "GET":
        pul = unread_for(cy, me, code)
        today = datetime.now().strftime("%Y-%m-%d")
        live = [r for r in cy["rooms"] if not r.get("until") or r["until"] >= today]
        return done({"rooms": [dict(r, unread=pul["rooms"].get(r["id"], 0), notify=bool(pul["notify"].get(r["id"])), mine=r.get("by") == code,
                                    by_name=cy["members"].get(r.get("by"), {}).get("name", "") if r.get("by") else "Design Lab",
                                    posts=sum(1 for p in cy["posts"] if r["tag"] in p.get("hashtags", []))) for r in live],
                     "muted": is_muted(me_m)})

    if head == "room-new" and method == "POST":
        name = str(b.get("name") or "").strip().lstrip("#")[:40]
        if not tag_of(name):
            raise ApiError(400, "Give the room a hashtag name, e.g. #marble or #whatsnewinarchitecture.")
        ok, _, msg = check_text(name + " " + str(b.get("about") or ""))
        if not ok:
            raise ApiError(400, msg)
        if is_muted(me_m):
            raise ApiError(403, "Your studio can't open rooms for a few days (house rules).")
        t = tag_of(name)
        if any(r["tag"] == t for r in cy["rooms"]):
            raise ApiError(409, f"#{t} is already open — find it in Rooms.")
        if sum(1 for r in cy["rooms"] if r.get("by") == code) >= 10:
            raise ApiError(400, "A studio can open up to 10 rooms. Close one you don't use first.")
        until = str(b.get("until") or "")[:10]
        if until and not re.match(r"^\d{4}-\d{2}-\d{2}$", until):
            until = ""
        r = {"id": t, "name": name, "tag": t, "about": str(b.get("about") or "").strip()[:140], "city": "", "by": code,
             "until": until, "kind": b.get("kind") if b.get("kind") in ("topic", "product", "place") else "topic", "made": now_iso()}
        cy["rooms"].append(r)
        return done({"room": r})

    if head == "room-delete" and method == "POST":
        r = next((x for x in cy["rooms"] if x["id"] == b.get("id")), None)
        if not r or r.get("by") != code:
            raise ApiError(403, "Only the studio that opened this room (or Design Lab) can close it.")
        cy["rooms"].remove(r)
        return done({"ok": True})

    if head == "room" and len(parts) > 1:
        room = next((r for r in cy["rooms"] if r["id"] == parts[1]), None)
        if not room:
            raise ApiError(404, "That room is closed.")
        msgs = cy["messages"].setdefault(room["id"], [])
        if method == "POST":
            text = str(b.get("text") or "").strip()[:1000]
            if not text:
                raise ApiError(400, "Write something first.")
            if is_muted(me_m):
                raise ApiError(403, "Your studio can't write in open rooms for a few days (house rules). Private messages still work.")
            ok, status, msg = check_text(text)
            if not ok:
                strike(cy, code)
                save(cy)
                raise ApiError(400, msg)
            x = {"id": new_id("m"), "firm": code, "firm_name": me_m["name"], "kind": me_m["kind"], "who": uname, "text": text,
                 "time": now_iso(), "status": status}
            msgs.append(x)
            del msgs[:-800]
            if status == "held":
                cy["flags"].insert(0, {"id": new_id("f"), "what": "message", "ref": x["id"], "room": room["id"], "by": code,
                                       "reason": "Hiring / staff (auto)", "time": now_iso()})
            note = msg
        else:
            note = ""
        cy["prefs"].setdefault(me, {}).setdefault("seen", {})["room:" + room["id"]] = now_iso()
        show = [m for m in msgs if m.get("status", "ok") == "ok" or m["firm"] == code][-150:]
        return done({"room": room, "messages": show, "note": note, "me": code, "mine": room.get("by") == code,
                     "posts": [post_public(cy, p, me) for p in cy["posts"] if room.get("tag") in p.get("hashtags", []) and visible(p, code)][:30],
                     "notify": bool(cy["prefs"].get(me, {}).get("notify", {}).get(room["id"]))})

    if head == "notify" and method == "POST":
        cy["prefs"].setdefault(me, {}).setdefault("notify", {})[str(b.get("room"))] = bool(b.get("on"))
        return done({"ok": True})

    # ---- private messages (studio to studio)
    if head == "threads" and method == "GET":
        out = []
        seen = cy["prefs"].get(me, {}).get("seen", {})
        for t in cy["threads"]:
            if code not in t["firms"] or (t["status"] == "ignored" and t["to"] == code):
                continue
            last = t["messages"][-1] if t["messages"] else {}
            if t.get("kind") == "group":
                out.append({"id": t["id"], "group": True, "with": "", "with_name": t["name"], "with_kind": "group", "status": "open",
                            "incoming": False, "last": (last.get("who", "") + ": " if last and not last.get("system") else "") + (last.get("text") or ("📎 attachment" if last.get("attach") else ""))[:120],
                            "time": last.get("time", t["time"]), "members": len(t["firms"]),
                            "muted": cy["prefs"].get(me, {}).get("notify", {}).get("t:" + t["id"]) is False,
                            "unread": bool(last) and last.get("firm") != code and last["time"] > seen.get("t:" + t["id"], "")})
                continue
            other = t["firms"][0] if t["firms"][1] == code else t["firms"][1]
            om = cy["members"].get(other, {})
            out.append({"id": t["id"], "with": other, "with_name": om.get("name", other), "with_kind": om.get("kind", ""),
                        "status": t["status"], "incoming": t["to"] == code, "last": last.get("text", "")[:120], "subject": t.get("subject", ""),
                        "time": last.get("time", t["time"]), "unread": bool(last) and last.get("firm") != code and last["time"] > seen.get("t:" + t["id"], "")})
        out.sort(key=lambda x: x["time"], reverse=True)
        return done({"threads": out})

    if head == "message" and method == "POST":     # start a conversation
        to = str(b.get("to") or "")
        text = str(b.get("text") or "").strip()[:2000]
        if to == code or to not in cy["members"]:
            raise ApiError(400, "Choose who to message.")
        if not text:
            raise ApiError(400, "Write a message.")
        ok, _, msg = check_text(text, open_space=False)
        if not ok:
            raise ApiError(400, msg)
        t = next((x for x in cy["threads"] if set(x["firms"]) == {code, to}), None)
        if not t:
            t = {"id": new_id("t"), "firms": [code, to], "from": code, "to": to, "status": "request", "time": now_iso(), "messages": []}
            cy["threads"].insert(0, t)
        elif t["status"] == "ignored" and t["to"] == code:
            t["status"] = "open"
        if t["status"] == "request" and t["from"] == code and len(t["messages"]) >= 2:
            raise ApiError(400, "Wait for them to reply before sending more.")
        subject = str(b.get("subject") or "").strip()[:100]
        if subject:
            t["subject"] = subject
        t["messages"].append({"firm": code, "who": uname, "text": text, "time": now_iso(), "subject": subject,
                              "from_label": f"{me_m['name']} ({'vendor' if me_m['kind'] == 'vendor' else 'architect / designer'}{', ' + me_m['city'] if me_m.get('city') else ''})"})
        return done({"thread": t["id"]})

    if head == "thread" and len(parts) > 1 and (next((x for x in cy["threads"] if x["id"] == parts[1]), {}) or {}).get("kind") == "group":
        t = next((x for x in cy["threads"] if x["id"] == parts[1] and code in x["firms"]), None)
        if not t:
            raise ApiError(404, "You are not in this group.")
        if method == "POST":
            text = str(b.get("text") or "").strip()[:2000]
            ok, _, msg = check_text(text, open_space=False) if text else (True, "ok", "")
            if not ok:
                raise ApiError(400, msg)
            att = take_attach(b, private=True)
            if not text and not att:
                raise ApiError(400, "Write a message.")
            t["messages"].append({"firm": code, "who": uname, "text": text, "attach": att, "time": now_iso(), "reply": str(b.get("reply") or "")[:200]})
            del t["messages"][:-1000]
        cy["prefs"].setdefault(me, {}).setdefault("seen", {})["t:" + t["id"]] = now_iso()
        return done({"thread": {"id": t["id"], "group": True, "name": t["name"], "admin": t["admin"] == code, "status": "open",
                                "members": [{"code": c, "name": cy["members"].get(c, {}).get("name", c)} for c in t["firms"]],
                                "muted": cy["prefs"].get(me, {}).get("notify", {}).get("t:" + t["id"]) is False,
                                "messages": [dict(m, mine=m["firm"] == code, firm_name=cy["members"].get(m["firm"], {}).get("name", ""))
                                             for m in t["messages"][-300:]]}})

    if head == "thread" and len(parts) > 1:
        t = next((x for x in cy["threads"] if x["id"] == parts[1] and code in x["firms"]), None)
        if not t:
            raise ApiError(404, "Conversation not found.")
        action = parts[2] if len(parts) > 2 else ""
        if method == "POST" and action == "ignore" and t["to"] == code:
            t["status"] = "ignored"
        elif method == "POST":
            text = str(b.get("text") or "").strip()[:2000]
            if not text and not b.get("attach"):
                raise ApiError(400, "Write a message.")
            ok, _, msg = check_text(text, open_space=False)
            if not ok:
                raise ApiError(400, msg)
            if t["status"] == "request" and t["from"] == code and len(t["messages"]) >= 2:
                raise ApiError(400, "Wait for them to reply before sending more.")
            if t["to"] == code and t["status"] in ("request", "ignored"):
                t["status"] = "open"            # replying = accepting
            t["messages"].append({"firm": code, "who": uname, "text": text, "time": now_iso(), "attach": take_attach(b, private=True),
                                  "reply": str(b.get("reply") or "")[:200]})
        cy["prefs"].setdefault(me, {}).setdefault("seen", {})["t:" + t["id"]] = now_iso()
        other = t["firms"][0] if t["firms"][1] == code else t["firms"][1]
        om = cy["members"].get(other, {})
        return done({"thread": {"id": t["id"], "status": t["status"], "incoming": t["to"] == code, "with": other, "subject": t.get("subject", ""),
                                "with_name": om.get("name", other), "with_kind": om.get("kind", ""),
                                "muted": cy["prefs"].get(me, {}).get("notify", {}).get("t:" + t["id"]) is False,
                                "messages": [dict(m, mine=m["firm"] == code) for m in t["messages"][-300:]]}})

    # ---- Open House (events)
    if head == "events" and method == "GET":
        mine = (q.get("mine") or [""])[0]
        today = datetime.now().strftime("%Y-%m-%d")
        back = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%d")
        evs = [e for e in cy["events"] if not e.get("hidden") and (e.get("end") or e["date"]) >= back
               and (not e.get("private") or code in e.get("invited", []) or e["host"] == code)]
        if mine:
            evs = [e for e in evs if e["host"] == code]
        else:
            evs = [e for e in evs if city_match(e.get("city"), city) or code in e.get("invited", []) or e["host"] == code]
        evs.sort(key=lambda e: e["date"])
        return done({"events": [event_public(cy, e, code) for e in evs]})

    if head == "event" and method == "POST" and len(parts) == 1:
        title = str(b.get("title") or "").strip()[:120]
        date = str(b.get("date") or "")[:10]
        if not title or not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
            raise ApiError(400, "Give the Open House a title and a date.")
        if date < datetime.now().strftime("%Y-%m-%d"):
            raise ApiError(400, "Choose a date from today onwards.")
        end = str(b.get("end") or date)[:10]
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", end) or end < date:
            end = date
        details = str(b.get("details") or "").strip()[:2000]
        ok, _, msg = check_text(title + " " + details, open_space=False)
        if not ok:
            raise ApiError(400, msg)
        inv = b.get("invite") or {}
        cities = [c.lower() for c in inv.get("cities") or [] if c]
        kinds = [k for k in inv.get("kinds") or [] if k in ("architect", "vendor")]
        picked = [c for c in inv.get("codes") or [] if c in cy["members"]]
        invited = set(picked)
        everyone = bool(inv.get("everyone"))
        for m in cy["members"].values():
            if m["code"] == code or m.get("hidden"):
                continue
            if everyone or ((not cities or (m.get("city") or "").lower() in cities) and (not kinds or m["kind"] in kinds) and (cities or kinds)):
                invited.add(m["code"])
        e = {"id": new_id("e"), "host": code, "who": uname, "title": title, "date": date, "time": str(b.get("time") or "")[:5],
             "place": str(b.get("place") or "").strip()[:200], "city": str(b.get("city") or me_m.get("city") or "").title(),
             "online": bool(b.get("online")), "details": details, "image": store_file(b["image"]) if b.get("image") else "",
             "kind": str(b.get("kind") or "Open House")[:40], "invited": sorted(invited), "open": bool(b.get("open", True)),
             "rsvps": {}, "time_made": now_iso(), "hidden": False, "end": end, "private": bool(b.get("private")),
             "seats": max(0, min(500, int(b.get("seats") or 0))), "ask": [str(x)[:60] for x in (b.get("ask") or [])][:4]}
        if e["private"]:
            e["open"] = False
            if not invited:
                raise ApiError(400, "A private event needs people to invite — choose a city, architects or vendors.")
        e["page"] = event_page(e, me_m)      # the bot writes the event page and the reply form
        cy["events"].append(e)
        return done({"event": event_public(cy, e, code)})

    if head == "event" and len(parts) > 2 and parts[2] == "rsvp" and method == "POST":
        e = next((x for x in cy["events"] if x["id"] == parts[1]), None)
        if not e or e.get("hidden"):
            raise ApiError(404, "That event is gone.")
        status = b.get("status")
        if status not in ("coming", "maybe", "no"):
            raise ApiError(400, "Choose Coming, Maybe or Can't come.")
        if e.get("private") and code not in e.get("invited", []):
            raise ApiError(403, "This is a private event.")
        if (e.get("end") or e["date"]) < datetime.now().strftime("%Y-%m-%d"):
            raise ApiError(400, "This event is over.")
        try:
            count = max(1, min(20, int(b.get("count") or 1)))
        except (TypeError, ValueError):
            count = 1
        if status == "coming" and e.get("seats"):
            taken = sum(r.get("count", 1) for c, r in e["rsvps"].items() if r["status"] == "coming" and c != code)
            if taken + count > e["seats"]:
                raise ApiError(400, f"Sorry — only {max(0, e['seats'] - taken)} seat(s) left.")
        e["rsvps"][code] = {"status": status, "who": str(b.get("who") or uname)[:80], "contact": str(b.get("contact") or "").strip()[:60],
                            "count": count, "answers": {str(k)[:60]: str(v)[:200] for k, v in (b.get("answers") or {}).items()}, "time": now_iso()}
        return done({"event": event_public(cy, e, code)})

    if head == "event" and len(parts) > 2 and parts[2] == "cancel" and method == "POST":
        e = next((x for x in cy["events"] if x["id"] == parts[1] and x["host"] == code), None)
        if e:
            e["hidden"] = True
        return done({"ok": True})

    # ---- THE COMMUNITY SCREEN: one big shared conversation + everything members share
    if head == "community":
        if method == "POST":
            text = str(b.get("text") or "").strip()[:1500]
            if is_muted(me_m):
                raise ApiError(403, "Your studio can't write in the community for a few days (house rules). Private messages still work.")
            ok, status, msg = check_text(text) if text else (True, "ok", "")
            if not ok:
                strike(cy, code)
                save(cy)
                raise ApiError(400, msg)
            att = take_attach(b, private=False)
            if not text and not att:
                raise ApiError(400, "Write something or add a photo.")
            x = {"id": new_id("c"), "firm": code, "who": uname, "text": text, "attach": att, "time": now_iso(), "status": status,
                 "reply": str(b.get("reply") or "")[:20]}
            cy["community"].append(x)
            del cy["community"][:-2000]
            if status == "held":
                cy["flags"].insert(0, {"id": new_id("f"), "what": "community", "ref": x["id"], "by": code, "reason": "Hiring / staff (auto)", "time": now_iso()})
        since = (q.get("since") or [""])[0]
        cy["prefs"].setdefault(me, {}).setdefault("seen", {})["community"] = now_iso()
        items = []
        for x in cy["community"][-300:]:
            if x.get("status", "ok") == "ok" or x["firm"] == code:
                m = cy["members"].get(x["firm"], {})
                items.append(dict(x, kind="msg", firm_name=m.get("name", ""), firm_kind=m.get("kind", ""), logo=m.get("logo", ""),
                                  mine=x["firm"] == code))
        for p in cy["posts"][:200]:
            if p["type"] in ("welcome", "postcard", "pin", "gallery", "arrival", "moodboard", "news") and visible(p, code):
                items.append(dict(post_public(cy, p, me), kind="post"))
        items.sort(key=lambda x: x["time"])
        if since:
            items = [x for x in items if x["time"] > since]
        return done({"items": items[-250:], "me": code, "muted": bool(cy["prefs"].get(me, {}).get("notify", {}).get("community") is False),
                     "members": sum(1 for m in cy["members"].values() if not m.get("hidden")), "now": now_iso()})

    if head == "community-mute" and method == "POST":
        cy["prefs"].setdefault(me, {}).setdefault("notify", {})["community"] = not bool(b.get("mute"))
        return done({"ok": True})

    if head == "community-delete" and method == "POST":
        x = next((y for y in cy["community"] if y["id"] == b.get("id") and y["firm"] == code), None)
        if x:
            cy["community"].remove(x)
        return done({"ok": True})

    # ---- GROUP CHATS (private conversations stay in threads too)
    if head == "group-new" and method == "POST":
        name = str(b.get("name") or "").strip()[:60]
        members = [c for c in (b.get("members") or []) if c in cy["members"] and c != code][:100]
        if not name or not members:
            raise ApiError(400, "Give the group a name and choose at least one member.")
        t = {"id": new_id("g"), "kind": "group", "name": name, "firms": [code] + members, "from": code, "to": "", "admin": code,
             "status": "open", "time": now_iso(), "messages": [{"firm": code, "who": uname, "text": f"{me_m['name']} made the group “{name}”.",
                                                                 "time": now_iso(), "system": True}]}
        cy["threads"].insert(0, t)
        return done({"thread": t["id"]})

    if head == "group" and len(parts) > 2 and method == "POST":
        t = next((x for x in cy["threads"] if x["id"] == parts[1] and x.get("kind") == "group" and code in x["firms"]), None)
        if not t:
            raise ApiError(404, "Group not found.")
        act = parts[2]
        if act == "add" and t["admin"] == code:
            add = [c for c in (b.get("members") or []) if c in cy["members"] and c not in t["firms"]]
            t["firms"] += add
            if add:
                t["messages"].append({"firm": code, "who": uname, "time": now_iso(), "system": True,
                                      "text": "Added " + ", ".join(cy["members"][c]["name"] for c in add)})
        elif act == "leave":
            t["firms"] = [c for c in t["firms"] if c != code]
            t["messages"].append({"firm": code, "who": uname, "time": now_iso(), "system": True, "text": f"{me_m['name']} left"})
            if t["admin"] == code and t["firms"]:
                t["admin"] = t["firms"][0]
        elif act == "rename" and t["admin"] == code:
            t["name"] = str(b.get("name") or t["name"]).strip()[:60]
        return done({"ok": True})

    if head == "chat-mute" and method == "POST":
        cy["prefs"].setdefault(me, {}).setdefault("notify", {})["t:" + str(b.get("id"))] = not bool(b.get("mute"))
        return done({"ok": True})

    # ---- OPEN HOUSE: one event page with a wall for photos and talk
    if head == "event" and len(parts) > 1 and method == "GET":
        e = next((x for x in cy["events"] if x["id"] == parts[1] and not x.get("hidden")), None)
        if not e or (e.get("private") and code not in e.get("invited", []) and e["host"] != code):
            raise ApiError(404, "That event isn't open to you.")
        out = event_public(cy, e, code)
        out["wall"] = [dict(w, firm_name=cy["members"].get(w["firm"], {}).get("name", ""), mine=w["firm"] == code) for w in e.get("wall", [])[-200:]]
        out["invited_names"] = [cy["members"][c]["name"] for c in e.get("invited", []) if c in cy["members"]][:60] if e["host"] == code else []
        return done({"event": out})

    if head == "event" and len(parts) > 2 and parts[2] == "wall" and method == "POST":
        e = next((x for x in cy["events"] if x["id"] == parts[1] and not x.get("hidden")), None)
        if not e or (e.get("private") and code not in e.get("invited", []) and e["host"] != code):
            raise ApiError(404, "That event isn't open to you.")
        text = str(b.get("text") or "").strip()[:1000]
        ok, status, msg = check_text(text, open_space=not e.get("private")) if text else (True, "ok", "")
        if not ok:
            raise ApiError(400, msg)
        att = take_attach(b, private=bool(e.get("private")))
        if not text and not att:
            raise ApiError(400, "Write something or add a photo.")
        e.setdefault("wall", []).append({"id": new_id("w"), "firm": code, "who": uname, "text": text, "attach": att, "time": now_iso()})
        del e["wall"][:-500]
        return done({"ok": True})

    # ---- PERSPECTIVE (the magazine): editions shelf, digital book, page pins, discussion
    if head == "editions":
        seed_editions(cy)
        return done({"editions": [edition_card(x) for x in cy["editions"] if x.get("published")]})

    if head == "edition" and len(parts) > 1:
        seed_editions(cy)
        x = next((y for y in cy["editions"] if y["id"] == parts[1] and y.get("published")), None)
        if not x:
            raise ApiError(404, "That edition isn't here.")
        act = parts[2] if len(parts) > 2 else ""
        if method == "POST" and act in ("pin", "talk"):
            text = str(b.get("text") or "").strip()[:600]
            if not text:
                raise ApiError(400, "Write your comment first.")
            ok, status, msg = check_text(text)
            if not ok:
                raise ApiError(400, msg)
            row = {"id": new_id("k"), "firm": code, "who": uname, "text": text, "time": now_iso()}
            if act == "pin":
                try:
                    row.update({"page": max(0, min(len(x["pages"]) - 1, int(b.get("page")))),
                                "x": max(0.0, min(1.0, float(b.get("x")))), "y": max(0.0, min(1.0, float(b.get("y"))))})
                except (TypeError, ValueError):
                    raise ApiError(400, "Tap the page where your comment belongs.")
                x.setdefault("pins", []).append(row)
            else:
                x.setdefault("talk", []).append(row)
                del x["talk"][:-500]
        named = lambda r: dict(r, firm_name=cy["members"].get(r["firm"], {}).get("name", ""), mine=r["firm"] == code)
        return done({"edition": dict(edition_card(x), pages=x["pages"], pins=[named(r) for r in x.get("pins", [])],
                                     talk=[named(r) for r in x.get("talk", [])[-200:]])})

    raise ApiError(404, "Unknown Courtyard request.")


# ---------------------------------------------------------------- Design Lab owner controls

def admin(method, sub, b):
    cy = load()
    parts = [p for p in sub.split("/") if p]
    head = parts[0] if parts else "state"

    def done(out):
        save(cy)
        return out

    if head == "state":
        held_posts = {p["id"]: p for p in cy["posts"] if p.get("status") == "held"}
        flags = []
        for f in cy["flags"][:100]:
            item = None
            if f["what"] == "post":
                p = next((x for x in cy["posts"] if x["id"] == f["ref"]), None)
                item = p and {"title": p["title"], "text": p["text"][:300], "status": p.get("status")}
            elif f["what"] == "message":
                m = next((x for x in cy["messages"].get(f.get("room", ""), []) if x["id"] == f["ref"]), None)
                item = m and {"title": "Message in " + f.get("room", ""), "text": m["text"][:300], "status": m.get("status")}
            flags.append(dict(f, item=item, by_name=cy["members"].get(f["by"], {}).get("name", f["by"])))
        return {"members": sorted(cy["members"].values(), key=lambda m: m["joined"], reverse=True),
                "posts": [dict(p, firm_name=cy["members"].get(p["firm"], {}).get("name", ""), likes=len(p["likes"]),
                               comments=len(p["comments"])) for p in cy["posts"][:150] if p["type"] != "welcome"],
                "events": [dict(e, host_name=cy["members"].get(e["host"], {}).get("name", ""), coming=sum(1 for r in e["rsvps"].values() if r["status"] == "coming"),
                                invited=len(e["invited"])) for e in sorted(cy["events"], key=lambda e: e["date"], reverse=True)[:100]],
                "rooms": [dict(r, by_name=cy["members"].get(r.get("by"), {}).get("name", "") if r.get("by") else "Design Lab") for r in cy["rooms"]],
                "ads": cy["ads"], "issues": cy["issues"], "flags": flags, "held": len(held_posts),
                "submissions": [dict(x, firm_name=cy["members"].get(x["firm"], {}).get("name", "")) for x in cy["submissions"][:80]],
                "hero": cy["settings"].get("hero", "")}

    if head == "hero" and method == "POST":           # the big courtyard picture at the top of The Courtyard
        cy["settings"]["hero"] = "" if b.get("clear") else store_file(b.get("image"), 6 * 1024 * 1024)
        return done({"hero": cy["settings"]["hero"]})

    if head == "submission" and method == "POST":
        x = next((y for y in cy["submissions"] if y["id"] == b.get("id")), None)
        if not x:
            raise ApiError(404, "Not found.")
        x["status"] = "approved" if b.get("act") == "approve" else "declined" if b.get("act") == "decline" else x["status"]
        x["decided"] = now_iso()
        return done({"ok": True})

    if head == "member" and method == "POST":
        m = cy["members"].get(b.get("code"))
        if not m:
            raise ApiError(404, "Member not found.")
        act = b.get("act")
        if act == "verify":
            m["verified"] = not m.get("verified")
        elif act == "hide":
            m["hidden"] = not m.get("hidden")
        elif act == "mute":
            m["muted_until"] = "" if is_muted(m) else (datetime.now() + timedelta(days=7)).isoformat(timespec="seconds")
        elif act == "edit":
            for k in ("website", "instagram", "email", "city", "about"):
                if k in b:
                    m[k] = str(b[k]).strip()[:500]
        return done({"member": m})

    if head == "flag" and method == "POST":
        f = next((x for x in cy["flags"] if x["id"] == b.get("id")), None)
        if not f:
            raise ApiError(404, "Already handled.")
        allow = b.get("act") == "allow"
        if f["what"] == "post":
            p = next((x for x in cy["posts"] if x["id"] == f["ref"]), None)
            if p:
                if allow:
                    p["status"] = "ok"
                else:
                    cy["posts"].remove(p)
        elif f["what"] == "message":
            msgs = cy["messages"].get(f.get("room", ""), [])
            m = next((x for x in msgs if x["id"] == f["ref"]), None)
            if m:
                if allow:
                    m["status"] = "ok"
                else:
                    msgs.remove(m)
        cy["flags"].remove(f)
        return done({"ok": True})

    if head == "post" and method == "POST":
        p = next((x for x in cy["posts"] if x["id"] == b.get("id")), None)
        if not p:
            raise ApiError(404, "Post not found.")
        act = b.get("act")
        if act == "delete":
            cy["posts"].remove(p)
        elif act in ("week", "month", ""):
            if act:
                for x in cy["posts"]:
                    if x.get("pick") == act:
                        x["pick"] = ""
            p["pick"] = act
        return done({"ok": True})

    if head == "news" and method == "POST":       # a post from Design Lab itself
        title = str(b.get("title") or "").strip()[:120]
        if not title:
            raise ApiError(400, "Give it a title.")
        cy["members"].setdefault("DL", {"code": "DL", "name": "Design Lab", "kind": "designlab", "profession": "The Courtyard team",
                                        "city": "", "area": "", "about": "", "website": "", "instagram": "", "email": "", "phone": "",
                                        "trades": [], "cover": "", "logo": "", "joined": now_iso(), "verified": True, "hidden": True})
        cy["posts"].insert(0, {"id": new_id("p"), "type": "news", "firm": "DL", "user": "", "who": "Design Lab", "title": title,
                               "text": str(b.get("text") or "")[:2000], "images": [store_file(b["image"])] if b.get("image") else [],
                               "file": "", "city": str(b.get("city") or "").title(), "tags": [], "likes": [], "comments": [],
                               "time": now_iso(), "status": "ok", "pick": "", "link": str(b.get("link") or "")[:300]})
        return done({"ok": True})

    if head == "event" and method == "POST":
        e = next((x for x in cy["events"] if x["id"] == b.get("id")), None)
        if e:
            e["hidden"] = not e.get("hidden")
        return done({"ok": True})

    if head == "room" and method == "POST":
        if b.get("act") == "delete":
            cy["rooms"] = [r for r in cy["rooms"] if r["id"] != b.get("id")]
        else:
            name = str(b.get("name") or "").strip()[:40]
            if not name:
                raise ApiError(400, "Give the room a name.")
            rid = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:30] or new_id("r")
            if any(r["id"] == rid for r in cy["rooms"]):
                rid += "-" + secrets.token_hex(2)
            cy["rooms"].append({"id": rid, "name": name, "about": str(b.get("about") or "")[:120], "city": str(b.get("city") or "").title()})
        return done({"rooms": cy["rooms"]})

    if head == "ad" and method == "POST":
        if b.get("act") == "delete":
            cy["ads"] = [a for a in cy["ads"] if a["id"] != b.get("id")]
        else:
            if not str(b.get("advertiser") or "").strip():
                raise ApiError(400, "Who is the advertiser?")
            cy["ads"].insert(0, {"id": new_id("a"), "advertiser": str(b["advertiser"]).strip()[:80], "title": str(b.get("title") or "")[:100],
                                 "text": str(b.get("text") or "")[:300], "link": str(b.get("link") or "")[:300],
                                 "size": b.get("size") if b.get("size") in ("quarter", "half", "full") else "quarter",
                                 "price": float(b.get("price") or 0), "paid": bool(b.get("paid")), "active": True,
                                 "image": store_file(b["image"]) if b.get("image") else "", "time": now_iso()})
        return done({"ads": cy["ads"]})

    if head == "magazine" and method == "POST":
        return done({"issue": make_issue(cy, b.get("month") or datetime.now().strftime("%Y-%m"))})

    raise ApiError(404, "Unknown request.")


# ---------------------------------------------------------------- the monthly magazine (made by the bot, free)

def make_issue(cy, month):
    label = datetime.strptime(month + "-01", "%Y-%m-%d").strftime("%B %Y")
    ok = [p for p in cy["posts"] if p.get("status", "ok") == "ok"]
    in_month = [p for p in ok if p["time"].startswith(month)] or ok
    gallery = sorted([p for p in in_month if p["type"] == "gallery"], key=lambda p: (p.get("pick") == "month", p.get("pick") == "week", len(p["likes"])), reverse=True)
    arrivals = sorted([p for p in in_month if p["type"] == "arrival"], key=lambda p: len(p["likes"]), reverse=True)
    events = sorted([e for e in cy["events"] if not e.get("hidden") and e["date"] >= month + "-01"], key=lambda e: e["date"])
    joined = [m for m in cy["members"].values() if m.get("joined", "").startswith(month) and not m.get("hidden")]
    snap = lambda p: {"title": p["title"], "text": p["text"][:400], "images": p["images"][:3], "firm": cy["members"].get(p["firm"], {}).get("name", ""),
                      "city": p.get("city", ""), "tags": [cy["members"].get(c, {}).get("name", "") for c in p.get("tags", [])]}
    issue = {"id": new_id("i"), "month": month, "title": f"The Courtyard — {label}", "made": now_iso(),
             "cover": snap(gallery[0]) if gallery else None, "gallery": [snap(p) for p in gallery[1:5]],
             "arrivals": [snap(p) for p in arrivals[:6]],
             "events": [{"title": e["title"], "date": e["date"], "city": e.get("city", ""), "host": cy["members"].get(e["host"], {}).get("name", "")} for e in events[:6]],
             "joined": [{"name": m["name"], "kind": m["kind"], "city": m.get("city", "")} for m in joined[:20]],
             "ads": [dict(a) for a in cy["ads"] if a.get("active") and a.get("paid")][:6],
             "hero": cy["settings"].get("hero", "")}
    subs = [x for x in cy["submissions"] if x["status"] == "approved" and not x.get("used")]
    sub_snap = lambda x: {"title": x["title"], "text": x["text"][:900], "images": x["images"][:4], "link": x.get("link", ""), "file": x.get("file", ""),
                          "firm": cy["members"].get(x["firm"], {}).get("name", ""), "city": cy["members"].get(x["firm"], {}).get("city", ""), "tags": []}
    story = next((x for x in subs if x["kind"] == "cover-story"), None) or next((x for x in subs if x["kind"] == "portfolio"), None)
    issue["cover_story"] = sub_snap(story) if story else None
    issue["portfolios"] = [sub_snap(x) for x in subs if x["kind"] == "portfolio" and x is not story][:4]
    issue["catalogs"] = [sub_snap(x) for x in subs if x["kind"] in ("catalog", "video")][:6]
    issue["sub_events"] = [sub_snap(x) for x in subs if x["kind"] == "event"][:4]
    issue["postcards"] = [snap(p) | {"place": p.get("place", "")} for p in in_month if p["type"] == "postcard"][:6]
    issue["pins"] = [snap(p) | {"material": p.get("material", ""), "brand": p.get("brand", "")} for p in in_month if p["type"] == "pin"][:8]
    for x in subs:
        x["used"] = issue["id"]
    cy["issues"].insert(0, issue)
    return issue


def _e(t):
    return (str(t or "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def issue_html(issue_id):
    """Six pages: cover · display (pins & ads) · cover story · portfolios · makers (catalogs & videos) · Open House & postcards."""
    cy = load()
    i = next((x for x in cy["issues"] if x["id"] == issue_id), None)
    if not i:
        return None
    img = lambda n: f"/cy/files/{_e(n)}"
    month = datetime.strptime(i["month"] + "-01", "%Y-%m-%d").strftime("%B %Y")

    def story(st, big=False):
        if not st:
            return ""
        pics = "".join(f'<img src="{img(n)}" alt="">' for n in st["images"][: (4 if big else 1)])
        tags = f'<p class="by">With {", ".join(_e(t) for t in st["tags"] if t)}</p>' if any(st.get("tags") or []) else ""
        link = f'<p><a href="{_e(st["link"])}">{_e(st["link"])}</a></p>' if st.get("link") else ""
        pdf = f'<p><a href="{img(st["file"])}">Open the catalog (PDF)</a></p>' if st.get("file") else ""
        return (f'<article class="{"big" if big else ""}"><div class="pics">{pics}</div><h3>{_e(st["title"])}</h3>'
                f'<p class="by">{_e(st["firm"])}{" · " + _e(st["city"]) if st.get("city") else ""}</p><p>{_e(st["text"])}</p>{tags}{link}{pdf}</article>')

    def ad(a_):
        pic = f'<img src="{img(a_["image"])}" alt="">' if a_.get("image") else ""
        visit = f'<a href="{_e(a_["link"])}">Visit</a>' if a_.get("link") else ""
        return (f'<aside class="ad">{pic}<b>{_e(a_["advertiser"])}</b><span>{_e(a_["title"])}</span>'
                f'<small>{_e(a_["text"])}</small>{visit}<i>Advertisement</i></aside>')
    ads = "".join(ad(a_) for a_ in i.get("ads", []))
    pins = "".join(f'<figure class="pin"><img src="{img(p["images"][0])}" alt=""><figcaption><b>{_e(p.get("material") or p["title"])}</b>'
                   f'<span>{_e(p.get("brand") or p["firm"])}</span></figcaption></figure>' for p in i.get("pins", []) if p["images"])
    cards = "".join(f'<figure class="card"><img src="{img(p["images"][0])}" alt=""><figcaption><b>{_e(p.get("place") or p["title"])}</b>'
                    f'<span>{_e(p["firm"])}</span></figcaption></figure>' for p in i.get("postcards", []) if p["images"])
    ev = "".join(f'<li><b>{_e(e["date"])}</b> {_e(e["title"])} <span>{_e(e["host"])}{" · " + _e(e["city"]) if e["city"] else ""}</span></li>' for e in i["events"])
    jn = ", ".join(f'{_e(m["name"])} ({_e(m["city"] or m["kind"])})' for m in i["joined"])
    cover_img = i.get("hero") or ((i.get("cover_story") or i.get("cover") or {}).get("images") or [""])[0]
    cover_url = img(cover_img) if cover_img else "/shared/courtyard-hero.jpg"
    lead = i.get("cover_story") or i.get("cover")
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(i["title"])}</title><style>
@font-face{{font-family:"DL Jakarta";src:url(/shared/fonts/plus-jakarta-sans-latin-400-normal.woff2) format("woff2");font-weight:400}}@font-face{{font-family:"DL Jakarta";src:url(/shared/fonts/plus-jakarta-sans-latin-600-normal.woff2) format("woff2");font-weight:500 650}}@font-face{{font-family:"DL Jakarta";src:url(/shared/fonts/plus-jakarta-sans-latin-800-normal.woff2) format("woff2");font-weight:700 900}}
:root{{--t:#1A5140;--t2:#123C30;--iv:#F6FBF6;--ink:#0E2A21;--mute:#5D7A6C}}*{{box-sizing:border-box}}
body{{margin:0;background:var(--t2);font:17px/1.6 "DL Jakarta",system-ui,sans-serif;color:var(--ink)}}
.page{{max-width:900px;margin:28px auto;background:var(--iv);padding:56px 60px;box-shadow:0 30px 60px -30px rgba(0,0,0,.6);page-break-after:always;position:relative}}
.num{{position:absolute;bottom:18px;right:24px;font:600 10px system-ui,sans-serif;letter-spacing:.3em;color:var(--mute)}}
.cover{{padding:0;min-height:1100px;display:flex;flex-direction:column;justify-content:flex-end;color:#fff;background:var(--t) center/cover no-repeat}}
.cover .shade{{background:linear-gradient(180deg,rgba(8,38,28,0) 0%,rgba(8,38,28,.75) 100%);padding:60px}}
.cover h1{{font:800 92px/0.95 "DL Jakarta",system-ui,sans-serif;margin:0;letter-spacing:-.02em}}
.kick{{font:600 11px system-ui,sans-serif;letter-spacing:.32em;text-transform:uppercase}}
.cover .lead{{font-size:22px;max-width:560px;margin:18px 0 0}}
h2{{font:600 11px system-ui,sans-serif;letter-spacing:.32em;text-transform:uppercase;color:var(--t);margin:0 0 22px;border-bottom:1px solid #dccbbb;padding-bottom:12px}}
article{{margin-bottom:30px}}article h3{{font:700 28px/1.15 "DL Jakarta",system-ui,sans-serif;margin:14px 0 4px}}
.by{{font:600 11.5px system-ui,sans-serif;letter-spacing:.08em;color:var(--mute);margin:0 0 10px;text-transform:uppercase}}
.pics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}}.pics img{{width:100%;aspect-ratio:4/3;object-fit:cover;display:block}}
article.big .pics img:first-child{{grid-column:1/-1;aspect-ratio:16/9}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:30px}}
.pins{{columns:3 200px;column-gap:14px}}.pin,.card{{break-inside:avoid;margin:0 0 14px;background:#fff;padding:8px 8px 12px}}.pin img,.card img{{width:100%;display:block}}
.pin figcaption,.card figcaption{{display:flex;flex-direction:column;font-size:14px;padding-top:8px}}.pin span,.card span{{font:12px system-ui,sans-serif;color:var(--mute)}}
.cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}}.card{{transform:rotate(-1deg)}}.card:nth-child(2n){{transform:rotate(1.2deg)}}
ul{{padding-left:18px}}li span{{color:var(--mute);font-size:14px}}
.ad{{display:flex;flex-direction:column;gap:4px;border:1px solid #dccbbb;padding:16px;margin:14px 0;font-family:system-ui,sans-serif;background:#fff}}
.ad img{{width:100%;max-height:240px;object-fit:cover}}.ad i{{font-size:10px;letter-spacing:.2em;text-transform:uppercase;color:#aaa}}a{{color:var(--t)}}
.foot{{font:12px system-ui,sans-serif;color:var(--mute);text-align:center;margin-top:30px}}
@media (max-width:700px){{.page{{padding:30px 22px;margin:0 0 10px}}.cover{{min-height:88vh}}.cover h1{{font-size:56px}}.cover .shade{{padding:30px 22px}}.grid,.cards{{grid-template-columns:1fr}}}}
@media print{{body{{background:#fff}}.page{{box-shadow:none;margin:0}}}}</style></head><body>
<section class="page cover" style="background-image:url({cover_url})"><div class="shade"><p class="kick">The Courtyard · {_e(month)}</p><h1>The Courtyard</h1>
<p class="lead">{_e(lead["title"]) if lead else "Where architects and makers meet."}</p><p class="kick" style="margin-top:22px;opacity:.8">A magazine by Design Lab</p></div></section>
<section class="page"><h2>On display · materials &amp; brands</h2>{f'<div class="pins">{pins}</div>' if pins else "<p>Pin your materials and brands in The Courtyard to be on this page.</p>"}{ads}<span class="num">2</span></section>
<section class="page"><h2>Cover story</h2>{story(i.get("cover_story") or i.get("cover"), True) or "<p>Send your best project to the magazine from My page.</p>"}<span class="num">3</span></section>
<section class="page"><h2>Portfolios</h2><div class="grid">{"".join(story(x) for x in (i.get("portfolios") or [])) or "".join(story(x) for x in i["gallery"]) or "<p>More work next month.</p>"}</div><span class="num">4</span></section>
<section class="page"><h2>From the makers · catalogs, films &amp; new arrivals</h2><div class="grid">{"".join(story(x) for x in (i.get("catalogs") or [])) + "".join(story(x) for x in i["arrivals"]) or "<p>Vendors: send your catalog or film from My page.</p>"}</div><span class="num">5</span></section>
<section class="page"><h2>Open House</h2><ul>{ev or "<li>Host an Open House from The Courtyard.</li>"}</ul>{"".join(story(x) for x in (i.get("sub_events") or []))}
{f'<h2 style="margin-top:34px">Postcards</h2><div class="cards">{cards}</div>' if cards else ""}
<h2 style="margin-top:34px">New in The Courtyard</h2><p>{jn or "Welcome to everyone who joined this month."}</p>
<p class="foot">The Courtyard is the community of Design Lab — where architects, designers and makers meet.</p><span class="num">6</span></section>
</body></html>"""


def page_html(slug):
    """A studio's public portfolio page (works like a small website). Counts a view."""
    cy = load()
    m = next((x for x in cy["members"].values() if x.get("slug") == slug and not x.get("hidden")), None)
    if not m:
        return None
    m["views"] = m.get("views", 0) + 1
    save(cy)
    img = lambda n: f"/cy/files/{_e(n)}"
    link = lambda u: u if re.match(r"^https?://", u or "") else "https://" + (u or "")
    insta = lambda h: "https://instagram.com/" + re.sub(r"^@|^https?://(www\.)?instagram\.com/", "", h or "")
    layout = m.get("layout", "grid")
    projects = [p for p in (m.get("portfolio") or []) if p.get("public", True)]
    top = m.get("cover") or next((p["cover"] for p in projects if p.get("cover")), "")
    def proj(p, n):
        pics = "".join(f'<a href="{img(x)}"><img src="{img(x)}" alt="{_e(p["name"])}" loading="lazy"></a>' for x in ([p["cover"]] + [y for y in p["images"] if y != p["cover"]]) if x)
        meta = " · ".join(_e(x) for x in (p.get("kind"), p.get("place"), p.get("year")) if x)
        vid = f'<p><a href="{_e(link(p["video"]))}">Watch the film</a></p>' if p.get("video") else ""
        return f'<section class="proj" id="{_e(p.get("id") or "p" + str(n))}"><a id="p{n}"></a><div class="pics">{pics}</div><div class="txt"><h2>{_e(p["name"])}</h2><p class="meta">{meta}</p><p>{_e(p.get("text", ""))}</p>{vid}</div></section>'
    def tile(n, p):
        pic = f'<img src="{img(p["cover"])}" alt="" loading="lazy">' if p.get("cover") else ""
        return f'<a class="tile" href="#p{n}">{pic}<span>{_e(p["name"])}</span></a>'
    tiles = "".join(tile(n, p) for n, p in enumerate(projects))
    contacts = "".join(x for x in (
        f'<a href="{_e(link(m["website"]))}">Website</a>' if m.get("website") else "",
        f'<a href="{_e(insta(m["instagram"]))}">Instagram</a>' if m.get("instagram") else "",
        f'<a href="mailto:{_e(m["email"])}">{_e(m["email"])}</a>' if m.get("email") else "",
        f'<a href="tel:{_e(m["phone"])}">{_e(m["phone"])}</a>' if m.get("phone") else ""))
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(m["name"])}</title><meta name="description" content="{_e((m.get("about") or "")[:150])}"><style>
@font-face{{font-family:"DL Jakarta";src:url(/shared/fonts/plus-jakarta-sans-latin-400-normal.woff2) format("woff2");font-weight:400}}@font-face{{font-family:"DL Jakarta";src:url(/shared/fonts/plus-jakarta-sans-latin-600-normal.woff2) format("woff2");font-weight:500 650}}@font-face{{font-family:"DL Jakarta";src:url(/shared/fonts/plus-jakarta-sans-latin-800-normal.woff2) format("woff2");font-weight:700 900}}
:root{{--t:#1A5140;--iv:#F6FBF6;--ink:#0E2A21;--mute:#5D7A6C}}*{{box-sizing:border-box}}
body{{margin:0;background:var(--iv);color:var(--ink);font:17px/1.6 "DL Jakarta",system-ui,sans-serif}}
header{{min-height:62vh;display:flex;align-items:flex-end;background:var(--t) center/cover no-repeat;color:#fff}}
header .in{{width:100%;padding:48px clamp(18px,5vw,64px);background:linear-gradient(180deg,rgba(8,38,28,0),rgba(8,38,28,.7))}}
h1{{font-weight:800;letter-spacing:-.04em;font-size:clamp(40px,7vw,84px);line-height:1;margin:0}}.kick{{font:600 11px system-ui,sans-serif;letter-spacing:.3em;text-transform:uppercase;opacity:.85}}
.about{{max-width:760px;margin:46px auto;padding:0 20px;font-size:19px}}.contacts{{display:flex;gap:18px;flex-wrap:wrap;font:600 13px system-ui,sans-serif}}
a{{color:var(--t)}}.tiles{{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,260px),1fr));gap:14px;padding:0 clamp(18px,5vw,64px);max-width:1200px;margin:0 auto 50px}}
.tile{{display:block;text-decoration:none;color:var(--ink)}}.tile img{{width:100%;aspect-ratio:4/5;object-fit:cover;display:block}}.tile span{{display:block;padding:8px 0;font-size:16px}}
.proj{{max-width:1100px;margin:0 auto 70px;padding:0 clamp(18px,5vw,64px)}}.pics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:10px}}
.pics img{{width:100%;aspect-ratio:4/3;object-fit:cover;display:block}}.pics a:first-child{{grid-column:1/-1}}.pics a:first-child img{{aspect-ratio:16/9}}
.layout-large .pics{{grid-template-columns:1fr}}.layout-story .proj{{max-width:820px}}
.proj h2{{font-weight:700;letter-spacing:-.03em;font-size:32px;margin:20px 0 2px}}.meta{{font:600 12px system-ui,sans-serif;letter-spacing:.1em;text-transform:uppercase;color:var(--mute);margin:0 0 10px}}
footer{{text-align:center;font:12px system-ui,sans-serif;color:var(--mute);padding:30px}}</style></head>
<body class="layout-{_e(layout)}"><header {f'style="background-image:url({img(top)})"' if top else ""}><div class="in"><p class="kick">{_e(m.get("profession") or ("Maker" if m["kind"] == "vendor" else "Architecture & interiors"))}{" · " + _e(", ".join(x for x in (m.get("area"), m.get("city")) if x)) if m.get("city") else ""}</p><h1>{_e(m["name"])}</h1></div></header>
<div class="about">{f"<p>{_e(m['about'])}</p>" if m.get("about") else ""}<div class="contacts">{contacts}</div></div>
{f'<div class="tiles">{tiles}</div>' if len(projects) > 1 else ""}
{"".join(proj(p, n) for n, p in enumerate(projects)) or '<p class="about">Portfolio coming soon.</p>'}
<footer>A Design Lab page · The Courtyard</footer></body></html>"""
