"""
Design Lab Cloud — the central back end (prototype v0.1)

One small server, three faces, kept in separate folders so each can change
without touching the others:

  /            the public website            (business/website/)
  /admin       Aalok's owner dashboard        (business/admin/)
  /api/...     the back end every part talks to (this file)

What it does
  * Firms sign up on the website and pay the one-time fee (TEST payments only
    in this prototype - no real money moves, no payment gateway is connected).
  * Payment issues a firm code (DL-0001), an activation key, the company bot
    and the ₹500 starter credit.
  * The studio software connects with code + key, registers its users and
    gets a bot seat for each (company bot covers 3 users; each extra user gets
    their own bot).
  * Every paid bot task is metered: AI cost + 30% Design Lab fees, taken from
    the prepaid wallet. Alert at 10% left; bots pause at zero.
  * Month end: subscription charged, top-ups older than 12 months expire.

Uses only Python's standard library. Start with: python cloud.py
"""

import hashlib
import hmac
import io
import json
import mimetypes
import os
import re
import secrets
import sys
import threading
import time
import urllib.parse
import zipfile

import courtyard   # The Courtyard community (separate file)
import bots        # the bots, their training and the AI connection (separate file)
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
WEBSITE_DIR = os.path.join(HERE, "website")
ADMIN_DIR = os.path.join(HERE, "admin")
DATA_DIR = os.path.join(HERE, "data")
DATA_FILE = os.path.join(DATA_DIR, "cloud.json")
STUDIO_DIR = os.path.normpath(os.path.join(HERE, "..", "client-software"))
PORT = int(os.environ.get("DESIGNLAB_CLOUD_PORT", "8800"))
VERSION = "0.1"

LOCK = threading.RLock()
ADMIN_TOKENS = {}          # sign-in token -> expiry time (owner dashboard); kept in memory only
ADMIN_HOURS = 12
ADMIN_FAILS = {}           # ip -> times of wrong dashboard passwords
FIRM_FAILS = {}            # ip -> times of wrong firm code / key
SIGNUPS = {}               # ip -> times of new registrations
ADMIN_ANYWHERE = bool(os.environ.get("DESIGNLAB_ADMIN_ANYWHERE"))   # later, when Design Lab is online with HTTPS


def admin_ok(tok):
    exp = ADMIN_TOKENS.get(tok or "")
    if exp and exp > time.time():
        return True
    ADMIN_TOKENS.pop(tok or "", None)
    return False


def too_many(store, ip, limit, minutes):
    now = time.time()
    store[ip] = [t for t in store.get(ip, []) if now - t < minutes * 60]
    return len(store[ip]) >= limit

DEFAULT_SETTINGS = {
    "setup_fee": 10000,          # one time, per firm
    "gst_pct": 18,
    "gateway_pct": 2,            # payment gateway charge, added to the client's payment
    "starter_credit": 500,
    "upi_id": "",                # Design Lab's UPI ID for the QR code; empty = test QR (no real payment)
    "upi_name": "Design Lab",
    "monthly_fee": 499,          # per firm, includes 3 users
    # vendors pay more: they gain the most from reaching architects
    "vendor_setup_fee": 25000,
    "vendor_monthly_fee": 1999,
    "courtyard_listing_year": 15000,   # vendor in The Courtyard only (no software)
    "featured_arrival_week": 999,
    "event_promotion": 1999,
    "magazine_ad_quarter": 2000,
    "magazine_ad_full": 5000,
    "included_users": 1,
    "extra_user_fee": 199,       # per extra user per month (each gets their own bot)
    "min_topup": 1000,
    "topup_valid_months": 12,
    "low_balance_pct": 10,       # alert when this % of the last top-up is left
    "fees_pct": {"backend": 15, "training": 10, "management": 5},   # = 30% on AI cost
    # AI cost to Design Lab per task, in rupees (set from real provider bills later)
    "rates": {
        "site_mom": {"label": "Site Bot - MOM written", "ai_cost": 1.50},
        "office_draft": {"label": "Office Bot - email or follow-up drafted", "ai_cost": 1.00},
        "file_preview": {"label": "Office Bot - unclear file named from preview", "ai_cost": 0.20},
        "layout": {"label": "Layout Bot - plan turned into rooms", "ai_cost": 25.00},
        "social_post": {"label": "Social Bot - post edited and scheduled", "ai_cost": 8.00},
        "assistant_chat": {"label": "Assistant - answer written by AI", "ai_cost": 0.50},
        "mom_tidy": {"label": "MOM Bot - meeting tidied into a MOM (Hindi/English)", "ai_cost": 2.00},
        "gallery_sort": {"label": "Gallery Bot - picture sorted into a room", "ai_cost": 0.30},
    },
}


# ---------------------------------------------------------------- storage

def now():
    return datetime.now()


def now_iso():
    return now().isoformat(timespec="seconds")


def load():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    data.setdefault("admin", None)
    data.setdefault("settings", json.loads(json.dumps(DEFAULT_SETTINGS)))
    if not data["settings"].get("seats_v2"):          # v0.9: 1 user included, every extra user Rs 199 / month
        data["settings"]["included_users"] = 1
        data["settings"]["seats_v2"] = True
    for k, v in DEFAULT_SETTINGS.items():
        data["settings"].setdefault(k, json.loads(json.dumps(v)))
    for k, v in DEFAULT_SETTINGS["rates"].items():          # new bot tasks reach older installs too
        data["settings"]["rates"].setdefault(k, json.loads(json.dumps(v)))
    data.setdefault("firms", [])
    data.setdefault("orders", [])
    data.setdefault("next_code", 1)
    return data


def save(data):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA_FILE)


def money(x):
    return round(float(x) + 1e-9, 2)


def hash_secret(secret, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt, hashlib.pbkdf2_hmac("sha256", secret.encode(), bytes.fromhex(salt), 120_000).hex()


def find_firm(data, code):
    for f in data["firms"]:
        if f["code"].lower() == (code or "").lower():
            return f
    return None


# ---------------------------------------------------------------- wallet

def wallet_balance(firm):
    return money(sum(b["left"] for b in firm["wallet"]["buckets"]))


def ledger(firm, kind, amount, note, income=0.0, extra=None):
    entry = {"time": now_iso(), "kind": kind, "amount": money(amount), "income": money(income), "note": note,
             "balance": wallet_balance(firm)}
    if extra:
        entry.update(extra)
    firm["wallet"]["ledger"].insert(0, entry)
    firm["wallet"]["ledger"] = firm["wallet"]["ledger"][:500]


def add_credit(firm, amount, note, months, kind="topup"):
    expires = (now() + timedelta(days=round(30.44 * months))).date().isoformat()
    firm["wallet"]["buckets"].append({"added": now_iso(), "amount": money(amount), "left": money(amount),
                                      "expires": expires, "note": note})
    firm["wallet"]["last_topup"] = money(amount)
    ledger(firm, kind, amount, note)
    refresh_status(firm)


def take(firm, amount):
    """Deduct from the oldest-expiring credit first. Returns False if not enough."""
    amount = money(amount)
    if wallet_balance(firm) + 1e-9 < amount:
        return False
    for b in sorted(firm["wallet"]["buckets"], key=lambda b: b["expires"]):
        use = min(b["left"], amount)
        b["left"] = money(b["left"] - use)
        amount = money(amount - use)
        if amount <= 0:
            break
    firm["wallet"]["buckets"] = [b for b in firm["wallet"]["buckets"] if b["left"] > 0]
    return True


def refresh_status(firm):
    """Bots run while there is balance; alert at the low-balance mark."""
    s = load_settings_cache()
    bal = wallet_balance(firm)
    last = firm["wallet"].get("last_topup") or s["min_topup"]
    if firm["status"] in ("pending", "suspended"):
        return
    firm["status"] = "active" if bal > 0 else "paused"
    low = bal <= last * s["low_balance_pct"] / 100
    alerts = firm.setdefault("alerts", [])
    if bal <= 0 and not any(a["kind"] == "paused" and not a.get("cleared") for a in alerts):
        alerts.insert(0, {"time": now_iso(), "kind": "paused", "text": "Wallet empty - paid bots paused. Free features keep working."})
    elif low and bal > 0 and not any(a["kind"] == "low" and not a.get("cleared") for a in alerts):
        alerts.insert(0, {"time": now_iso(), "kind": "low", "text": f"Only Rs {bal:.0f} left. Please top up to keep the bots working."})
    if not low:
        for a in alerts:
            a["cleared"] = True


_SETTINGS = {}


def load_settings_cache():
    return _SETTINGS or DEFAULT_SETTINGS


def price_task(settings, task, units=1):
    rate = settings["rates"].get(task)
    if not rate:
        return None
    ai = money(rate["ai_cost"] * max(1, units))
    fees = {k: money(ai * pct / 100) for k, pct in settings["fees_pct"].items()}
    return {"ai_cost": ai, "fees": fees, "total": money(ai + sum(fees.values())), "label": rate["label"]}


# ---------------------------------------------------------------- firms and bots

def upi_link(s, order):
    """UPI QR content. Until Design Lab's own UPI / payment company is set, it is a TEST code (pays no one)."""
    from urllib.parse import quote
    test = not s.get("upi_id")
    pa = s.get("upi_id") or "designlab.test@upi"
    link = (f"upi://pay?pa={quote(pa)}&pn={quote(s.get('upi_name') or 'Design Lab')}&am={order['total']:.2f}"
            f"&cu=INR&tn={quote('Design Lab setup ' + order['id'])}&tr={order['id']}")
    return {"upi": link, "test": test, "payee": pa}


def new_firm(data, body):
    code = f"DL-{data['next_code']:04d}"
    data["next_code"] += 1
    return {
        "code": code, "status": "pending", "created": now_iso(),
        "name": body["firm"], "owner": body["name"], "email": body["email"], "phone": body.get("phone", ""),
        "city": body.get("city", ""), "kind": body.get("kind", "designer"),
        "profession": body.get("profession", ""), "designation": body.get("designation", ""),
        "address": body.get("address", ""),
        "key_hash": None, "key_salt": None, "studio_linked": None,
        "users": [], "bots": [],
        "wallet": {"buckets": [], "ledger": [], "last_topup": 0},
        "usage": [], "alerts": [],
    }


def ensure_company_bot(firm):
    if not any(b["type"] == "company" for b in firm["bots"]):
        firm["bots"].append({"id": firm["code"], "type": "company", "seats": 3, "created": now_iso(),
                             "roles": ["Folder Bot", "Site Bot", "Office Bot"], "status": "active"})


def assign_seats(firm, settings):
    """Seats 1-3 run on the company bot; every user after that gets their own bot."""
    inc = settings["included_users"]
    keep = {b["id"] for b in firm["bots"] if b["type"] in ("company", "manual")}
    user_bots = []
    for i, u in enumerate(firm["users"]):
        u["seat"] = i + 1
        if u["seat"] <= inc:
            u["bot"] = firm["code"]
        else:
            bid = f"{firm['code']}-{u['seat']:02d}"
            u["bot"] = bid
            existing = next((b for b in firm["bots"] if b["id"] == bid), None)
            user_bots.append(existing or {"id": bid, "type": "user", "user": u["id"], "created": now_iso(),
                                          "roles": ["Folder Bot", "Site Bot", "Office Bot"], "status": "active"})
            user_bots[-1]["user"] = u["id"]
    firm["bots"] = [b for b in firm["bots"] if b["id"] in keep] + user_bots


def monthly_charge(firm, settings):
    extra = max(0, len(firm["users"]) - settings["included_users"])
    fee = settings.get("vendor_monthly_fee", 1999) if firm.get("kind") == "vendor" else settings["monthly_fee"]
    base = fee + extra * settings["extra_user_fee"]
    return {"base": money(base), "extra_users": extra, "gst": money(base * settings["gst_pct"] / 100),
            "total": money(base * (1 + settings["gst_pct"] / 100))}


def firm_public(firm, settings, detail=False):
    out = {k: v for k, v in firm.items() if k not in ("key_hash", "key_salt", "usage", "wallet", "alerts", "activity")}
    out["balance"] = wallet_balance(firm)
    out["monthly"] = monthly_charge(firm, settings)
    month = now().strftime("%Y-%m")
    used = [u for u in firm["usage"] if u["time"].startswith(month)]
    out["month_usage"] = money(sum(u["total"] for u in used))
    out["month_tasks"] = len(used)
    out["alerts"] = [a for a in firm.get("alerts", []) if not a.get("cleared")][:5]
    if detail:
        out["usage"] = firm["usage"][:100]
        out["ledger"] = firm["wallet"]["ledger"][:100]
        out["buckets"] = firm["wallet"]["buckets"]
        out["activity"] = firm.get("activity", [])[:100]
    return out


# ---------------------------------------------------------------- studio download

def studio_zip():
    """Zip the studio software folder on the fly, so the download is always current."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(STUDIO_DIR):
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "projects")]
            for f in files:
                if f in ("designlab_config.json",) or f.endswith(".pyc"):
                    continue
                full = os.path.join(root, f)
                z.write(full, os.path.join("Design Lab Studio", os.path.relpath(full, STUDIO_DIR)))
    return buf.getvalue()


# ---------------------------------------------------------------- HTTP

class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


class Handler(BaseHTTPRequestHandler):
    server_version = "DesignLabCloud/" + VERSION

    def log_message(self, fmt, *args):
        if args and "/api/" in str(args[0]):
            return
        sys.stderr.write("  " + (fmt % args) + "\n")

    def end_headers(self):
        # standard protections; no cross-site access (the studio software talks to this server directly, not through a browser)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; "
                         "connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'; form-action 'self'")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        super().end_headers()

    def here(self):
        """True when the request comes from this computer itself (not the network, not a sharing link)."""
        if ADMIN_ANYWHERE:
            return True
        if self.headers.get("Cf-Connecting-Ip") or self.headers.get("X-Forwarded-For"):
            return False
        return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, ctype, name=None, status=200):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if name:
            self.send_header("Content-Disposition", f'attachment; filename="{name}"')
        self.end_headers()
        self.wfile.write(data)

    def static(self, base, rel):
        rel = rel.lstrip("/") or "index.html"
        full = os.path.normpath(os.path.join(base, rel))
        if not full.startswith(os.path.normpath(base) + os.sep) or not os.path.isfile(full):
            return self.send_error(404)
        with open(full, "rb") as f:
            self.send_bytes(f.read(), mimetypes.guess_type(full)[0] or "application/octet-stream")

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 40 * 1024 * 1024:
            raise ApiError(413, "That is too large (limit 40 MB).")
        try:
            return json.loads(self.rfile.read(n).decode() or "{}") if n else {}
        except ValueError:
            raise ApiError(400, "The request could not be read.")

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(url.path)
        self._q = urllib.parse.parse_qs(url.query)
        try:
            if path.startswith("/api/"):
                with LOCK:
                    return self.send_json(200, self.route("GET", path, {}))
            if path.startswith("/cy/files/"):
                fp = courtyard.file_path(path[len("/cy/files/"):])
                if not fp:
                    raise ApiError(404, "Not found.")
                ext = os.path.splitext(fp)[1].lower()
                with open(fp, "rb") as f:     # documents always download (never open as a web page)
                    return self.send_bytes(f.read(), mimetypes.guess_type(fp)[0] or "application/octet-stream",
                                           name=None if ext in (".jpg", ".png", ".webp", ".pdf") else "document" + ext)
            if path.startswith("/magazine/"):
                html = courtyard.issue_html(path[len("/magazine/"):])
                if not html:
                    raise ApiError(404, "That issue isn't here.")
                return self.send_bytes(html.encode("utf-8"), "text/html; charset=utf-8")
            if path.startswith("/p/"):
                with LOCK:
                    html = courtyard.page_html(path[3:].strip("/")[:40])
                if not html:
                    raise ApiError(404, "That page isn't here.")
                return self.send_bytes(html.encode("utf-8"), "text/html; charset=utf-8")
            if path == "/download/studio.zip":
                return self.send_bytes(studio_zip(), "application/zip", "Design Lab Studio.zip")
            if (path == "/admin" or path.startswith("/admin/")) and not self.here():
                return self.send_bytes("The owner dashboard opens only on the Design Lab computer itself.".encode(), "text/plain; charset=utf-8", status=403)
            if path == "/admin" or path.startswith("/admin/"):
                return self.static(ADMIN_DIR, path[len("/admin"):])
            if path.startswith("/shared/"):
                return self.static(os.path.join(HERE, "shared"), path[len("/shared"):])
            return self.static(WEBSITE_DIR, path)
        except ApiError as e:
            self.send_json(e.status, {"error": e.message})

    def do_POST(self):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        self._q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        try:
            b = self.body()
            if path in ("/api/website/ask", "/api/studio/bot", "/api/admin/bots/test"):
                return self.send_json(200, self.bot_call(path, b))     # AI can take a while: don't hold everyone up
            with LOCK:
                self.send_json(200, self.route("POST", path, b))
        except ApiError as e:
            self.send_json(e.status, {"error": e.message})
        except Exception as e:  # pragma: no cover
            self.send_json(500, {"error": f"Something went wrong: {e}"})

    # ------------------------------------------------------------ bots (run outside the lock)
    def bot_call(self, path, b):
        if path == "/api/website/ask":
            ip = self.client_address[0]
            now = time.time()
            ASK_TIMES[ip] = [t for t in ASK_TIMES.get(ip, []) if now - t < 60] + [now]
            if len(ASK_TIMES[ip]) > 8:
                raise ApiError(429, "Please wait a minute before asking again.")
            r = bots.run("frontdesk", str(b.get("message") or "")[:1000], "website", b.get("history") or [])
            if not r["answer"]:
                r["answer"] = "Thank you for asking! A person from Design Lab will reply — leave your phone number or email here and we'll get back to you."
            if b.get("contact"):
                with LOCK:
                    data = load()
                    data.setdefault("website_leads", []).insert(0, {"time": now_iso(), "contact": str(b["contact"])[:120], "message": str(b.get("message") or "")[:500]})
                    save(data)
            return {"answer": r["answer"]}
        if path == "/api/admin/bots/test":
            if not self.here():
                raise ApiError(403, "The owner dashboard opens only on the Design Lab computer itself.")
            if not admin_ok(self.headers.get("X-Admin", "")):
                raise ApiError(401, "Please sign in.")
            return bots.admin("POST", "test", b)
        # /api/studio/bot : a studio uses a bot; AI use is charged to the firm's balance
        with LOCK:
            data = load()
            ip = self.client_address[0]
            if too_many(FIRM_FAILS, ip, 10, 10):
                raise ApiError(429, "Too many wrong tries. Please wait 10 minutes.")
            firm = find_firm(data, self.headers.get("X-Firm", ""))
            key = self.headers.get("X-Key", "")
            if not firm or not firm.get("key_hash") or not hmac.compare_digest(hash_secret(key, firm["key_salt"])[1], firm["key_hash"]):
                FIRM_FAILS.setdefault(ip, []).append(time.time())
                raise ApiError(401, "Firm code or activation key is wrong.")
            if firm["status"] == "suspended":
                raise ApiError(403, "This firm is suspended. Please contact Design Lab.")
            bot = bots.load()["bots"].get(str(b.get("bot")))
            task = (bot or {}).get("task")
            s = data["settings"]
            price = price_task(s, task) if task else None
            if price and bots.ai_ready() and wallet_balance(firm) < price["total"]:
                raise ApiError(402, "Wallet empty - AI bots are paused. Top up to continue; free features keep working.")
        r = bots.run(str(b.get("bot")), b.get("text"), firm["code"], b.get("history") or [])
        if r["ai"] and price:
            with LOCK:
                data = load()
                firm = find_firm(data, firm["code"])
                if take(firm, price["total"]):
                    firm["usage"].insert(0, {"time": now_iso(), "task": task, "label": price["label"], "user": str(b.get("user") or "")[:40],
                                             "project": str(b.get("project") or "")[:80], "bot": b.get("bot"), "ai_cost": price["ai_cost"],
                                             "fees": price["fees"], "total": price["total"]})
                    ledger(firm, "usage", -price["total"], f"{price['label']} ({b.get('project') or ''})", income=sum(price["fees"].values()))
                    refresh_status(firm)
                    save(data)
            r["charged"] = price["total"]
        return r

    # ------------------------------------------------------------ routes
    def route(self, method, path, b):
        data = load()
        _SETTINGS.clear()
        _SETTINGS.update(data["settings"])
        s = data["settings"]

        # ---- public (website)
        if path == "/api/pricing":
            return {k: s[k] for k in ("setup_fee", "gst_pct", "gateway_pct", "starter_credit", "monthly_fee", "vendor_setup_fee", "vendor_monthly_fee",
                                      "included_users", "extra_user_fee", "min_topup", "topup_valid_months", "fees_pct")}
        if path == "/api/signup" and method == "POST":
            if too_many(SIGNUPS, self.client_address[0], 5, 60):
                raise ApiError(429, "Too many registrations from here. Please try again later.")
            SIGNUPS.setdefault(self.client_address[0], []).append(time.time())
            for k in ("name", "firm", "email"):
                if not (b.get(k) or "").strip():
                    raise ApiError(400, "Please fill in your name, firm name and email.")
            if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", b["email"].strip()):
                raise ApiError(400, "That email address doesn't look right.")
            firm = new_firm(data, {k: (b.get(k) or "").strip() for k in ("name", "firm", "email", "phone", "city", "address", "kind", "profession", "designation")})
            fee = s.get("vendor_setup_fee", 25000) if firm.get("kind") == "vendor" else s["setup_fee"]
            gst = money(fee * s["gst_pct"] / 100)
            gw = money((fee + gst) * s["gateway_pct"] / 100)
            order = {"id": "ORD-" + secrets.token_hex(4).upper(), "firm": firm["code"], "time": now_iso(),
                     "kind": "setup", "amount": money(fee), "gst": gst, "gateway": gw, "total": money(fee + gst + gw),
                     "status": "awaiting payment"}
            data["firms"].append(firm)
            data["orders"].insert(0, order)
            save(data)
            return {"order": order, "firm": {"code": firm["code"], "name": firm["name"]}, "pay": upi_link(s, order)}
        if path == "/api/pay/test" and method == "POST":
            if not self.here():   # test payments (no money) only from this computer, until real payments / owner approval exist
                raise ApiError(403, "Registration from outside is not open yet. Please contact Design Lab.")
            order = next((o for o in data["orders"] if o["id"] == b.get("order")), None)
            if not order or order["status"] != "awaiting payment":
                raise ApiError(400, "This order can't be paid (already paid or not found).")
            firm = find_firm(data, order["firm"])
            order["status"] = "paid"
            order["paid"] = now_iso()
            order["mode"] = "TESTING - started without paying" if b.get("skip") else "TEST - no money moved"
            if b.get("skip"):
                order["status"] = "skipped (testing)"
            key = "-".join(secrets.token_hex(2).upper() for _ in range(4))
            firm["key_salt"], firm["key_hash"] = hash_secret(key)
            firm["status"] = "active"
            firm["activated"] = now_iso()
            ensure_company_bot(firm)
            if b.get("skip"):
                ledger(firm, "setup_fee", 0, f"Setup fee not charged - started without paying for testing (order {order['id']})")
            else:
                ledger(firm, "setup_fee", 0, f"One-time setup fee Rs {order['amount']:.0f} + GST paid (order {order['id']})",
                       income=order["amount"])
            add_credit(firm, s["starter_credit"], "Starter credit included with setup", s["topup_valid_months"], "starter")
            save(data)
            courtyard.on_join(firm)        # "Welcome ..." on The Courtyard's welcome wall
            return {"code": firm["code"], "key": key, "firm": firm["name"], "download": "/download/studio.zip",
                    "starter_credit": s["starter_credit"]}

        # ---- studio software (firm code + activation key)
        if path.startswith("/api/studio/"):
            ip = self.client_address[0]
            if too_many(FIRM_FAILS, ip, 10, 10):
                raise ApiError(429, "Too many wrong tries. Please wait 10 minutes.")
            firm = find_firm(data, self.headers.get("X-Firm", ""))
            key = self.headers.get("X-Key", "")
            if not firm or not firm.get("key_hash") or not hmac.compare_digest(hash_secret(key, firm["key_salt"])[1], firm["key_hash"]):
                FIRM_FAILS.setdefault(ip, []).append(time.time())
                raise ApiError(401, "Firm code or activation key is wrong.")
            if firm["status"] == "suspended":
                raise ApiError(403, "This firm is suspended. Please contact Design Lab.")
            act = path[len("/api/studio/"):]
            if act.startswith("courtyard"):
                uq = lambda h: urllib.parse.unquote(self.headers.get(h, ""))
                return courtyard.handle(method, act[len("courtyard"):], b, getattr(self, "_q", {}), firm,
                                        uq("X-User-Id")[:40] or "studio", uq("X-User-Name")[:80] or firm["name"], uq("X-User-Role"))
            if act == "link":
                firm["studio_linked"] = now_iso()
                firm["studio_version"] = b.get("version", "")
                save(data)
            elif act == "users" and method == "POST":
                incoming = []
                for u in b.get("users", []):
                    uid = str(u.get("id", "")).strip().lower()
                    if uid:
                        old = next((x for x in firm["users"] if x["id"] == uid), {})
                        incoming.append({"id": uid, "name": str(u.get("name", ""))[:80], "role": u.get("role", "designer"),
                                         "registered": old.get("registered") or now_iso()})
                firm["users"] = incoming
                assign_seats(firm, s)
                save(data)
            elif act == "usage" and method == "POST":
                price = price_task(s, b.get("task"), int(b.get("units") or 1))
                if not price:
                    raise ApiError(400, "Unknown bot task.")
                if not take(firm, price["total"]):
                    refresh_status(firm)
                    save(data)
                    raise ApiError(402, "Wallet empty - paid bots are paused. Top up to continue; free features keep working.")
                rec = {"time": now_iso(), "task": b.get("task"), "label": price["label"], "user": b.get("user", ""),
                       "project": b.get("project", ""), "bot": b.get("bot", firm["code"]),
                       "ai_cost": price["ai_cost"], "fees": price["fees"], "total": price["total"]}
                firm["usage"].insert(0, rec)
                firm["usage"] = firm["usage"][:2000]
                ledger(firm, "usage", -price["total"], f"{price['label']} ({b.get('project', '')})",
                       income=sum(price["fees"].values()))
                refresh_status(firm)
                save(data)
            elif act == "topup" and method == "POST":
                amt = money(b.get("amount") or 0)
                if amt < s["min_topup"]:
                    raise ApiError(400, f"Minimum top-up is Rs {s['min_topup']}.")
                gst = money(amt * s["gst_pct"] / 100)
                gw = money((amt + gst) * s["gateway_pct"] / 100)
                data["orders"].insert(0, {"id": "ORD-" + secrets.token_hex(4).upper(), "firm": firm["code"], "time": now_iso(),
                                          "kind": "topup", "amount": amt, "gst": gst, "gateway": gw, "total": money(amt + gst + gw),
                                          "status": "paid", "paid": now_iso(), "mode": "TEST - no money moved"})
                add_credit(firm, amt, f"Top-up Rs {amt:.0f} (TEST payment)", s["topup_valid_months"])
                save(data)
            elif act == "bot-learn" and method == "POST":
                return bots.learn(str(b.get("bot")), b.get("q"), b.get("a"), firm["code"])
            elif act == "bots" and method == "GET":
                d = bots.load()
                return {"ready": bots.ai_ready(d), "bots": {k: {"on": v.get("on"), "name": v.get("name")} for k, v in d["bots"].items()}}
            elif act == "activity" and method == "POST":
                rec = {"time": now_iso(), "kind": str(b.get("kind", ""))[:20], "text": str(b.get("text", ""))[:200],
                       "project": str(b.get("project", ""))[:120], "client": str(b.get("client", ""))[:120]}
                firm.setdefault("activity", []).insert(0, rec)
                firm["activity"] = firm["activity"][:500]
                if rec["kind"] == "project":
                    firm["projects_added"] = firm.get("projects_added", 0) + 1
                save(data)
                return {"ok": True}
            elif act == "feedback" and method == "POST":
                data.setdefault("feedback", []).insert(0, {"time": now_iso(), "firm": firm["name"], "code": firm["code"],
                                                          "kind": str(b.get("kind", "feature"))[:20], "user": str(b.get("user", ""))[:80],
                                                          "text": str(b.get("text", ""))[:1200]})
                data["feedback"] = data["feedback"][:500]
                save(data)
                return {"ok": True}
            elif act != "wallet":
                raise ApiError(404, "Unknown request.")
            return {"firm": firm_public(firm, s), "users": firm["users"], "bots": firm["bots"],
                    "spend": [{k: u.get(k) for k in ("time", "label", "user", "project", "total")} for u in firm.get("usage", [])[:30]],
                    "pricing": {"monthly_fee": s["monthly_fee"], "extra_user_fee": s["extra_user_fee"],
                                "included_users": s["included_users"], "min_topup": s["min_topup"]}}

        # ---- owner dashboard (only from this computer, unless Design Lab is set up online)
        if path.startswith("/api/admin/") and not self.here():
            raise ApiError(403, "The owner dashboard opens only on the Design Lab computer itself.")
        if path == "/api/admin/state":
            return {"setup": bool(data["admin"])}
        if path == "/api/admin/setup" and method == "POST":
            if data["admin"]:
                raise ApiError(409, "Already set up. Please sign in.")
            if len(b.get("password") or "") < 8:
                raise ApiError(400, "Choose a password of at least 8 characters.")
            salt, h = hash_secret(b["password"])
            data["admin"] = {"salt": salt, "hash": h, "created": now_iso()}
            save(data)
            tok = secrets.token_urlsafe(24)
            ADMIN_TOKENS[tok] = time.time() + ADMIN_HOURS * 3600
            return {"token": tok}
        if path == "/api/admin/login" and method == "POST":
            a = data["admin"]
            ip = self.client_address[0]
            if too_many(ADMIN_FAILS, ip, 5, 15):
                raise ApiError(429, "Too many wrong passwords. Please wait 15 minutes.")
            if not a or not hmac.compare_digest(hash_secret(b.get("password") or "", a["salt"])[1], a["hash"]):
                ADMIN_FAILS.setdefault(ip, []).append(time.time())
                data.setdefault("admin_log", []).insert(0, {"time": now_iso(), "ip": ip, "event": "wrong dashboard password"})
                del data["admin_log"][300:]
                save(data)
                time.sleep(0.8)
                raise ApiError(401, "Wrong password.")
            ADMIN_FAILS.pop(ip, None)
            data.setdefault("admin_log", []).insert(0, {"time": now_iso(), "ip": ip, "event": "signed in to the dashboard"})
            del data["admin_log"][300:]
            save(data)
            tok = secrets.token_urlsafe(24)
            ADMIN_TOKENS[tok] = time.time() + ADMIN_HOURS * 3600
            return {"token": tok}
        if path.startswith("/api/admin/"):
            if not admin_ok(self.headers.get("X-Admin", "")):
                raise ApiError(401, "Please sign in.")
            return self.admin(method, path[len("/api/admin/"):], b, data, s)

        raise ApiError(404, "Unknown request.")

    def admin(self, method, act, b, data, s):
        if act.startswith("bots"):
            out = bots.admin(method, act[len("bots"):], b)
            if act in ("bots/state", "bots"):
                out["leads"] = data.get("website_leads", [])[:30]
            return out
        if act.startswith("courtyard"):
            return courtyard.admin(method, act[len("courtyard"):], b)
        firms = data["firms"]
        if act == "overview":
            month = now().strftime("%Y-%m")
            income = {"setup": 0.0, "subscriptions": 0.0, "bot_fees": 0.0, "expired": 0.0}
            ai_cost = 0.0
            for f in firms:
                for e in f["wallet"]["ledger"]:
                    if not e["time"].startswith(month):
                        continue
                    key = {"setup_fee": "setup", "subscription": "subscriptions", "usage": "bot_fees", "expired": "expired"}.get(e["kind"])
                    if key:
                        income[key] += e.get("income", 0)
                ai_cost += sum(u["ai_cost"] for u in f["usage"] if u["time"].startswith(month))
            active = [f for f in firms if f["status"] in ("active", "paused")]
            return {
                "month": now().strftime("%B %Y"),
                "firms": len(active), "pending": sum(1 for f in firms if f["status"] == "pending"),
                "paused": sum(1 for f in firms if f["status"] == "paused"),
                "users": sum(len(f["users"]) for f in active),
                "bots": sum(len(f["bots"]) for f in active),
                "wallets": money(sum(wallet_balance(f) for f in active)),
                "income": {k: money(v) for k, v in income.items()},
                "income_total": money(sum(income.values())),
                "ai_cost": money(ai_cost),
                "alerts": [dict(a, firm=f["name"], code=f["code"]) for f in firms for a in f.get("alerts", []) if not a.get("cleared")][:20],
                "orders": data["orders"][:15],
                "requests": data.get("feedback", [])[:20],
            }
        if act == "firms":
            return {"firms": [firm_public(f, s) for f in firms]}
        if act == "settings" and method == "GET":
            return {"settings": s}
        if act == "settings" and method == "POST":
            for k in ("setup_fee", "gst_pct", "gateway_pct", "starter_credit", "monthly_fee", "included_users",
                      "extra_user_fee", "min_topup", "topup_valid_months", "low_balance_pct", "vendor_setup_fee", "vendor_monthly_fee",
                      "courtyard_listing_year", "featured_arrival_week", "event_promotion", "magazine_ad_quarter", "magazine_ad_full"):
                if k in b:
                    s[k] = float(b[k]) if "." in str(b[k]) else int(b[k])
            if isinstance(b.get("fees_pct"), dict):
                s["fees_pct"] = {k: float(v) for k, v in b["fees_pct"].items()}
            if isinstance(b.get("rates"), dict):
                for k, v in b["rates"].items():
                    if k in s["rates"]:
                        s["rates"][k]["ai_cost"] = float(v)
            save(data)
            return {"settings": s}
        if act == "month-end" and method == "POST":
            report = []
            today = now().date().isoformat()
            for f in firms:
                if f["status"] not in ("active", "paused"):
                    continue
                # expire old credit first
                expired = money(sum(bk["left"] for bk in f["wallet"]["buckets"] if bk["expires"] <= today))
                if expired:
                    f["wallet"]["buckets"] = [bk for bk in f["wallet"]["buckets"] if bk["expires"] > today]
                    ledger(f, "expired", -expired, "Credit older than 12 months expired", income=expired)
                ch = monthly_charge(f, s)
                ok = take(f, ch["base"])
                if ok:
                    ledger(f, "subscription", -ch["base"],
                           f"Monthly subscription Rs {s['monthly_fee']}" + (f" + {ch['extra_users']} extra user(s) x Rs {s['extra_user_fee']}" if ch["extra_users"] else "")
                           + " (GST invoiced separately)", income=ch["base"])
                else:
                    f.setdefault("alerts", []).insert(0, {"time": now_iso(), "kind": "subscription", "text": f"Monthly subscription Rs {ch['base']:.0f} could not be taken - wallet too low."})
                refresh_status(f)
                report.append({"code": f["code"], "firm": f["name"], "charged": ch["base"] if ok else 0, "expired": expired, "ok": ok})
            save(data)
            return {"report": report}
        m = re.match(r"^firms/([^/]+)(?:/([a-z\-]+))?$", act)
        if m:
            f = find_firm(data, m.group(1))
            if not f:
                raise ApiError(404, "Firm not found.")
            sub = m.group(2)
            if sub == "credit" and method == "POST":
                amt = money(b.get("amount") or 0)
                if amt <= 0:
                    raise ApiError(400, "Enter an amount.")
                add_credit(f, amt, b.get("note") or "Credit added by Design Lab", s["topup_valid_months"], "credit")
            elif sub == "bot" and method == "POST":
                n = sum(1 for x in f["bots"] if x["type"] == "manual") + 1
                f["bots"].append({"id": f"{f['code']}-X{n}", "type": "manual", "created": now_iso(),
                                  "roles": [r for r in (b.get("roles") or ["Social Bot"])], "note": b.get("note", ""),
                                  "status": "active"})
            elif sub == "status" and method == "POST":
                if b.get("status") not in ("active", "suspended"):
                    raise ApiError(400, "Status must be active or suspended.")
                f["status"] = b["status"]
                if b["status"] == "active":
                    refresh_status(f)
            elif sub is not None:
                raise ApiError(404, "Unknown request.")
            if sub:
                save(data)
            return {"firm": firm_public(f, s, detail=True)}
        raise ApiError(404, "Unknown request.")


courtyard.ApiError = ApiError
bots.ApiError = ApiError
ASK_TIMES = {}   # website visitor ip -> recent question times (simple limit)


def lan():
    try:
        sck = __import__("socket").socket(2, 2)
        sck.connect(("10.255.255.255", 1))
        ip = sck.getsockname()[0]
        sck.close()
        return ip
    except OSError:
        return "localhost"


def main():
    mimetypes.add_type("text/javascript", ".js")
    mimetypes.add_type("text/css", ".css")
    try:
        httpd = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError:
        print(f"\n  Design Lab Cloud is already running (port {PORT} is busy).\n")
        return
    print("")
    print("  ==============================================")
    print("   DESIGN LAB CLOUD  v" + VERSION + "  — running")
    print("  ==============================================")
    print(f"   Website:          http://localhost:{PORT}")
    print(f"   Your dashboard:   http://localhost:{PORT}/admin")
    print(f"   Studio connects:  http://{lan()}:{PORT}")
    print("   Payments are TEST only — no money moves.")
    print("   To stop: click this window and press Ctrl+C.")
    print("")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Design Lab Cloud stopped.\n")


if __name__ == "__main__":
    main()
