"""
Design Lab - THE BOTS and the AI connection (owner dashboard → Bots).

Each bot has a job, instructions, examples, knowledge and house rules that the owner writes and improves
("training"). Every save keeps a version, so an older version can be brought back.
When an AI account is connected (Claude / Anthropic or ChatGPT / OpenAI), bots that use AI answer with it;
without it they fall back to their examples and knowledge (free, simple matching).

Data: business/data/bots.json   (the AI key is kept here, on Design Lab's own computer only)
"""
import json
import vault
import os
import re
import secrets
import time
import urllib.error
import urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
BOTS_FILE = os.path.join(HERE, "data", "bots.json")
ApiError = None   # set by cloud.py

DEFAULT_BOTS = [
    {"id": "frontdesk", "name": "Front Desk", "where": "Design Lab website", "uses_ai": True, "task": "",
     "job": "Welcomes visitors on the Design Lab website, explains what Design Lab does, prices and how to join, and helps them sign up.",
     "instructions": "You are the front desk of Design Lab, software for architects, interior designers and interior vendors in India. "
                     "Be warm, short and clear. Explain Office, Site, The Courtyard and the vendor side in plain words. "
                     "Prices: architects ₹10,000 + GST one time, ₹499/month for 3 users, ₹199 per extra user, bot use from a prepaid balance. "
                     "Vendors: ₹25,000 + GST one time and ₹1,999/month. If you don't know something, say a person from Design Lab will reply.",
     "examples": [{"q": "What is Design Lab?", "a": "Design Lab runs your studio's office and site work: folders, MOMs, snags, schedules, vendors and a community called The Courtyard — on your own computer, with your phone as the screen."},
                  {"q": "How much does it cost?", "a": "For architects and designers: ₹10,000 + GST once, then ₹499 a month for 3 users. Bots are paid from a small prepaid balance — you only pay for what they do."}],
     "knowledge": "", "rules": "Never promise discounts. Never ask for card or bank details. Keep answers under 80 words."},
    {"id": "assistant", "name": "Studio Assistant", "where": "Office → Talk to your assistant", "uses_ai": True, "task": "assistant_chat",
     "job": "Answers the studio team's questions in the Office chat when the free rules don't understand them.",
     "instructions": "You help an Indian architecture / interior design studio use Design Lab. Answer in short, plain English. "
                     "If the question needs an action the software can do (new project, find a file, sort folders, find a vendor), tell them the exact words to type.",
     "examples": [], "knowledge": "", "rules": "Never invent project facts. Don't give legal or tax advice."},
    {"id": "folder", "name": "Folder Bot", "where": "Every project's folders", "uses_ai": False, "task": "file_preview",
     "job": "Files everything dropped in 00 Inbox into the right folder, keeps only the latest drawing, and asks before moving a file that looks misplaced.",
     "instructions": "Rules: .dwg/.dxf → 01 Drawings; renders → 02 3D; photos → 03 Site Photos by date; MOM → 04 MOM; quotes/bills → 06 Bills & Quotes; "
                     "older revisions → Superseded. When a file name says nothing, ask the AI to look at it (paid).",
     "examples": [], "knowledge": "", "rules": "Never delete. Never move a file without telling the studio."},
    {"id": "sorter", "name": "Smart Sorting Bot", "where": "Project folders → files left in 00 Inbox", "uses_ai": True, "task": "file_preview",
     "job": "Looks at files the free rules could not place (unclear names) and decides the right Design Lab folder for each, so old and new files end up arranged.",
     "instructions": "You sort files for an Indian architecture / interior design studio into Design Lab project folders. "
                     "You are given a list of file names (sometimes with the old folder path they came from). For each file choose ONE folder from this list only: "
                     "01 Drawings/Plans, 01 Drawings/Elevations, 01 Drawings/Sections, 01 Drawings/Details, 01 Drawings/Ceiling, 01 Drawings/Electrical, "
                     "01 Drawings/Plumbing, 01 Drawings/Working, 02 3D/Models, 02 3D/Renders, 03 Site Photos, 04 MOM, 06 Bills & Quotes, 07 Client Docs, "
                     "08 Vendors, 09 Mood Board, or 00 Inbox if you really cannot tell. "
                     "Hints: GFC, layout, furniture layout = Plans; RCP, false ceiling = Ceiling; tile/laminate/catalogue/brochure from a brand = 08 Vendors; "
                     "inspiration, reference, moodboard, Pinterest = 09 Mood Board; PO, invoice, estimate, BOQ, quotation = 06 Bills & Quotes; "
                     "agreement, scope, brief, client ID = 07 Client Docs; WhatsApp images from site = 03 Site Photos; .skp, .max, .blend = 02 3D/Models. "
                     "Reply with JSON only, no other words: {\"file name\": \"folder\", ...}",
     "examples": [], "knowledge": "", "rules": "Use only the folders listed. Never invent new folders. Never delete anything. Reply with JSON only."},
    {"id": "mom", "name": "MOM Writer", "where": "Site → Meeting / Write MOM", "uses_ai": True, "task": "mom_tidy",
     "job": "Turns what was said at a site meeting (English, Hindi or both) into a clean MOM in English: decisions, changes, actions with who and by when.",
     "instructions": "Rewrite the meeting notes as minutes of meeting in clear English. Translate Hindi or Hinglish. Group by room. "
                     "Mark each point as Decision, Change or Action; for actions add who and by when if said. Keep the client's words where they matter.",
     "examples": [{"q": "kitchen ka counter statuario rahega, aur wardrobe ke shutters fluted glass karo, electrician monday tak points shift karega",
                   "a": "Kitchen — Decision: Counter top in Statuario marble.\nMaster bedroom — Change: Wardrobe shutters to fluted glass.\nKitchen — Action: Electrician to shift the points by Monday."}],
     "knowledge": "", "rules": "Never add things that were not said. Never include prices unless they were said."},
    {"id": "gallery", "name": "Gallery Bot", "where": "Project Gallery (client pictures)", "uses_ai": True, "task": "gallery_sort",
     "job": "Puts every picture a client sends into the right room / subject folder of the project Gallery.",
     "instructions": "From the client's words and the picture, choose the room (e.g. Living room, Master bedroom, Kitchen) and the subject "
                     "(e.g. Lighting, Flooring, Furniture, Colours). If unsure, use Random.",
     "examples": [], "knowledge": "", "rules": "Never share a client's pictures outside their project."},
    {"id": "courtyard", "name": "Courtyard Host", "where": "The Courtyard", "uses_ai": True, "task": "",
     "job": "Writes the welcome note for each new member, keeps rooms friendly, and suggests who should meet whom.",
     "instructions": "Write warm, short welcome notes: name, city, what they do, one line about their work. Suggest introductions between architects and makers "
                     "who share a city, style or material.",
     "examples": [{"q": "New member: Stone Age, Mumbai, marble & stone", "a": "Welcome Stone Age from Mumbai — makers of marble and stone surfaces. Say hello and see their latest slabs!"}],
     "knowledge": "", "rules": "Be kind. No selling. No phone numbers in open spaces."},
    {"id": "magazine", "name": "Magazine Editor", "where": "The Courtyard Magazine", "uses_ai": True, "task": "",
     "job": "Puts together the monthly Courtyard Magazine and writes short, beautiful text for each story.",
     "instructions": "Write like a quiet-luxury design magazine: short, elegant, specific about materials and light. 40–80 words per story.",
     "examples": [], "knowledge": "", "rules": "Only use approved posts. Credit every architect and maker."},
]


def load():
    try:
        with open(BOTS_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    d.setdefault("ai", {"provider": "anthropic", "model": "claude-haiku-5-5", "key": "", "enabled": False, "monthly_limit": 2000,
                        "local_url": "http://localhost:11434"})
    d["ai"]["key"] = vault.reveal(d["ai"].get("key", ""))      # the AI key is locked on disk (see vault.py)
    d["ai"].setdefault("monthly_limit", 2000)
    d["ai"].setdefault("local_url", "http://localhost:11434")
    d.setdefault("cache", {})
    d.setdefault("bots", {})
    for b in DEFAULT_BOTS:
        cur = d["bots"].setdefault(b["id"], dict(json.loads(json.dumps(b)), on=True, versions=[], updated=""))
        for k in ("name", "where", "job", "task", "uses_ai"):
            cur.setdefault(k, b[k])
    d.setdefault("log", [])
    return d


def save(d):
    os.makedirs(os.path.dirname(BOTS_FILE), exist_ok=True)
    tmp = BOTS_FILE + ".tmp"
    out = dict(d, ai=dict(d.get("ai") or {}))
    out["ai"]["key"] = vault.lock(out["ai"].get("key", ""))
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    os.replace(tmp, BOTS_FILE)


def ai_ready(d=None):
    d = d or load()
    ai = d["ai"]
    return bool(ai.get("enabled") and (ai.get("key") or ai.get("provider") == "local"))


def month_calls(d):
    m = datetime.now().strftime("%Y-%m")
    return sum(1 for l in d["log"] if l["time"].startswith(m) and l.get("who") != "owner test")


def public_ai(ai):
    k = ai.get("key") or ""
    return {"provider": ai.get("provider"), "model": ai.get("model"), "enabled": ai.get("enabled"), "local_url": ai.get("local_url"),
            "monthly_limit": ai.get("monthly_limit"), "key_set": bool(k), "key_hint": ("…" + k[-4:]) if len(k) > 8 else ""}


# ---------------------------------------------------------------- talking to the AI

def ai_chat(ai, system, messages, max_tokens=700):
    provider = ai.get("provider") or "anthropic"
    if provider == "anthropic":
        url = "https://api.anthropic.com/v1/messages"
        body = {"model": ai.get("model") or "claude-haiku-5-5", "max_tokens": max_tokens, "system": system, "messages": messages}
        headers = {"x-api-key": ai["key"], "anthropic-version": "2023-06-01", "content-type": "application/json"}
    else:
        # OpenAI, or a FREE model running on this computer (Ollama speaks the same language)
        url = ("https://api.openai.com/v1/chat/completions" if provider == "openai"
               else (ai.get("local_url") or "http://localhost:11434").rstrip("/") + "/v1/chat/completions")
        body = {"model": ai.get("model") or ("gpt-4o-mini" if provider == "openai" else "llama3.2"), "max_tokens": max_tokens,
                "messages": [{"role": "system", "content": system}] + messages}
        headers = {"content-type": "application/json"}
        if provider == "openai":
            headers["Authorization"] = "Bearer " + ai["key"]
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=180 if provider == "local" else 60) as r:
            out = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("error", {})
            msg = msg.get("message") if isinstance(msg, dict) else str(msg)
        except Exception:
            msg = ""
        raise ApiError(502, f"The AI said no ({e.code}). {msg or 'Check the key and model name.'}")
    except (urllib.error.URLError, OSError):
        if provider == "local":
            raise ApiError(503, "The free AI on this computer isn't running. Install Ollama and start it, or choose Claude / ChatGPT.")
        raise ApiError(503, "Can't reach the AI right now. Check the internet on the Design Lab computer.")
    if provider == "anthropic":
        text = "".join(c.get("text", "") for c in out.get("content", []) if c.get("type") == "text")
        u = out.get("usage", {})
        tokens = (u.get("input_tokens", 0), u.get("output_tokens", 0))
    else:
        text = out["choices"][0]["message"]["content"]
        u = out.get("usage", {})
        tokens = (u.get("prompt_tokens", 0), u.get("completion_tokens", 0))
    return text.strip(), tokens


def system_for(bot):
    parts = [bot.get("instructions", "")]
    if bot.get("rules"):
        parts.append("House rules (always follow):\n" + bot["rules"])
    if bot.get("knowledge"):
        parts.append("Knowledge you can use:\n" + bot["knowledge"][:12000])
    ex = (bot.get("examples") or [])[:20] + (bot.get("learned") or [])[:20]
    if ex:
        parts.append("Examples of good answers:\n" + "\n\n".join(f"Q: {e['q']}\nA: {e['a']}" for e in ex))
    return "\n\n".join(p for p in parts if p)


def fallback(bot, text):
    """No AI: answer from the bot's own examples / knowledge (simple word match)."""
    words = set(re.findall(r"[a-z0-9]{3,}", text.lower()))
    best, score = None, 0
    for e in bot.get("examples", []) + bot.get("learned", []):
        w = set(re.findall(r"[a-z0-9]{3,}", e["q"].lower()))
        sc = len(words & w)
        if sc > score:
            best, score = e, sc
    if best and score:
        return best["a"]
    for para in re.split(r"\n\s*\n", bot.get("knowledge", "")):
        w = set(re.findall(r"[a-z0-9]{3,}", para.lower()))
        if len(words & w) >= 2:
            return para.strip()[:600]
    return None


def learn(bot_id, question, answer, who=""):
    """A person corrected a bot's answer: keep the correction as an example (free training)."""
    d = load()
    bot = d["bots"].get(bot_id)
    q, a = str(question or "").strip()[:1500], str(answer or "").strip()[:3000]
    if not bot or len(q) < 3 or len(a) < 3:
        return {"ok": False}
    bot.setdefault("learned", []).insert(0, {"q": q, "a": a, "who": who, "time": datetime.now().isoformat(timespec="seconds")})
    bot["learned"] = bot["learned"][:200]
    save(d)
    return {"ok": True}


def run(bot_id, text, who="", history=None):
    """Use a bot. Returns {"answer", "ai": bool, "tokens"}."""
    d = load()
    bot = d["bots"].get(bot_id)
    if not bot or not bot.get("on"):
        raise ApiError(403, "This bot is switched off.")
    text = str(text or "").strip()[:6000]
    if not text:
        raise ApiError(400, "Nothing to answer.")
    key = re.sub(r"[^a-z0-9 ]", "", text.lower()).strip()
    if bot_id == "frontdesk" and not history and key in d["cache"] and time.time() - d["cache"][key]["t"] < 7 * 86400:
        return {"answer": d["cache"][key]["a"], "ai": False, "tokens": (0, 0), "cached": True}     # same question again: free
    if bot.get("uses_ai") and ai_ready(d) and (who == "owner test" or month_calls(d) < float(d["ai"].get("monthly_limit") or 0)):
        msgs = [m for m in (history or [])[-8:] if m.get("role") in ("user", "assistant")] + [{"role": "user", "content": text}]
        answer, tokens = ai_chat(d["ai"], system_for(bot), msgs)
        if bot_id == "frontdesk" and not history:
            d["cache"][key] = {"a": answer, "t": time.time()}
            if len(d["cache"]) > 500:
                for k in sorted(d["cache"], key=lambda k: d["cache"][k]["t"])[:100]:
                    d["cache"].pop(k, None)
        d["log"].insert(0, {"time": datetime.now().isoformat(timespec="seconds"), "bot": bot_id, "who": who, "tokens": tokens})
        d["log"] = d["log"][:3000]
        save(d)
        return {"answer": answer, "ai": True, "tokens": tokens}
    ans = fallback(bot, text)
    return {"answer": ans or "", "ai": False, "tokens": (0, 0)}


# ---------------------------------------------------------------- owner dashboard → Bots

def admin(method, sub, b):
    d = load()
    parts = [p for p in sub.split("/") if p]
    head = parts[0] if parts else "state"
    if head == "state":
        month = datetime.now().strftime("%Y-%m")
        use = {}
        for l in d["log"]:
            if l["time"].startswith(month):
                u = use.setdefault(l["bot"], {"calls": 0, "tokens": 0})
                u["calls"] += 1
                u["tokens"] += sum(l.get("tokens") or (0, 0))
        return {"ai": public_ai(d["ai"]), "ready": ai_ready(d), "month_calls": month_calls(d),
                "bots": [dict({k: v for k, v in bot.items() if k != "versions"}, id=bid, versions=len(bot.get("versions", [])),
                              use=use.get(bid, {"calls": 0, "tokens": 0})) for bid, bot in d["bots"].items()]}
    if head == "bot" and len(parts) > 1:
        bot = d["bots"].get(parts[1])
        if not bot:
            raise ApiError(404, "No such bot.")
        if method == "GET":
            return {"bot": dict(bot, id=parts[1])}
        act = b.get("act") or "save"
        if act == "toggle":
            bot["on"] = not bot.get("on")
        elif act == "forget":
            i = int(b.get("index", -1))
            if 0 <= i < len(bot.get("learned", [])):
                bot["learned"].pop(i)
        elif act == "promote":
            i = int(b.get("index", -1))
            if 0 <= i < len(bot.get("learned", [])):
                e = bot["learned"].pop(i)
                bot.setdefault("examples", []).append({"q": e["q"], "a": e["a"]})
        elif act == "restore":
            v = next((x for x in bot.get("versions", []) if x["id"] == b.get("version")), None)
            if not v:
                raise ApiError(404, "That version is gone.")
            for k in ("instructions", "examples", "knowledge", "rules"):
                bot[k] = v[k]
        else:
            # keep the previous training as a version before changing it
            bot.setdefault("versions", []).insert(0, {"id": secrets.token_hex(4), "time": datetime.now().isoformat(timespec="seconds"),
                                                      **{k: bot.get(k) for k in ("instructions", "examples", "knowledge", "rules")}})
            bot["versions"] = bot["versions"][:30]
            for k, n in (("instructions", 8000), ("knowledge", 60000), ("rules", 3000), ("job", 500)):
                if k in b:
                    bot[k] = str(b.get(k) or "")[:n]
            if isinstance(b.get("examples"), list):
                bot["examples"] = [{"q": str(e.get("q", ""))[:1000], "a": str(e.get("a", ""))[:2000]}
                                   for e in b["examples"] if str(e.get("q", "")).strip() and str(e.get("a", "")).strip()][:60]
            bot["updated"] = datetime.now().isoformat(timespec="seconds")
        save(d)
        return {"bot": dict(bot, id=parts[1])}
    if head == "test" and method == "POST":
        r = run(str(b.get("bot")), b.get("message"), "owner test", b.get("history") or [])
        if not r["answer"]:
            r["answer"] = ("(AI is not connected, and nothing in this bot's examples or knowledge matches. "
                           "Connect the AI above, or add an example for this question.)")
        return r
    if head == "ai" and method == "POST":
        ai = d["ai"]
        if b.get("provider") in ("anthropic", "openai", "local"):
            ai["provider"] = b["provider"]
        if b.get("model"):
            ai["model"] = str(b["model"]).strip()[:80]
        if b.get("key"):
            ai["key"] = str(b["key"]).strip()[:300]
        if b.get("clear_key"):
            ai["key"] = ""
        if "enabled" in b:
            ai["enabled"] = bool(b["enabled"])
        if b.get("provider") == "local":
            ai["provider"] = "local"
        if b.get("local_url"):
            ai["local_url"] = str(b["local_url"]).strip()[:200]
        if "monthly_limit" in b:
            try:
                ai["monthly_limit"] = int(float(b["monthly_limit"] or 0))
            except ValueError:
                pass
        save(d)
        if b.get("check"):
            if not ai.get("key") and ai.get("provider") != "local":
                raise ApiError(400, "Paste the AI key first.")
            t0 = time.time()
            text, _ = ai_chat(ai, "Reply with exactly: Design Lab is connected.", [{"role": "user", "content": "Hello"}], 30)
            return {"ai": public_ai(ai), "check": f"Connected ✓ ({text[:60]}) in {time.time() - t0:.1f}s"}
        return {"ai": public_ai(ai)}
    raise ApiError(404, "Unknown request.")
