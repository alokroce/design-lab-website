@echo off
title Design Lab
cd /d "%~dp0"
echo.
echo   DESIGN LAB
echo   ----------
echo.
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && python -c "import sys" >nul 2>nul && set "PY=python"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe""
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\Python313\python.exe""
if defined PY goto run
echo   Design Lab needs Python (free). Installing it now - this takes 2 to 5 minutes.
echo   If Windows asks "Do you want to allow this app to make changes", click Yes.
echo.
winget install -e --id Python.Python.3.12 --scope user --accept-source-agreements --accept-package-agreements
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe""
if defined PY goto run
echo.
echo   Python could not be installed automatically.
echo   Please install it from https://www.python.org/downloads/  (tick "Add python.exe to PATH"),
echo   then double-click START DESIGN LAB again.
pause
exit /b
:run
echo   Starting Design Lab. Keep the two small windows open while you work.
start "Design Lab - business (keep open)" /min /d "%~dp0business" %PY% cloud.py
start "Design Lab - studio (keep open)" /min /d "%~dp0client-software" %PY% server.py
timeout /t 5 /nobreak >nul
start "" http://localhost:8750
echo.
echo   Design Lab is open in your browser: http://localhost:8750
echo   If Windows Firewall asks, click "Allow" so your phone can open Design Lab on the same Wi-Fi.
echo.
echo   You can close this window.
timeout /t 15 >nul
