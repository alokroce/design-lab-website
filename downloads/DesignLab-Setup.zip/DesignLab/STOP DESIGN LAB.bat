@echo off
title Design Lab - stop
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'server.py|cloud.py' -and $_.Name -match 'py' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
echo Design Lab has stopped. Your projects and files are safe.
timeout /t 4 >nul
