"""
Design Lab - the DEMO copy that is shared by link (double-click SHARE DESIGN LAB).

Runs as a second copy of the studio software (port 8760) with its own folder:
    C:\\design lab\\designlab system\\demo
so visitors never see the real studio.

- Filled with sample projects, contacts, vendors, Business figures, a mood board and social media pictures.
- "New user · Register" works for visitors from anywhere: details -> payment (test QR) -> choose user ID.
  Instead of making a new firm, the visitor is added to the demo studio, and their access ends after 3 days.
- Every visitor (name, firm, phone, email) is written to demo\\demo_visitors.json for the owner (leads).
"""
import os
import re
import secrets
import shutil
import threading
import time
from datetime import datetime, timedelta

S = None  # server module
SEED_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo-seed")
PENDING = {}            # registration id -> details while a visitor registers
DEMO_DAYS = 3
FIRM_NAME = "Design Lab Demo Studio"


def visitors_file():
    return os.path.join(S.HOME_DIR, "demo_visitors.json")


# ---------------------------------------------------------------- registration for visitors

def _rid(rid):
    rid = (rid or "").strip()
    if not re.match(r"^[A-Za-z0-9]{8,40}$", rid):
        raise S.ApiError(400, "Please reload the page and try again.")
    return rid


def reg_start(rid, body):
    rid = _rid(rid)
    d = {k: str(body.get(k) or "").strip()[:200] for k in
         ("kind", "profession", "firm", "name", "designation", "city", "address", "phone", "email")}
    if not d["profession"]:
        raise S.ApiError(400, "Choose what you are, or type it under Other.")
    if not d["firm"] or not d["name"]:
        raise S.ApiError(400, "Please enter your firm name and your name.")
    if not d["phone"] and not d["email"]:
        raise S.ApiError(400, "Please enter a phone number or an email.")
    if d["phone"] and len(S.norm_phone(d["phone"])) < 10:
        raise S.ApiError(400, "Please enter a 10-digit phone number.")
    if d["email"] and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", d["email"]):
        raise S.ApiError(400, "That email address doesn't look right.")
    vendor = d["kind"] == "vendor"
    fee = 25000 if vendor else 10000
    gst = round(fee * 0.18, 2)
    gw = round((fee + gst) * 0.02, 2)
    order = {"id": "DEMO-" + secrets.token_hex(3).upper(), "amount": fee, "gst": gst, "gateway": gw, "total": round(fee + gst + gw, 2),
             "status": "awaiting payment"}
    pay = {"upi": f"upi://pay?pa=designlab.test@upi&pn=Design%20Lab%20DEMO&am={order['total']:.2f}&cu=INR&tn={order['id']}",
           "test": True, "payee": "designlab.test@upi"}
    PENDING[rid] = {"details": d, "order": order, "time": time.time()}
    for k in [k for k, v in PENDING.items() if time.time() - v["time"] > 3600]:
        PENDING.pop(k, None)
    _log_visitor(d, "started registration")
    return {"order": order, "pay": pay}


def reg_pay(rid, body):
    p = PENDING.get(_rid(rid))
    if not p:
        raise S.ApiError(400, "Please fill in your details first.")
    p["paid"] = True
    return {"code": "DEMO"}


def reg_finish(rid, body, ip):
    p = PENDING.get(_rid(rid))
    if not p or not p.get("paid"):
        raise S.ApiError(402, "Please complete the payment step first.")
    d = p["details"]
    uid = (body.get("user_id") or "").strip().lower()
    pw = body.get("password") or ""
    if not re.match(r"^[a-z0-9._\-]{3,30}$", uid):
        raise S.ApiError(400, "User ID: 3–30 letters, numbers, dots or dashes, no spaces.")
    if pw != (body.get("password2") or ""):
        raise S.ApiError(400, "The two passwords don't match.")
    problem = S.password_problem(pw)
    if problem:
        raise S.ApiError(400, problem)
    with S.LOCK:
        firm = S.load_firm()
        if any(u["id"] == uid for u in firm["users"]):
            raise S.ApiError(400, "That user ID is taken in the demo. Please choose another.")
        if S.contact_taken(firm, d["phone"], d["email"]):
            # same person trying again: let them in with a fresh account
            firm["users"] = [u for u in firm["users"] if not (u.get("demo_until") and
                             ((d["phone"] and S.norm_phone(u.get("phone", "")) == S.norm_phone(d["phone"])) or
                              (d["email"] and (u.get("email") or "").lower() == d["email"].lower())))]
        salt, digest = S.hash_password(pw)
        until = (datetime.now() + timedelta(days=DEMO_DAYS)).isoformat(timespec="seconds")
        firm["users"].append({"id": uid, "name": d["name"], "role": "designer", "salt": salt, "hash": digest,
                              "profession": d["profession"], "designation": d["designation"] or ("Owner / Proprietor" if d.get("kind") == "vendor" else "Principal"),
                              "phone": d["phone"], "email": S.norm_email(d["email"]), "status": "active",
                              "added": S.now_iso(), "demo_until": until, "demo_firm": d["firm"], "demo_city": d["city"],
                              "demo_kind": "vendor" if d.get("kind") == "vendor" else "designer"})
        firm.setdefault("private_access", []).append(uid)
        S.save_json(S.firm_file(), firm)
    PENDING.pop(rid, None)
    _log_visitor(d, "joined the demo", uid)
    S.security_log("demo visitor joined", uid, ip)
    tok = S.session_new(uid, True)
    return {"token": tok, "name": d["name"], "firm": "Design Lab Demo Showroom" if d.get("kind") == "vendor" else FIRM_NAME,
            "recovery_code": "DEMO-ONLY-NOT-NEEDED"}


def _log_visitor(d, what, uid=""):
    try:
        with S.LOCK:
            v = S.load_json(visitors_file(), [])
            v.insert(0, {"time": S.now_iso(), "what": what, "user_id": uid, "name": d.get("name"), "firm": d.get("firm"),
                         "profession": d.get("profession"), "city": d.get("city"), "phone": d.get("phone"), "email": d.get("email")})
            S.save_json(visitors_file(), v[:2000])
    except Exception as exc:
        print("Demo visitor log:", exc)


# ---------------------------------------------------------------- the demo studio, filled with sample work

def _img(name):
    return os.path.join(SEED_DIR, name)


def _copy(name, folder, new_name=None):
    os.makedirs(folder, exist_ok=True)
    src = _img(name)
    if os.path.isfile(src):
        dst = os.path.join(folder, new_name or name)
        if not os.path.exists(dst):
            shutil.copy2(src, dst)
        return os.path.basename(dst)
    return None


def seed():
    with S.LOCK:
        if S.load_firm():
            return
        print("  Making the demo studio with sample work …")
        root = S.default_root()
        os.makedirs(os.path.join(root, ".designlab"), exist_ok=True)
        cfg = S.config()
        cfg["projects_root"] = S.store_root(root)
        cfg["testing_mode"] = False
        S.save_json(S.CONFIG_FILE, cfg)
        salt, digest = S.hash_password(secrets.token_urlsafe(18) + "9a")
        firm = {"firm": FIRM_NAME, "created": S.now_iso(), "code": "DEMO", "kind": "designer", "profession": "Interior designer",
                "city": "Mumbai", "address": "Sample studio", "phone": "", "email": "", "demo": True,
                "users": [{"id": "demo-owner", "name": "Design Lab", "role": "owner", "salt": salt, "hash": digest,
                           "designation": "Principal", "status": "active", "added": S.now_iso()}],
                "private_access": []}
        S.save_json(S.firm_file(), firm)
        S.save_json(os.path.join(root, ".designlab", "assistant.json"),
                    {"step": "ready", "messages": [{"id": "d1", "time": S.now_iso(), "from": "bot",
                     "text": "Welcome to the Design Lab demo! Everything here is sample work, so explore freely. "
                             "Try typing **help**, **find marble**, **electrician** or **new project Worli flat for Mr Shah**."}],
                     "flags": {}, "imported": []})
        owner = {"id": "demo-owner", "name": "Design Lab"}
        today = datetime.now()
        day = lambda n: (today + timedelta(days=n)).strftime("%Y-%m-%d")
        projects = [
            ("Juhu Sea-facing Residence", "Mr & Mrs Kapoor", "Juhu Tara Road, Mumbai", ["marble.jpg", "teak.jpg", "lime-plaster.jpg"],
             "Quiet luxury by the sea: Statuario marble, teak, lime plaster walls, brass details, soft warm light."),
            ("Bandra Boutique Café", "Bean & Co.", "Pali Hill, Bandra West", ["terrazzo.jpg", "brass.jpg", "teak.jpg"],
             "Terrazzo floor, brass bar edge, warm teak counters; relaxed and bright by day, glowing at night."),
            ("Alibaug Weekend Villa", "The Mehra family", "Awas, Alibaug", ["lime-plaster.jpg", "teak.jpg", "terrazzo.jpg"],
             "Lime-washed walls, Kota stone, teak louvres, courtyard planting; barefoot and breezy."),
        ]
        contacts = {
            0: [("client", "Mr Rohan Kapoor", "Owner", "", "98200 10001"), ("client", "Mrs Anya Kapoor", "Wife", "", "98200 10002"),
                ("contractor", "Suresh Patil", "Civil", "Patil Constructions", "98200 10003"), ("contractor", "Ramesh Yadav", "Electrical", "Volt Works", "98200 10004"),
                ("vendor", "Imran Shaikh", "Marble & stone", "Stone Age Marbles", "98200 10005"), ("vendor", "Neha Jain", "Lighting", "Lumen House", "98200 10006")],
            1: [("client", "Karan Mehta", "Owner", "", "98200 10011"), ("contractor", "Anil Gupta", "Carpentry", "Woodline Interiors", "98200 10012"),
                ("vendor", "Farah Khan", "Tiles", "Terrazzo Co.", "98200 10013")],
            2: [("client", "Mr Vikram Mehra", "Owner", "", "98200 10021"), ("contractor", "Joseph D'Souza", "Plumbing", "Aqua Fix", "98200 10022"),
                ("vendor", "Pooja Shah", "Fabric & upholstery", "Loom & Weave", "98200 10023")],
        }
        notes = {
            0: [("decision", "Living room", "Client approved Statuario for the living room floor, book-matched."),
                ("change", "Master bedroom", "Change wardrobe shutters to fluted glass with bronze frame."),
                ("action", "Kitchen", "Electrician to shift two points behind the island by Monday.")],
            1: [("note", "Bar", "Brass edge sample to be checked under warm 2700K light."),
                ("action", "Seating", "Upholstery samples to reach the site by Friday.")],
            2: [("decision", "Courtyard", "Keep the old neem tree; deck to step around it."),
                ("note", "Bathrooms", "Lime plaster with tadelakt finish in both bathrooms.")],
        }
        for i, (name, client, addr, mood, words) in enumerate(projects):
            proj = S.new_project({"name": name, "client": client, "address": addr}, owner, quiet=True)
            pdir = proj["_dir"]
            proj["contacts"] = [S.clean_contact({"kind": k, "name": n, "relation": r if k == "client" else "", "trade": r if k != "client" else "",
                                                 "company": c, "phone": ph}) for k, n, r, c, ph in contacts[i]]
            proj["events"] = [{"id": secrets.token_hex(3), "title": "Site visit with client", "date": day(1 + i), "time": "11:00", "kind": "meeting"},
                              {"id": secrets.token_hex(3), "title": "Material selection at showroom", "date": day(4 + i), "time": "16:30", "kind": "meeting"}]
            proj["snags"] = [{"id": secrets.token_hex(3), "time": S.now_iso(), "room": "Living room" if i == 0 else "General",
                              "text": "Skirting gap near the window", "owner": contacts[i][2][1], "due": day(3), "status": "open"}]
            proj["notes"] = [{"id": secrets.token_hex(3), "time": S.now_iso(), "by": "Design Lab", "room": r, "kind": k, "text": t} for k, r, t in notes[i]]
            mb_dir = os.path.join(pdir, "09 Mood Board")
            proj["moodboard"] = {"words": words, "images": [x for x in (_copy(m, mb_dir, f"mood {j + 1} {m}") for j, m in enumerate(mood)) if x]}
            _copy("living-room.jpg", os.path.join(pdir, "02 3D", "Renders"), "living room view 1.jpg")
            _copy(mood[0], os.path.join(pdir, "03 Site Photos", day(-2)), "site sample.jpg")
            S.add_log(proj, "project", "Sample project for the Design Lab demo")
            S.save_project(proj)
        # studio list, business, social board
        import book
        import records
        for p in contacts.values():
            book.learn([S.clean_contact({"kind": k, "name": n, "trade": r, "company": c, "phone": ph}) for k, n, r, c, ph in p if k != "client"])
        R = lambda kind, items: S.save_json(os.path.join(root, ".designlab", "records", kind + ".json"),
                                            [dict(it, id=secrets.token_hex(5), created=S.now_iso(), by="Design Lab") for it in items])
        os.makedirs(os.path.join(root, ".designlab", "records"), exist_ok=True)
        R("hours", [{"date": day(-d), "person": who, "project": pr, "hours": h, "work": w} for d, who, pr, h, w in
                    [(1, "Aalok", "Juhu Sea-facing Residence", 4, "Living room details"), (2, "Priya", "Bandra Boutique Café", 6, "Bar elevations"),
                     (3, "Aalok", "Alibaug Weekend Villa", 3, "Client meeting"), (5, "Priya", "Juhu Sea-facing Residence", 7, "Lighting layout")]])
        R("expenses", [{"date": day(-d), "project": pr, "category": c, "amount": a, "paid_by": "Studio", "bill": "", "note": ""} for d, pr, c, a in
                       [(1, "Juhu Sea-facing Residence", "Samples", 8500), (2, "Bandra Boutique Café", "Site travel", 1200), (4, "Office", "Software", 4999)]])
        R("fees", [{"date": day(-30), "project": "Juhu Sea-facing Residence", "client": "Mr & Mrs Kapoor", "type": "Fee agreed", "amount": 1800000, "mode": "", "note": ""},
                   {"date": day(-20), "project": "Juhu Sea-facing Residence", "client": "Mr & Mrs Kapoor", "type": "Payment received", "amount": 600000, "mode": "Bank", "note": ""},
                   {"date": day(-15), "project": "Bandra Boutique Café", "client": "Bean & Co.", "type": "Fee agreed", "amount": 450000, "mode": "", "note": ""},
                   {"date": day(-5), "project": "Bandra Boutique Café", "client": "Bean & Co.", "type": "Payment received", "amount": 150000, "mode": "UPI", "note": ""}])
        R("ledger", [{"date": day(-7), "party": "Sample entry", "project": "Demo", "direction": "Received", "amount": 10000, "photo": "", "note": "Private, password-locked"}])
        # vendor side samples (shown to visitors who register as a vendor)
        fdir = os.path.join(root, ".designlab", "records", "files")
        os.makedirs(fdir, exist_ok=True)
        photo = {}
        for m in ("marble.jpg", "teak.jpg", "terrazzo.jpg", "brass.jpg", "lime-plaster.jpg"):
            n = secrets.token_hex(10) + ".jpg"
            if _copy(m, fdir, n):
                photo[m] = n
        R("catalog", [{"name": n, "category": c, "code": code, "price": pr, "unit": u, "stock": st, "lot": lot, "reserved": res,
                       "photo": photo.get(img, ""), "note": ""} for n, c, code, pr, u, st, lot, res, img in
                      [("Statuario Venato", "Marble", "ST-221", 1450, "sq ft", 820, "Lot 14 · book-matched", "Juhu Sea-facing Residence", "marble.jpg"),
                       ("Burma Teak veneer", "Veneer", "BT-08", 310, "sq ft", 2400, "Bundle 3", "", "teak.jpg"),
                       ("Venetian terrazzo", "Tiles", "TZ-90", 260, "sq ft", 1500, "Batch B", "Bandra Boutique Café", "terrazzo.jpg"),
                       ("Brushed brass trim", "Hardware", "BR-12", 980, "running ft", 400, "", "", "brass.jpg"),
                       ("Lime plaster finish", "Wall finish", "LP-02", 145, "sq ft", 0, "Made to order", "", "lime-plaster.jpg")]])
        R("v_architects", [{"name": n, "firm": f, "city": c, "phone": ph, "email": "", "projects": pr, "specified": sp, "last_contact": day(-d), "next_step": nx, "note": ""}
                           for n, f, c, ph, pr, sp, d, nx in
                           [("Aalok", "Sample Design Studio", "Mumbai", "98200 20001", "Juhu residence", "Statuario, brass trim", 2, "Send lot photos"),
                            ("Riya Desai", "Desai Architects", "Bengaluru", "98200 20002", "Indiranagar villa", "Terrazzo", 6, "Showroom visit"),
                            ("Kabir Rao", "Studio KR", "Pune", "98200 20003", "Office fit-out", "Teak veneer", 12, "Revised quote")]])
        R("samples", [{"item": i, "architect": a, "project": p, "sent": day(-d), "follow_up": day(f), "status": st, "note": ""} for i, a, p, d, f, st in
                      [("Statuario 30x30", "Sample Design Studio", "Juhu residence", 6, -1, "Sent"),
                       ("Terrazzo chips board", "Desai Architects", "Indiranagar villa", 3, 2, "Followed up"),
                       ("Teak veneer 1x2 ft", "Studio KR", "Office fit-out", 20, -10, "Approved")]])
        R("quotes", [{"ref": r, "party": p, "project": pr, "date": day(-d), "amount": a, "version": v, "status": st, "file": "", "note": ""} for r, p, pr, d, a, v, st in
                     [("Q-118", "Sample Design Studio", "Juhu residence", 4, 1240000, 2, "Revised"), ("Q-121", "Desai Architects", "Indiranagar villa", 1, 380000, 1, "Quoted"),
                      ("Q-109", "Studio KR", "Office fit-out", 18, 220000, 1, "Approved")]])
        R("orders", [{"ref": r, "party": p, "project": pr, "items": it, "amount": a, "due": day(d), "status": st, "note": ""} for r, p, pr, it, a, d, st in
                     [("O-77", "Studio KR", "Office fit-out", "Teak veneer 700 sq ft", 217000, 5, "In production"),
                      ("O-75", "Sample Design Studio", "Juhu residence", "Statuario 600 sq ft", 870000, 1, "Ready"),
                      ("O-70", "Desai Architects", "Indiranagar villa", "Terrazzo 900 sq ft", 234000, -4, "Delivered")]])
        R("dispatch", [{"order": "O-75 Statuario 600 sq ft", "date": day(0), "slot": "10am–1pm", "vehicle": "MH-02 AB 1234", "driver": "Sunil",
                        "driver_phone": "98200 30001", "site": "Juhu Tara Road, Mumbai", "site_contact": "Suresh Patil", "site_phone": "98200 10003",
                        "loading": "Our team", "status": "Planned", "note": ""}])
        R("sitejobs", [{"type": "Installation", "site": "Indiranagar villa", "date": day(0), "team": "Team B", "contact": "98200 20002", "status": "Planned", "note": ""}])
        R("accounts", [{"ref": "INV-301", "party": "Desai Architects", "date": day(-10), "amount": 234000, "received": 100000, "due": day(-2), "status": "Part paid", "note": ""},
                       {"ref": "INV-305", "party": "Studio KR", "date": day(-3), "amount": 110000, "received": 0, "due": day(12), "status": "Due", "note": ""}])
        soc = os.path.join(root, "Social Media")
        for j, m in enumerate(["living-room.jpg", "marble.jpg", "terrazzo.jpg"]):
            _copy(m, os.path.join(soc, "To review" if j else "Wanted", "Photos"), f"{day(-j)} {m}")
    threading.Thread(target=_seed_courtyard, daemon=True).start()


def _seed_courtyard():
    """Join The Courtyard as the demo studio (when Design Lab's server is running) and share one Gallery post."""
    time.sleep(3)
    try:
        with S.LOCK:
            firm = S.load_firm()
            if S.cloud_cfg(firm).get("url") or firm.get("courtyard_tried"):
                return
            firm["courtyard_tried"] = True
            S.save_json(S.firm_file(), firm)
        url = S.cloud_url()
        r = S.cloud_call(None, "/api/signup", {"name": "Design Lab", "firm": FIRM_NAME, "email": "demo@designlab.local", "phone": "",
                                              "city": "Mumbai", "kind": "designer", "profession": "Interior designer"}, {"url": url})
        a = S.cloud_call(None, "/api/pay/test", {"order": r["order"]["id"], "skip": True}, {"url": url})
        with S.LOCK:
            firm = S.load_firm()
            firm["cloud"] = {"url": url, "code": a["code"], "key": a["key"], "linked": S.now_iso(), "firm_name": FIRM_NAME}
            firm["code"] = a["code"]
            S.save_json(S.firm_file(), firm)
        firm = S.load_firm()
        import base64
        imgs = []
        for m in ("living-room.jpg", "marble.jpg", "teak.jpg"):
            with open(_img(m), "rb") as f:
                imgs.append("data:image/jpeg;base64," + base64.b64encode(f.read()).decode())
        hdr = {"X-User-Id": "demo-owner", "X-User-Name": "Design%20Lab", "X-User-Role": "owner"}
        S.cloud_call(firm, "/api/studio/courtyard/profile", {"about": "This is the Design Lab demo studio — sample work to show how Design Lab feels.",
                                                              "city": "Mumbai", "trades": ["Demo", "Residences", "Hospitality"]}, headers=hdr, timeout=20)
        S.cloud_call(firm, "/api/studio/courtyard/post", {"type": "gallery", "title": "Juhu Sea-facing Residence (sample)",
                                                           "text": "Statuario, teak and lime plaster — a sample project in the Design Lab demo.",
                                                           "images": imgs, "city": "Mumbai"}, headers=hdr, timeout=30)
    except Exception as exc:
        print("  Demo: The Courtyard isn't reachable right now (", exc, ")")
