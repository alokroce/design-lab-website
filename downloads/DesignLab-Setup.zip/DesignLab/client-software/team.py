"""Team: invitations (join a team), job titles, Courtyard access per member, profile & settings,
dashboard choices, feature requests, and what each member uses.

The owner invites; the member makes their own user ID and password. New members never get
The Courtyard automatically — the owner is asked, and ticks the sections they may use.
"""
import re
import secrets
import time
from datetime import datetime, timedelta

S = None   # server module (set by server.py)

ARCH_ROLES = ["Principal", "Partner", "Associate", "Senior designer", "Designer", "Junior designer", "Site supervisor",
              "Draughtsman", "Office admin", "Accounts"]
VENDOR_ROLES = ["Owner", "Sales", "Showroom manager", "Accounts", "Logistics / dispatch", "Site / installation", "Production"]

# The Courtyard sections an owner can open for a member (Perspective: read and comment are separate)
CY_SECTIONS = [("community", "Community"), ("people", "People"), ("messages", "Messages"), ("events", "Open House"),
               ("perspective_read", "Perspective — read"), ("perspective_comment", "Perspective — comment")]
CY_ALL = {k: True for k, _ in CY_SECTIONS}

DASH_BLOCKS = [("kpis", "Numbers at the top"), ("coming", "Coming up"), ("happened", "What happened")]

JOIN_FAILS = {}
INVITE_DAYS = 7


def roles_for(firm):
    base = VENDOR_ROLES if (firm or {}).get("kind") == "vendor" else ARCH_ROLES
    extra = [r for r in (firm.get("custom_roles") or []) if r not in base]
    return base + extra


def remember_role(firm, designation):
    d = str(designation or "").strip()[:60]
    if d and d not in roles_for(firm) and d.lower() != "other":
        firm.setdefault("custom_roles", []).append(d)
    return d


# ---------------------------------------------------------------- invitations

def _code():
    a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(a) for _ in range(4)) + "-" + "".join(secrets.choice(a) for _ in range(4))


def invites_view(firm):
    now = S.now_iso()
    return [dict(i) for i in firm.get("invites", []) if i.get("expires", "") > now]


def invite_new(firm, user, body):
    if user.get("role") != "owner":
        raise S.ApiError(403, "Only the owner can invite people.")
    name = str(body.get("name") or "").strip()[:80]
    if not name:
        raise S.ApiError(400, "Write the person's name.")
    active = sum(1 for u in firm["users"] if u.get("status", "active") == "active")
    pending = len(invites_view(firm))
    extra = active + pending + 1 - S.INCLUDED_USERS
    if extra > 0 and not body.get("confirm"):
        return {"confirm": True, "extra": extra, "fee": S.EXTRA_USER_FEE, "monthly": extra * S.EXTRA_USER_FEE,
                "text": f"When {name} joins you will have {extra} extra user{'s' if extra != 1 else ''}: "
                        f"Rs {extra * S.EXTRA_USER_FEE} a month on top of your subscription (Rs {S.EXTRA_USER_FEE} more than now)."}
    role = body.get("role") if body.get("role") in ("designer", "site") else "designer"
    inv = {"code": _code(), "name": name, "designation": remember_role(firm, body.get("designation")), "role": role,
           "by": user["id"], "created": S.now_iso(),
           "expires": (datetime.now() + timedelta(days=INVITE_DAYS)).isoformat(timespec="seconds")}
    firm["invites"] = invites_view(firm) + [inv]
    S.save_json(S.firm_file(), firm)
    S.security_log(f"invited {name}", user["id"])
    return {"invite": inv, "invites": invites_view(firm)}


def invite_cancel(firm, user, body):
    if user.get("role") != "owner":
        raise S.ApiError(403, "Only the owner can do this.")
    firm["invites"] = [i for i in invites_view(firm) if i["code"] != body.get("code")]
    S.save_json(S.firm_file(), firm)
    return {"invites": invites_view(firm)}


def join(handler, body):
    """Public: someone with an invite code makes their own user ID and password."""
    ip = handler.client_address[0]
    now = time.time()
    JOIN_FAILS[ip] = [t for t in JOIN_FAILS.get(ip, []) if now - t < 600]
    if len(JOIN_FAILS[ip]) >= 8:
        raise S.ApiError(429, "Too many tries. Please wait 10 minutes.")
    firm = S.load_firm()
    if not firm:
        raise S.ApiError(409, "Design Lab isn't set up on this computer yet.")
    code = str(body.get("code") or "").strip().upper().replace(" ", "")
    if len(code) == 8:
        code = code[:4] + "-" + code[4:]
    inv = next((i for i in invites_view(firm) if secrets.compare_digest(i["code"], code)), None)
    if not inv:
        JOIN_FAILS[ip].append(now)
        time.sleep(0.5)
        raise S.ApiError(404, "That invitation code isn't right or has expired. Ask your studio owner for a new one.")
    uid = str(body.get("user_id") or "").strip().lower()
    if not re.match(r"^[a-z0-9._\-]{3,30}$", uid):
        raise S.ApiError(400, "Choose a user ID of 3–30 letters or numbers, no spaces.")
    if any(u["id"] == uid for u in firm["users"]):
        raise S.ApiError(409, "That user ID is taken. Try another.")
    pw = body.get("password") or ""
    if pw != (body.get("password2") or ""):
        raise S.ApiError(400, "The two passwords don't match.")
    problem = S.password_problem(pw)
    if problem:
        raise S.ApiError(400, problem)
    phone, email = str(body.get("phone") or "").strip(), S.norm_email(body.get("email"))
    if phone and len(S.norm_phone(phone)) < 10:
        raise S.ApiError(400, "Please enter a 10-digit phone number.")
    taken = S.contact_taken(firm, phone, email)
    if taken:
        raise S.ApiError(409, taken)
    salt, digest = S.hash_password(pw)
    name = str(body.get("name") or inv["name"]).strip()[:80] or inv["name"]
    firm["users"].append({"id": uid, "name": name, "role": inv["role"], "salt": salt, "hash": digest,
                          "designation": inv.get("designation", ""), "phone": phone, "email": email,
                          "status": "active", "added": S.now_iso(), "invited_by": inv["by"], "cy": {}})
    firm["invites"] = [i for i in invites_view(firm) if i["code"] != inv["code"]]
    firm.setdefault("alerts", []).insert(0, {"id": secrets.token_hex(4), "kind": "joined", "user": uid, "name": name, "time": S.now_iso()})
    S.save_json(S.firm_file(), firm)
    S.security_log(f"{uid} joined the team with an invitation", uid, ip)
    S.cloud_sync_users(firm)
    tok = S.session_new(uid, True)
    return {"token": tok, "name": name, "firm": firm.get("firm"), "role": inv["role"]}


def on_user_added(firm, uid):
    """A member the owner added by hand also waits for a Courtyard decision."""
    for u in firm["users"]:
        if u["id"] == uid:
            u["cy"] = {}
            firm.setdefault("alerts", []).insert(0, {"id": secrets.token_hex(4), "kind": "joined", "user": uid, "name": u["name"], "time": S.now_iso()})


# ---------------------------------------------------------------- Courtyard access

def cy_access(user):
    if user.get("role") == "owner" or "cy" not in user:     # owner, and members from before v0.10, keep everything
        return dict(CY_ALL)
    return {k: bool(user["cy"].get(k)) for k, _ in CY_SECTIONS}


def cy_section(path, posting):
    """Which Courtyard section a request belongs to (None = always allowed for anyone with some access)."""
    head = path[len("/api/cy/"):].split("?")[0].split("/")[0] if path.startswith("/api/cy/") else ""
    if head in ("people", "member"):
        return "people"
    if head in ("threads", "thread", "group-new", "group", "touch", "chat-mute"):
        return "messages"
    if head in ("events", "event", "event-new"):
        return "events"
    if head in ("editions", "edition"):
        return "perspective_comment" if posting else "perspective_read"
    if head in ("submit", "submissions"):
        return "perspective_read"
    if head in ("community", "community-mute", "community-delete", "post", "like", "comment", "save", "saved", "flag"):
        return "community"
    return None


def cy_guard(user, path, posting):
    acc = cy_access(user)
    if not any(acc.values()):
        raise S.ApiError(403, "Your studio owner hasn't opened The Courtyard for you yet.")
    sec = cy_section(path, posting)
    if sec and not acc.get(sec):
        label = dict(CY_SECTIONS).get(sec, "this part")
        raise S.ApiError(403, f"Your studio owner hasn't opened “{label}” for you.")


def cy_set(firm, user, body):
    if user.get("role") != "owner":
        raise S.ApiError(403, "Only the owner can do this.")
    uid = str(body.get("id") or "")
    want = body.get("sections") or {}
    for u in firm["users"]:
        if u["id"] == uid and u.get("role") != "owner":
            u["cy"] = {k: bool(want.get(k)) for k, _ in CY_SECTIONS}
            if u["cy"].get("perspective_comment"):
                u["cy"]["perspective_read"] = True
    firm["alerts"] = [a for a in firm.get("alerts", []) if not (a.get("kind") == "joined" and a.get("user") == uid)]
    S.save_json(S.firm_file(), firm)
    S.security_log(f"Courtyard access changed for {uid}", user["id"])
    return {"ok": True}


def alert_dismiss(firm, user, body):
    if user.get("role") != "owner":
        raise S.ApiError(403, "Only the owner can do this.")
    firm["alerts"] = [a for a in firm.get("alerts", []) if a.get("id") != body.get("id")]
    S.save_json(S.firm_file(), firm)
    return {"ok": True}


def owner_alerts(firm, user):
    if user.get("role") != "owner":
        return []
    ids = {u["id"] for u in firm.get("users", [])}
    return [a for a in firm.get("alerts", []) if a.get("kind") != "joined" or a.get("user") in ids][:10]


# ---------------------------------------------------------------- profile, settings, dashboard

def profile(firm, user, sess_count):
    return {"id": user["id"], "name": user["name"], "phone": user.get("phone", ""), "email": user.get("email", ""),
            "designation": user.get("designation", ""), "role": user.get("role", ""), "firm": firm.get("firm", ""),
            "kind": firm.get("kind", ""), "dash": user.get("dash") or {}, "dash_blocks": DASH_BLOCKS,
            "devices": sess_count, "cy": cy_access(user), "cy_sections": CY_SECTIONS,
            "requests": [r for r in firm.get("feature_requests", []) if r.get("by") == user["id"]][:20]}


def profile_save(firm, user, body):
    name = str(body.get("name") or "").strip()[:80]
    if not name:
        raise S.ApiError(400, "Your name can't be empty.")
    phone, email = str(body.get("phone") or "").strip(), S.norm_email(body.get("email"))
    if phone and len(S.norm_phone(phone)) < 10:
        raise S.ApiError(400, "Please enter a 10-digit phone number.")
    taken = S.contact_taken(firm, phone, email, except_id=user["id"])
    if taken:
        raise S.ApiError(409, taken)
    for u in firm["users"]:
        if u["id"] == user["id"]:
            u.update({"name": name, "phone": phone, "email": email})
            if isinstance(body.get("dash"), dict):
                u["dash"] = {k: bool(body["dash"].get(k, True)) for k, _ in DASH_BLOCKS}
    S.save_json(S.firm_file(), firm)
    S.security_log("updated own profile", user["id"])
    return {"ok": True}


def feature_request(firm, user, body):
    text = str(body.get("text") or "").strip()[:1200]
    if len(text) < 8:
        raise S.ApiError(400, "Tell us a little more about what you'd like.")
    r = {"id": secrets.token_hex(4), "by": user["id"], "name": user["name"], "text": text, "time": S.now_iso(), "status": "sent"}
    firm.setdefault("feature_requests", []).insert(0, r)
    firm["feature_requests"] = firm["feature_requests"][:200]
    S.save_json(S.firm_file(), firm)
    try:      # Design Lab reads every request; nothing changes in the software until it is reviewed and confirmed
        S.cloud_call(firm, "/api/studio/feedback", {"kind": "feature", "text": text, "user": user["name"]})
    except Exception:
        r["status"] = "saved here — will be sent when the studio is connected"
    return {"request": r}


# ---------------------------------------------------------------- who used what

def member_usage(firm, spend):
    month = datetime.now().strftime("%Y-%m")
    signins = {}
    for l in S.read_security_log():
        if l.get("event") == "signed in" and l.get("who"):
            signins.setdefault(l["who"], l.get("time", ""))
    out = []
    active = [u for u in firm.get("users", []) if u.get("status", "active") == "active"]
    for i, u in enumerate(active):
        ai = sum(float(x.get("total") or 0) for x in spend if (x.get("user") == u["id"] or x.get("user") == u["name"]) and str(x.get("time", "")).startswith(month))
        seat = 0 if i < S.INCLUDED_USERS else S.EXTRA_USER_FEE
        out.append({"id": u["id"], "name": u["name"], "seat": seat, "ai": round(ai, 2), "total": round(seat + ai, 2),
                    "last_in": signins.get(u["id"], ""), "cy": cy_access(u), "new": "cy" in u and not any(u["cy"].values())})
    return out
