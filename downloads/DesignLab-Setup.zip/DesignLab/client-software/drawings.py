"""
Design Lab - Site plans and corrections.

* Lists the drawings in "01 Drawings" (latest revision only; old ones live in Superseded).
* Each drawing can be linked to rooms, so at site you see the drawings for the room you're in.
* A correction = marks drawn on the drawing + room + type + note. The marked-up picture is saved
  in "01 Drawings/Site corrections" and the correction becomes an office task.
* When a new revision of that drawing arrives (Replace, or dropped in 00 Inbox), its open
  corrections close by themselves ("closed by revision ...").
* A drawing can be sent to the client for sign-off (Approve / Ask for a change) through the client link.
* PDFs and CAD files can't be drawn on in the browser: the studio is reminded to save a JPG copy
  ("<name> (copy for marking).jpg") next to it.
"""
import base64
import os
import re
import secrets
from datetime import datetime

S = None
DRAW = "01 Drawings"
SKIP = ("Superseded", "Site corrections")
IMG = (".jpg", ".jpeg", ".png", ".webp")
COPY_TAG = " (copy for marking)"
TYPES = ["Dimension", "Material / finish", "Electrical", "Plumbing", "Furniture / joinery", "Ceiling", "Civil", "Other"]
REV_TAG = re.compile(r"(?:rev|r)[\s_\-]?(\d+[a-z]?)$", re.IGNORECASE)


def _key(name):
    stem = os.path.splitext(name)[0]
    if stem.lower().endswith(COPY_TAG):
        stem = stem[: -len(COPY_TAG)]
    return S.REV_RE.sub("", stem).strip().lower()


def _rev(name):
    m = REV_TAG.search(os.path.splitext(name)[0].replace(COPY_TAG, ""))
    return ("R" + m.group(1).upper()) if m else ""


def _kind(name):
    ext = os.path.splitext(name)[1].lower()
    if ext in IMG:
        return "image"
    if ext == ".pdf":
        return "pdf"
    if ext in S.DRAW_EXT:
        return "cad"
    return "other"


def scan(pdir):
    """All current drawings, grouped by drawing (same name without the revision tag)."""
    base = os.path.join(pdir, DRAW)
    groups = {}
    if not os.path.isdir(base):
        return groups
    for b, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in SKIP and not d.startswith(".")]
        for f in files:
            if f.startswith(".") or f.startswith("Design Lab layout"):
                continue
            full = os.path.join(b, f)
            rel = os.path.relpath(full, pdir).replace("\\", "/")
            k = os.path.relpath(b, base).replace("\\", "/") + "|" + _key(f)
            g = groups.setdefault(k, {"key": k, "folder": os.path.relpath(b, base).replace("\\", "/"), "files": []})
            g["files"].append({"rel": rel, "name": f, "kind": _kind(f), "rev": _rev(f), "copy": COPY_TAG in f,
                               "time": datetime.fromtimestamp(os.path.getmtime(full)).isoformat(timespec="seconds")})
    for g in groups.values():
        g["files"].sort(key=lambda x: x["time"], reverse=True)
        main = [x for x in g["files"] if not x["copy"]] or g["files"]
        g["main"] = main[0]
        stem = os.path.splitext(g["main"]["name"])[0]
        if g["main"]["kind"] == "image":
            g["mark"] = g["main"]
        else:   # a picture copy only counts if it is a copy of THIS revision
            g["mark"] = next((x for x in g["files"] if x["kind"] == "image" and x["copy"]
                              and os.path.splitext(x["name"])[0][: -len(COPY_TAG)] == stem), None)
        g["title"] = os.path.splitext(g["main"]["name"])[0]
    return groups


def check_revisions(proj):
    """Open corrections whose drawing has a newer version now are closed by that revision."""
    groups = None
    changed = False
    for c in proj.get("corrections", []):
        if c.get("status") != "open":
            continue
        if groups is None:
            groups = scan(proj["_dir"])
        g = groups.get(c["key"])
        if not g:
            continue
        cur = g["main"]
        if cur["rel"] != c["drawing"] and not cur["copy"] and not os.path.isfile(os.path.join(proj["_dir"], c["drawing"])):
            c.update({"status": "closed", "closed": S.now_iso(), "closed_by": "Revision",
                      "closed_note": f"New revision uploaded: {cur['name']}"})
            S.add_log(proj, "drawing", f"Correction closed by new revision {cur['name']}: {c['note'][:50]}")
            changed = True
    return changed


def state(proj):
    pdir = proj["_dir"]
    if check_revisions(proj):
        S.save_project(proj)
    groups = scan(pdir)
    links = proj.get("drawing_rooms", {})
    signs = proj.get("signoffs", {})
    corr = proj.get("corrections", [])
    out = []
    for k, g in sorted(groups.items(), key=lambda kv: (kv[1]["folder"], kv[1]["title"].lower())):
        open_n = sum(1 for c in corr if c["key"] == k and c["status"] == "open")
        sup = os.path.join(pdir, DRAW, "Superseded")
        old = 0
        if os.path.isdir(sup):
            old = sum(1 for f in os.listdir(sup) if _key(re.sub(r" \(replaced [\d\-]+\)", "", os.path.splitext(f)[0]) + ".x") == k.split("|", 1)[1])
        out.append({"key": k, "title": g["title"], "folder": g["folder"], "main": g["main"], "mark": g["mark"],
                    "needs_copy": g["mark"] is None and g["main"]["kind"] in ("pdf", "cad"),
                    "rooms": links.get(k, []), "open": open_n, "older": old, "signoff": signs.get(k)})
    return {"drawings": out, "corrections": sorted(sorted(corr, key=lambda c: c["time"], reverse=True), key=lambda c: c["status"] != "open"),
            "types": TYPES, "rooms": [r.get("name") for r in proj.get("rooms", []) if r.get("name")]}


def _group(proj, key):
    g = scan(proj["_dir"]).get(str(key or ""))
    if not g:
        raise S.ApiError(404, "That drawing has moved. Refresh and try again.")
    return g


def set_rooms(proj, who, body):
    _group(proj, body.get("key"))
    rooms = [str(r).strip()[:40] for r in (body.get("rooms") or []) if str(r).strip()][:12]
    proj.setdefault("drawing_rooms", {})[body["key"]] = rooms
    S.save_project(proj)
    return {"ok": True}


def save_copy(proj, who, body):
    """PDF/CAD: save a JPG/PNG copy next to it so corrections can be drawn on it."""
    g = _group(proj, body.get("key"))
    m = re.match(r"^data:image/(jpeg|png|webp);base64,(.+)$", body.get("data") or "", re.S)
    if not m:
        raise S.ApiError(400, "Choose a JPG or PNG picture of the drawing.")
    ext = ".jpg" if m.group(1) == "jpeg" else "." + m.group(1)
    main = g["main"]
    folder = os.path.dirname(os.path.join(proj["_dir"], main["rel"]))
    full = os.path.join(folder, os.path.splitext(main["name"])[0] + COPY_TAG + ext)
    with open(full, "wb") as f:
        f.write(base64.b64decode(m.group(2)))
    S.add_log(proj, "drawing", f"{who} added a picture copy of {main['name']} for marking corrections")
    S.save_project(proj)
    return {"ok": True}


def correct(proj, user, body, source="team"):
    g = _group(proj, body.get("key"))
    note = str(body.get("note") or "").strip()[:1500]
    marks = body.get("marks") or []
    if not note and not marks:
        raise S.ApiError(400, "Draw on the drawing or write what needs to change.")
    pdir = proj["_dir"]
    cid = secrets.token_hex(4)
    pic = ""
    m = re.match(r"^data:image/(png|jpeg);base64,(.+)$", body.get("image") or "", re.S)
    if m:
        d = os.path.join(pdir, DRAW, "Site corrections")
        os.makedirs(d, exist_ok=True)
        n = 1 + sum(1 for c in proj.get("corrections", []) if c["key"] == g["key"])
        full = S.unique_path(os.path.join(d, f"{datetime.now().strftime('%Y-%m-%d')} {g['title'][:60]} - correction {n}.{'png' if m.group(1) == 'png' else 'jpg'}"))
        with open(full, "wb") as f:
            f.write(base64.b64decode(m.group(2)))
        pic = os.path.relpath(full, pdir).replace("\\", "/")
    c = {"id": cid, "key": g["key"], "title": g["title"], "drawing": g["main"]["rel"], "rev": g["main"]["rev"],
         "room": str(body.get("room") or "").strip()[:40], "type": body.get("type") if body.get("type") in TYPES else "Other",
         "note": note, "marks": len(marks) if isinstance(marks, list) else 0, "picture": pic,
         "by": user["name"] if isinstance(user, dict) else str(user), "source": source, "time": S.now_iso(),
         "assigned": str(body.get("assigned") or "").strip()[:60], "status": "open"}
    proj.setdefault("corrections", []).append(c)
    S.add_log(proj, "drawing", f"Correction on {g['title']}{' (' + c['room'] + ')' if c['room'] else ''} by {c['by']}: {note[:60]}")
    S.assistant.notify(f"New drawing correction in **{proj['name']}** — {g['title']}{' · ' + c['room'] if c['room'] else ''}: {note[:80]}")
    S.save_project(proj)
    return {"correction": c}


def update(proj, user, body):
    c = next((x for x in proj.get("corrections", []) if x["id"] == str(body.get("id"))), None)
    if not c:
        raise S.ApiError(404, "That correction is gone.")
    if "assigned" in body:
        c["assigned"] = str(body.get("assigned") or "").strip()[:60]
    if body.get("status") == "closed":
        c.update({"status": "closed", "closed": S.now_iso(), "closed_by": user["name"], "closed_note": str(body.get("note") or "Done")[:300]})
        S.add_log(proj, "drawing", f"{user['name']} closed a correction on {c['title']}")
    elif body.get("status") == "open":
        c["status"] = "open"
        for k in ("closed", "closed_by", "closed_note"):
            c.pop(k, None)
    S.save_project(proj)
    return {"ok": True}


def signoff_send(proj, user, body):
    g = _group(proj, body.get("key"))
    if not proj.get("client_links") or not any(l.get("on") for l in proj["client_links"]):
        raise S.ApiError(400, "Make a client link first (in the Gallery, under Client access), then send drawings for sign-off.")
    proj.setdefault("signoffs", {})[g["key"]] = {"rel": g["main"]["rel"], "name": g["main"]["name"], "title": g["title"], "rev": g["main"]["rev"],
                                                 "status": "waiting", "sent": S.now_iso(), "by": user["name"]}
    S.add_log(proj, "drawing", f"{user['name']} sent {g['main']['name']} to the client for sign-off")
    S.save_project(proj)
    return {"ok": True}


def signoff_reply(proj, who, body):
    s = (proj.get("signoffs") or {}).get(str(body.get("key")))
    if not s:
        raise S.ApiError(404, "That drawing isn't waiting for you any more.")
    decision = body.get("decision")
    if decision not in ("approved", "changes"):
        raise S.ApiError(400, "Choose Approve or Ask for a change.")
    note = str(body.get("note") or "").strip()[:1000]
    if decision == "changes" and not note:
        raise S.ApiError(400, "Please write what you would like changed.")
    s.update({"status": decision, "replied": S.now_iso(), "reply_by": who, "note": note})
    S.add_log(proj, "drawing", f"{who} {'approved' if decision == 'approved' else 'asked for a change on'} {s['name']}" + (f": {note[:60]}" if note else ""))
    S.assistant.notify(f"**{who}** {'approved ✅' if decision == 'approved' else 'asked for a change on'} **{s['name']}** ({proj['name']})" + (f": {note[:80]}" if note else ""))
    if decision == "approved":
        d = os.path.join(proj["_dir"], "07 Client Docs", "Sign-offs")
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, f"{datetime.now().strftime('%Y-%m-%d')} {S.safe_name(s['title'])} approved.txt"), "w", encoding="utf-8") as f:
            f.write(f"Drawing: {s['name']}\nRevision: {s.get('rev') or '-'}\nApproved by: {who} (client link)\nOn: {datetime.now().strftime('%d %b %Y %H:%M')}\n"
                    + (f"Note: {note}\n" if note else ""))
        S.save_project(proj)
    else:
        correct(proj, who, {"key": str(body.get("key")), "note": note, "type": "Other"}, source="client")
    return {"ok": True}
