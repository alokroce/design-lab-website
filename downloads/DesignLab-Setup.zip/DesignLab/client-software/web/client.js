(function () {
  "use strict";
  const tok = location.pathname.split("/")[2] || "";
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fileUrl = (rel) => `/cfile/${encodeURIComponent(tok)}/${rel.split("/").map(encodeURIComponent).join("/")}`;
  const fmt = (iso) => { try { return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short" }); } catch (e) { return ""; } };
  let D = null, tab = "choose", picked = [];
  let tt = 0;
  function toast(m) { const t = $("#toast"); t.textContent = m; t.classList.add("on"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("on"), 2800); }
  async function api(act, body) {
    const r = await fetch(`/api/client/${encodeURIComponent(tok)}${act ? "/" + act : ""}`, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Something went wrong. Please try again.");
    return d;
  }
  function shrink(file) {
    return new Promise((ok) => {
      const fr = new FileReader();
      fr.onload = () => { const img = new Image(); img.onload = () => { const k = Math.min(1, 2000 / Math.max(img.width, img.height)); const c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); ok(c.toDataURL("image/jpeg", .86)); }; img.onerror = () => ok(""); img.src = fr.result; };
      fr.readAsDataURL(file);
    });
  }
  async function load() {
    try { D = await api(""); document.title = `${D.project} · ${D.firm}`; draw(); }
    catch (e) { $("#app").innerHTML = `<p class="err">${esc(e.message)}</p>`; }
  }
  function pic(x, choose) {
    return `<figure class="pic ${x.pick === "yes" ? "yes" : ""}" data-id="${esc(x.id)}">
      <a href="${fileUrl(x.rel)}" target="_blank" rel="noopener"><img src="${fileUrl(x.rel)}" alt="${esc(x.caption || "Picture")}" loading="lazy"></a>
      <figcaption>
        <span class="where">${esc(x.room || "")}${x.room && x.caption ? " · " : ""}${esc(x.caption || "")}${x.source === "client" ? " · you sent this" : ""}</span>
        ${(x.comments || []).map((c) => `<span class="com"><b>${esc(c.source === "client" ? "You" : c.by)}:</b> ${esc(c.text)}</span>`).join("")}
        ${choose ? `<div class="row"><button class="b ${x.pick === "yes" ? "on-yes" : ""}" data-pick="${x.pick === "yes" ? "" : "yes"}">${x.pick === "yes" ? "✓ You chose this" : "I like this"}</button>
          <button class="b ghost" data-pick="${x.pick === "no" ? "" : "no"}">${x.pick === "no" ? "Said no · undo" : "Not for me"}</button></div>` : ""}
        <form class="row cform"><input placeholder="Write a comment" aria-label="Comment"><button class="b ghost">Send</button></form>
      </figcaption></figure>`;
  }
  const size = (n) => n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
  const isImg = (n) => /\.(jpe?g|png|webp|gif)$/i.test(n);
  function filesView() {
    const groups = {};
    D.files.forEach((f) => { (groups[f.folder] = groups[f.folder] || []).push(f); });
    const keys = Object.keys(groups).sort();
    return `<p class="hint">Files your designer has opened for you — drawings, 3D, site photos and more. Tap to open or download.${D.expires ? ` This page works until ${esc(fmt(D.expires))}.` : ""}</p>
      ${keys.length ? keys.map((k) => `<section class="card fgroup"><b>${esc(k.replace(/^\d+ /, "").replace(/\/\d+ /g, " / "))}</b>
        ${groups[k].some((f) => isImg(f.name)) ? `<div class="fthumbs">${groups[k].filter((f) => isImg(f.name)).slice(0, 40).map((f) => `<a href="${fileUrl(f.rel)}" target="_blank" rel="noopener"><img src="${fileUrl(f.rel)}" alt="${esc(f.name)}" loading="lazy"></a>`).join("")}</div>` : ""}
        <ul class="flist">${groups[k].filter((f) => !isImg(f.name)).map((f) => `<li><a href="${fileUrl(f.rel)}" target="_blank" rel="noopener">${esc(f.name)}</a><span>${esc(size(f.size))} · ${esc(fmt(f.time))}</span></li>`).join("")}</ul></section>`).join("")
        : `<p class="empty">Nothing in these folders yet.</p>`}`;
  }
  function draw() {
    const opts = D.items.filter((x) => x.bucket === "selection" || x.bucket === "selected");
    const others = D.items.filter((x) => !(x.bucket === "selection" || x.bucket === "selected"));
    const waiting = D.signoffs.filter((s) => s.status === "waiting").length;
    $("#app").innerHTML = `
      <header><small>${esc(D.firm)}</small><h1>${esc(D.project)}</h1><p>Hello ${esc(D.client)} — this page is just for your home.</p></header>
      <nav>
        <button data-tab="choose" class="${tab === "choose" ? "on" : ""}">To choose<b>${opts.length}</b></button>
        <button data-tab="pics" class="${tab === "pics" ? "on" : ""}">Pictures<b>${others.length}</b></button>
        <button data-tab="send" class="${tab === "send" ? "on" : ""}">Send pictures</button>
        <button data-tab="draw" class="${tab === "draw" ? "on" : ""}">Drawings${waiting ? `<b>${waiting}</b>` : ""}</button>
        ${(D.folders || []).length ? `<button data-tab="files" class="${tab === "files" ? "on" : ""}">Files<b>${D.files.length}</b></button>` : ""}
      </nav>
      <main>${tab === "choose" ? `<p class="hint">Options from your designer. Tap <b>I like this</b> on what you want — they are told straight away.</p>
          ${opts.length ? `<div class="grid">${opts.map((x) => pic(x, true)).join("")}</div>` : `<p class="empty">Nothing to choose right now.</p>`}`
        : tab === "pics" ? `<p class="hint">Pictures shared with you, and pictures you sent.</p>
          ${others.length ? `<div class="grid">${others.map((x) => pic(x, false)).join("")}</div>` : `<p class="empty">No pictures yet.</p>`}`
        : tab === "send" ? `<p class="hint">Send pictures you like — from Instagram, Pinterest, a showroom, anywhere. Say which room they are for, and your designer's Gallery Bot files them.</p>
          <div class="card">
            <label class="b">Choose pictures<input type="file" accept="image/*" multiple hidden id="files"></label>
            <div class="thumbs" id="thumbs"></div>
            <select id="room"><option value="">Which room? (or let us sort it)</option>${D.rooms.map((r) => `<option>${esc(r)}</option>`).join("")}</select>
            <textarea id="words" rows="2" placeholder="A few words, e.g. I like this colour for the kids' room (you can speak with the keyboard mic)"></textarea>
            <button class="b" id="send">Send to my designer</button>
          </div>`
        : tab === "files" ? filesView()
        : `<p class="hint">Drawings your designer has sent for your approval.</p>
          ${D.signoffs.length ? D.signoffs.map((s) => `<div class="card" data-key="${esc(s.key)}">
            <div><b>${esc(s.title)}</b> ${s.rev ? `<span class="tag">${esc(s.rev)}</span>` : ""} ${s.status === "approved" ? `<span class="tag ok">You approved · ${esc(fmt(s.replied))}</span>` : s.status === "changes" ? `<span class="tag warn">You asked for a change</span>` : `<span class="tag warn">Waiting for you</span>`}</div>
            <a href="${fileUrl(s.rel)}" target="_blank" rel="noopener">Open the drawing</a>
            ${s.note ? `<span class="com"><b>Your note:</b> ${esc(s.note)}</span>` : ""}
            ${s.status === "waiting" ? `<textarea rows="2" placeholder="Anything to change? Write it here."></textarea>
              <div class="row"><button class="b on-yes" data-sign="approved">Approve</button><button class="b ghost" data-sign="changes">Ask for a change</button></div>` : ""}
          </div>`).join("") : `<p class="empty">Nothing to approve right now.</p>`}`}
      </main>
      <footer>Private page from ${esc(D.firm)} · made with Design Lab</footer>`;
  }
  document.addEventListener("click", async (e) => {
    const t = e.target;
    const tb = t.closest("[data-tab]"); if (tb) { tab = tb.dataset.tab; draw(); scrollTo(0, 0); return; }
    try {
      const pk = t.closest("[data-pick]");
      if (pk) { await api("pick", { id: pk.closest("[data-id]").dataset.id, pick: pk.dataset.pick }); toast(pk.dataset.pick === "yes" ? "Thank you — your designer can see you chose this" : "Noted"); return load(); }
      if (t.id === "send") {
        if (!picked.length) { toast("Choose one or more pictures first."); return; }
        t.disabled = true; t.textContent = "Sending…";
        try { const r = await api("upload", { images: picked, room: $("#room").value, caption: $("#words").value, bucket: $("#room").value ? "room" : "sort" });
          picked = []; toast(`Sent ${r.added} picture${r.added === 1 ? "" : "s"} — thank you!`); tab = "pics"; return load(); }
        finally { t.disabled = false; t.textContent = "Send to my designer"; }
      }
      const sg = t.closest("[data-sign]");
      if (sg) { const card = sg.closest("[data-key]"); await api("signoff", { key: card.dataset.key, decision: sg.dataset.sign, note: card.querySelector("textarea").value }); toast(sg.dataset.sign === "approved" ? "Approved — thank you!" : "Sent to your designer"); return load(); }
    } catch (x) { toast(x.message); }
  });
  document.addEventListener("submit", async (e) => {
    if (!e.target.classList.contains("cform")) return;
    e.preventDefault();
    const inp = e.target.querySelector("input"); if (!inp.value.trim()) return;
    try { await api("comment", { id: e.target.closest("[data-id]").dataset.id, text: inp.value }); toast("Comment sent"); load(); } catch (x) { toast(x.message); }
  });
  document.addEventListener("change", async (e) => {
    if (e.target.id !== "files") return;
    const files = [...e.target.files].slice(0, 12);
    toast("Getting pictures ready…");
    picked = [];
    for (const f of files) { const d = await shrink(f); if (d) picked.push({ name: f.name, data: d }); }
    $("#thumbs").innerHTML = picked.map((p) => `<img src="${p.data}" alt="">`).join("");
  });
  load();
})();
