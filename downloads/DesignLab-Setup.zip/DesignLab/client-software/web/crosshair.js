/* DESIGN LAB — the CAD crosshair (architect / designer side, computer only)
   Like the cursor in a drawing program: two fine lines follow the mouse, a small pick box sits where they cross,
   the position is read out beside it, and whatever you point at gets a dashed selection box with grips and its size. */
(() => {
  "use strict";
  if (!window.matchMedia("(pointer: fine)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const root = document.createElement("div");
  root.className = "cad";
  root.setAttribute("aria-hidden", "true");
  root.innerHTML = `<div class="cad-h"></div><div class="cad-v"></div><div class="cad-pick"></div><div class="cad-xy"></div><div class="cad-sel"><i></i><i></i><i></i><i></i><b></b></div>`;
  document.body.appendChild(root);
  const h = root.querySelector(".cad-h"), v = root.querySelector(".cad-v"), pick = root.querySelector(".cad-pick"), xy = root.querySelector(".cad-xy");
  const sel = root.querySelector(".cad-sel"), label = sel.querySelector("b");
  const TARGETS = ".panel, .card, .kpi, .tile, .s-proj, .g-tile, .bot, .vstage, .soc-item";
  let x = 0, y = 0, raf = 0, target = null;
  const active = () => document.body.classList.contains("sk") && !document.body.classList.contains("is-vendor")
    && !document.querySelector(".marker, .cap-sheet:not([hidden]), .cv-sheet");

  function draw() {
    raf = 0;
    if (!active()) { root.classList.remove("on"); return; }
    root.classList.add("on");
    h.style.transform = `translateY(${y}px)`;
    v.style.transform = `translateX(${x}px)`;
    pick.style.transform = `translate(${x}px, ${y}px)`;
    xy.style.transform = `translate(${x + 14}px, ${y + 12}px)`;
    xy.textContent = `X ${(x * 10).toFixed(0).padStart(5, " ")}   Y ${(y * 10).toFixed(0).padStart(5, " ")}`;
    if (target && document.contains(target)) {
      const r = target.getBoundingClientRect();
      sel.style.left = r.left - 3 + "px"; sel.style.top = r.top - 3 + "px";
      sel.style.width = r.width + 6 + "px"; sel.style.height = r.height + 6 + "px";
      const name = ((target.querySelector("h3, .card-name, .tile-label, b") || {}).textContent || "").trim().split("\n")[0].slice(0, 28);
      label.textContent = `${name ? name + "  ·  " : ""}${Math.round(r.width * 10)} × ${Math.round(r.height * 10)}`;
      sel.classList.add("on");
    } else sel.classList.remove("on");
  }
  const queue = () => { if (!raf) raf = requestAnimationFrame(draw); };
  document.addEventListener("pointermove", (e) => {
    if (e.pointerType !== "mouse") return;
    x = e.clientX; y = e.clientY;
    target = e.target.closest ? e.target.closest(TARGETS) : null;
    queue();
  }, { passive: true });
  document.addEventListener("scroll", queue, { passive: true, capture: true });
  document.addEventListener("pointerleave", () => root.classList.remove("on"));
  window.addEventListener("blur", () => root.classList.remove("on"));
})();
