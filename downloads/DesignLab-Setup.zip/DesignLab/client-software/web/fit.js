/* v0.2.2 - keep the pendulum and DESIGN LAB clear of the sign-in forms on any screen size.
   Measures the free space and lifts the pendulum only as much as needed; hides it if there is no room. */
(function () {
  "use strict";
  var intro = document.getElementById("intro");
  var view = document.getElementById("view-login");
  if (!intro || !view) return;
  function place() {
    if (view.hidden || !intro.classList.contains("dim")) { intro.style.transform = ""; intro.style.opacity = ""; return; }
    var brand = document.getElementById("brand");
    var first = view.querySelector(".side-switch");
    if (!brand || !first) return;
    var keep = intro.style.transition;
    intro.style.transition = "none";
    intro.style.transform = "none";
    var b = brand.getBoundingClientRect();
    var top = first.getBoundingClientRect().top;
    intro.style.transform = "translateY(" + (-(intro._shift || 0)) + "px)";
    void intro.offsetHeight;
    intro.style.transition = keep;
    var shift = Math.max(0, b.bottom - top + 28);
    intro._shift = shift;
    intro.style.transform = "translateY(" + (-shift) + "px)";
    intro.style.opacity = (b.top - shift < 10) ? "0" : "";
  }
  var queue = function () { requestAnimationFrame(place); };
  new MutationObserver(queue).observe(view, { attributes: true, subtree: true, attributeFilter: ["hidden"] });
  new MutationObserver(queue).observe(intro, { attributes: true, attributeFilter: ["class"] });
  window.addEventListener("resize", queue);
})();
