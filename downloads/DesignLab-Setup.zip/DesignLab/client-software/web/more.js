/* Design Lab — extra screens that plug into app.js through window.DLX
   Business (hours, expenses, password-locked fees, private ledger) · Vendor Showroom & Works · Social media board
   Capture (phone -> studio computer) · Meeting (voice -> MOM) · Mood board · Welcome picture · THE COURTYARD */
(() => {
  "use strict";
  const X = window.DLX;
  if (!X || !X.api) return;
  const { esc, toast, $, $$ } = X;

  /* ---------- small helpers ---------- */
  async function req(path, body) {            // like api(), but keeps the status (423 = locked page)
    const opts = { method: body === undefined ? "GET" : "POST", headers: { "Content-Type": "application/json", "X-Token": X.token() } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    let res;
    try { res = await fetch(path, opts); } catch (e) { const er = new Error("Can't reach the Design Lab server. Is the studio computer on?"); er.status = 0; throw er; }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { const er = new Error(data.error || "Something went wrong."); er.status = res.status; throw er; }
    return data;
  }
  const inr = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });
  const tq = () => "f=" + encodeURIComponent(X.fkey());
  const ago = (iso) => {
    if (!iso) return "";
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s / 60) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago";
    if (s < 86400 * 7) return Math.floor(s / 86400) + " d ago";
    return X.fmtDate(iso);
  };
  const md = (t) => esc(t || "").replace(/\n/g, "<br>");
  function readFile(file) {
    return new Promise((ok, bad) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = bad; r.readAsDataURL(file); });
  }
  async function shrink(file, max = 1600, q = 0.82) {     // photos are made lighter before sending (saves data on phones)
    if (!/^image\/(jpeg|png|webp|heic|heif)/.test(file.type)) return readFile(file);
    try {
      const url = URL.createObjectURL(file);
      const img = await new Promise((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = bad; i.src = url; });
      const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement("canvas");
      c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      return c.toDataURL("image/jpeg", q);
    } catch (e) { return readFile(file); }
  }
  function sure(btn) {                         // two taps to delete, no pop-up boxes
    if (btn.dataset.sure) return true;
    const old = btn.textContent;
    btn.dataset.sure = "1"; btn.textContent = "Sure?"; btn.classList.add("sure");
    setTimeout(() => { delete btn.dataset.sure; btn.textContent = old; btn.classList.remove("sure"); }, 3000);
    return false;
  }
  let PROJECTS = null;
  async function projects(force) {
    if (!PROJECTS || force) { try { PROJECTS = (await X.api("/api/projects")).projects; } catch (e) { PROJECTS = []; } }
    return PROJECTS;
  }

  /* =========================================================
     RECORDS — any list described by the server (records.py)
     ========================================================= */
  const recState = {};
  function lockScreen(box, after, label) {
    box.innerHTML = `<section class="panel lock-panel">
      <div class="lock-ic" aria-hidden="true">🔒</div>
      <h3>${esc(label || "Private page")}</h3>
      <p class="hint-text">Only people your studio owner allows can open this, on their own screen, with their own password. It locks itself again after 15 minutes.</p>
      <form class="inline-form lock-form" id="lock-form"><input type="password" id="lock-pw" placeholder="Your password" autocomplete="current-password"><button class="btn" type="submit">Open</button></form>
      <p class="form-error" id="lock-err"></p></section>`;
    $("#lock-form", box).addEventListener("submit", async (e) => {
      e.preventDefault();
      try { await req("/api/private/unlock", { password: $("#lock-pw", box).value }); toast("Opened for 15 minutes"); armRelock(); after(); }
      catch (x) { $("#lock-err", box).textContent = x.message; }
    });
    setTimeout(() => { const i = $("#lock-pw", box); if (i) i.focus(); }, 50);
  }
  let relock = null;
  function armRelock() {
    clearTimeout(relock);
    relock = setTimeout(() => { if ($(".is-private")) X.renderOffice(); }, 15 * 60 * 1000 + 2000);
  }

  let ARCHS = [];   // architects in The Courtyard (for sharing an order's progress)
  function fieldInput(f, v, projs) {
    const id = "rf-" + f.k;
    const val = v === undefined || v === null ? "" : v;
    if (f.t === "cyarch") return X.me().courtyard ? `<select id="${id}"><option value="">Not shared</option>${ARCHS.map((a) => `<option value="${esc(a.code)}" ${a.code === val ? "selected" : ""}>${esc(a.name)}${a.city ? " · " + esc(a.city) : ""}</option>`).join("")}</select>`
      : `<input id="${id}" type="hidden" value="${esc(val)}"><span class="hint-text">Connect to Design Lab to share order progress with architects.</span>`;
    if (f.t === "select") return `<select id="${id}"><option value="">Choose…</option>${f.opts.map((o) => `<option ${o === val ? "selected" : ""}>${esc(o)}</option>`).join("")}</select>`;
    if (f.t === "project") return `<input id="${id}" list="rf-projects" value="${esc(val)}" placeholder="Project or Office"><datalist id="rf-projects">${projs.map((p) => `<option value="${esc(p.name)}">`).join("")}<option value="Office"></datalist>`;
    if (f.t === "area") return `<textarea id="${id}" rows="3">${esc(val)}</textarea>`;
    if (f.t === "file") return `<span class="file-in">${val ? (/\.pdf$/.test(val) ? `<a href="/recfiles/${esc(val)}?${tq()}" target="_blank" rel="noopener">Open PDF</a>` : `<img src="/recfiles/${esc(val)}?${tq()}" alt="">`) : ""}<input type="file" id="${id}" accept="image/*,application/pdf" data-old="${esc(val)}"></span>`;
    const type = { date: "date", number: "number", money: "number", phone: "tel", email: "email" }[f.t] || "text";
    return `<input id="${id}" type="${type}" ${type === "number" ? 'step="any" inputmode="decimal"' : ""} value="${esc(val)}">`;
  }
  function cell(f, v, kind) {
    if (v === undefined || v === null || v === "") return "";
    if (f.t === "money") return inr(v);
    if (f.t === "cyarch") { const a = ARCHS.find((x) => x.code === v); return a ? "Shared with " + esc(a.name) : "Shared"; }
    if (f.t === "date") return esc(X.fmtDate(v));
    if (f.t === "phone") return `<a href="tel:${esc(v)}">${esc(v)}</a>`;
    if (f.t === "file") return /\.pdf$/.test(v) ? "PDF" : `<img class="thumb" src="/recfiles/${esc(v)}?${tq()}" alt="" loading="lazy">`;
    if (f.k === "status" || f.k === "type" || f.k === "direction") return `<span class="st st-${esc(String(v).toLowerCase().replace(/[^a-z]+/g, "-"))}">${esc(v)}</span>`;
    return esc(String(v)).slice(0, 120);
  }
  async function renderRec(box, kind, opts = {}) {
    let r;
    try { r = await req(`/api/rec/${kind}`); }
    catch (x) { if (x.status === 423) return lockScreen(box, () => renderRec(box, kind, opts), opts.lockLabel); if (x.status === 403) { box.innerHTML = `<div class="empty">${esc(x.message)}</div>`; return; } throw x; }
    const sc = r.schema;
    const st = recState[kind] = recState[kind] || { filter: "", q: "" };
    const fieldsBy = Object.fromEntries(sc.fields.map((f) => [f.k, f]));
    let items = r.items;
    if (st.filter) items = items.filter((it) => (it[sc.status] || "") === st.filter);
    if (st.q) { const q = st.q.toLowerCase(); items = items.filter((it) => Object.values(it).join(" ").toLowerCase().includes(q)); }
    const sm = r.summary;
    const chips = [];
    chips.push(`<span class="sumchip"><b>${sm.count}</b> ${esc(sm.count === 1 ? sc.one : sc.label.toLowerCase())}</span>`);
    if (sm.total !== undefined) chips.push(`<span class="sumchip"><b>${kind === "hours" ? sm.total : inr(sm.total)}</b> total</span>`);
    if (sm.open !== undefined) chips.push(`<span class="sumchip warn"><b>${sm.open}</b> open</span>`);
    if (sm.pending !== undefined) chips.push(`<span class="sumchip warn"><b>${inr(sm.pending)}</b> to collect</span>`);
    if (sm.received !== undefined) chips.push(`<span class="sumchip"><b>${inr(sm.received)}</b> received</span><span class="sumchip"><b>${inr(sm.paid)}</b> paid</span>`);
    const projs = sc.fields.some((f) => f.t === "project") ? await projects() : [];
    if (sc.fields.some((f) => f.t === "cyarch") && X.me().courtyard && !ARCHS.length) { try { ARCHS = (await req("/api/cy/architects")).people; } catch (e) {} }
    box.innerHTML = `
      ${opts.noHead ? "" : `<div class="o-head"><div><p class="eyebrow">${esc(opts.eyebrow || "")}</p><h2 class="o-title">${esc(sc.label)}${sc.private ? ' <span class="lock-tag">🔒 private</span>' : ""}</h2></div>
        <div class="head-acts">${sc.private ? `<button class="btn ghost" data-r-lock>Lock now</button>` : ""}<button class="btn" data-r-new>+ Add ${esc(sc.one)}</button></div></div>`}
      ${opts.noHead ? `<div class="btn-row r-top">${sc.private ? `<button class="btn ghost small" data-r-lock>Lock now</button>` : ""}<button class="btn small" data-r-new>+ Add ${esc(sc.one)}</button></div>` : ""}
      <div class="sumchips">${chips.join("")}</div>
      ${sm.projects ? `<section class="panel"><h3>By project</h3><div class="scroll-x"><table class="team"><thead><tr><th>Project</th><th>Fee agreed</th><th>Received</th><th>Deductions</th><th>Pending</th></tr></thead><tbody>
        ${Object.entries(sm.projects).map(([p, v]) => `<tr><td><b>${esc(p)}</b></td><td>${inr(v.agreed)}</td><td>${inr(v.received)}</td><td>${inr(v.deduction)}</td><td class="${v.pending > 0 ? "warn-t" : ""}">${inr(v.pending)}</td></tr>`).join("")}</tbody></table></div></section>` : ""}
      <div id="r-form"></div>
      <section class="panel ${sc.private ? "is-private" : ""}">
        <div class="r-tools">
          ${sc.status ? `<div class="chips-row"><button class="fchip ${st.filter ? "" : "on"}" data-r-f="">All</button>${(sc.fields.find((f) => f.k === sc.status) || { opts: [] }).opts.map((o) => `<button class="fchip ${st.filter === o ? "on" : ""}" data-r-f="${esc(o)}">${esc(o)} <i>${sm.by_status && sm.by_status[o] ? sm.by_status[o] : ""}</i></button>`).join("")}</div>` : ""}
          <input class="r-search" id="r-q" placeholder="Search…" value="${esc(st.q)}">
        </div>
        ${items.length ? `<div class="scroll-x"><table class="team rec"><thead><tr>${sc.cols.map((c) => `<th>${esc((fieldsBy[c] || {}).label || c)}</th>`).join("")}<th></th></tr></thead><tbody>
          ${items.map((it) => `<tr class="click" data-r-edit="${esc(it.id)}">${sc.cols.map((c) => `<td data-l="${esc((fieldsBy[c] || {}).label || c)}">${cell(fieldsBy[c] || {}, it[c], kind)}</td>`).join("")}<td class="nowrap">${sc.keep ? (it.versions && it.versions.length ? `<span class="tag" title="Earlier versions are kept">edited</span>` : "") : `<button class="x" data-r-del="${esc(it.id)}" aria-label="Delete">×</button>`}</td></tr>`).join("")}
        </tbody></table></div>` : `<p class="empty">${r.items.length ? "Nothing matches." : `No ${esc(sc.label.toLowerCase())} yet. Tap “+ Add ${esc(sc.one)}”.`}</p>`}
      </section>`;
    const form = (it) => {
      $("#r-form", box).innerHTML = `<form class="panel form" id="rec-form"><h3>${it.id ? "Edit" : "Add"} ${esc(sc.one)}</h3>
        <div class="grid2">${sc.fields.map((f) => `<label class="f ${f.wide || f.t === "area" ? "full2" : ""}"><span>${esc(f.label)}${f.req ? "" : " <i>(optional)</i>"}</span>${fieldInput(f, it[f.k] ?? (f.t === "date" && f.req ? X.todayIso() : ""), projs)}</label>`).join("")}</div>
        ${(it.history || []).length ? `<div class="hist"><p class="eyebrow">Tracking — every change</p><ol>${it.history.map((h) => `<li><b>${esc(h.status)}</b> <span>${esc(X.fmtDate(h.time))} ${esc(new Date(h.time).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" }))} · ${esc(h.by)}</span></li>`).join("")}</ol></div>` : ""}
        <div class="form-row"><p class="form-error" id="rec-err"></p><span class="btn-row tight"><button class="btn ghost" type="button" data-r-cancel>Cancel</button><button class="btn" type="submit">Save</button></span></div></form>`;
      const fm = $("#rec-form", box);
      fm.scrollIntoView({ behavior: "smooth", block: "start" });
      fm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const item = { id: it.id };
        for (const f of sc.fields) {
          const el = $("#rf-" + f.k, fm);
          if (f.t === "file") item[f.k] = el.files[0] ? await shrink(el.files[0]) : el.dataset.old;
          else item[f.k] = el.value;
        }
        try { await req(`/api/rec/${kind}`, { item }); toast("Saved"); renderRec(box, kind, opts); }
        catch (x) { $("#rec-err", fm).textContent = x.message; }
      });
    };
    box.onclick = async (e) => {
      const t = e.target;
      if (t.closest("[data-r-new]")) return form({});
      if (t.closest("[data-r-cancel]")) { $("#r-form", box).innerHTML = ""; return; }
      if (t.closest("[data-r-lock]")) { await req("/api/private/lock", {}); toast("Locked"); return renderRec(box, kind, opts); }
      const f = t.closest("[data-r-f]");
      if (f) { st.filter = f.dataset.rF; return renderRec(box, kind, opts); }
      const d = t.closest("[data-r-del]");
      if (d) { e.stopPropagation(); if (!sure(d)) return; await req(`/api/rec/${kind}/delete`, { id: d.dataset.rDel }); toast("Deleted"); return renderRec(box, kind, opts); }
      const ed = t.closest("[data-r-edit]");
      if (ed && !t.closest("a")) { const it = r.items.find((x) => x.id === ed.dataset.rEdit); if (it) form(it); }
    };
    const q = $("#r-q", box);
    q.oninput = () => { clearTimeout(q._t); q._t = setTimeout(() => { st.q = q.value; renderRec(box, kind, opts).then(() => { const n = $("#r-q", box); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 350); };
    if (opts.autoAdd) form({});
  }
  X.tabs["rec:"] = (box, tab) => renderRec(box, tab.slice(4), { eyebrow: X.office.mode === "showroom" ? "Showroom" : "Office" });
  /* ---------- My profile & settings (everyone, architect and vendor) ---------- */
  X.tabs.profile = async (box) => {
    const p = await req("/api/me/profile");
    const dash = p.dash || {};
    box.innerHTML = `<div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">My profile</h2>
        <p class="o-sub">Your details, password, security and settings. Only you can change these.</p></div></div>
      <form class="panel form" id="pf-form"><h3>My details</h3>
        <div class="grid2">
          <label class="f"><span>Name</span><input id="pf-name" value="${esc(p.name)}"></label>
          <label class="f"><span>User ID (you sign in with this)</span><input value="${esc(p.id)}" disabled></label>
          <label class="f"><span>Phone</span><input id="pf-phone" type="tel" inputmode="tel" value="${esc(p.phone)}"></label>
          <label class="f"><span>Email</span><input id="pf-email" type="email" inputmode="email" value="${esc(p.email)}"></label>
          <label class="f"><span>Job title</span><input value="${esc(p.designation || (p.role === "owner" ? "Owner" : ""))}" disabled></label>
          <label class="f"><span>${p.kind === "vendor" ? "Company" : "Studio"}</span><input value="${esc(p.firm)}" disabled></label>
        </div>
        <div class="form-row"><p class="form-error" id="pf-err"></p><button class="btn">Save my details</button></div></form>
      <form class="panel form" id="pf-pw"><h3>Change my password</h3>
        <div class="grid2">
          <label class="f"><span>Current password</span><input id="pf-old" type="password" autocomplete="current-password"></label>
          <label class="f"><span>New password (8+ letters and numbers)</span><input id="pf-new" type="password" autocomplete="new-password"></label>
          <label class="f"><span>Confirm new password</span><input id="pf-new2" type="password" autocomplete="new-password"></label>
        </div>
        <div class="form-row"><p class="form-error" id="pf-pwerr"></p><button class="btn">Change password</button></div></form>
      <section class="panel"><h3>Security &amp; privacy</h3>
        <p>You are signed in on <b>${p.devices}</b> device${p.devices === 1 ? "" : "s"}.</p>
        <div class="btn-row"><button class="btn ghost" data-pf-out>Sign out on all other devices</button></div>
        <p class="hint-text">Your password is never stored as written — only a locked fingerprint of it. Sign-ins and account changes are recorded in the owner's security list. Design Lab never tracks where you are.</p>
        <p class="hint-text">The Courtyard for you: ${p.cy_sections.filter(([k]) => p.cy[k]).map(([, l]) => esc(l)).join(", ") || "not opened yet — your studio owner decides"}.</p></section>
      <section class="panel"><h3>My dashboard <span class="h-note">choose what your Today page shows</span></h3>
        <div class="l-folders">${p.dash_blocks.map(([k, l]) => `<label class="chk"><input type="checkbox" data-dash="${esc(k)}" ${dash[k] === false ? "" : "checked"}> ${esc(l)}</label>`).join("")}</div>
        <div class="btn-row"><button class="btn" data-pf-dash>Save</button></div></section>
      <form class="panel form" id="pf-req"><h3>Ask for a new feature <span class="h-note">tell us what would help — Design Lab reviews every request</span></h3>
        <textarea id="pf-req-t" rows="3" placeholder="e.g. On Today, show which client approvals are still waiting"></textarea>
        <p class="hint-text">Nothing changes in your software by itself. Design Lab looks at the request, and you confirm before anything new is switched on.</p>
        <div class="form-row"><p class="form-error" id="pf-req-err"></p><button class="btn">Send request</button></div>
        ${p.requests.length ? `<ul class="list tight">${p.requests.map((r) => `<li><span class="when">${esc(X.fmtDate(r.time))}</span><span class="what">${esc(r.text)}</span><span class="where">${esc(r.status)}</span></li>`).join("")}</ul>` : ""}</form>`;
    const val = (id) => $("#" + id, box).value;
    $("#pf-form", box).onsubmit = async (e) => { e.preventDefault(); try { await req("/api/me/profile", { name: val("pf-name"), phone: val("pf-phone"), email: val("pf-email"), dash }); toast("Saved"); } catch (x) { $("#pf-err", box).textContent = x.message; } };
    $("#pf-pw", box).onsubmit = async (e) => {
      e.preventDefault();
      try { const r = await req("/api/me/password", { old: val("pf-old"), new: val("pf-new"), new2: val("pf-new2") }); X.setToken && X.setToken(r.token); $("#pf-pw", box).reset(); toast("Password changed. Other devices have been signed out."); }
      catch (x) { $("#pf-pwerr", box).textContent = x.message; }
    };
    $("#pf-req", box).onsubmit = async (e) => { e.preventDefault(); try { await req("/api/me/feature", { text: val("pf-req-t") }); toast("Request sent to Design Lab"); X.tabs.profile(box); } catch (x) { $("#pf-req-err", box).textContent = x.message; } };
    box.onclick = async (e) => {
      if (e.target.closest("[data-pf-out]")) { try { const r = await req("/api/me/signout-others", {}); X.setToken && X.setToken(r.token); toast("Signed out everywhere else"); X.tabs.profile(box); } catch (x) { toast(x.message); } }
      if (e.target.closest("[data-pf-dash]")) {
        $$("[data-dash]", box).forEach((i) => { dash[i.dataset.dash] = i.checked; });
        try { await req("/api/me/profile", { name: val("pf-name"), phone: val("pf-phone"), email: val("pf-email"), dash }); toast("Your Today page is updated"); } catch (x) { toast(x.message); }
      }
    };
  };

  /* ---------- the hidden private book ----------
     Business (architect), Accounts (vendor) and Team & wallet (both): type the secret word and press Enter,
     or press and hold the page heading and say it. Only then does the button appear — and it still asks for the password. */
  const BOOK_TABS = ["business", "rec:accounts", "team"];
  const bookHere = () => BOOK_TABS.includes(X.office.tab) && !X.office.project && X.officeBody && X.officeBody.offsetParent !== null;
  let bookBuf = "", bookBufT = 0;
  async function bookTry(phrase) {
    if (!phrase || phrase.trim().length < 3) return;
    try { const r = await req("/api/private/reveal", { phrase }); if (r.show) bookButton(); } catch (x) { /* stay silent */ }
  }
  function bookButton() {
    if (!bookHere() || $("[data-book-open]", X.officeBody)) return;
    const b = document.createElement("button");
    b.className = "btn book-btn"; b.dataset.bookOpen = "1"; b.textContent = "🔒 Private book";
    const head = $(".o-head", X.officeBody);
    (head || X.officeBody.firstElementChild || X.officeBody).after(b);
    b.addEventListener("click", openBook);
  }
  function openBook() {
    const back = X.office.tab;
    X.officeBody.onclick = null;
    X.officeBody.innerHTML = `<div class="o-head"><div><p class="eyebrow">Private · only you</p><h2 class="o-title">Private book</h2>
        <p class="o-sub">Cash, cash notes and commissions. Locked with your password; it locks again after 15 minutes. Entries are kept for good — they are never erased, and every edit keeps the earlier version.</p></div>
        <button class="btn ghost" data-book-back>← Back</button></div><div id="book-body"></div><div id="book-phrase"></div>`;
    $("[data-book-back]", X.officeBody).addEventListener("click", () => { X.office.tab = back; X.renderOffice(); });
    const body = $("#book-body", X.officeBody);
    renderBook(body).then(() => { if (!$(".lock-panel", body) && (X.me().role || "") === "owner") phraseForm($("#book-phrase", X.officeBody), true); }).catch(() => {});
  }
  /* the private book itself: a numbered account book with running balance, bill photos, and bills made here */
  const inr2 = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  function printHtml(html) {            // print just this, on clean white paper
    let pr = document.getElementById("print-root");
    if (!pr) { pr = document.createElement("div"); pr.id = "print-root"; document.body.appendChild(pr); }
    pr.innerHTML = html;
    document.body.classList.add("printing");
    window.print();
    setTimeout(() => { document.body.classList.remove("printing"); pr.innerHTML = ""; }, 500);
  }
  async function renderBook(box) {
    let r;
    try { r = await req("/api/rec/ledger"); }
    catch (x) { if (x.status === 423) return lockScreen(box, () => renderBook(box), "Private book"); box.innerHTML = `<div class="empty">${esc(x.message)}</div>`; return; }
    const st = recState.book = recState.book || { q: "" };
    let items = r.items;
    if (st.q) { const q = st.q.toLowerCase(); items = items.filter((it) => [it.entry_no, it.party, it.bill_no, it.what, it.note, it.project].join(" ").toLowerCase().includes(q)); }
    const last = r.items.length ? r.items[0].balance : 0;
    box.innerHTML = `<div class="btn-row r-top book-acts"><button class="btn" data-bk-new>+ New entry</button><button class="btn" data-bk-bill>+ Make a bill</button>
        <button class="btn ghost" data-bk-print>Print the book</button><button class="btn ghost" data-r-lock>Lock now</button></div>
      <div class="sumchips"><span class="sumchip"><b>${r.summary.count}</b> entries</span><span class="sumchip"><b>${inr2(r.summary.received)}</b> received</span>
        <span class="sumchip"><b>${inr2(r.summary.paid)}</b> paid</span><span class="sumchip ${last < 0 ? "warn" : ""}"><b>${inr2(last)}</b> balance</span></div>
      <div id="bk-form"></div>
      <section class="panel is-private book-sheet">
        <div class="r-tools"><input class="r-search" id="bk-q" placeholder="Search a name, entry number or bill number…" value="${esc(st.q)}"></div>
        ${items.length ? `<div class="scroll-x"><table class="team rec book"><thead><tr><th>Entry no.</th><th>Date</th><th>Particulars</th><th>Bill no.</th><th class="num">Received (in)</th><th class="num">Paid (out)</th><th class="num">Balance</th><th></th></tr></thead><tbody>
          ${items.map((it) => `<tr class="click" data-bk-edit="${esc(it.id)}">
            <td data-l="Entry no."><b>${esc(it.entry_no || "")}</b></td><td data-l="Date">${esc(X.fmtDate(it.date))}</td>
            <td data-l="Particulars"><b>${esc(it.party || "")}</b> <span class="tag">${esc(it.what || "")}</span>${it.project ? `<br><span class="hint-text">${esc(it.project)}</span>` : ""}${it.note ? `<br><span class="hint-text">${esc(it.note)}</span>` : ""}</td>
            <td data-l="Bill no.">${esc(it.bill_no || "")}</td>
            <td data-l="Received" class="num">${it.direction === "Received" ? inr2(it.amount) : ""}</td>
            <td data-l="Paid" class="num">${it.direction === "Paid" ? inr2(it.amount) : ""}</td>
            <td data-l="Balance" class="num"><b>${inr2(it.balance)}</b></td>
            <td class="nowrap">${it.bill ? `<button class="btn small ghost" data-bk-view="${esc(it.id)}">View bill</button>` : ""}${it.photo ? (/\.pdf$/.test(it.photo) ? `<a class="btn small ghost" href="/recfiles/${esc(it.photo)}?${tq()}" target="_blank" rel="noopener">Bill PDF</a>` : `<a href="/recfiles/${esc(it.photo)}?${tq()}" target="_blank" rel="noopener"><img class="thumb" src="/recfiles/${esc(it.photo)}?${tq()}" alt="Bill photo" loading="lazy"></a>`) : ""}${it.versions && it.versions.length ? ` <span class="tag" title="Earlier versions are kept">edited</span>` : ""}</td></tr>`).join("")}
        </tbody></table></div>` : `<p class="empty">${r.items.length ? "Nothing matches." : "No entries yet. Tap “+ New entry” or “+ Make a bill”."}</p>`}
        <p class="hint-text">Entries are never erased. To correct one, open it and change it — the earlier version is kept — or add a correcting entry.</p>
      </section><div id="bk-print" class="print-only"></div>`;
    const entryForm = (it) => {
      const f = $("#bk-form", box);
      f.innerHTML = `<form class="panel form" id="bk-ef"><h3>${it.id ? "Entry " + esc(it.entry_no || "") : "New entry"} <span class="h-note">${it.id ? "the earlier version is kept" : "the entry number is given automatically"}</span></h3>
        <div class="grid2">
          <label class="f"><span>Date</span><input type="date" id="bk-date" value="${esc(it.date || X.todayIso())}"></label>
          <label class="f"><span>What</span><select id="bk-what">${["Cash", "Commission", "Bill", "Cash note", "Other"].map((o) => `<option ${o === (it.what || "Cash") ? "selected" : ""}>${o}</option>`).join("")}</select></label>
          <label class="f"><span>Name (person or firm)</span><input id="bk-party" value="${esc(it.party || "")}"></label>
          <label class="f"><span>Bill number <i>(from the bill, if any)</i></span><input id="bk-billno" value="${esc(it.bill_no || "")}"></label>
          <label class="f"><span>Money</span><select id="bk-dir">${["Received", "Paid", "Just a note"].map((o) => `<option ${o === (it.direction || "Received") ? "selected" : ""}>${o}</option>`).join("")}</select></label>
          <label class="f"><span>Amount (₹)</span><input id="bk-amt" type="number" min="0" step="0.01" inputmode="decimal" value="${esc(it.amount ?? "")}"></label>
          <label class="f"><span>Project / reference <i>(optional)</i></span><input id="bk-proj" value="${esc(it.project || "")}"></label>
          <label class="f"><span>Photo of the bill <i>(optional)</i></span><input id="bk-photo" type="file" accept="image/*,application/pdf" capture="environment"></label>
          <label class="f full2"><span>Note <i>(optional)</i></span><input id="bk-note" value="${esc(it.note || "")}"></label>
        </div>
        <div class="form-row"><p class="form-error" id="bk-err"></p><span class="btn-row tight"><button class="btn ghost" type="button" data-bk-cancel>Cancel</button><button class="btn">Save entry</button></span></div></form>`;
      f.scrollIntoView({ behavior: "smooth", block: "start" });
      $("#bk-ef", f).onsubmit = async (e) => {
        e.preventDefault();
        const ph = $("#bk-photo", f).files[0];
        const item = { id: it.id, date: $("#bk-date", f).value, what: $("#bk-what", f).value, party: $("#bk-party", f).value, bill_no: $("#bk-billno", f).value,
          direction: $("#bk-dir", f).value, amount: $("#bk-amt", f).value, project: $("#bk-proj", f).value, note: $("#bk-note", f).value,
          photo: ph ? (ph.type === "application/pdf" ? await new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(ph); }) : await shrink(ph)) : (it.photo || "") };
        try { await req("/api/rec/ledger", { item }); toast(it.id ? "Entry updated" : "Entry saved"); renderBook(box); } catch (x) { $("#bk-err", f).textContent = x.message; }
      };
    };
    const billForm = () => {
      const f = $("#bk-form", box);
      const row = () => `<div class="bill-line"><input placeholder="Description" class="bl-d"><input placeholder="Qty" class="bl-q" type="number" min="0" step="any" value="1"><input placeholder="Rate (₹)" class="bl-r" type="number" min="0" step="0.01"><b class="bl-a">₹0</b></div>`;
      f.innerHTML = `<form class="panel form" id="bk-bf"><h3>Make a bill <span class="h-note">it gets its own bill number and goes into the book</span></h3>
        <div class="grid2">
          <label class="f"><span>Bill to (name)</span><input id="bl-party"></label>
          <label class="f"><span>Date</span><input type="date" id="bl-date" value="${X.todayIso()}"></label>
          <label class="f"><span>Phone <i>(optional)</i></span><input id="bl-phone" inputmode="tel"></label>
          <label class="f"><span>Address <i>(optional)</i></span><input id="bl-addr"></label>
          <label class="f"><span>Money</span><select id="bl-dir"><option value="Received">We receive this money</option><option value="Paid">We pay this money</option></select></label>
          <label class="f"><span>Project / reference <i>(optional)</i></span><input id="bl-proj"></label>
        </div>
        <p class="eyebrow">Items</p><div id="bl-lines">${row()}${row()}</div>
        <button type="button" class="btn small ghost" data-bl-add>+ Add a line</button>
        <div class="bill-tot"><label class="chk"><input type="checkbox" id="bl-gst"> Add GST</label><input id="bl-gstp" type="number" min="0" max="28" step="0.5" value="18" aria-label="GST %" disabled> %
          <span>Total: <b id="bl-total">₹0.00</b></span></div>
        <label class="f full2"><span>Note on the bill <i>(optional)</i></span><input id="bl-note"></label>
        <div class="form-row"><p class="form-error" id="bl-err"></p><span class="btn-row tight"><button class="btn ghost" type="button" data-bk-cancel>Cancel</button><button class="btn">Make the bill</button></span></div></form>`;
      f.scrollIntoView({ behavior: "smooth", block: "start" });
      const fm = $("#bk-bf", f);
      const calc = () => {
        let sub = 0;
        $$(".bill-line", fm).forEach((l) => { const a = (Number($(".bl-q", l).value) || 0) * (Number($(".bl-r", l).value) || 0); sub += a; $(".bl-a", l).textContent = inr2(a); });
        const g = $("#bl-gst", fm).checked ? sub * (Number($("#bl-gstp", fm).value) || 0) / 100 : 0;
        $("#bl-total", fm).textContent = inr2(sub + g) + (g ? ` (incl. GST ${inr2(g)})` : "");
      };
      fm.oninput = calc;
      fm.onchange = (e) => { if (e.target.id === "bl-gst") $("#bl-gstp", fm).disabled = !e.target.checked; calc(); };
      fm.onclick = (e) => { if (e.target.closest("[data-bl-add]")) $("#bl-lines", fm).insertAdjacentHTML("beforeend", row()); };
      fm.onsubmit = async (e) => {
        e.preventDefault();
        const lines = $$(".bill-line", fm).map((l) => ({ desc: $(".bl-d", l).value, qty: $(".bl-q", l).value, rate: $(".bl-r", l).value }));
        try {
          const res = await req("/api/private/bill", { party: $("#bl-party", fm).value, date: $("#bl-date", fm).value, phone: $("#bl-phone", fm).value, address: $("#bl-addr", fm).value,
            direction: $("#bl-dir", fm).value, project: $("#bl-proj", fm).value, items: lines, gst: $("#bl-gst", fm).checked, gst_pct: $("#bl-gstp", fm).value, note: $("#bl-note", fm).value });
          toast(`Bill ${res.bill.no} made and written in the book`);
          await renderBook(box); showBill(res.bill);
        } catch (x) { $("#bl-err", fm).textContent = x.message; }
      };
    };
    const showBill = (b) => {
      const html = `<article class="bill-doc"><header><div><h2>${esc(b.from || "")}</h2><p>${b.direction === "Paid" ? "Payment voucher" : "Bill"}</p></div>
          <div class="bill-no"><b>${esc(b.no)}</b><span>${esc(X.fmtDate(b.date))}</span></div></header>
        <p class="bill-to"><span>${b.direction === "Paid" ? "Paid to" : "Bill to"}</span><b>${esc(b.party)}</b>${b.address ? `<br>${esc(b.address)}` : ""}${b.phone ? `<br>${esc(b.phone)}` : ""}</p>
        <table><thead><tr><th>#</th><th>Description</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr></thead>
          <tbody>${b.lines.map((l, i) => `<tr><td>${i + 1}</td><td>${esc(l.desc)}</td><td class="num">${l.qty}</td><td class="num">${inr2(l.rate)}</td><td class="num">${inr2(l.amount)}</td></tr>`).join("")}</tbody>
          <tfoot><tr><td colspan="4">Subtotal</td><td class="num">${inr2(b.subtotal)}</td></tr>${b.gst ? `<tr><td colspan="4">GST ${b.gst_pct}%</td><td class="num">${inr2(b.gst)}</td></tr>` : ""}<tr class="grand"><td colspan="4">Total</td><td class="num">${inr2(b.total)}</td></tr></tfoot></table>
        ${b.note ? `<p>${esc(b.note)}</p>` : ""}<footer>Made by ${esc(b.by)} · ${esc(X.fmtDate(b.made))}</footer></article>`;
      const sh = document.createElement("div"); sh.className = "bill-sheet";
      sh.innerHTML = `<div class="bill-wrap">${html}<div class="btn-row"><button class="btn" data-bp>Print / save as PDF</button><button class="btn ghost" data-bx>Close</button></div></div>`;
      document.body.appendChild(sh);
      sh.onclick = (e) => { if (e.target.closest("[data-bx]") || e.target === sh) sh.remove(); if (e.target.closest("[data-bp]")) printHtml(html); };
    };
    box.onclick = async (e) => {
      const t = e.target;
      if (t.closest("[data-bk-new]")) return entryForm({});
      if (t.closest("[data-bk-bill]")) return billForm();
      if (t.closest("[data-bk-cancel]")) { $("#bk-form", box).innerHTML = ""; return; }
      if (t.closest("[data-r-lock]")) { await req("/api/private/lock", {}); toast("Locked"); return renderBook(box); }
      if (t.closest("[data-bk-print]")) {
        const tb = $(".book-sheet table", box);
        printHtml(`<div class="print-book"><h2>${esc(X.me().firm || "")} — Private book</h2><p>Printed ${esc(X.fmtDate(X.todayIso()))}</p>${tb ? tb.outerHTML : "<p>No entries.</p>"}</div>`); return;
      }
      const v = t.closest("[data-bk-view]"); if (v) { const it = r.items.find((x) => x.id === v.dataset.bkView); if (it && it.bill) showBill(it.bill); return; }
      const ed = t.closest("[data-bk-edit]");
      if (ed && !t.closest("a, button")) { const it = r.items.find((x) => x.id === ed.dataset.bkEdit); if (it) entryForm(it); }
    };
    const q = $("#bk-q", box);
    q.oninput = () => { clearTimeout(q._t); q._t = setTimeout(() => { st.q = q.value; renderBook(box).then(() => { const n = $("#bk-q", box); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 350); };
  }
  function phraseForm(box, change) {
    box.innerHTML = `<details class="panel"${change ? "" : " open"}><summary><b>${change ? "Change the secret word" : "Private book — set your secret word"}</b></summary>
      <p class="hint-text">${change ? "" : "The private book stays hidden. On Business, Accounts or Team &amp; wallet, type your secret word and press Enter (or press and hold the page heading and say it) — then the button appears. It still asks for your password. "}Don't use your password as the secret word.</p>
      <form class="inline-form" id="bp-form" style="grid-template-columns:1fr 1fr auto"><input id="bp-phrase" type="password" placeholder="Secret word or phrase" autocomplete="off"><input id="bp-pw" type="password" placeholder="Your password" autocomplete="current-password"><button class="btn">Save</button></form>
      <p class="form-error" id="bp-err"></p></details>`;
    $("#bp-form", box).addEventListener("submit", async (e) => {
      e.preventDefault();
      try { await req("/api/private/phrase", { phrase: $("#bp-phrase", box).value, password: $("#bp-pw", box).value }); toast("Secret word saved"); box.innerHTML = change ? "" : `<p class="hint-text">Secret word saved. The private book is now hidden.</p>`; }
      catch (x) { $("#bp-err", box).textContent = x.message; }
    });
  }
  X.bookSetup = async (box) => {                 // shown on Team & wallet to the owner only until a secret word is set
    try { const r = await req("/api/rec-schemas"); if (r.book && r.book.owner && !r.book.set) { const d = document.createElement("div"); box.appendChild(d); phraseForm(d, false); } } catch (x) {}
  };
  document.addEventListener("keydown", (e) => {
    if (!bookHere()) { bookBuf = ""; return; }
    const fld = e.target.closest && e.target.closest("input, textarea, select, [contenteditable]");
    if (fld && fld.offsetParent !== null) return;          // typing into a visible box is never read
    if (Date.now() - bookBufT > 4000) bookBuf = "";
    bookBufT = Date.now();
    if (e.key === "Enter") { const p = bookBuf; bookBuf = ""; if (p) { e.preventDefault(); bookTry(p); } return; }
    if (e.key === "Escape") { bookBuf = ""; return; }
    if (e.key === "Backspace") { bookBuf = bookBuf.slice(0, -1); return; }
    if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) bookBuf = (bookBuf + e.key).slice(-60);
  });
  let holdT = null;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  document.addEventListener("pointerdown", (e) => {
    if (!SR || !bookHere() || !e.target.closest(".o-title")) return;
    holdT = setTimeout(() => {
      const rec = new SR(); rec.lang = "en-IN"; rec.maxAlternatives = 3; rec.interimResults = false;
      toast("Listening…");
      rec.onresult = (ev) => { const alts = [...ev.results[0]].map((a) => a.transcript); (async () => { for (const a of alts) { const r = await req("/api/private/reveal", { phrase: a }).catch(() => ({})); if (r.show) return bookButton(); } })(); };
      try { rec.start(); } catch (x) {}
    }, 700);
  });
  ["pointerup", "pointerleave", "pointercancel"].forEach((n) => document.addEventListener(n, () => clearTimeout(holdT)));

  /* ---------- Vendor Showroom: today, and every update from the Office ---------- */
  X.tabs.supdates = async (box) => {
    const [t, u] = await Promise.all([req("/api/vendor/today"), req("/api/vendor/updates")]);
    box.innerHTML = `<div class="o-head"><div><p class="eyebrow">${esc(X.fmtDate(X.todayIso()))} · Showroom</p><h2 class="o-title">Today &amp; updates</h2>
        <p class="o-sub">Everything the Office does — orders, deliveries, samples — shows here as it happens.</p></div>
        <div class="head-acts"><button class="btn" data-sgo="rec:visits">+ Book a visit</button></div></div>
      <div class="cols">
        <section class="panel"><h3>Visits today</h3>${t.visits_today.length ? `<ul class="list">${t.visits_today.map((v) => `<li><span class="when">${esc(v.time || "")}</span><span class="what"><b>${esc(v.architect)}</b>${v.client ? " with " + esc(v.client) : ""}</span><span class="where">${esc(v.looking_for || "")} · ${esc(v.status || "")}</span></li>`).join("")}</ul>` : `<p class="empty">No visits booked today.</p>`}</section>
        <section class="panel"><h3>Samples to follow up</h3>${t.samples_due.length ? `<ul class="list">${t.samples_due.map((s) => `<li><span class="what"><b>${esc(s.item)}</b> → ${esc(s.architect)}</span><span class="where">${esc(X.fmtDate(s.follow_up))}</span></li>`).join("")}</ul>` : `<p class="empty">Nothing to chase.</p>`}</section>
      </div>
      <section class="panel"><h3>Updates from the Office</h3>${u.updates.length ? `<ul class="list feed">${u.updates.map((x) => `<li><span class="dot k-${x.status === "Delivered" || x.status === "Installed" ? "photo" : "change"}"></span><span class="what"><b>${esc(x.what)}</b> ${esc(x.title)} → <span class="st st-${esc(x.status.toLowerCase().replace(/[^a-z]+/g, "-"))}">${esc(x.status)}</span>${x.pod ? ` · <a href="/recfiles/${esc(x.pod)}?${tq()}" target="_blank" rel="noopener">proof photo</a>` : ""}</span><span class="where">${esc(x.by)} · ${esc(ago(x.time))}</span></li>`).join("")}</ul>` : `<p class="empty">No updates yet. When the Office changes an order, delivery or sample, it appears here.</p>`}</section>`;
    box.onclick = (e) => { const g = e.target.closest("[data-sgo]"); if (g) { X.office.tab = g.dataset.sgo; X.renderOffice(); } };
  };

  /* ---------- Vendor: Today ---------- */
  X.tabs.vtoday = async (box) => {
    const t = await req("/api/vendor/today");
    const me = X.me();
    const stages = ["Confirmed", "In production", "Ready", "Dispatched", "Delivered", "Installed"];
    box.innerHTML = `
      <div class="o-head"><div><p class="eyebrow">${esc(X.fmtDate(X.todayIso()))} · Office</p><h2 class="o-title">Good ${new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}, ${esc(me.name || "")}</h2></div></div>
      <div id="owner-alerts"></div>
      <div class="kpis">
        <button class="kpi" data-vgo="rec:quotes"><b>${t.quotes_open}</b><span>open quotes · ${inr(t.quotes_value)}</span></button>
        <button class="kpi ${t.pending ? "warn" : ""}" data-vgo="rec:accounts"><b>${inr(t.pending)}</b><span>to collect</span></button>
        <button class="kpi ${t.samples_due.length ? "warn" : ""}" data-vgo="rec:samples"><b>${t.samples_due.length}</b><span>samples to follow up</span></button>
        <button class="kpi" data-vgo="rec:v_architects"><b>${t.architects}</b><span>architects · ${t.products} products</span></button>
      </div>
      <section class="panel"><h3>Orders by stage</h3><div class="vstages">${stages.map((s) => `<div class="vstage"><b>${t.orders_by_stage[s] || 0}</b><span>${s}</span></div>`).join("")}</div></section>
      <div class="cols">
        <section class="panel"><h3>Samples to follow up</h3>${t.samples_due.length ? `<ul class="list">${t.samples_due.map((s) => `<li><span class="what"><b>${esc(s.item)}</b> → ${esc(s.architect)}</span><span class="where">${esc(s.project || "")} · follow up ${esc(X.fmtDate(s.follow_up))}</span></li>`).join("")}</ul>` : `<p class="empty">Nothing to chase today.</p>`}</section>
        <section class="panel"><h3>Dispatch and site today</h3>${t.dispatch_today.length + t.jobs_today.length ? `<ul class="list">${t.dispatch_today.map((d) => `<li><span class="what"><b>${esc(d.order)}</b> ${esc(d.slot || "")}</span><span class="where">${esc(d.vehicle || "")} ${d.driver_phone ? "· " + esc(d.driver_phone) : ""} · ${esc(d.status || "")}</span></li>`).join("")}${t.jobs_today.map((j) => `<li><span class="what"><b>${esc(j.type)}</b> ${esc(j.site)}</span><span class="where">${esc(j.team || "")} · ${esc(j.status || "")}</span></li>`).join("")}</ul>` : `<p class="empty">No deliveries or site jobs today.</p>`}</section>
      </div>
      ${t.overdue.length ? `<section class="panel attention"><h3>Payments overdue</h3><ul class="list">${t.overdue.map((a) => `<li><span class="what"><b>${esc(a.party)}</b> · ${esc(a.ref)}</span><span class="where">${inr(a.left)} · was due ${esc(X.fmtDate(a.due))}</span></li>`).join("")}</ul></section>` : ""}`;
    if (X.ownerAlerts) req("/api/home").then((h) => X.ownerAlerts($("#owner-alerts", box), h.alerts)).catch(() => {});
    box.onclick = (e) => {
      const g = e.target.closest("[data-vgo]");
      if (!g) return;
      X.office.tab = g.dataset.vgo;
      X.renderOffice();
    };
  };

  /* ---------- Architect: Business ---------- */
  const biz = { sub: "overview" };
  X.tabs.business = async (box) => {
    const subs = [["overview", "Overview"], ["hours", "Hours"], ["expenses", "Expenses"], ["fees", "Fees 🔒"]];
    if ((X.me().role || "") === "owner") subs.push(["access", "Who can open 🔒"]);
    box.innerHTML = `<div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">Business</h2>
      <p class="o-sub">Your time, costs and fees — so you know what each project really earns.</p></div></div>
      <nav class="subtabs">${subs.map(([k, l]) => `<button data-biz="${k}" class="${biz.sub === k ? "on" : ""}">${l}</button>`).join("")}</nav>
      <div id="biz-body"></div>`;
    $(".subtabs", box).onclick = (e) => { const b = e.target.closest("[data-biz]"); if (b) { biz.sub = b.dataset.biz; X.tabs.business(box); } };
    const inner = $("#biz-body", box);
    if (biz.sub === "overview") return bizOverview(inner);
    if (biz.sub === "access") return bizAccess(inner);
    return renderRec(inner, biz.sub, { noHead: true, lockLabel: "Fees" });
  };
  async function bizOverview(box) {
    const o = await req("/api/business");
    const rows = Object.entries(o.projects);
    box.innerHTML = `
      <div class="kpis three">
        <div class="kpi"><b>${o.month_hours}</b><span>hours this month</span></div>
        <div class="kpi"><b>${inr(o.month_expenses)}</b><span>expenses this month</span></div>
        <div class="kpi">${o.unlocked ? `<b>${inr(rows.reduce((a, [, v]) => a + (v.received || 0), 0))}</b><span>fees received (all time)</span>` : `<b>🔒</b><span>${o.can_private ? "open Fees to see money" : "fees are private"}</span>`}</div>
      </div>
      <section class="panel"><h3>Per project</h3>
        ${rows.length ? `<div class="scroll-x"><table class="team"><thead><tr><th>Project</th><th>Hours</th><th>Expenses</th>${o.unlocked ? "<th>Fee agreed</th><th>Received</th><th>Pending</th><th>Received − expenses</th>" : ""}</tr></thead><tbody>
          ${rows.map(([p, v]) => `<tr><td><b>${esc(p)}</b></td><td>${Math.round(v.hours * 10) / 10}</td><td>${inr(v.expenses)}</td>${o.unlocked ? `<td>${inr(v.agreed)}</td><td>${inr(v.received)}</td><td class="${v.pending > 0 ? "warn-t" : ""}">${inr(v.pending)}</td><td><b>${inr(v.profit ?? (v.received || 0) - v.expenses)}</b></td>` : ""}</tr>`).join("")}
        </tbody></table></div>` : `<p class="empty">Add hours and expenses to see each project here.</p>`}
        ${!o.unlocked && o.can_private ? `<div class="btn-row"><button class="btn ghost" data-biz-open>Show fees (password)</button></div>` : ""}
      </section>`;
    box.onclick = (e) => { if (e.target.closest("[data-biz-open]")) { biz.sub = "fees"; X.renderOffice(); } };
  }
  async function bizAccess(box) {
    const t = await X.api("/api/users");
    box.innerHTML = `<section class="panel"><h3>Who can open private pages <span class="h-note">Fees and the private book</span></h3>
      <p class="hint-text">Each person opens them with their own password, on their own screen. Everyone else never sees them.</p>
      <ul class="list">${t.users.filter((u) => !u.pending).map((u) => `<li><span class="what"><b>${esc(u.name)}</b> ${u.role === "owner" ? '<span class="tag">owner</span>' : ""}</span>
        ${u.role === "owner" ? `<span class="where">always</span>` : `<label class="switch"><input type="checkbox" data-acc="${esc(u.id)}" ${u.private ? "checked" : ""}><span></span></label>`}</li>`).join("")}</ul></section>`;
    box.onchange = async (e) => {
      const c = e.target.closest("[data-acc]"); if (!c) return;
      try { await req("/api/private/access", { id: c.dataset.acc, on: c.checked }); toast(c.checked ? "Access given" : "Access removed"); } catch (x) { toast(x.message); c.checked = !c.checked; }
    };
  }

  /* =========================================================
     SOCIAL MEDIA BOARD + CAPTURE
     ========================================================= */
  const soc = { bucket: "To review" };
  X.tabs.social = async (box) => {
    const s = await req("/api/social");
    const items = s.items.filter((i) => i.bucket === soc.bucket);
    const buckets = s.folders || ["To review", "Wanted", "Not wanted", "Posted"];
    if (!buckets.includes(soc.bucket)) soc.bucket = "To review";
    const custom = !(s.base || []).includes(soc.bucket);
    box.innerHTML = `<div class="o-head"><div><p class="eyebrow">Content</p><h2 class="o-title">Social media board</h2>
      <p class="o-sub">Everything you capture for social media lands here, sorted into photos and videos. Keep what you want; post from here.</p></div>
      <div class="head-acts"><button class="btn" data-cap-open>+ Add photos or videos</button></div></div>
      <nav class="subtabs soc-tabs">${buckets.map((b) => `<button data-soc="${esc(b)}" class="${soc.bucket === b ? "on" : ""}">${esc(b)} <i>${s.counts[b] || 0}</i></button>`).join("")}<button class="soc-new" data-soc-new>+ New folder</button></nav>
      <form class="inline-form soc-newf" id="soc-newf" hidden><input id="soc-newn" placeholder="Folder name, e.g. Diwali 2026" maxlength="40"><button class="btn small">Make folder</button></form>
      ${custom && !(s.counts[soc.bucket]) ? `<p class="hint-text">This folder is empty. <button class="link-quiet show" data-soc-rm="${esc(soc.bucket)}">Remove folder</button></p>` : ""}
      ${items.length ? `<div class="soc-grid">${items.map((i) => `<figure class="soc-item">
          ${i.kind === "photo" ? `<a href="/social-file?rel=${encodeURIComponent(i.rel)}&${tq()}" target="_blank" rel="noopener"><img src="/social-file?rel=${encodeURIComponent(i.rel)}&${tq()}" alt="" loading="lazy"></a>`
            : i.kind === "video" ? `<video src="/social-file?rel=${encodeURIComponent(i.rel)}&${tq()}" controls preload="metadata" playsinline></video>`
            : `<a class="soc-file" href="/social-file?rel=${encodeURIComponent(i.rel)}&${tq()}" target="_blank" rel="noopener">${esc(i.name)}</a>`}
          <figcaption>${i.note ? `<p>${esc(i.note)}</p>` : ""}<span>${esc(ago(i.time))} · ${i.kind}</span>
            <span class="soc-acts">${i.bucket !== "Wanted" ? `<button class="btn small" data-soc-move="Wanted" data-rel="${esc(i.rel)}">Keep</button>` : ""}${i.bucket !== "Posted" ? `<button class="btn small ghost" data-soc-move="Posted" data-rel="${esc(i.rel)}">Mark posted</button>` : ""}
              <select class="soc-to" data-soc-to="${esc(i.rel)}" aria-label="Move to folder"><option value="">Move to…</option>${buckets.filter((b) => b !== i.bucket).map((b) => `<option>${esc(b)}</option>`).join("")}</select>
            ${i.kind === "photo" && X.me().courtyard ? `<button class="btn small ghost" data-soc-share="${esc(i.rel)}">Share in Courtyard</button>` : ""}</span></figcaption></figure>`).join("")}</div>`
        : `<p class="empty">${soc.bucket === "To review" ? "Nothing new. Tap the Capture button on your phone and choose “Social media”." : "Nothing here yet."}</p>`}
      <p class="path">On the studio computer: ${esc(s.folder)}</p>`;
    $("#soc-newf", box).onsubmit = async (e) => {
      e.preventDefault();
      try { await req("/api/social/folder", { name: $("#soc-newn", box).value }); soc.bucket = $("#soc-newn", box).value.trim(); toast("Folder made"); X.tabs.social(box); } catch (x) { toast(x.message); }
    };
    box.onchange = async (e) => {
      const sel = e.target.closest("[data-soc-to]"); if (!sel || !sel.value) return;
      try { await req("/api/social/move", { rel: sel.dataset.socTo, bucket: sel.value }); toast("Moved to " + sel.value); X.tabs.social(box); } catch (x) { toast(x.message); }
    };
    box.onclick = async (e) => {
      const b = e.target.closest("[data-soc]"); if (b) { soc.bucket = b.dataset.soc; return X.tabs.social(box); }
      const m = e.target.closest("[data-soc-move]");
      if (m) { await req("/api/social/move", { rel: m.dataset.rel, bucket: m.dataset.socMove }); toast("Moved to " + m.dataset.socMove); return X.tabs.social(box); }
      if (e.target.closest("[data-cap-open]")) return openCapture("social");
      if (e.target.closest("[data-soc-new]")) { const f = $("#soc-newf", box); f.hidden = !f.hidden; if (!f.hidden) $("#soc-newn", box).focus(); return; }
      const rm = e.target.closest("[data-soc-rm]");
      if (rm) { try { await req("/api/social/folder-remove", { name: rm.dataset.socRm }); soc.bucket = "To review"; toast("Folder removed"); return X.tabs.social(box); } catch (x) { return toast(x.message); } }
      const sh = e.target.closest("[data-soc-share]");
      if (sh) {
        const blob = await (await fetch(`/social-file?rel=${encodeURIComponent(sh.dataset.socShare)}&${tq()}`)).blob();
        const data = await shrink(new File([blob], "p.jpg", { type: blob.type || "image/jpeg" }));
        X.cyPreset = { type: "gallery", images: [data] };
        X.go("courtyard");
      }
    };
  };

  const capBtn = $("#cap-fab"), capSheet = $("#cap-sheet");
  async function openCapture(to) {
    const projs = await projects(true);
    const vendor = X.me().kind === "vendor";
    capSheet.innerHTML = `<div class="cap-card" role="dialog" aria-label="Capture">
      <header><b>Capture</b><small>Goes straight to the studio computer</small><button class="x" data-cap-close aria-label="Close">×</button></header>
      <label class="cap-pick"><input type="file" id="cap-file" accept="image/*,video/*,application/pdf" multiple><span>📷 Take a photo or video, or choose from the phone</span></label>
      <p class="cap-chosen" id="cap-chosen"></p>
      <p class="eyebrow">Send to</p>
      <div class="cap-to">
        <label><input type="radio" name="cap-to" value="social" ${to !== "project" && to !== "bills" ? "checked" : ""}><span>Social media board</span></label>
        ${!vendor && projs.length ? `<label><input type="radio" name="cap-to" value="project" ${to === "project" ? "checked" : ""}><span>A project</span></label>` : ""}
        <label><input type="radio" name="cap-to" value="bills" ${to === "bills" ? "checked" : ""}><span>Bills</span></label>
      </div>
      <select id="cap-proj" hidden>${projs.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("")}</select>
      <input id="cap-note" placeholder="A note (optional) — e.g. “lobby wall, use for Diwali post”">
      <div class="cap-bar" hidden><i></i></div>
      <p class="form-error" id="cap-err"></p>
      <button class="btn cap-send" id="cap-send">Send</button></div>`;
    capSheet.hidden = false;
    const sync = () => { $("#cap-proj").hidden = !($("input[name=cap-to]:checked") || {}).value || $("input[name=cap-to]:checked").value !== "project"; };
    sync();
    capSheet.onchange = (e) => { if (e.target.name === "cap-to") sync(); if (e.target.id === "cap-file") $("#cap-chosen").textContent = [...e.target.files].map((f) => f.name).join(", "); };
    capSheet.onclick = async (e) => {
      if (e.target === capSheet || e.target.closest("[data-cap-close]")) { capSheet.hidden = true; return; }
      if (!e.target.closest("#cap-send")) return;
      const files = [...$("#cap-file").files];
      if (!files.length) { $("#cap-err").textContent = "Choose a photo, video or file first."; return; }
      const dest = $("input[name=cap-to]:checked").value;
      $("#cap-send").disabled = true; $(".cap-bar").hidden = false;
      try {
        for (let i = 0; i < files.length; i++) {
          const f = files[i];
          if (f.size > 55 * 1024 * 1024) throw new Error(`“${f.name}” is too big (over 55 MB).`);
          $(".cap-bar i").style.width = Math.round((i / files.length) * 100) + "%";
          const data = f.type.startsWith("image/") ? await shrink(f, 2400, 0.88) : await readFile(f);
          await req("/api/capture", { data, name: f.name.replace(/\.(heic|heif)$/i, ".jpg"), to: dest, project: $("#cap-proj").value, note: $("#cap-note").value });
        }
        $(".cap-bar i").style.width = "100%";
        toast(`Sent ${files.length} to ${dest === "social" ? "Social media board" : dest === "bills" ? "Bills" : "the project"}`);
        capSheet.hidden = true;
        if (X.office.tab === "social" && !$("#view-office").hidden) X.renderOffice();
      } catch (x) { $("#cap-err").textContent = x.message; $("#cap-send").disabled = false; }
    };
  }
  capBtn.addEventListener("click", () => openCapture("social"));
  setInterval(() => {                       // Capture shows once signed in, on every screen after the pendulum
    const show = !!X.token() && $("#view-login").hidden && !$("#view-welcome").hidden + !$("#view-office").hidden + !$("#view-site").hidden + !$("#view-courtyard").hidden > 0;
    capBtn.hidden = !show;
  }, 700);

  /* =========================================================
     SITE: MEETING (voice -> points -> MOM)
     ========================================================= */
  X.meeting = (p, room) => {
    const box = $("#s-meeting");
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const canListen = !!SR && window.isSecureContext;
    const canRecord = !!(navigator.mediaDevices && window.MediaRecorder) && window.isSecureContext;
    box.hidden = false;
    box.innerHTML = `<h3>Meeting</h3>
      <p class="s-help">${canListen ? "Tap <b>Listen</b> and talk normally — English or Hindi. Everything is written down as you speak." : "Tap the <b>microphone on your phone keyboard</b> and talk — English or Hindi. Keep talking; tap the mic again if it stops."} When the meeting is over, tap <b>Meeting over</b> and the MOM is made from it.</p>
      ${canListen ? `<div class="s-btns meet-btns"><button class="s-btn" data-listen="en-IN">Listen · English</button><button class="s-btn" data-listen="hi-IN">Listen · Hindi</button><span class="meet-live" id="meet-live"></span></div>` : ""}
      <textarea id="meet-text" rows="9" placeholder="The meeting appears here…"></textarea>
      <div class="s-form-row"><button class="btn ghost light" data-meet-cancel>Cancel</button><button class="btn orange" data-meet-done>Meeting over — make MOM</button></div>`;
    box.scrollIntoView({ behavior: "smooth", block: "start" });
    const ta = $("#meet-text", box);
    if (!canListen) setTimeout(() => ta.focus(), 200);
    let rec = null, listening = false, media = null, chunks = [];
    const stopAll = () => {
      listening = false;
      try { rec && rec.stop(); } catch (e) {}
      try { media && media.state !== "inactive" && media.stop(); } catch (e) {}
      $$("[data-listen]", box).forEach((b) => b.classList.remove("on"));
      const l = $("#meet-live", box); if (l) l.textContent = "";
    };
    box.onclick = async (e) => {
      const l = e.target.closest("[data-listen]");
      if (l) {
        if (listening) { stopAll(); return; }
        listening = true; l.classList.add("on");
        rec = new SR(); rec.lang = l.dataset.listen; rec.continuous = true; rec.interimResults = true;
        rec.onresult = (ev) => {
          let fin = "", tmp = "";
          for (let i = ev.resultIndex; i < ev.results.length; i++) (ev.results[i].isFinal ? (fin += ev.results[i][0].transcript) : (tmp += ev.results[i][0].transcript));
          if (fin) ta.value = (ta.value ? ta.value.replace(/\s*$/, "") + ". " : "") + fin.trim();
          $("#meet-live", box).textContent = tmp ? "… " + tmp : "● listening";
        };
        rec.onend = () => { if (listening) { try { rec.start(); } catch (x) {} } };   // keeps going after pauses
        rec.onerror = (ev) => { if (ev.error === "not-allowed") { toast("Allow the microphone to use Listen"); stopAll(); } };
        try { rec.start(); $("#meet-live", box).textContent = "● listening"; } catch (x) { toast("Listening didn't start. Use the keyboard mic instead."); stopAll(); }
        if (canRecord && !media) {          // also keep the sound as a backup
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            media = new MediaRecorder(stream); chunks = [];
            media.ondataavailable = (d) => d.data.size && chunks.push(d.data);
            media.start(5000);
          } catch (x) { media = null; }
        }
        return;
      }
      if (e.target.closest("[data-meet-cancel]")) { stopAll(); box.hidden = true; box.innerHTML = ""; return; }
      if (e.target.closest("[data-meet-done]")) {
        stopAll();
        const text = ta.value.trim();
        if (text.length < 3) { toast("Nothing recorded yet"); return; }
        await new Promise((ok) => setTimeout(ok, 400));
        let audio = "";
        if (chunks.length) { const blob = new Blob(chunks, { type: media.mimeType || "audio/webm" }); if (blob.size < 40 * 1024 * 1024) audio = await readFile(blob); }
        try {
          const r = await req(`/api/projects/${p.id}/meeting`, { text, room, audio });
          toast(`${r.points} points added — making the MOM`);
          await X.renderSiteProject();
          const mb = $("#site-body [data-mom]"); if (mb) mb.click();
        } catch (x) { toast(x.message); }
      }
    };
  };

  /* =========================================================
     MOOD BOARD (inside a project, Office)
     ========================================================= */
  X.afterProject = (p) => {
    const box = $("#mood-panel");
    if (!box) return;
    const mb = p.moodboard || { words: "", images: [] };
    const src = (n) => X.fileUrl(p.id, "09 Mood Board/" + n);
    box.innerHTML = `<h3>Mood board <span class="h-note">the look and materials for this project</span></h3>
      <div class="mood-grid">${mb.images.map((n) => `<figure><img src="${src(n)}" alt="" loading="lazy"><button class="x" data-mood-rm="${esc(n)}" aria-label="Remove">×</button></figure>`).join("")}
        <label class="mood-add"><input type="file" accept="image/*" multiple id="mood-file" hidden><span>+ Add pictures</span></label></div>
      <label class="f full"><span>Design language <i>(colours, materials, mood — in your words)</i></span><textarea id="mood-words" rows="3">${esc(mb.words)}</textarea></label>
      <div class="btn-row"><button class="btn ghost" data-mood-save>Save words</button>
      ${X.me().courtyard ? `<button class="btn" data-mood-share>Ask vendors in The Courtyard</button>` : ""}</div>
      <p class="hint-text">Sharing posts this board as a “Looking for” request. Vendors reply with matching products and samples; your project name and client stay private.</p>`;
    box.onchange = async (e) => {
      if (e.target.id !== "mood-file") return;
      const add = [];
      for (const f of e.target.files) add.push(await shrink(f, 1400, 0.8));
      try { await X.api(`/api/projects/${p.id}/moodboard`, { add }); toast("Added to the mood board"); X.renderOffice(); } catch (x) { toast(x.message); }
    };
    box.onclick = async (e) => {
      const rm = e.target.closest("[data-mood-rm]");
      if (rm) { if (!sure(rm)) return; await X.api(`/api/projects/${p.id}/moodboard`, { remove: rm.dataset.moodRm }); return X.renderOffice(); }
      if (e.target.closest("[data-mood-save]")) { await X.api(`/api/projects/${p.id}/moodboard`, { words: $("#mood-words").value }); toast("Saved"); }
      if (e.target.closest("[data-mood-share]")) {
        await X.api(`/api/projects/${p.id}/moodboard`, { words: $("#mood-words").value });
        const b = e.target.closest("[data-mood-share]"); b.disabled = true; b.textContent = "Sharing…";
        try { const r = await X.api(`/api/projects/${p.id}/moodboard-share`, { title: "Looking for: " + ($("#mood-words").value.split(/[.\n]/)[0] || "materials for a new project").slice(0, 90), text: $("#mood-words").value }); toast(r.note || "Shared in The Courtyard"); }
        catch (x) { toast(x.message); }
        b.disabled = false; b.textContent = "Ask vendors in The Courtyard";
      }
    };
  };

  /* =========================================================
     WELCOME PICTURE (firm's own photo behind the welcome page)
     ========================================================= */
  X.welcomePhoto = (me) => {
    const v = $("#view-welcome");
    v.classList.toggle("has-photo", !!me.welcome_photo);
    v.style.setProperty("--wphoto", me.welcome_photo ? `url("/brand-photo?${tq()}&v=${Date.now()}")` : "none");
    let ctl = $("#wphoto-ctl");
    if (!ctl) {
      ctl = document.createElement("div"); ctl.id = "wphoto-ctl"; ctl.className = "wphoto-ctl";
      $(".welcome", v).appendChild(ctl);
      ctl.addEventListener("change", async (e) => {
        if (e.target.id !== "wphoto-file" || !e.target.files[0]) return;
        try { await X.api("/api/brand/photo", { data: await shrink(e.target.files[0], 2200, 0.85) }); toast("Welcome picture changed"); X.welcomePhoto(Object.assign(X.me(), { welcome_photo: true })); } catch (x) { toast(x.message); }
      });
      ctl.addEventListener("click", async (e) => {
        if (!e.target.closest("[data-wphoto-clear]")) return;
        await X.api("/api/brand/photo", { clear: true }); toast("Back to the Design Lab look"); X.welcomePhoto(Object.assign(X.me(), { welcome_photo: false }));
      });
    }
    ctl.hidden = me.role !== "owner";
    ctl.innerHTML = `<label class="link-quiet">Change picture<input type="file" accept="image/*" id="wphoto-file" hidden></label>${me.welcome_photo ? `<button class="link-quiet" data-wphoto-clear>Use Design Lab look</button>` : ""}`;
  };

})();
