/* =========================================================
   DESIGN LAB — THE COURTYARD (v0.8, redesigned)
   A calm, terracotta meeting place for architects and makers.
   Courtyard · People · Rooms · Messages · Open House · Magazine · My page
   Material & Brand Pins · Postcards · Welcome notes
   Lives on Design Lab's server; this file talks to it through the studio (/api/cy/...).
   ========================================================= */
(() => {
  "use strict";
  const X = window.DLX;
  if (!X || !X.api) return;
  const { esc, toast, $, $$ } = X;

  /* ---------- helpers ---------- */
  async function req(path, body) {
    const opts = { method: body === undefined ? "GET" : "POST", headers: { "Content-Type": "application/json", "X-Token": X.token() } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    let res;
    try { res = await fetch(path, opts); } catch (e) { throw new Error("Can't reach the Design Lab server. Is the studio computer on?"); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { const er = new Error(data.error || "Something went wrong."); er.status = res.status; throw er; }
    return data;
  }
  const ago = (iso) => {
    if (!iso) return "";
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s / 60) + " min ago";
    if (s < 86400) return Math.floor(s / 3600) + " h ago";
    if (s < 86400 * 7) return Math.floor(s / 86400) + " d ago";
    return X.fmtDate(iso);
  };
  const md = (t) => esc(t || "").replace(/(^|\s)#([\w&-]+)/g, '$1<button class="hash" data-tag="$2">#$2</button>').replace(/\n/g, "<br>");
  const readFile = (file) => new Promise((ok, bad) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = bad; r.readAsDataURL(file); });
  async function shrink(file, max = 1800, q = 0.84) {
    if (!/^image\/(jpeg|png|webp)/.test(file.type)) return readFile(file);
    try {
      const url = URL.createObjectURL(file);
      const img = await new Promise((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = bad; i.src = url; });
      const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement("canvas");
      c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      return c.toDataURL("image/jpeg", q);
    } catch (e) { return readFile(file); }
  }
  function sure(btn) {
    if (btn.dataset.sure) return true;
    const old = btn.textContent;
    btn.dataset.sure = "1"; btn.textContent = "Sure?"; btn.classList.add("sure");
    setTimeout(() => { delete btn.dataset.sure; btn.textContent = old; btn.classList.remove("sure"); }, 3000);
    return false;
  }
  const fimg = (n) => `/cy/files/${encodeURIComponent(n)}`;
  const initial = (name) => esc((name || "?").trim().charAt(0).toUpperCase());
  const tick = (m) => (m.verified ? `<i class="cv-tick" title="Verified by Design Lab">✓</i>` : "");
  const kindLabel = (k) => ({ architect: "Architect · designer", vendor: "Maker · vendor", designlab: "Design Lab" }[k] || "");
  const insta = (h) => "https://instagram.com/" + String(h || "").replace(/^@/, "").replace(/^https?:\/\/(www\.)?instagram\.com\//, "");
  const day = (d, o) => new Date(d + "T00:00").toLocaleDateString("en-IN", o);
  function sheet(html) {
    const box = document.createElement("div");
    box.className = "cv-sheet";
    box.innerHTML = `<div class="cv-card">${html}</div>`;
    document.body.appendChild(box);
    box.addEventListener("click", (e) => { if (e.target === box || e.target.closest("[data-close]")) box.remove(); });
    return box;
  }

  /* ---------- state + frame ---------- */
  const cy = { tab: "feed", city: "", tag: "", home: null, view: null, room: null, thread: null, event: null, timer: null, people: { kind: "", q: "" }, sub: "" };
  const body = $("#cy-body");
  const view = $("#view-courtyard");

  $("#cy-tabs").addEventListener("click", (e) => {
    const b = e.target.closest("[data-cy]"); if (!b) return;
    Object.assign(cy, { tab: b.dataset.cy, view: null, room: null, thread: null, event: null, tag: "", sub: "" });
    render();
  });
  $("#cy-city-top").addEventListener("change", (e) => { cy.city = e.target.value; render(); });
  $("#cy-share-top").addEventListener("click", () => compose());

  const TAB_SEC = { feed: "community", people: "people", messages: "messages", events: "events", magazine: "perspective_read" };
  const allowed = (tab) => { const a = X.me().cy_access; return !a || !TAB_SEC[tab] || !!a[TAB_SEC[tab]]; };
  const canComment = () => { const a = X.me().cy_access; return !a || !!a.perspective_comment; };
  function mark() {
    if (!allowed(cy.tab)) cy.tab = ["feed", "people", "messages", "events", "magazine"].find(allowed) || "profile";
    $$("#cy-tabs [data-cy]").forEach((b) => { b.hidden = !allowed(b.dataset.cy); b.classList.toggle("on", b.dataset.cy === cy.tab && !cy.view); });
  }
  function cities(list) {
    const sel = $("#cy-city-top");
    const have = [...sel.options].map((o) => o.value).join("|");
    const want = ["", ...list].join("|");
    if (have !== want) sel.innerHTML = `<option value="">All India</option>${list.map((c) => `<option ${c === cy.city ? "selected" : ""}>${esc(c)}</option>`).join("")}`;
    sel.value = cy.city;
  }

  X.cyState = () => ({ tab: cy.tab, thread: cy.thread, event: cy.event, sub: cy.sub, city: cy.city });
  X.cyGo = (tab, extra) => { Object.assign(cy, { tab, sub: "", view: null, tag: "", room: null, thread: null, event: null }, extra || {}); return render(); };
  X.cyRestore = (p) => { Object.assign(cy, { tab: p.tab || "feed", thread: p.thread || null, event: p.event || null, sub: p.sub || "", city: p.city || "" }); };
  async function render() {
    clearTimeout(cy.timer);
    if (X.savePlace) X.savePlace();
    body.onclick = null; body.onsubmit = null; body.onchange = null;
    mark();
    view.scrollTop = 0;
    try {
      if (!X.me().courtyard && !cy.url) {
        const hh = await X.api("/api/home").catch(() => ({}));
        if (!hh.courtyard) throw new Error("Connect this studio to Design Lab (Office → Team & wallet → Design Lab Cloud) to join The Courtyard.");
        cy.url = hh.cy_url || "";
      }
      if (cy.view) return await member(cy.view);
      if (cy.tag) return await tagPage(cy.tag);
      if (cy.tab === "feed") return cy.sub === "pins" ? await pinsPage() : await feed();
      if (cy.tab === "people") return await people();
      if (cy.tab === "messages") { await threads(); return cy.thread ? await thread(cy.thread) : undefined; }
      if (cy.tab === "events") return cy.event ? await eventPage(cy.event) : await events();
      if (cy.tab === "magazine") return await magazine();
      if (cy.tab === "profile") return await myPage();
    } catch (x) {
      const old = x.message === "restart" || /undefined|not a function|Unknown Courtyard/.test(x.message);
      body.innerHTML = `<div class="cv-wrap"><div class="cv-empty"><h2>The Courtyard</h2><p>${old
        ? "Design Lab needs a restart to show the new Courtyard. On the studio computer: open the designlab system folder and double-click RESTART DESIGN LAB, wait 10 seconds, then open The Courtyard again."
        : esc(x.message)}</p></div></div>`;
    }
  }
  X.renderCourtyard = async () => {
    if (X.cyPreset) { const p = X.cyPreset; X.cyPreset = null; cy.tab = "feed"; await render(); compose(p.type, p.images); return; }
    return render();
  };
  async function home(force) {
    if (!cy.home || force) cy.home = await req(`/api/cy/home?city=${encodeURIComponent(cy.city)}`);
    cities(cy.home.cities || []);
    setBadge(cy.home.pulse);
    return cy.home;
  }
  const head = (eyebrow, title, sub, acts = "") => `<div class="cv-head"><div><p class="cv-eye">${eyebrow}</p><h2>${title}</h2>${sub ? `<p class="cv-sub">${sub}</p>` : ""}</div>${acts ? `<div class="cv-acts">${acts}</div>` : ""}</div>`;

  /* ---------- cards ---------- */
  function pinCard(p) {
    return `<figure class="cv-pin" data-post="${esc(p.id)}">
      <button class="cv-pin-img" data-open="${esc(p.id)}"><img src="${fimg(p.images[0])}" alt="${esc(p.material || p.title)}" loading="lazy"></button>
      <figcaption>
        <b>${esc(p.material || p.title)}</b>
        <span class="cv-small">${esc(p.brand || p.firm_name)}${p.finish ? " · " + esc(p.finish) : ""}</span>
        <span class="cv-pin-acts"><button class="cv-save ${p.saved ? "on" : ""}" data-save="${esc(p.id)}" aria-label="Save">${p.saved ? "Saved" : "Save"}</button>
        <button class="cv-link" data-toproj="${esc(p.id)}">To a project</button></span>
      </figcaption></figure>`;
  }
  function postcard(p) {
    return `<figure class="cv-postcard" data-post="${esc(p.id)}">
      <button class="cv-pc-img" data-open="${esc(p.id)}"><img src="${fimg(p.images[0])}" alt="${esc(p.place)}" loading="lazy"></button>
      <figcaption><span class="cv-stamp">${esc((p.place || "").split(",")[0])}</span>
        <p>${esc(p.title)}</p>
        <span class="cv-small">from <button class="cv-who" data-member="${esc(p.firm)}">${esc(p.firm_name)}</button></span>
        <span class="cv-tags">${(p.hashtags || []).slice(0, 3).map((t) => `<button class="hash" data-tag="${esc(t)}">#${esc(t)}</button>`).join(" ")}</span>
      </figcaption></figure>`;
  }
  function welcomeCard(p) {
    const today = (p.joined || p.time || "").slice(0, 10) === X.todayIso();
    return `<article class="cv-welcome" data-post="${esc(p.id)}">
      <div class="cv-av">${p.logo ? `<img src="${fimg(p.logo)}" alt="">` : initial(p.firm_name)}</div>
      <p class="cv-eye">Welcome</p>
      <h4><button class="cv-who" data-member="${esc(p.firm)}">${esc(p.firm_name)}</button>${tick(p)}</h4>
      <p class="cv-small">joined Design Lab ${today ? "today" : ago(p.joined || p.time)}${p.member_city ? " · from " + esc(p.member_city) : ""}</p>
      ${p.speciality ? `<p class="cv-spec">${esc(p.speciality)}</p>` : ""}
      <div class="cv-wrow">${p.instagram ? `<a class="cv-link" href="${esc(insta(p.instagram))}" target="_blank" rel="noopener">Instagram ↗</a>` : ""}
        <button class="cv-pill ${p.liked ? "on" : ""}" data-like="${esc(p.id)}">${p.liked ? "Welcomed" : "Say welcome"}${p.likes ? " · " + p.likes : ""}</button></div>
    </article>`;
  }
  const TYPE = { gallery: "Work", arrival: "New arrival", moodboard: "Looking for", news: "Notes", postcard: "Postcard", pin: "Pin" };
  function postCard(p) {
    if (p.type === "welcome") return welcomeCard(p);
    if (p.type === "pin") return pinCard(p);
    if (p.type === "postcard") return postcard(p);
    return `<article class="cv-post t-${esc(p.type)}" data-post="${esc(p.id)}">
      <header><button class="cv-av sm" data-member="${esc(p.firm)}">${p.firm_logo ? `<img src="${fimg(p.firm_logo)}" alt="">` : initial(p.firm_name)}</button>
        <div><button class="cv-who" data-member="${esc(p.firm)}">${esc(p.firm_name)}</button>${tick(p)}<span class="cv-small">${esc(kindLabel(p.firm_kind))}${p.city ? " · " + esc(p.city) : ""} · ${esc(ago(p.time))}</span></div>
        <span class="cv-type">${TYPE[p.type] || ""}${p.pick ? ` · ${p.pick === "month" ? "Gallery of the month" : "Gallery of the week"}` : ""}</span></header>
      ${p.status === "held" ? `<p class="cv-held">Waiting for Design Lab to check this (house rules).</p>` : ""}
      ${p.images.length ? `<div class="cv-imgs n${Math.min(p.images.length, 4)}">${p.images.slice(0, 4).map((n) => `<a href="${fimg(n)}" target="_blank" rel="noopener"><img src="${fimg(n)}" alt="" loading="lazy"></a>`).join("")}</div>` : ""}
      <h3>${esc(p.title)}</h3>
      ${p.text ? `<p class="cv-text">${md(p.text)}</p>` : ""}
      ${p.tags.length ? `<p class="cv-small">With ${p.tags.map((t) => `<button class="cv-who" data-member="${esc(t.code)}">${esc(t.name)}</button>`).join(", ")}</p>` : ""}
      ${p.file ? `<p><a class="cv-link" href="${fimg(p.file)}" target="_blank" rel="noopener">Open catalog (PDF)</a></p>` : ""}
      <div class="cv-postacts">
        <button class="${p.liked ? "on" : ""}" data-like="${esc(p.id)}">${p.liked ? "♥" : "♡"} ${p.likes || ""}</button>
        <button data-cmt="${esc(p.id)}">Comment${p.comments.length ? " · " + p.comments.length : ""}</button>
        ${!p.mine && p.firm !== "DL" ? `<button data-touch="${esc(p.firm)}" data-subject="${esc(p.type === "arrival" ? "Samples" : p.type === "moodboard" ? "I can help" : "About your post")}" data-pre="${esc(`About “${p.title}”: `)}">${p.type === "arrival" ? "Ask for a sample" : p.type === "moodboard" ? "I can help" : "Get in touch"}</button>` : ""}
        ${p.mine ? `<button data-delpost="${esc(p.id)}">Delete</button>` : `<button class="cv-quiet" data-report="${esc(p.id)}">Report</button>`}
      </div>
      <div class="cv-cmts" id="cm-${esc(p.id)}" hidden>${p.comments.map((c) => `<p><b>${esc(c.firm_name)}</b> ${esc(c.text)} <span class="cv-small">${esc(ago(c.time))}</span></p>`).join("")}
        <form class="cv-inline" data-cform="${esc(p.id)}"><input placeholder="Write a comment…" maxlength="600"><button class="cv-btn sm">Send</button></form></div>
    </article>`;
  }
  function openPost(p) {
    const s = sheet(`<header class="cv-sh"><b>${esc(p.type === "pin" ? (p.material || p.title) : p.type === "postcard" ? p.place : p.title)}</b><button class="cv-x" data-close>×</button></header>
      <div class="cv-big">${p.images.map((n) => `<img src="${fimg(n)}" alt="">`).join("")}</div>
      ${p.type === "pin" ? `<dl class="cv-dl">${p.material ? `<dt>Material</dt><dd>${esc(p.material)}</dd>` : ""}${p.brand ? `<dt>Brand</dt><dd>${esc(p.brand)}</dd>` : ""}${p.finish ? `<dt>Finish / size</dt><dd>${esc(p.finish)}</dd>` : ""}<dt>Pinned by</dt><dd><button class="cv-who" data-member="${esc(p.firm)}">${esc(p.firm_name)}</button>${p.city ? " · " + esc(p.city) : ""}</dd></dl>` : ""}
      ${p.type === "postcard" ? `<p class="cv-text">${esc(p.title)}</p>` : ""}
      ${p.text ? `<p class="cv-text">${md(p.text)}</p>` : ""}
      <p class="cv-tags">${(p.hashtags || []).map((t) => `<button class="hash" data-tag="${esc(t)}">#${esc(t)}</button>`).join(" ")}</p>
      <div class="cv-row">${p.type === "pin" ? `<button class="cv-btn ghost" data-save="${esc(p.id)}">${p.saved ? "Saved" : "Save"}</button><button class="cv-btn ghost" data-toproj="${esc(p.id)}">Save to a project's mood board</button>` : ""}
        ${!p.mine ? `<button class="cv-btn" data-touch="${esc(p.firm)}" data-subject="${p.type === "pin" ? "Samples" : "Say hello"}" data-pre="${esc(`About “${p.material || p.title}”: `)}">${p.type === "pin" ? "Ask about this" : "Say hello"}</button>` : ""}</div>`);
    s.addEventListener("click", (e) => common(e, () => s.remove()));
  }
  function findPost(id) {
    const h = cy.home || {};
    const all = [...(h.feed || []), ...(h.pins || []), ...(h.postcards || []), ...(cy.extra || [])];
    return all.find((p) => p.id === id);
  }

  /* shared clicks for every Courtyard page (and the post sheet) */
  async function common(e, close) {
    const t = e.target;
    const tg = t.closest("[data-tag]"); if (tg) { close && close(); cy.tag = tg.dataset.tag; cy.view = null; return render(); }
    const mem = t.closest("[data-member]"); if (mem && mem.dataset.member !== "DL") { close && close(); cy.view = mem.dataset.member; return render(); }
    const op = t.closest("[data-open]"); if (op) { const p = findPost(op.dataset.open); if (p) openPost(p); return; }
    const sv = t.closest("[data-save]");
    if (sv) { try { const r = await req("/api/cy/save", { id: sv.dataset.save }); sv.classList.toggle("on", r.post.saved); sv.textContent = r.post.saved ? "Saved" : "Save"; const p = findPost(r.post.id); if (p) p.saved = r.post.saved; toast(r.post.saved ? "Saved to your pins (My page)" : "Removed from your pins"); } catch (x) { toast(x.message); } return; }
    const tp = t.closest("[data-toproj]"); if (tp) { const p = findPost(tp.dataset.toproj); if (p) toProject(p); return; }
    const to = t.closest("[data-touch]"); if (to) { close && close(); return getInTouch(to.dataset.touch, to.dataset.subject || "", to.dataset.pre || ""); }
    const lk = t.closest("[data-like]");
    if (lk) { try { const r = await req("/api/cy/like", { id: lk.dataset.like }); const old = body.querySelector(`[data-post="${r.post.id}"]`); if (old) old.outerHTML = postCard(r.post); } catch (x) { toast(x.message); } return; }
    const cm = t.closest("[data-cmt]"); if (cm) { const b = $("#cm-" + cm.dataset.cmt); b.hidden = !b.hidden; if (!b.hidden) $("input", b).focus(); return; }
    const dp = t.closest("[data-delpost]"); if (dp) { if (!sure(dp)) return; await req("/api/cy/delete-post", { id: dp.dataset.delpost }); toast("Deleted"); cy.home = null; return render(); }
    const rp = t.closest("[data-report]"); if (rp) { if (!sure(rp)) return; await req("/api/cy/report", { what: "post", id: rp.dataset.report, reason: "Reported by a member" }); toast("Thank you — Design Lab will check it"); return; }
    const go = t.closest("[data-cygo]"); if (go) { close && close(); Object.assign(cy, { tab: go.dataset.cygo, sub: go.dataset.sub || "", view: null, tag: "", room: null, thread: null, event: go.dataset.event || null }); return render(); }
    if (t.closest("[data-compose]")) { close && close(); return compose(t.closest("[data-compose]").dataset.compose || ""); }
  }
  body.addEventListener("click", (e) => { if (!body.onclick) common(e); });
  body.addEventListener("submit", async (e) => {
    const f = e.target.closest("[data-cform]"); if (!f) return;
    e.preventDefault();
    const i = $("input", f);
    try { const r = await req("/api/cy/comment", { id: f.dataset.cform, text: i.value }); if (r.note) toast(r.note); const old = body.querySelector(`[data-post="${r.post.id}"]`); if (old) { old.outerHTML = postCard(r.post); $("#cm-" + r.post.id).hidden = false; } }
    catch (x) { toast(x.message); }
  });

  /* ---------- CHAT PIECES (community screen, messages, groups, event walls) ---------- */
  const DOC_ACCEPT = ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.dwg,.dxf,.txt,.csv,.zip";
  const hhmm = (iso) => { try { return new Date(iso).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" }); } catch (e) { return ""; } };
  const dayLabel = (iso) => {
    const d = new Date(iso), t = new Date(); const y = new Date(); y.setDate(t.getDate() - 1);
    if (d.toDateString() === t.toDateString()) return "Today";
    if (d.toDateString() === y.toDateString()) return "Yesterday";
    return d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: d.getFullYear() === t.getFullYear() ? undefined : "numeric" });
  };
  function attachHtml(list) {
    return (list || []).map((a) => {
      if (a.kind === "image") return `<a class="cv-att-img" href="${fimg(a.file)}" target="_blank" rel="noopener"><img src="${fimg(a.file)}" alt="Photo" loading="lazy"></a>`;
      if (a.kind === "doc") return `<a class="cv-att-doc" href="${fimg(a.file)}" target="_blank" rel="noopener" download><i>${esc((a.name.split(".").pop() || "").toUpperCase().slice(0, 4))}</i><span>${esc(a.name)}</span></a>`;
      if (a.kind === "location") { const q = a.lat !== undefined ? `${a.lat},${a.lng}` : a.label; return `<a class="cv-att-loc" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}" target="_blank" rel="noopener"><i>⌖</i><span>${esc(a.label || "Shared location")}<small>Open in Maps</small></span></a>`; }
      if (a.kind === "contact") { const ph = (a.phone || "").replace(/\D/g, ""); return `<span class="cv-att-con"><i>${initial(a.name)}</i><span><b>${esc(a.name)}</b><small>${esc(a.phone)}${a.email ? " · " + esc(a.email) : ""}</small>
        <span class="cv-row">${ph ? `<a href="tel:${esc(a.phone)}">Call</a><a href="https://wa.me/${ph.length === 10 ? "91" + ph : ph}" target="_blank" rel="noopener">WhatsApp</a>` : ""}${a.email ? `<a href="mailto:${esc(a.email)}">Email</a>` : ""}</span></span></span>`; }
      return "";
    }).join("");
  }
  function bubble(m, opts = {}) {
    if (m.system) return `<div class="cv-sys">${esc(m.text)}</div>`;
    const who = m.firm_name || m.who || "";
    return `<div class="cv-bub ${m.mine ? "mine" : ""}" data-mid="${esc(m.id || "")}">
      ${!m.mine && opts.names ? `<button class="cv-bub-who" data-member="${esc(m.firm)}">${esc(who)}${m.who && m.who !== who ? ` <small>· ${esc(m.who)}</small>` : ""}</button>` : ""}
      ${m.subject ? `<i class="cv-subj">${esc(m.subject)}</i>` : ""}
      ${attachHtml(m.attach)}
      ${m.text ? `<p>${md(m.text)}</p>` : ""}
      <span class="cv-bub-t">${esc(hhmm(m.time))}${m.status === "held" ? " · waiting for check" : ""}${opts.del && m.mine ? ` · <button class="cv-del" data-delmsg="${esc(m.id)}">delete</button>` : ""}</span>
    </div>`;
  }
  function chatLog(list, opts) {
    let last = "", out = "";
    list.forEach((m) => { const d = (m.time || "").slice(0, 10); if (d !== last) { out += `<div class="cv-day"><span>${esc(dayLabel(m.time))}</span></div>`; last = d; } out += opts.render ? opts.render(m) : bubble(m, opts); });
    return out || `<p class="cv-soft center">Say hello — it starts here.</p>`;
  }
  function composerHtml(id, ph, opts = {}) {
    return `<form class="cv-comp" id="${id}">
      <div class="cv-comp-prev" hidden></div>
      <div class="cv-comp-row">
        <div class="cv-plus-wrap"><button type="button" class="cv-plus" aria-label="Attach">+</button>
          <div class="cv-plus-menu" hidden>
            <label><i>▣</i>Photo<input type="file" accept="image/*" multiple hidden data-at="image"></label>
            <label><i>◉</i>Camera<input type="file" accept="image/*" capture="environment" hidden data-at="image"></label>
            <label><i>▤</i>Document<input type="file" accept="${DOC_ACCEPT}" hidden data-at="doc"></label>
            <button type="button" data-at="location"><i>⌖</i>Location</button>
            ${opts.contact ? `<button type="button" data-at="contact"><i>☺</i>Contact</button>` : ""}
          </div></div>
        <textarea rows="1" placeholder="${esc(ph)}" maxlength="2000" aria-label="Message"></textarea>
        <button class="cv-send" aria-label="Send">➤</button>
      </div></form>`;
  }
  function bindComposer(form, send) {
    let att = [];
    const prev = form.querySelector(".cv-comp-prev"), menu = form.querySelector(".cv-plus-menu"), ta = form.querySelector("textarea");
    const draw = () => {
      prev.hidden = !att.length;
      prev.innerHTML = att.map((a, i) => `<span class="cv-chip-att">${a.kind === "image" ? `<img src="${a.data}" alt="">` : `<i>${{ doc: "▤", location: "⌖", contact: "☺" }[a.kind]}</i>`}<em>${esc(a.kind === "image" ? "Photo" : a.name || a.label || "")}</em><button type="button" data-rm="${i}" aria-label="Remove">×</button></span>`).join("");
    };
    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 140) + "px"; });
    ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(pointer: fine)").matches) { e.preventDefault(); form.requestSubmit(); } });
    form.addEventListener("click", async (e) => {
      if (e.target.closest(".cv-plus")) { menu.hidden = !menu.hidden; return; }
      const rm = e.target.closest("[data-rm]"); if (rm) { att.splice(Number(rm.dataset.rm), 1); return draw(); }
      const at = e.target.closest("button[data-at]");
      if (at && at.dataset.at === "location") {
        menu.hidden = true;
        const ask = () => { const s = sheet(`<form class="cv-form"><header class="cv-sh"><b>Share a location</b><button type="button" class="cv-x" data-close>×</button></header>
            <label class="cv-f"><span>Place or address</span><input id="lc-l" placeholder="e.g. Stone Age showroom, Lower Parel"></label><div class="cv-row end"><button class="cv-btn">Add</button></div></form>`);
          s.querySelector("form").addEventListener("submit", (ev) => { ev.preventDefault(); const l = s.querySelector("#lc-l").value.trim(); if (l) { att.push({ kind: "location", label: l }); draw(); } s.remove(); }); };
        if (!navigator.geolocation || !window.isSecureContext) return ask();
        toast("Finding where you are…");
        navigator.geolocation.getCurrentPosition((p) => { att.push({ kind: "location", lat: p.coords.latitude, lng: p.coords.longitude, label: "My location" }); draw(); }, ask, { timeout: 8000 });
        return;
      }
      if (at && at.dataset.at === "contact") {
        menu.hidden = true;
        const s = sheet(`<form class="cv-form"><header class="cv-sh"><b>Share a contact</b><button type="button" class="cv-x" data-close>×</button></header>
          <div class="cv-grid2"><label class="cv-f"><span>Name</span><input id="ct-n"></label><label class="cv-f"><span>Phone</span><input id="ct-p" inputmode="tel"></label>
          <label class="cv-f wide"><span>Email (optional)</span><input id="ct-e" type="email"></label></div><div class="cv-row end"><button class="cv-btn">Add</button></div></form>`);
        s.querySelector("form").addEventListener("submit", (ev) => { ev.preventDefault(); const n = s.querySelector("#ct-n").value.trim(); if (!n) return; att.push({ kind: "contact", name: n, phone: s.querySelector("#ct-p").value.trim(), email: s.querySelector("#ct-e").value.trim() }); draw(); s.remove(); });
      }
    });
    form.addEventListener("change", async (e) => {
      const inp = e.target.closest("input[data-at]"); if (!inp) return;
      menu.hidden = true;
      for (const f of [...inp.files].slice(0, 6)) {
        if (inp.dataset.at === "image") att.push({ kind: "image", data: await shrink(f) });
        else { if (f.size > 16e6) { toast("That document is over 16 MB."); continue; } att.push({ kind: "doc", name: f.name, data: await readFile(f) }); }
      }
      inp.value = ""; att = att.slice(0, 6); draw();
    });
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const text = ta.value.trim(); if (!text && !att.length) return;
      const btn = form.querySelector(".cv-send"); btn.disabled = true;
      try { await send({ text, attach: att }); ta.value = ""; ta.style.height = ""; att = []; draw(); } catch (x) { toast(x.message); }
      btn.disabled = false; ta.focus();
    });
  }

  /* ---------- THE COURTYARD — landing (picture + what it is) and the community screen ---------- */
  async function feed() {
    const h = await home(true);
    if (!h.v) throw new Error("restart");
    const hero = h.hero ? fimg(h.hero) : "courtyard-hero.jpg";
    body.innerHTML = `
      <section class="cv-land">
        <figure class="cv-land-img"><img src="${hero}" alt="The Courtyard — a shared meeting place around a tree"></figure>
        <div class="cv-land-title"><p class="cv-eye">The Courtyard · by Design Lab</p><h1>Where architects and makers meet</h1></div>
      </section>
      <section class="cv-land-txt">
        <p class="cv-lead">A shared meeting place for architects, interior designers, vendors and makers. One community to talk in, share what you find, meet at events — and be seen for your work.</p>
        <ul class="cv-what">
          <li data-cygo="feed"><b>Community</b><span>one open conversation for everyone · welcome every new member</span></li>
          <li data-cygo="people"><b>People</b><span>architects, designers and makers, city by city</span></li>
          <li data-cygo="messages"><b>Messages</b><span>private and group chats — photos, documents, locations</span></li>
          <li data-cygo="events"><b>Open House</b><span>dinners, showroom evenings, exhibitions — public or by invitation</span></li>
          <li data-cygo="magazine"><b>Perspective</b><span>the Design Lab magazine</span></li>
          <li data-cygo="profile"><b>My page</b><span>your portfolio or catalogue, with its own link</span></li>
        </ul>
        <p class="cv-small">${h.members.architect} architects &amp; designers · ${h.members.vendor} makers &amp; vendors</p>
      </section>
      <section class="cv-community" id="community">
        <header class="cv-ch">
          <div><h3>Community</h3><span class="cv-small" id="cm-sub">everyone in The Courtyard</span></div>
          <span class="cv-row"><button class="cv-pill" data-compose="postcard">Postcard</button><button class="cv-pill" data-compose="pin">Pin a material</button>
            <button class="cv-pill" id="cm-mute"></button></span>
        </header>
        <div class="cv-chat big" id="cm-log"><p class="cv-soft center">Loading…</p></div>
        ${h.muted ? `<p class="cv-held">Your studio can't write here for a few days (house rules). Private messages still work.</p>` : composerHtml("cm-form", "Write to everyone in The Courtyard…")}
        <p class="cv-small center cv-rules">Be kind. No phone numbers or emails here (use Get in touch). No hiring ads.</p>
      </section>
      <div class="cv-wrap">
        ${h.events.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Open House</h3><span class="cv-sec-a"><button class="cv-link" data-cygo="events">All events</button></span></div>
          <div class="cv-evstrip">${h.events.map((e) => `<button class="cv-evmini" data-cygo="events" data-event="${esc(e.id)}"><b>${esc(day(e.date, { day: "numeric" }))}</b><span>${esc(day(e.date, { month: "short" }))}</span><em>${esc(e.title)}</em><small>${esc(e.host_name)}${e.city ? " · " + esc(e.city) : ""}</small></button>`).join("")}</div></section>` : ""}
        ${h.pins.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Recommended materials</h3><span class="cv-sec-a"><button class="cv-link" data-cygo="feed" data-sub="pins">See all</button></span></div>
          <div class="cv-pins">${h.pins.slice(0, 8).map(pinCard).join("")}</div></section>` : ""}
      </div>`;
    let since = "", items = [];
    const log = $("#cm-log");
    const item = (x) => {
      if (x.kind === "msg") return bubble(x, { names: true, del: true });
      if (x.type === "welcome") return `<div class="cv-welc"><div class="cv-av">${x.logo ? `<img src="${fimg(x.logo)}" alt="">` : initial(x.firm_name)}</div>
        <div><p><b>Welcome, <button class="cv-who" data-member="${esc(x.firm)}">${esc(x.firm_name)}</button></b>${tick(x)}</p>
        <span class="cv-small">${esc(kindLabel(x.firm_kind))}${x.member_city ? " · " + esc(x.member_city) : ""}${x.speciality ? " · " + esc(x.speciality) : ""}</span>
        ${x.instagram ? `<a class="cv-link" href="${esc(insta(x.instagram))}" target="_blank" rel="noopener">Instagram ↗</a>` : ""}</div>
        <button class="cv-pill ${x.liked ? "on" : ""}" data-like="${esc(x.id)}">${x.liked ? "Welcomed" : "Say welcome"}${x.likes ? " · " + x.likes : ""}</button></div>`;
      return `<div class="cv-share" data-post="${esc(x.id)}"><span class="cv-small"><button class="cv-who" data-member="${esc(x.firm)}">${esc(x.firm_name)}</button> shared ${x.type === "postcard" ? "a postcard" : x.type === "pin" ? "a material" : x.type === "arrival" ? "a new arrival" : x.type === "moodboard" ? "what they're looking for" : "a post"} · ${esc(hhmm(x.time))}</span>
        <button class="cv-share-in" data-open="${esc(x.id)}">${x.images[0] ? `<img src="${fimg(x.images[0])}" alt="" loading="lazy">` : ""}<span><b>${esc(x.type === "pin" ? (x.material || x.title) : x.type === "postcard" ? x.place : x.title)}</b>${x.text ? `<em>${esc(x.text.slice(0, 120))}</em>` : ""}</span></button></div>`;
    };
    const draw = (stick) => {
      const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 80;
      log.innerHTML = chatLog(items, { render: item });
      if (stick || atBottom) { log.scrollTop = log.scrollHeight; log.dataset.pin = "1"; }
    };
    // pictures arrive after the text: keep the chat at the newest message while they load
    log.addEventListener("load", () => { if (log.dataset.pin) log.scrollTop = log.scrollHeight; }, true);
    log.addEventListener("scroll", () => { log.dataset.pin = log.scrollHeight - log.scrollTop - log.clientHeight < 80 ? "1" : ""; });
    const load = async (stick) => {
      const r = await req(`/api/cy/community${since ? "?since=" + encodeURIComponent(since) : ""}`);
      if (since) { const known = new Set(items.map((i) => i.id)); items = items.concat(r.items.filter((i) => !known.has(i.id))); } else items = r.items;
      since = r.now;
      $("#cm-mute").textContent = r.muted ? "Alerts off" : "Alerts on"; $("#cm-mute").classList.toggle("on", !r.muted); $("#cm-mute").dataset.muted = r.muted ? "1" : "";
      $("#cm-sub").textContent = `${r.members} members · everyone can read and write`;
      if (!since || r.items.length || stick) draw(stick);
      clearTimeout(cy.timer);
      cy.timer = setTimeout(() => { if (cy.tab === "feed" && !cy.view && !cy.tag && !cy.sub && !view.hidden && $("#cm-log")) load(false).catch(() => {}); }, 7000);
    };
    await load(true);
    const f = $("#cm-form"); if (f) bindComposer(f, async (p) => { await req("/api/cy/community", p); await load(true); });
    body.onclick = async (e) => {
      const m = e.target.closest("#cm-mute");
      if (m) { const mute = !m.dataset.muted; await req("/api/cy/community-mute", { mute }); toast(mute ? "Community alerts off" : "Community alerts on"); return load(false); }
      const d = e.target.closest("[data-delmsg]"); if (d) { if (!sure(d)) return; await req("/api/cy/community-delete", { id: d.dataset.delmsg }); items = items.filter((i) => i.id !== d.dataset.delmsg); return draw(false); }
      const lk = e.target.closest("[data-like]");
      if (lk) { try { const r = await req("/api/cy/like", { id: lk.dataset.like }); const it = items.find((i) => i.id === r.post.id); if (it) Object.assign(it, r.post); draw(false); } catch (x) { toast(x.message); } return; }
      const op = e.target.closest("[data-open]"); if (op) { const p = items.find((i) => i.id === op.dataset.open) || findPost(op.dataset.open); if (p) openPost(p); return; }
      common(e);
    };
  }
  async function pinsPage() {
    const h = await home(true);
    body.innerHTML = `<div class="cv-wrap">${head("The Courtyard", "Material &amp; Brand Pins", "Everything members have pinned. Save the ones you like — or send them straight to a project's mood board.", `<button class="cv-btn" data-compose="pin">+ Pin a material</button>`)}
      <div class="cv-pins">${h.pins.map(pinCard).join("")}</div></div>`;
  }
  async function tagPage(tag) {
    const r = await req(`/api/cy/home?tag=${encodeURIComponent(tag)}&city=${encodeURIComponent(cy.city)}`);
    cy.extra = [...r.feed, ...r.pins, ...r.postcards];
    const pins = r.pins, cards = r.postcards, rest = r.feed.filter((p) => !["pin", "postcard"].includes(p.type));
    body.innerHTML = `<div class="cv-wrap"><button class="cv-crumb" data-back>&larr; Back</button>
      ${head("Hashtag", "#" + esc(tag), `${r.feed.length} post${r.feed.length === 1 ? "" : "s"} · pins, postcards and posts with #${esc(tag)}`, `<button class="cv-btn ghost" data-compose="postcard">+ Postcard with #${esc(tag)}</button>`)}
      ${pins.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Pins</h3></div><div class="cv-pins">${pins.map(pinCard).join("")}</div></section>` : ""}
      ${cards.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Postcards</h3></div><div class="cv-cards">${cards.map(postcard).join("")}</div></section>` : ""}
      ${rest.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Posts</h3></div><div class="cv-feed">${rest.map(postCard).join("")}</div></section>` : ""}
      ${!r.feed.length ? `<p class="cv-soft">Nothing with #${esc(tag)} yet.</p>` : ""}</div>`;
    cy.composeTag = tag;
    body.onclick = (e) => { if (e.target.closest("[data-back]")) { cy.tag = ""; return render(); } common(e); };
  }

  /* ---------- Share (one sheet for everything) ---------- */
  const KINDS = [["news", "A thought or update", "Share news, knowledge or an opinion"], ["gallery", "My work", "A finished project — tag the makers"],
    ["pin", "Material & brand pin", "A stone, fabric, light, fitting…"], ["postcard", "Postcard", "A place you visited and loved"],
    ["moodboard", "Looking for", "Ask makers for ideas and products"], ["arrival", "New arrival", "For makers: a new product"]];
  async function compose(kind = "", images = []) {
    const h = await home();
    const vendor = h.me.kind === "vendor";
    let type = kind || "news", imgs = images.slice(), pdf = "";
    const s = sheet(`<form class="cv-form" id="cv-compose"><header class="cv-sh"><b>Share in The Courtyard</b><button type="button" class="cv-x" data-close>×</button></header>
      <div class="cv-kinds">${KINDS.filter(([k]) => k !== "arrival" || vendor).map(([k, l, d]) => `<button type="button" class="cv-kind ${k === type ? "on" : ""}" data-k="${k}"><b>${l}</b><span>${d}</span></button>`).join("")}</div>
      <div class="cv-fields"></div>
      <div class="cv-imgs-in" id="cv-imgs"></div>
      <div class="cv-row"><label class="cv-btn ghost sm">+ Photos<input type="file" accept="image/*" multiple hidden id="cv-photos"></label>
        <label class="cv-btn ghost sm" id="cv-pdf-l" hidden>+ Catalog PDF<input type="file" accept="application/pdf" hidden id="cv-pdf"></label><span class="cv-small" id="cv-pdf-n"></span></div>
      <p class="cv-small">House rules: be kind; no phone numbers or emails in open posts (use Get in touch); no hiring ads.</p>
      <p class="cv-err" id="cv-err"></p>
      <div class="cv-row end"><button type="button" class="cv-btn ghost" data-close>Cancel</button><button class="cv-btn" type="submit">Share</button></div></form>`);
    const f = $("#cv-compose", s);
    const tagHint = cy.composeTag ? " #" + cy.composeTag : "";
    const fields = () => {
      const F = (id, label, ph = "", area = false) => `<label class="cv-f"><span>${label}</span>${area ? `<textarea id="${id}" rows="3" placeholder="${esc(ph)}"></textarea>` : `<input id="${id}" placeholder="${esc(ph)}">`}</label>`;
      $(".cv-fields", f).innerHTML = type === "pin"
        ? F("cf-material", "Material", "e.g. Statuario marble, oak veneer, linen") + F("cf-brand", "Brand / maker", "e.g. the brand or your company") + F("cf-finish", "Finish / size (optional)", "e.g. honed, 1200 × 600") + F("cf-text", "A line about it (optional)", "Where it works best…" + tagHint, true)
        : type === "postcard"
          ? F("cf-place", "Place", "e.g. Rani ki Vav, Patan") + F("cf-title", "One line", "This is where I went and I loved it") + F("cf-text", "Hashtags", "#stepwell #gujarat" + tagHint)
          : F("cf-title", "Title", type === "gallery" ? "e.g. A quiet home in Juhu" : type === "moodboard" ? "e.g. Looking for a warm grey terrazzo" : "A short title") + F("cf-text", "A few words", "Use #hashtags so people can find it" + tagHint, true)
          + (type === "gallery" ? `<label class="cv-f"><span>Makers who worked on it (they'll be credited)</span><select id="cf-tags" multiple size="4"></select></label>` : "");
      $("#cv-pdf-l", f).hidden = type !== "arrival";
      if (type === "gallery") req("/api/cy/people?kind=vendor").then((r) => { const sel = $("#cf-tags", f); if (sel) sel.innerHTML = r.people.map((m) => `<option value="${esc(m.code)}">${esc(m.name)}${m.city ? " · " + esc(m.city) : ""}</option>`).join(""); }).catch(() => {});
    };
    const thumbs = () => { $("#cv-imgs", f).innerHTML = imgs.map((d, i) => `<span><img src="${d}" alt=""><button type="button" data-rmimg="${i}" aria-label="Remove">×</button></span>`).join(""); };
    fields(); thumbs();
    f.addEventListener("click", (e) => {
      const k = e.target.closest("[data-k]"); if (k) { type = k.dataset.k; $$(".cv-kind", f).forEach((b) => b.classList.toggle("on", b === k)); fields(); }
      const rm = e.target.closest("[data-rmimg]"); if (rm) { imgs.splice(Number(rm.dataset.rmimg), 1); thumbs(); }
    });
    f.addEventListener("change", async (e) => {
      if (e.target.id === "cv-photos") { for (const file of e.target.files) imgs.push(await shrink(file)); imgs = imgs.slice(0, 10); thumbs(); }
      if (e.target.id === "cv-pdf" && e.target.files[0]) { if (e.target.files[0].size > 8e6) { toast("PDF must be under 8 MB"); return; } pdf = await readFile(e.target.files[0]); $("#cv-pdf-n", f).textContent = e.target.files[0].name; }
    });
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      const v = (id) => ($("#" + id, f) || {}).value || "";
      const btn = $("button[type=submit]", f); btn.disabled = true;
      const payload = { type, images: imgs, city: cy.city };
      if (type === "pin") Object.assign(payload, { title: v("cf-material") || v("cf-brand"), material: v("cf-material"), brand: v("cf-brand"), finish: v("cf-finish"), text: v("cf-text") });
      else if (type === "postcard") Object.assign(payload, { place: v("cf-place"), title: v("cf-title") || "This is where I went and I loved it", text: v("cf-text") });
      else Object.assign(payload, { title: v("cf-title"), text: v("cf-text"), file: type === "arrival" ? pdf : "", tags: type === "gallery" ? [...$("#cf-tags", f).selectedOptions].map((o) => o.value) : [] });
      try { const r = await req("/api/cy/post", payload); s.remove(); toast(r.note || "Shared in The Courtyard"); cy.home = null; render(); }
      catch (x) { $("#cv-err", f).textContent = x.message; btn.disabled = false; }
    });
  }

  /* pin / postcard -> a project's mood board */
  async function toProject(p) {
    let projs = [];
    try { projs = (await X.api("/api/projects")).projects; } catch (e) {}
    if (!projs.length) { toast("Make a project first (Office → Projects)."); return; }
    const s = sheet(`<form class="cv-form"><header class="cv-sh"><b>Save to a project</b><button type="button" class="cv-x" data-close>×</button></header>
      <div class="cv-topimg"><img src="${fimg(p.images[0])}" alt=""><span><b>${esc(p.material || p.title)}</b><span class="cv-small">${esc(p.brand || p.firm_name)}</span></span></div>
      <label class="cv-f"><span>Which project?</span><select id="tp-proj">${projs.map((x) => `<option value="${esc(x.id)}">${esc(x.name)}${x.client ? " · " + esc(x.client) : ""}</option>`).join("")}</select></label>
      <p class="cv-small">The picture is copied into the project's 09 Mood Board, with the material and brand noted.</p>
      <div class="cv-row end"><button type="button" class="cv-btn ghost" data-close>Cancel</button><button class="cv-btn">Save to mood board</button></div></form>`);
    $("form", s).addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const r = await req("/api/cy-to-project", { project: $("#tp-proj", s).value, images: p.images.slice(0, 3), title: p.material || p.title,
          note: [p.material, p.brand, p.finish].filter(Boolean).join(" — ") + (p.firm_name ? ` (pinned by ${p.firm_name})` : "") });
        s.remove(); toast(`Saved to ${r.project}'s mood board`);
      } catch (x) { toast(x.message); }
    });
  }

  /* ---------- People: refined visiting cards ---------- */
  async function people() {
    const st = cy.people;
    const r = await req(`/api/cy/people?kind=${st.kind}&city=${encodeURIComponent(cy.city)}&q=${encodeURIComponent(st.q)}`);
    const h = await home();
    body.innerHTML = `<div class="cv-wrap">${head("The Courtyard", "People", "Architects, interior designers, makers and vendors. Open a card to see their work; Get in touch to write to them.")}
      <div class="cv-tools"><div class="cv-seg">${[["", "Everyone"], ["architect", "Architects &amp; designers"], ["vendor", "Makers &amp; vendors"]].map(([k, l]) => `<button class="${st.kind === k ? "on" : ""}" data-pk="${k}">${l}</button>`).join("")}</div>
        <input class="cv-search" id="pp-q" placeholder="Search a name, a material, an area…" value="${esc(st.q)}"></div>
      ${(h.cities || []).length ? `<div class="cv-citytags">${["", ...h.cities].map((c) => `<button class="cv-ctag ${c === cy.city ? "on" : ""}" data-pcity="${esc(c)}">${c ? "#" + esc(c.replace(/\s+/g, "")) : "All India"}</button>`).join("")}</div>` : ""}
      <div class="cv-vcards">${r.people.map((m) => `<article class="cv-vcard">
          <button class="cv-vc-top" data-member="${esc(m.code)}">
            <span class="cv-vc-av">${m.logo ? `<img src="${fimg(m.logo)}" alt="">` : `<i>${initial(m.name)}</i>`}</span>
            <span class="cv-vc-id"><b>${esc(m.name)}${m.verified ? `<i class="cv-tick" title="Verified by Design Lab">✓</i>` : ""}</b>
              <em>${esc(m.profession || kindLabel(m.kind))}</em></span>
          </button>
          ${m.intro ? `<p class="cv-vc-intro">${esc(m.intro)}</p>` : `<p class="cv-vc-intro soft">${m.kind === "vendor" ? "Maker / vendor" : "Architect / designer"} in The Courtyard.</p>`}
          ${m.trades && m.trades.length ? `<p class="cv-vc-trades">${esc(m.trades.slice(0, 3).join(" · "))}</p>` : ""}
          <footer><span class="cv-vc-tags">${m.city_tag ? `<button class="cv-ctag sm" data-pcity="${esc(m.city)}">${esc(m.city_tag)}</button>` : ""}${m.area ? `<span>${esc(m.area)}</span>` : ""}</span>
            <span class="cv-row">${m.instagram ? `<a class="cv-icon" href="${esc(insta(m.instagram))}" target="_blank" rel="noopener" title="Instagram">IG</a>` : ""}<button class="cv-touch" data-touch="${esc(m.code)}">Get in touch</button></span></footer>
        </article>`).join("") || `<p class="cv-soft">No one matches yet.</p>`}</div></div>`;
    body.onclick = (e) => {
      const b = e.target.closest("[data-pk]"); if (b) { st.kind = b.dataset.pk; return people(); }
      const c = e.target.closest("[data-pcity]"); if (c) { cy.city = c.dataset.pcity; cities((cy.home && cy.home.cities) || []); return people(); }
      common(e);
    };
    const q = $("#pp-q"); q.oninput = () => { clearTimeout(q._t); q._t = setTimeout(() => { st.q = q.value; people().then(() => { const n = $("#pp-q"); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 400); };
  }
  const SUBJECTS = ["Project enquiry", "Samples", "Collaboration", "Visit / meeting", "Say hello", "Other"];
  async function getInTouch(code, subject = "", pre = "") {
    const h = await home();
    const s = sheet(`<form class="cv-form"><header class="cv-sh"><b>Get in touch</b><button type="button" class="cv-x" data-close>×</button></header>
      <p class="cv-small">From <b>${esc(h.me.name)}</b> (${esc(kindLabel(h.me.kind))}${h.me.city ? ", " + esc(h.me.city) : ""}) — they'll see who it is from and what it's about. It lands in their Messages; they can reply or ignore.</p>
      <label class="cv-f"><span>About</span><select id="gt-sub">${[...new Set([subject, ...SUBJECTS].filter(Boolean))].map((x) => `<option ${x === subject ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></label>
      <label class="cv-f"><span>Message</span><textarea id="gt-text" rows="5" maxlength="2000">${esc(pre)}</textarea></label>
      <p class="cv-err" id="gt-err"></p>
      <div class="cv-row end"><button type="button" class="cv-btn ghost" data-close>Cancel</button><button class="cv-btn">Send</button></div></form>`);
    $("#gt-text", s).focus();
    $("form", s).addEventListener("submit", async (e) => {
      e.preventDefault();
      try { const r = await req("/api/cy/message", { to: code, subject: $("#gt-sub", s).value, text: $("#gt-text", s).value }); s.remove(); toast("Sent"); Object.assign(cy, { tab: "messages", view: null, tag: "", thread: r.thread }); render(); }
      catch (x) { $("#gt-err", s).textContent = x.message; }
    });
  }

  async function member(code) {
    const r = await req(`/api/cy/member/${encodeURIComponent(code)}`);
    const m = r.member;
    cy.extra = [...r.posts, ...r.tagged];
    const link = (u) => (/^https?:\/\//.test(u) ? u : "https://" + u);
    const pins = r.posts.filter((p) => p.type === "pin"), cards = r.posts.filter((p) => p.type === "postcard"), work = r.posts.filter((p) => !["pin", "postcard"].includes(p.type));
    body.innerHTML = `<section class="cv-mhero" ${m.cover ? `style="--hero:url('${fimg(m.cover)}')"` : ""}><div class="cv-hero-in">
        <button class="cv-crumb light" data-back>&larr; Back</button>
        <div class="cv-av lg">${m.logo ? `<img src="${fimg(m.logo)}" alt="">` : initial(m.name)}</div>
        <p class="cv-eye light">${esc(m.profession || kindLabel(m.kind))}${m.city ? " · " + esc([m.area, m.city].filter(Boolean).join(", ")) : ""}</p>
        <h1>${esc(m.name)} ${tick(m)}</h1>
        <div class="cv-row">${m.website ? `<a class="cv-link light" href="${esc(link(m.website))}" target="_blank" rel="noopener">Website ↗</a>` : ""}${m.instagram ? `<a class="cv-link light" href="${esc(insta(m.instagram))}" target="_blank" rel="noopener">Instagram ↗</a>` : ""}
          ${r.me ? `<button class="cv-btn light" data-cygo="profile">Edit my page</button>` : `<button class="cv-btn light" data-touch="${esc(m.code)}">Get in touch</button>`}</div></div></section>
      <div class="cv-wrap">
        ${m.about ? `<p class="cv-about">${md(m.about)}</p>` : ""}
        ${m.trades && m.trades.length ? `<p class="cv-tags">${m.trades.map((t) => `<span class="cv-chip">${esc(t)}</span>`).join(" ")}</p>` : ""}
        ${pins.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Pins</h3></div><div class="cv-pins">${pins.map(pinCard).join("")}</div></section>` : ""}
        ${work.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Work &amp; notes</h3></div><div class="cv-feed">${work.map(postCard).join("")}</div></section>` : ""}
        ${cards.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Postcards</h3></div><div class="cv-cards">${cards.map(postcard).join("")}</div></section>` : ""}
        ${r.tagged.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Projects they were part of</h3></div><div class="cv-feed">${r.tagged.map(postCard).join("")}</div></section>` : ""}
        ${r.events.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Open House</h3></div><ul class="cv-list">${r.events.map((e) => `<li><b>${esc(X.fmtDate(e.date))}</b> ${esc(e.title)} <span class="cv-small">${esc(e.city || "")}</span></li>`).join("")}</ul></section>` : ""}
        ${!r.posts.length && !m.about ? `<p class="cv-soft">Nothing shared yet.</p>` : ""}
      </div>`;
    body.onclick = (e) => { if (e.target.closest("[data-back]")) { cy.view = null; return render(); } common(e); };
  }

  /* ---------- Messages: an inbox like a phone — chats on the left, the open chat on the right ---------- */
  const wide = () => window.matchMedia("(min-width: 900px)").matches;
  const chatRow = (t) => `<li><button class="cv-chatrow ${cy.thread === t.id ? "on" : ""} ${t.unread ? "unread" : ""}" data-thread="${esc(t.id)}">
      <span class="cv-av ${t.group ? "grp" : ""}">${t.group ? "◎" : initial(t.with_name)}</span>
      <span class="cv-cr-mid"><b>${esc(t.with_name)}</b>
        <span>${t.group ? `<i class="cv-kind">Group · ${t.members}</i> ` : `<i class="cv-kind">Private</i> `}${t.subject ? `<i class="cv-subj">${esc(t.subject)}</i> ` : ""}${esc(t.last)}</span></span>
      <span class="cv-cr-end"><em>${esc(ago(t.time))}</em>${t.unread ? `<i class="cv-unread">new</i>` : ""}${t.muted ? `<i class="cv-mutedot" title="Alerts off">🔕</i>` : ""}${t.status === "request" && !t.incoming ? `<i class="cv-wait">waiting</i>` : ""}</span>
    </button></li>`;
  async function threadList() {
    const r = await req("/api/cy/threads");
    const reqs = r.threads.filter((t) => t.status === "request" && t.incoming);
    const rest = r.threads.filter((t) => !(t.status === "request" && t.incoming));
    return `${reqs.length ? `<p class="cv-listh">Want to talk to you</p><ul class="cv-chatlist">${reqs.map(chatRow).join("")}</ul>` : ""}
      <ul class="cv-chatlist">${rest.map(chatRow).join("") || `<li class="cv-soft cv-empty">No chats yet. Find someone in People and tap Get in touch, or make a group.</li>`}</ul>`;
  }
  async function threads() {
    body.innerHTML = `<section class="cv-inbox ${cy.thread ? "has-chat" : ""}">
        <aside class="cv-inbox-list">
          <header class="cv-inbox-h"><h2>Messages</h2><span class="cv-row"><button class="cv-pill" data-newgroup>New group</button><button class="cv-pill on" data-cygo="people">New chat</button></span></header>
          <div id="grp-new"></div>
          <div id="chat-list">${await threadList()}</div>
        </aside>
        <div class="cv-inbox-chat" id="msg-pane">${cy.thread ? "" : `<div class="cv-inbox-empty"><b>Your chats</b><span>Choose a chat on the left. Private chats are between two studios; groups are for a project, a trip or a team.</span></div>`}</div>
      </section>`;
    body.onclick = inboxClick;
  }
  async function inboxClick(e) {
    const t = e.target.closest("[data-thread]");
    if (t) { cy.thread = t.dataset.thread; if (X.savePlace) X.savePlace(); return wide() && $("#msg-pane") ? thread(cy.thread) : render(); }
    if (e.target.closest("[data-newgroup]")) return groupForm();
    common(e);
  }
  async function pickMembers(box, preset = []) {
    const r = await req("/api/cy/people");
    const me = (cy.home && cy.home.me && cy.home.me.code) || "";
    box.innerHTML = `<input class="cv-search" placeholder="Search people…" data-pmq>
      <div class="cv-picklist">${r.people.filter((m) => m.code !== me).map((m) => `<label class="cv-pick"><input type="checkbox" value="${esc(m.code)}" ${preset.includes(m.code) ? "checked" : ""}>
        <span class="cv-av sm">${m.logo ? `<img src="${fimg(m.logo)}" alt="">` : initial(m.name)}</span><span><b>${esc(m.name)}</b><small>${esc(m.profession || kindLabel(m.kind))}${m.city ? " · " + esc(m.city) : ""}</small></span></label>`).join("")}</div>`;
    box.querySelector("[data-pmq]").oninput = (e) => { const q = e.target.value.toLowerCase(); box.querySelectorAll(".cv-pick").forEach((l) => { l.hidden = q && !l.textContent.toLowerCase().includes(q); }); };
    return () => [...box.querySelectorAll("input[type=checkbox]:checked")].map((i) => i.value);
  }
  async function groupForm() {
    const box = $("#grp-new");
    box.innerHTML = `<form class="cv-panel cv-form" id="gf"><h3>New group</h3><label class="cv-f"><span>Group name</span><input id="gf-n" maxlength="60" placeholder="e.g. Juhu residence team, Jaipur trip"></label>
      <span class="cv-f"><span>Who's in it</span></span><div id="gf-p"></div><p class="cv-err" id="gf-e"></p>
      <div class="cv-row end"><button type="button" class="cv-btn ghost" data-gx>Cancel</button><button class="cv-btn">Make group</button></div></form>`;
    const chosen = await pickMembers($("#gf-p"));
    $("#gf").onclick = (e) => { if (e.target.closest("[data-gx]")) box.innerHTML = ""; };
    $("#gf").onsubmit = async (e) => {
      e.preventDefault();
      try { const r = await req("/api/cy/group-new", { name: $("#gf-n").value, members: chosen() }); cy.thread = r.thread; render(); } catch (x) { $("#gf-e").textContent = x.message; }
    };
  }
  async function thread(id, quiet) {
    if (!$("#msg-pane")) { await threads(); }
    const host = $("#msg-pane"); $(".cv-inbox").classList.add("has-chat");
    $$(".cv-chatrow").forEach((b) => b.classList.toggle("on", b.dataset.thread === id));
    const r = (await req(`/api/cy/thread/${encodeURIComponent(id)}`)).thread;
    const isGroup = !!r.group;
    if (!quiet || !$("#th-log") || host.dataset.id !== id) {
      host.dataset.id = id;
      host.innerHTML = `<section class="cv-chatwin">
        <header class="cv-chathead"><button class="cv-crumb" data-back aria-label="Back to chats">&larr;</button>
          <span class="cv-av ${isGroup ? "grp" : ""}">${isGroup ? "◎" : initial(r.with_name)}</span>
          <div><b>${isGroup ? esc(r.name) : `<button class="cv-who" data-member="${esc(r.with)}">${esc(r.with_name)}</button>`}</b>
            <span class="cv-small">${isGroup ? esc(r.members.map((m) => m.name).join(", ")) : r.subject ? esc(r.subject) : "Private chat"}</span></div>
          <span class="cv-row">${isGroup && r.admin ? `<button class="cv-pill" data-gadd>Add people</button>` : ""}<button class="cv-pill ${r.muted ? "" : "on"}" data-tmute>${r.muted ? "Alerts off" : "Alerts on"}</button>
            ${isGroup ? `<button class="cv-pill" data-gleave>Leave</button>` : r.incoming && r.status === "request" ? `<button class="cv-pill" data-ignore>Ignore</button>` : ""}</span>
        </header>
        <div id="gadd"></div>
        ${!isGroup && r.incoming && r.status === "request" ? `<p class="cv-note">${esc(r.with_name)} wants to talk to you. Reply to accept, or Ignore.</p>` : ""}
        ${!isGroup && !r.incoming && r.status === "request" ? `<p class="cv-note">Sent. You can write again when they reply.</p>` : ""}
        <div class="cv-chat" id="th-log"></div>
        ${composerHtml("th-form", "Message", { contact: true })}
      </section>`;
      bindComposer($("#th-form"), async (p) => { await req(`/api/cy/thread/${encodeURIComponent(id)}`, p); await thread(id, true); $("#chat-list").innerHTML = await threadList(); });
      { const lg = $("#th-log"); lg.addEventListener("load", () => { if (lg.scrollHeight - lg.scrollTop - lg.clientHeight < 400) lg.scrollTop = lg.scrollHeight; }, true); }
      body.onclick = async (e) => {
        if (e.target.closest("[data-back]")) { cy.thread = null; return render(); }
        if (e.target.closest("[data-ignore]")) { await req(`/api/cy/thread/${encodeURIComponent(id)}/ignore`, {}); cy.thread = null; toast("Ignored"); return render(); }
        if (e.target.closest("[data-tmute]")) { await req("/api/cy/chat-mute", { id, mute: !r.muted }); host.dataset.id = ""; return thread(id); }
        const lv = e.target.closest("[data-gleave]"); if (lv) { if (!sure(lv)) return; await req(`/api/cy/group/${id}/leave`, {}); cy.thread = null; toast("You left the group"); return render(); }
        if (e.target.closest("[data-gadd]")) {
          const box = $("#gadd"); box.innerHTML = `<div class="cv-panel"><div id="ga-p"></div><div class="cv-row end"><button class="cv-btn" data-gaddok>Add</button></div></div>`;
          const chosen = await pickMembers($("#ga-p"));
          box.querySelector("[data-gaddok]").onclick = async () => { await req(`/api/cy/group/${id}/add`, { members: chosen() }); toast("Added"); host.dataset.id = ""; thread(id); };
          return;
        }
        return inboxClick(e);
      };
    }
    const log = $("#th-log");
    const atBottom = !log.dataset.seen || log.scrollHeight - log.scrollTop - log.clientHeight < 80;
    log.innerHTML = chatLog(r.messages, { names: isGroup });
    if (atBottom) { log.scrollTop = log.scrollHeight; log.dataset.seen = 1; }
    clearTimeout(cy.timer);
    cy.timer = setTimeout(() => { if (cy.tab === "messages" && cy.thread === id && !view.hidden) thread(id, true).catch(() => {}); }, 6000);
  }
  /* ---------- Open House: one screen of events, each with its own page ---------- */
  function evDates(e) {
    const one = !e.end || e.end === e.date;
    return one ? day(e.date, { weekday: "short", day: "numeric", month: "short" }) : `${day(e.date, { day: "numeric", month: "short" })} – ${day(e.end, { day: "numeric", month: "short" })}`;
  }
  const evTile = (e) => `<button class="cv-evtile ${e.over ? "over" : ""} ${e.invited && !e.mine && e.private ? "inv" : ""}" data-cygo="events" data-event="${esc(e.id)}">
      <span class="cv-evt-img">${e.image ? fit(fimg(e.image)) : ""}<i class="cv-evt-st st-${esc((e.status || "").replace(/\s+/g, "").toLowerCase())}">${esc(e.status || "")}</i>
        ${e.image ? "" : `<b>${esc(day(e.date, { day: "numeric" }))}</b><em>${esc(day(e.date, { month: "short" }))}</em>`}</span>
      <span class="cv-evt-txt"><small>${esc(e.kind || "Open House")}${e.private ? " · Private" : " · Open"}${e.mine ? " · You're hosting" : e.invited && e.private ? " · You're invited" : ""}</small>
        <b>${esc(e.title)}</b><span>${esc(evDates(e))}${e.time ? " · " + esc(e.time) : ""}</span><span>${e.online ? "Online" : esc([e.place, e.city].filter(Boolean).join(", "))}</span>
        <span>by ${esc(e.host_name)} · ${e.coming} coming${e.wall_count ? ` · ${e.wall_count} posts` : ""}</span></span></button>`;
  async function events() {
    const r = await req(`/api/cy/events?city=${encodeURIComponent(cy.city)}`);
    const now = r.events.filter((e) => !e.over), past = r.events.filter((e) => e.over);
    body.innerHTML = `<div class="cv-wrap">${head("The Courtyard", "Open House", "Dinners, showroom evenings, exhibitions, factory visits, talks — hosted by makers and architects. Open for everyone, or closed for the people you invite.", `<button class="cv-btn" data-evnew>Host an event</button>`)}
      <div id="ev-new"></div>
      <div class="cv-evgrid">${now.map(evTile).join("") || `<p class="cv-soft">No events coming up. Host the first one.</p>`}</div>
      ${past.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Recent events — photos and memories</h3></div><div class="cv-evgrid">${past.map(evTile).join("")}</div></section>` : ""}</div>`;
    body.onclick = (e) => { if (e.target.closest("[data-evnew]")) return eventForm(); common(e); };
  }
  async function eventPage(id, quiet) {
    let e;
    try { e = (await req(`/api/cy/event/${encodeURIComponent(id)}`)).event; } catch (x) { cy.event = null; return events(); }
    const pg = e.page || { text: e.details || "", form: ["Your name", "How many people", "Phone (only the host sees it)"] };
    const extra = pg.form.slice(3);
    const wallLog = () => chatLog((e.wall || []).map((w) => Object.assign({}, w)), { names: true });
    if (quiet && $("#ev-wall")) { const l = $("#ev-wall"); const b = l.scrollHeight - l.scrollTop - l.clientHeight < 80; l.innerHTML = wallLog(); if (b) l.scrollTop = l.scrollHeight; return; }
    body.innerHTML = `<section class="cv-evhero">${e.image ? fit(fimg(e.image), "cv-evhero-img") : ""}<div class="cv-hero-in">
        <button class="cv-crumb light" data-back>&larr; Open House</button>
        <p class="cv-eye light">${esc(e.kind || "Open House")} · ${e.private ? "Closed — by invitation" : "Open to everyone"} · <b>${esc(e.status)}</b></p><h1>${esc(e.title)}</h1>
        <p class="cv-hero-sub">${esc(evDates(e))}${e.time ? " · " + esc(e.time) : ""} · ${e.online ? "Online" : esc([e.place, e.city].filter(Boolean).join(", "))}</p></div></section>
      <div class="cv-wrap cv-evlayout">
        <div class="cv-evmain">
          <section class="cv-panel"><h3>About this event</h3><p class="cv-text">${md(pg.text)}</p>
            <p class="cv-small">Hosted by <button class="cv-who" data-member="${esc(e.host)}">${esc(e.host_name)}</button> · ${e.coming} coming · ${e.maybe} maybe${e.seats_left !== null && e.seats_left !== undefined ? ` · ${e.seats_left} seats left` : ""}</p>
            ${!e.mine ? `<div class="cv-row"><button class="cv-btn ghost" data-touch="${esc(e.host)}" data-subject="${esc("About: " + e.title)}" data-pre="${esc("A question about “" + e.title + "”: ")}">Ask the host a question</button></div>` : ""}</section>
          <section class="cv-panel"><h3>${e.over ? "Photos and memories" : "Event wall"} <span class="cv-small">photos, updates and talk about this event</span></h3>
            <div class="cv-chat" id="ev-wall"></div>${composerHtml("ev-form", e.over ? "Post a photo or a memory…" : "Write to everyone at this event…", { contact: !!e.private })}</section>
        </div>
        <aside class="cv-evside">
          ${e.mine ? `<section class="cv-panel"><h3>Who's coming</h3>
              <ul class="cv-list">${(e.rsvps || []).map((x) => `<li><b>${esc(x.name)}</b> — ${esc(x.status)}${x.count ? " · " + x.count : ""}${x.contact ? `<br><span class="cv-small">${esc(x.contact)}</span>` : ""}${x.answers ? Object.entries(x.answers).map(([k, v]) => `<br><span class="cv-small">${esc(k)}: ${esc(v)}</span>`).join("") : ""}</li>`).join("") || "<li class='cv-soft'>No replies yet.</li>"}</ul>
              ${e.private && e.invited_names.length ? `<p class="cv-small">Invited: ${esc(e.invited_names.join(", "))}</p>` : ""}
              <button class="cv-btn ghost sm" data-evcancel="${esc(e.id)}">Cancel event</button></section>`
          : e.over ? `<section class="cv-panel"><h3>This event is over</h3><p class="cv-small">Share your photos on the wall.</p></section>`
          : `<form class="cv-panel cv-form" id="rsvp"><h3>${e.private ? "You're invited" : "Confirm you're coming"}</h3>
              <p class="cv-small">${esc([e.place, e.city].filter(Boolean).join(", ") || (e.online ? "Online" : ""))}</p>
              <div class="cv-seg" id="rs-st">${[["coming", "Coming"], ["maybe", "Maybe"], ["no", "Can't come"]].map(([k, l]) => `<button type="button" class="${(e.my_rsvp ? e.my_rsvp.status : "coming") === k ? "on" : ""}" data-st="${k}">${l}</button>`).join("")}</div>
              <label class="cv-f"><span>${esc(pg.form[0])}</span><input id="rs-who" value="${esc((e.my_rsvp && e.my_rsvp.who) || X.me().name || "")}"></label>
              <label class="cv-f"><span>${esc(pg.form[1])}</span><input id="rs-n" type="number" min="1" max="20" value="${esc((e.my_rsvp && e.my_rsvp.count) || 1)}"></label>
              <label class="cv-f"><span>${esc(pg.form[2])}</span><input id="rs-ph" inputmode="tel" value="${esc((e.my_rsvp && e.my_rsvp.contact) || "")}"></label>
              ${extra.map((q) => `<label class="cv-f"><span>${esc(q)}</span><input data-ask="${esc(q)}" value="${esc(((e.my_rsvp && e.my_rsvp.answers) || {})[q] || "")}"></label>`).join("")}
              <p class="cv-err" id="rs-err"></p><button class="cv-btn">${e.my_rsvp ? "Update my reply" : "Confirm"}</button></form>`}
        </aside>
      </div>`;
    const l = $("#ev-wall"); l.innerHTML = wallLog(); l.scrollTop = l.scrollHeight;
    bindComposer($("#ev-form"), async (p) => { await req(`/api/cy/event/${e.id}/wall`, p); await eventPage(id, true); });
    let st = e.my_rsvp ? e.my_rsvp.status : "coming";
    body.onclick = async (ev) => {
      if (ev.target.closest("[data-back]")) { cy.event = null; return render(); }
      const s = ev.target.closest("[data-st]"); if (s) { st = s.dataset.st; $$("#rs-st button").forEach((b) => b.classList.toggle("on", b === s)); return; }
      const c = ev.target.closest("[data-evcancel]"); if (c) { if (!sure(c)) return; await req(`/api/cy/event/${c.dataset.evcancel}/cancel`, {}); toast("Event cancelled"); cy.event = null; return render(); }
      common(ev);
    };
    const f = $("#rsvp");
    if (f) f.onsubmit = async (ev) => {
      ev.preventDefault();
      const answers = Object.fromEntries($$("[data-ask]", f).map((i) => [i.dataset.ask, i.value]));
      try { await req(`/api/cy/event/${e.id}/rsvp`, { status: st, who: $("#rs-who").value, count: $("#rs-n").value, contact: $("#rs-ph").value, answers }); toast("Sent to the host"); eventPage(id); }
      catch (x) { $("#rs-err").textContent = x.message; }
    };
    clearTimeout(cy.timer);
    const tick2 = () => { cy.timer = setTimeout(async () => { if (cy.tab === "events" && cy.event === id && !view.hidden) { await eventPage(id, true).catch(() => {}); tick2(); } }, 8000); };
    tick2();
  }
  function eventForm() {
    const cl = (cy.home && cy.home.cities) || [];
    let img = "";
    $("#ev-new").innerHTML = `<form class="cv-panel cv-form" id="evf"><h3>Host an event</h3>
      <p class="cv-small">Fill in the basics — the Open House bot writes the event page and the reply form for you.</p>
      <div class="cv-grid2">
        <label class="cv-f"><span>What kind</span><select id="ev-kind">${["Open House", "Product launch", "Showroom evening", "Factory visit", "Talk / workshop", "Dinner", "Design circle", "Get-together"].map((k) => `<option>${k}</option>`).join("")}</select></label>
        <label class="cv-f"><span>Title</span><input id="ev-title" maxlength="120"></label>
        <label class="cv-f"><span>Starts</span><input id="ev-date" type="date" min="${X.todayIso()}" value="${X.todayIso()}"></label>
        <label class="cv-f"><span>Ends</span><input id="ev-end" type="date" min="${X.todayIso()}" value="${X.todayIso()}"></label>
        <label class="cv-f"><span>Time</span><input id="ev-time" type="time" value="18:30"></label>
        <label class="cv-f"><span>Seats (0 = no limit)</span><input id="ev-seats" type="number" min="0" value="0"></label>
        <label class="cv-f"><span>Place</span><input id="ev-place" placeholder="Showroom, address or link"></label>
        <label class="cv-f"><span>City</span><input id="ev-city" list="ev-cities" value="${esc(cy.city || (cy.home && cy.home.me.city) || "")}"><datalist id="ev-cities">${cl.map((c) => `<option value="${esc(c)}">`).join("")}</datalist></label>
        <label class="cv-f wide"><span>Details</span><textarea id="ev-details" rows="3"></textarea></label>
        <label class="cv-f wide"><span>Anything to ask people who reply? (optional, one per line)</span><textarea id="ev-ask" rows="2" placeholder="Food preference&#10;Which product interests you?"></textarea></label>
        <label class="cv-f"><span>Picture (optional)</span><input id="ev-img" type="file" accept="image/*"></label>
        <label class="cv-f"><span>Online event</span><select id="ev-online"><option value="">No</option><option value="1">Yes</option></select></label></div>
      <p class="cv-eye">Who can see it</p>
      <div class="cv-seg" id="ev-vis"><button type="button" class="on" data-vis="public">Open — everyone can see it</button><button type="button" data-vis="private">Closed — only people I invite</button></div>
      <div id="ev-pick" hidden><p class="cv-eye">Choose who to invite</p><div id="ev-pickbox"></div></div>
      <p class="cv-eye" id="ev-inv-l">Invite</p>
      <div class="cv-chips" id="ev-inv"><button type="button" class="cv-chip on" data-inv="everyone">Everyone</button><button type="button" class="cv-chip" data-inv="architect">Architects</button><button type="button" class="cv-chip" data-inv="vendor">Makers</button>
        ${cl.map((c) => `<button type="button" class="cv-chip" data-invc="${esc(c)}">${esc(c)}</button>`).join("")}</div>
      <p class="cv-err" id="ev-err"></p><div class="cv-row end"><button class="cv-btn ghost" type="button" data-evx>Cancel</button><button class="cv-btn" type="submit">Publish</button></div></form>`;
    const f = $("#evf"); f.scrollIntoView({ behavior: "smooth", block: "start" });
    let vis = "public", chosen = () => [];
    f.onclick = async (e) => {
      const v = e.target.closest("[data-vis]");
      if (v) {
        vis = v.dataset.vis; $$("#ev-vis button").forEach((b) => b.classList.toggle("on", b === v));
        $("#ev-pick").hidden = vis !== "private";
        if (vis === "private" && !$("#ev-pickbox").innerHTML) chosen = await pickMembers($("#ev-pickbox"));
        if (vis === "private") $$("#ev-inv .cv-chip").forEach((x) => x.classList.remove("on"));
        $("#ev-inv-l").textContent = vis === "private" ? "Also invite everyone in (optional)" : "Invite";
      }
      const b = e.target.closest("[data-inv],[data-invc]");
      if (b) {
        if (b.dataset.inv === "everyone") $$("#ev-inv .cv-chip").forEach((x) => x.classList.toggle("on", x === b));
        else { b.classList.toggle("on"); $('[data-inv="everyone"]').classList.toggle("on", !$$("#ev-inv .cv-chip.on:not([data-inv=everyone])").length); }
      }
      if (e.target.closest("[data-evx]")) $("#ev-new").innerHTML = "";
    };
    f.onchange = async (e) => { if (e.target.id === "ev-img" && e.target.files[0]) img = await shrink(e.target.files[0]); if (e.target.id === "ev-date" && $("#ev-end").value < e.target.value) $("#ev-end").value = e.target.value; };
    f.onsubmit = async (e) => {
      e.preventDefault();
      const on = $$("#ev-inv .cv-chip.on");
      const invite = { everyone: on.some((x) => x.dataset.inv === "everyone"), kinds: on.filter((x) => x.dataset.inv && x.dataset.inv !== "everyone").map((x) => x.dataset.inv), cities: on.filter((x) => x.dataset.invc).map((x) => x.dataset.invc), codes: chosen() };
      try {
        const r = await req("/api/cy/event", { kind: $("#ev-kind").value, title: $("#ev-title").value, date: $("#ev-date").value, end: $("#ev-end").value, time: $("#ev-time").value,
          place: $("#ev-place").value, city: $("#ev-city").value, details: $("#ev-details").value, online: !!$("#ev-online").value, image: img, invite,
          private: vis === "private", open: vis === "public", seats: $("#ev-seats").value, ask: $("#ev-ask").value.split("\n").map((s) => s.trim()).filter(Boolean) });
        toast("Published — the bot made the event page and reply form"); cy.event = r.event.id; render();
      } catch (x) { $("#ev-err").textContent = x.message; }
    };
  }

  /* ---------- PERSPECTIVE — the Design Lab magazine ---------- */
  const pimg = (ref) => (String(ref || "").startsWith("shared:") ? "/shared/" + ref.slice(7) : fimg(ref));
  const fit = (src, cls = "") => `<span class="cv-fit ${cls}"><i style="background-image:url('${src}')"></i><img src="${src}" alt="" loading="lazy"></span>`;   // whole picture, never cut
  async function magazine() {
    const [r, mine] = await Promise.all([req("/api/cy/editions"), req("/api/cy/submissions").catch(() => ({ submissions: [] }))]);
    const eds = r.editions.slice().sort((a, b) => b.number - a.number);
    const cur = eds[0];
    const no = (x) => String(x.number).padStart(2, "0");
    const book = (x, big) => `<button class="cv-book ${big ? "big" : ""}" data-edition="${esc(x.id)}" aria-label="Open Perspective edition ${no(x)}">${fit(pimg(x.cover))}<span><i>Perspective</i><b>Edition ${no(x)}</b><em>${esc(x.month)}</em></span>${x.demo ? `<u>Demo</u>` : ""}</button>`;
    body.innerHTML = `${cur ? `<section class="cv-maghero">
        <div class="cv-maghero-book">${book(cur, true)}</div>
        <div class="cv-maghero-txt"><p class="cv-eye">Perspective · the Design Lab magazine</p>
          <h1>Edition ${no(cur)}</h1><p class="cv-mag-month">${esc(cur.month)}${cur.demo ? " · Demo" : ""}</p>
          <p class="cv-lead">${esc(cur.description)}</p>
          ${cur.featured && cur.featured.length ? `<p class="cv-mag-inside"><b>Inside</b> ${esc(cur.featured.join(" · "))}</p>` : ""}
          ${cur.next ? `<p class="cv-mag-inside"><b>Next</b> ${esc(cur.next)}</p>` : ""}
          <div class="cv-row"><button class="cv-btn" data-edition="${esc(cur.id)}">Read the magazine</button><button class="cv-btn ghost" data-apply>Apply to be featured</button></div></div>
      </section>` : `<section class="cv-maghero"><div class="cv-maghero-txt"><h1>Perspective</h1><p class="cv-lead">The first edition is on its way.</p><button class="cv-btn ghost" data-apply>Apply to be featured</button></div></section>`}
      <section class="cv-library"><div class="cv-library-h"><h2>The library</h2><span class="cv-small">Every edition Design Lab has published</span></div>
        <div class="cv-shelf">${eds.map((x) => `<div class="cv-slot">${book(x)}</div>`).join("")}${Array.from({ length: Math.max(0, 5 - eds.length) }, () => `<div class="cv-slot empty"></div>`).join("")}</div></section>
      <div class="cv-wrap"><div id="apply"></div>
      ${mine.submissions.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Your applications</h3></div><ul class="cv-list">${mine.submissions.map((s) => `<li><b>${esc(s.title)}</b> <span class="cv-small">${esc(X.fmtDate(s.time))}</span> <i class="cv-status ${esc(s.status)}">${s.status === "waiting" ? "Design Lab will get in touch" : s.status === "approved" ? "Accepted" : "Not this time"}</i></li>`).join("")}</ul></section>` : ""}
      </div>`;
    body.onclick = (e) => {
      const b = e.target.closest("[data-edition]"); if (b) return reader(b.dataset.edition);
      if (e.target.closest("[data-apply]")) return applyForm();
      common(e);
    };
  }
  function applyForm() {
    const box = $("#apply");
    box.innerHTML = `<form class="cv-panel cv-form" id="subf"><h3>Apply to be featured in Perspective</h3>
      <p class="cv-small">Tell us your story in a few lines and add some pictures. Design Lab reads every application and gets in touch.</p>
      <div class="cv-seg" id="sb-k"><button type="button" class="on" data-k="cover-story">Cover my story (a project)</button><button type="button" data-k="catalog">Feature my product / material</button></div>
      <div class="cv-grid2"><label class="cv-f wide"><span>Title</span><input id="sb-title" maxlength="120"></label>
        <label class="cv-f wide"><span>A few lines</span><textarea id="sb-text" rows="4"></textarea></label>
        <label class="cv-f"><span>Pictures (up to 8)</span><input id="sb-img" type="file" accept="image/*" multiple></label>
        <label class="cv-f"><span>Link (website / video — optional)</span><input id="sb-link"></label></div>
      <p class="cv-err" id="sb-err"></p><div class="cv-row end"><button type="button" class="cv-btn ghost" data-sx>Cancel</button><button class="cv-btn">Send</button></div></form>`;
    box.scrollIntoView({ behavior: "smooth", block: "start" });
    let imgs = [], kind = "cover-story";
    const f = $("#subf");
    f.onclick = (e) => { const k = e.target.closest("[data-k]"); if (k) { kind = k.dataset.k; $$("#sb-k button").forEach((b) => b.classList.toggle("on", b === k)); } if (e.target.closest("[data-sx]")) box.innerHTML = ""; };
    f.onchange = async (e) => { if (e.target.id === "sb-img") { imgs = []; for (const file of [...e.target.files].slice(0, 8)) imgs.push(await shrink(file)); } };
    f.onsubmit = async (e) => {
      e.preventDefault();
      try { const r = await req("/api/cy/submit", { kind, title: $("#sb-title").value, text: $("#sb-text").value, link: $("#sb-link").value, images: imgs }); toast("Sent — Design Lab will get in touch"); magazine(); }
      catch (x) { $("#sb-err").textContent = x.message; }
    };
  }
  async function reader(id) {
    const ed = (await req(`/api/cy/edition/${encodeURIComponent(id)}`)).edition;
    const pages = ed.pages;
    const phone = () => matchMedia("(max-width: 760px)").matches;
    // a flip book: each leaf has a front and a back page. Computer: two pages open side by side. Phone: one page at a time.
    let mode = phone() ? "one" : "two";
    const makeLeaves = () => mode === "one" ? pages.map((_, i) => [i, null]) : Array.from({ length: Math.ceil(pages.length / 2) }, (_, j) => [2 * j, 2 * j + 1 < pages.length ? 2 * j + 1 : null]);
    let leaves = makeLeaves();
    let at = 0, pinMode = false, busy = false;      // at = how many leaves are turned
    const maxAt = () => (mode === "one" ? leaves.length - 1 : leaves.length);
    const ov = document.createElement("div");
    ov.className = "cv-reader pz";
    document.body.appendChild(ov);
    const KICK = { letter: "Letter", feature: "Feature", product: "Product spotlight", courtyard: "The Courtyard", back: "Perspective" };
    const pageHtml = (i) => {
      if (i === null || i === undefined) return `<div class="cv-page pz-blank"></div>`;
      const p = pages[i];
      const pins = ed.pins.filter((k) => k.page === i).map((k) => `<button class="cv-pin-dot" style="left:${k.x * 100}%;top:${k.y * 100}%" data-pin="${esc(k.id)}" title="${esc(k.firm_name)}">${initial(k.firm_name)}</button>`).join("");
      const kick = esc(p.kicker || KICK[p.kind] || "");
      let inner;
      if (p.kind === "cover") inner = `<div class="pz-cover"><img src="${pimg(p.image)}" alt="Perspective cover">${p.plain ? "" : `<div class="pz-cover-t"><i>${esc(p.kicker || "")}</i><h1>${esc(p.title)}</h1><p>${esc(p.text || "")}</p></div>`}</div>`;
      else if (p.kind === "full") inner = `<div class="pz-full ${p.light ? "light" : ""}"><img src="${pimg(p.image)}" alt=""><div class="pz-cap"><i>${kick}</i><h2>${esc(p.title)}</h2><p>${md(p.text || "")}</p></div></div>`;
      else if (p.kind === "split" || p.image) inner = `<div class="pz-split"><img src="${pimg(p.image)}" alt=""><div class="pz-txt"><i>${kick}</i><h2>${esc(p.title)}</h2><p>${md(p.text || "")}</p>${p.credit ? `<small>${esc(p.credit)}</small>` : ""}</div></div>`;
      else inner = `<div class="pz-letter pz-k-${esc(p.kind)}"><i>${kick}</i><h2>${esc(p.title)}</h2><div class="pz-body">${md(p.text || "")}</div><span class="pz-sign">Perspective · Edition ${String(ed.number).padStart(2, "0")}</span></div>`;
      return `<div class="cv-page" data-page="${i}">${inner}${pins}${i ? `<span class="pg-no">${i}</span>` : ""}</div>`;
    };
    const label = () => {
      if (mode === "one") return at === 0 ? "Cover" : `Page ${at} of ${pages.length - 1}`;
      if (at === 0) return "Cover";
      const l = leaves[at - 1][1], r = leaves[at] ? leaves[at][0] : null;
      return [l, r].filter((x) => x !== null && x !== undefined).length === 2 ? `Pages ${l}–${r}` : `Page ${l ?? r}`;
    };
    const size = () => {
      const st = ov.querySelector(".pz-stage"); if (!st) return;
      const W = st.clientWidth - 24, H = st.clientHeight - 16, R = 2 / 3;
      let ph = H, pw = ph * R;
      const cols = mode === "one" ? 1 : 2;
      if (pw * cols > W) { pw = W / cols; ph = pw / R; }
      const bk = ov.querySelector(".pz-book"); bk.style.setProperty("--pw", Math.floor(pw) + "px"); bk.style.setProperty("--ph", Math.floor(ph) + "px");
    };
    const zFix = () => leaves.forEach((_, j) => { const el = ov.querySelector(`.pz-leaf[data-l="${j}"]`); if (el) el.style.zIndex = j < at ? j + 1 : leaves.length - j + 1; });
    const place = () => {
      const bk = ov.querySelector(".pz-book");
      bk.classList.toggle("at-start", mode === "two" && at === 0);
      bk.classList.toggle("at-end", mode === "two" && at === leaves.length);
      leaves.forEach((_, j) => ov.querySelector(`.pz-leaf[data-l="${j}"]`).classList.toggle("turned", j < at));
      ov.querySelector(".pz-where").textContent = label() + ` · ${at + 1} / ${maxAt() + 1}`;
      ov.querySelector("[data-prev]").disabled = at === 0;
      ov.querySelector("[data-next]").disabled = at >= maxAt();
    };
    const turn = (d) => {
      if (busy) return;
      const to = at + d; if (to < 0 || to > maxAt()) return;
      const j = d > 0 ? at : at - 1;
      const el = ov.querySelector(`.pz-leaf[data-l="${j}"]`);
      busy = true; el.style.zIndex = leaves.length + 5; at = to; place();
      setTimeout(() => { zFix(); busy = false; }, 820);
    };
    const draw = () => {
      ov.innerHTML = `<header class="cv-rd-bar"><b>Perspective · Edition ${String(ed.number).padStart(2, "0")}${ed.demo ? " <u>Demo</u>" : ""}</b>
          <span class="cv-row">${canComment() ? `<button class="cv-pill ${pinMode ? "on" : ""}" data-pinmode>${pinMode ? "Tap the page to pin…" : "Pin a comment"}</button>` : ""}<button class="cv-pill" data-talk>Discussion · ${ed.talk.length}</button><button class="cv-pill" data-close-rd>Close</button></span></header>
        <div class="pz-stage ${pinMode ? "pinning" : ""}"><div class="pz-book ${mode}">
          ${leaves.map(([f, bk], j) => `<div class="pz-leaf" data-l="${j}"><div class="pz-face pz-fr">${pageHtml(f)}</div><div class="pz-face pz-bk">${mode === "two" ? pageHtml(bk) : ""}</div></div>`).join("")}
        </div></div>
        <footer class="cv-rd-nav"><button class="cv-pill" data-prev>← Previous</button><span class="pz-where"></span><button class="cv-pill" data-next>Next →</button></footer>
        <aside class="cv-rd-talk" hidden><header><b>Discussion</b><button class="cv-x" data-talkx>×</button></header><div class="cv-chat" id="rd-log">${chatLog(ed.talk.map((t) => Object.assign({}, t)), { names: true })}</div>
          ${canComment() ? `<form class="cv-inline" id="rd-form"><input placeholder="Say something about this edition…" maxlength="600"><button class="cv-btn sm">Send</button></form>` : `<p class="cv-small" style="padding:12px 16px">You can read the discussion. Your studio owner decides who can comment.</p>`}</aside>`;
      size(); zFix(); place();
    };
    const onResize = () => {
      const m = phone() ? "one" : "two";
      if (m !== mode) {             // keep roughly the same page when switching layout
        const first = mode === "two" ? Math.max(0, at * 2 - 1) : at;
        mode = m; leaves = makeLeaves(); at = Math.min(maxAt(), mode === "two" ? Math.ceil(first / 2) : first); draw();
      } else size();
    };
    window.addEventListener("resize", onResize);
    const reload = async () => { Object.assign(ed, (await req(`/api/cy/edition/${encodeURIComponent(id)}`)).edition); };
    draw();
    const key = (e) => { if (e.key === "ArrowRight") turn(1); if (e.key === "ArrowLeft") turn(-1); if (e.key === "Escape") close(); };
    const close = () => { ov.remove(); document.removeEventListener("keydown", key); window.removeEventListener("resize", onResize); };
    document.addEventListener("keydown", key);
    let sx = 0; ov.addEventListener("touchstart", (e) => { sx = e.touches[0].clientX; }, { passive: true });
    ov.addEventListener("touchend", (e) => { const d = e.changedTouches[0].clientX - sx; if (Math.abs(d) > 50 && !pinMode) turn(d < 0 ? 1 : -1); });
    ov.addEventListener("click", async (e) => {
      const t = e.target;
      if (t.closest("[data-close-rd]")) return close();
      if (t.closest("[data-next]")) return turn(1);
      if (t.closest("[data-prev]")) return turn(-1);
      if (t.closest("[data-pinmode]")) { pinMode = !pinMode; return draw(); }
      if (t.closest("[data-talk]")) { ov.querySelector(".cv-rd-talk").hidden = false; const l = ov.querySelector("#rd-log"); l.scrollTop = l.scrollHeight; return; }
      if (t.closest("[data-talkx]")) { ov.querySelector(".cv-rd-talk").hidden = true; return; }
      const pd = t.closest("[data-pin]");
      if (pd) { const k = ed.pins.find((x) => x.id === pd.dataset.pin); if (k) { const s = sheet(`<header class="cv-sh"><b>${esc(k.firm_name)}</b><button class="cv-x" data-close>×</button></header><p class="cv-text">${md(k.text)}</p><p class="cv-small">${esc(k.who)} · ${esc(ago(k.time))}</p>`); s.style.zIndex = 9700; } return; }
      const pg = t.closest(".cv-page");
      if (pg && !pinMode && !t.closest("a, button")) { const face = t.closest(".pz-face"); return turn(face && face.classList.contains("pz-bk") ? -1 : 1); }
      if (pg && pinMode) {
        const r = pg.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        const s = sheet(`<form class="cv-form"><header class="cv-sh"><b>Pin a comment here</b><button type="button" class="cv-x" data-close>×</button></header><textarea id="pn-t" rows="3" maxlength="600" placeholder="Your comment"></textarea><div class="cv-row end"><button class="cv-btn">Pin</button></div></form>`);
        s.style.zIndex = 9700;
        s.querySelector("form").addEventListener("submit", async (ev) => {
          ev.preventDefault();
          try { await req(`/api/cy/edition/${id}/pin`, { page: Number(pg.dataset.page), x, y, text: s.querySelector("#pn-t").value }); s.remove(); pinMode = false; await reload(); draw(); toast("Pinned"); } catch (x2) { toast(x2.message); }
        });
      }
    });
    ov.addEventListener("submit", async (e) => {
      if (e.target.id !== "rd-form") return;
      e.preventDefault();
      const i = e.target.querySelector("input"); if (!i.value.trim()) return;
      try { await req(`/api/cy/edition/${id}/talk`, { text: i.value }); await reload(); draw(); ov.querySelector(".cv-rd-talk").hidden = false; const l = ov.querySelector("#rd-log"); l.scrollTop = l.scrollHeight; } catch (x) { toast(x.message); }
    });
  }
  /* ---------- My page (a portfolio with its own link) ---------- */
  async function myPage() {
    const h = await home();
    const [mr, pg, sv] = await Promise.all([req(`/api/cy/member/${encodeURIComponent(h.me.code)}`), req("/api/cy/page"), req("/api/cy/saved").catch(() => ({ posts: [] }))]);
    const m = mr.member;
    cy.extra = sv.posts;
    const owner = (X.me().role || h.role || "") === "owner";
    const base = (X.me().cy_url || cy.url || "").replace(/\/$/, "");
    const url = base + "/p/" + pg.slug;
    const local = /localhost|127\.0\.0\.1|192\.168\./.test(base);
    body.innerHTML = `<div class="cv-wrap">${head("The Courtyard", "My page", (h.me.kind === "vendor" ? "Your catalogue" : "Your portfolio") + " — a page with its own link, like a small website. Collections marked Private stay only with you; See my page shows exactly what others see.",
        `<a class="cv-btn ghost" href="${esc(url)}" target="_blank" rel="noopener">See my page</a>`)}
      <section class="cv-dash"><div><b>${pg.views}</b><span>views of your link</span></div><div><b>${pg.portfolio.length}</b><span>projects</span></div><div><b>${pg.touches}</b><span>people got in touch</span></div>
        <div class="cv-linkbox"><span class="cv-small">Your link</span><code>${esc(url)}</code>
          <span class="cv-row"><button class="cv-btn sm" data-copy>Copy link</button><button class="cv-btn ghost sm" data-wa>WhatsApp</button></span>
          ${local ? `<span class="cv-small">This link works on your studio network now; it works for everyone once Design Lab is online.</span>` : ""}</div></section>
      ${owner ? "" : `<p class="cv-held">Only the studio owner can change this page.</p>`}

      <section class="cv-sec"><div class="cv-sec-h"><h3>Portfolio</h3><span class="cv-sec-a">${owner ? `<button class="cv-link" data-pfnew>+ Add a project</button>` : ""}</span></div>
        <div class="cv-seg sm" id="pf-layout">${[["grid", "Grid"], ["large", "Large pictures"], ["story", "Story"]].map(([k, l]) => `<button class="${pg.layout === k ? "on" : ""}" data-layout="${k}" ${owner ? "" : "disabled"}>${l}</button>`).join("")}</div>
        <div id="pf-edit"></div>
        <div class="cv-pf">${pg.portfolio.map((p, i) => `<article class="cv-pfc" data-pfopen="${esc(p.id)}" tabindex="0" title="Open this project">${p.cover ? `<img src="${fimg(p.cover)}" alt="" loading="lazy">` : `<div class="cv-pfnone">No pictures yet</div>`}
          <div><b>${esc(p.name)}${p.public === false ? ` <i class="cv-status">Private</i>` : ""}</b><span class="cv-small">${esc([p.kind, p.place, p.year].filter(Boolean).join(" · "))} · ${p.images.length} picture${p.images.length === 1 ? "" : "s"}</span></div>
          ${owner ? `<span class="cv-row"><button class="cv-link" data-pfe="${esc(p.id)}">Edit</button>${i ? `<button class="cv-link" data-pfm="${esc(p.id)}" data-by="-1">↑</button>` : ""}${i < pg.portfolio.length - 1 ? `<button class="cv-link" data-pfm="${esc(p.id)}" data-by="1">↓</button>` : ""}<button class="cv-quiet" data-pfd="${esc(p.id)}">Remove</button></span>` : ""}</article>`).join("") || `<p class="cv-soft">Add your first project: a name, a few pictures, and a cover.</p>`}</div></section>

      <section class="cv-sec"><div class="cv-sec-h"><h3>About your studio</h3></div>
        <form class="cv-panel cv-form" id="prof"><div class="cv-grid2">
          <label class="cv-f"><span>Cover picture (top of your page)</span><input type="file" id="pf-cover" accept="image/*" ${owner ? "" : "disabled"}></label>
          <label class="cv-f"><span>Logo</span><input type="file" id="pf-logo" accept="image/*" ${owner ? "" : "disabled"}></label>
          <label class="cv-f"><span>City</span><input id="pf-city" value="${esc(m.city || "")}"></label>
          <label class="cv-f"><span>Area / office</span><input id="pf-area" value="${esc(m.area || "")}" placeholder="e.g. Bandra West"></label>
          <label class="cv-f"><span>Website</span><input id="pf-web" value="${esc(m.website || "")}"></label>
          <label class="cv-f"><span>Instagram</span><input id="pf-ig" value="${esc(m.instagram || "")}" placeholder="@yourstudio"></label>
          <label class="cv-f"><span>Email on your page (optional)</span><input id="pf-mail" value="${esc(m.email || "")}"></label>
          <label class="cv-f"><span>Phone on your page (optional)</span><input id="pf-ph" value="${esc(m.phone || "")}"></label>
          <label class="cv-f wide"><span>${m.kind === "vendor" ? "What you make / supply" : "What you specialise in"} (comma separated)</span><input id="pf-trades" value="${esc((m.trades || []).join(", "))}" placeholder="${m.kind === "vendor" ? "Italian marble, quartz, onyx" : "Residences, hospitality, quiet luxury"}"></label>
          <label class="cv-f wide"><span>About</span><textarea id="pf-about" rows="4">${esc(m.about || "")}</textarea></label></div>
          <p class="cv-err" id="pf-err"></p>${owner ? `<div class="cv-row end"><button class="cv-btn">Save</button></div>` : ""}</form></section>

      ${sv.posts.length ? `<section class="cv-sec"><div class="cv-sec-h"><h3>Pins you saved</h3></div><div class="cv-pins">${sv.posts.map(pinCard).join("")}</div></section>` : ""}
    </div>`;
    let cover = "", logo = "";
    const f = $("#prof");
    f.onchange = async (e) => { if (e.target.id === "pf-cover" && e.target.files[0]) cover = await shrink(e.target.files[0], 2200); if (e.target.id === "pf-logo" && e.target.files[0]) logo = await shrink(e.target.files[0], 500); };
    f.onsubmit = async (e) => {
      e.preventDefault();
      try {
        await req("/api/cy/profile", { city: $("#pf-city").value, area: $("#pf-area").value, website: $("#pf-web").value, instagram: $("#pf-ig").value, email: $("#pf-mail").value,
          phone: $("#pf-ph").value, trades: $("#pf-trades").value.split(",").map((s) => s.trim()).filter(Boolean), about: $("#pf-about").value, cover, logo });
        toast("Saved"); cy.home = null; myPage();
      } catch (x) { $("#pf-err").textContent = x.message; }
    };
    body.onclick = async (e) => {
      const t = e.target;
      try {
        if (t.closest("[data-copy]")) { try { await navigator.clipboard.writeText(url); toast("Link copied"); } catch (x) { window.prompt("Copy your link:", url); } return; }
        if (t.closest("[data-wa]")) { window.open(`https://wa.me/?text=${encodeURIComponent(`${m.name} — our work: ${url}`)}`, "_blank", "noopener"); return; }
        const ly = t.closest("[data-layout]"); if (ly) { await req("/api/cy/layout", { layout: ly.dataset.layout }); $$("#pf-layout button").forEach((b) => b.classList.toggle("on", b === ly)); toast("Layout changed"); return; }
        if (t.closest("[data-pfnew]")) return pfEditor(null);
        const pe = t.closest("[data-pfe]"); if (pe) return pfEditor(pg.portfolio.find((p) => p.id === pe.dataset.pfe));
        const pm = t.closest("[data-pfm]"); if (pm) { await req("/api/cy/portfolio", { act: "move", id: pm.dataset.pfm, by: Number(pm.dataset.by) }); return myPage(); }
        const pd = t.closest("[data-pfd]"); if (pd) { if (!sure(pd)) return; await req("/api/cy/portfolio", { act: "delete", id: pd.dataset.pfd }); toast("Removed from your page"); return myPage(); }
        const po = t.closest("[data-pfopen]"); if (po && !t.closest("button, a, input")) { const pr = pg.portfolio.find((p) => p.id === po.dataset.pfopen); if (pr) return pfView(pr, { url, name: m.name, owner }); }
      } catch (x) { toast(x.message); return; }
      common(e);
    };
  }
  /* ---------- one portfolio project, full screen: share · add to Social media · post in The Courtyard ---------- */
  async function asDataUrl(name) {
    const b = await (await fetch(fimg(name))).blob();
    return await shrink(new File([b], "x.jpg", { type: b.type || "image/jpeg" }), 1800);
  }
  function pfView(p, ctx) {
    const pics = [p.cover, ...p.images.filter((x) => x !== p.cover)].filter(Boolean);
    const link = ctx.url + "#" + encodeURIComponent(p.id);
    const meta = [p.kind, p.place, p.year].filter(Boolean).join(" · ");
    const ov = document.createElement("div");
    ov.className = "cv-pfview";
    ov.innerHTML = `<header class="cv-pfv-bar"><div><b>${esc(p.name)}</b>${meta ? `<span>${esc(meta)}</span>` : ""}</div>
        <span class="cv-row"><button class="cv-pill" data-pv-share>Share</button>${ctx.owner ? `<button class="cv-pill" data-pv-social>Add to Social media</button><button class="cv-pill" data-pv-post>Post in The Courtyard</button>` : ""}<button class="cv-pill" data-pv-close>Close</button></span></header>
      <div class="cv-pfv-body">
        ${p.text ? `<p class="cv-pfv-text">${md(p.text)}</p>` : ""}
        ${p.video ? `<p><a class="cv-link" href="${esc(p.video)}" target="_blank" rel="noopener">Watch the film</a></p>` : ""}
        ${p.public === false ? `<p class="cv-held">This project is Private, so it is not on your public page. Choose Edit → make it public before sharing the link.</p>` : ""}
        <div class="cv-pfv-pics">${pics.map((x) => `<img src="${fimg(x)}" alt="${esc(p.name)}" loading="lazy">`).join("") || `<p class="cv-small">No pictures yet.</p>`}</div>
      </div>
      <div class="cv-pfv-share" hidden>
        <button class="cv-btn sm" data-pv-copy>Copy link</button>
        <button class="cv-btn sm ghost" data-pv-wa>WhatsApp</button>
        <button class="cv-btn sm ghost" data-pv-mail>Email</button>
        ${navigator.share ? `<button class="cv-btn sm ghost" data-pv-native>More…</button>` : ""}
        <span class="cv-small">${esc(link)}</span>
      </div>`;
    document.body.appendChild(ov);
    const close = () => { ov.remove(); document.removeEventListener("keydown", key); };
    const key = (e) => { if (e.key === "Escape") close(); };
    document.addEventListener("keydown", key);
    const msg = `${ctx.name} — ${p.name}${meta ? " (" + meta + ")" : ""}: ${link}`;
    ov.addEventListener("click", async (e) => {
      const t = e.target;
      if (t.closest("[data-pv-close]")) return close();
      if (t.closest("[data-pv-share]")) { const sh = $(".cv-pfv-share", ov); sh.hidden = !sh.hidden; return; }
      if (t.closest("[data-pv-copy]")) { try { await navigator.clipboard.writeText(link); toast("Link copied"); } catch (x) { window.prompt("Copy the link:", link); } return; }
      if (t.closest("[data-pv-wa]")) { window.open("https://wa.me/?text=" + encodeURIComponent(msg), "_blank", "noopener"); return; }
      if (t.closest("[data-pv-mail]")) { location.href = "mailto:?subject=" + encodeURIComponent(p.name) + "&body=" + encodeURIComponent(msg); return; }
      if (t.closest("[data-pv-native]")) { try { await navigator.share({ title: p.name, text: msg, url: link }); } catch (x) {} return; }
      const so = t.closest("[data-pv-social]");
      if (so) {
        so.disabled = true; let n = 0;
        for (const [i, x] of pics.entries()) {
          try { toast(`Adding picture ${i + 1} of ${pics.length}…`); await X.api("/api/capture", { data: await asDataUrl(x), name: `${p.name} ${i + 1}.jpg`, to: "social", note: `From My page: ${p.name}` }); n++; } catch (er) { toast(er.message); }
        }
        so.disabled = false;
        if (n) toast(`${n} picture${n === 1 ? "" : "s"} added to Office → Social media → To review`);
        return;
      }
      const po = t.closest("[data-pv-post]");
      if (po) {
        if (!sure(po)) return;
        po.disabled = true;
        try {
          const imgs = []; for (const x of pics.slice(0, 10)) imgs.push(await asDataUrl(x));
          const r = await req("/api/cy/post", { type: "gallery", images: imgs, city: cy.city, title: p.name, text: [meta, p.text].filter(Boolean).join("\n"), file: "", tags: [] });
          toast(r.note || "Posted in The Courtyard"); cy.home = null;
        } catch (er) { toast(er.message); }
        po.disabled = false;
      }
    });
  }
  function pfEditor(p) {
    p = p || { id: "", name: "", place: "", year: "", kind: "", text: "", video: "", images: [], cover: "" };
    let add = [];
    const box = $("#pf-edit");
    box.innerHTML = `<form class="cv-panel cv-form" id="pff"><h3>${p.id ? "Edit project" : "Add a project"}</h3>
      <div class="cv-grid2"><label class="cv-f"><span>Project / site name</span><input id="pe-name" value="${esc(p.name)}" maxlength="100"></label>
        <label class="cv-f"><span>Type</span><input id="pe-kind" value="${esc(p.kind)}" placeholder="Residence, hotel, restaurant…"></label>
        <label class="cv-f"><span>Place</span><input id="pe-place" value="${esc(p.place)}" placeholder="e.g. Juhu, Mumbai"></label>
        <label class="cv-f"><span>Year</span><input id="pe-year" value="${esc(p.year)}" placeholder="2025"></label>
        <label class="cv-f wide"><span>A few lines about it</span><textarea id="pe-text" rows="3">${esc(p.text)}</textarea></label>
        <label class="cv-f"><span>Video link (optional)</span><input id="pe-video" value="${esc(p.video)}" placeholder="YouTube / Instagram / Vimeo"></label>
        <label class="cv-f"><span>Add pictures</span><input id="pe-imgs" type="file" accept="image/*" multiple></label>
        <label class="cv-f"><span>Who can see it</span><select id="pe-pub"><option value="1" ${p.public !== false ? "selected" : ""}>Public — on my page link</option><option value="" ${p.public === false ? "selected" : ""}>Private — only me (show clients in person)</option></select></label></div>
      ${p.images.length ? `<p class="cv-small">Tap a picture to make it the cover · × removes it</p><div class="cv-pfimgs">${p.images.map((n) => `<span class="${n === p.cover ? "cover" : ""}"><button type="button" data-cover="${esc(n)}"><img src="${fimg(n)}" alt=""></button><button type="button" class="cv-x" data-rm="${esc(n)}">×</button></span>`).join("")}</div>` : ""}
      <div class="cv-pfimgs" id="pe-new"></div>
      <p class="cv-err" id="pe-err"></p><div class="cv-row end"><button type="button" class="cv-btn ghost" data-pex>Cancel</button><button class="cv-btn">Save project</button></div></form>`;
    const f = $("#pff"); f.scrollIntoView({ behavior: "smooth", block: "start" });
    const vals = () => ({ id: p.id, public: !!$("#pe-pub").value, name: $("#pe-name").value, kind: $("#pe-kind").value, place: $("#pe-place").value, year: $("#pe-year").value, text: $("#pe-text").value, video: $("#pe-video").value });
    f.onchange = async (e) => { if (e.target.id === "pe-imgs") { add = []; for (const file of [...e.target.files].slice(0, 12)) add.push(await shrink(file, 2200)); $("#pe-new").innerHTML = add.map((d) => `<span><img src="${d}" alt=""></span>`).join(""); } };
    f.onclick = async (e) => {
      if (e.target.closest("[data-pex]")) { box.innerHTML = ""; return; }
      const c = e.target.closest("[data-cover]"); if (c && p.id) { await req("/api/cy/portfolio", { ...vals(), cover: c.dataset.cover }); toast("Cover chosen"); const r = await req("/api/cy/page"); pfEditor(r.portfolio.find((x) => x.id === p.id)); return; }
      const r = e.target.closest("[data-rm]"); if (r && p.id) { await req("/api/cy/portfolio", { ...vals(), remove: r.dataset.rm }); const pg = await req("/api/cy/page"); pfEditor(pg.portfolio.find((x) => x.id === p.id)); return; }
    };
    f.onsubmit = async (e) => {
      e.preventDefault();
      const btn = $("button:not([type])", f); btn.disabled = true; btn.textContent = "Saving…";
      try { await req("/api/cy/portfolio", { ...vals(), add }); toast("Saved to your page"); myPage(); }
      catch (x) { $("#pe-err").textContent = x.message; btn.disabled = false; btn.textContent = "Save project"; }
    };
  }

  /* ---------- badge on the Courtyard tile ---------- */
  function setBadge(p) {
    const b = $("#cy-badge"); if (!b || !p) return;
    b.hidden = !p.badge; b.textContent = p.badge > 9 ? "9+" : p.badge;
    const mt = $('#cy-tabs [data-cy="messages"]'); if (mt) mt.dataset.n = p.threads + p.requests || "";
    const et = $('#cy-tabs [data-cy="events"]'); if (et) et.dataset.n = p.invites || "";
  }
  async function pulse() {
    if (X.token() && (X.me().courtyard || cy.url) && $("#view-login").hidden) { try { setBadge((await req("/api/cy/pulse")).pulse); } catch (e) {} }
    setTimeout(pulse, 60000);
  }
  setTimeout(pulse, 4000);
})();
