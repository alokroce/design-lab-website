/* =========================================================
   DESIGN LAB — project Gallery (with client links) and
   Drawings & corrections (office page and Site on the phone).
   Plugs into app.js through window.DLX.
   ========================================================= */
(function () {
  "use strict";
  const X = window.DLX;
  const { api, esc, toast, $, $$ } = X;
  const fmtDate = (d) => X.fmtDate(d);
  const url = (pid, rel) => X.fileUrl(pid, rel);

  // shrink a picture before upload (phones make 8–12 MB photos)
  function shrink(file, max = 2000) {
    return new Promise((ok, bad) => {
      const fr = new FileReader();
      fr.onerror = bad;
      fr.onload = () => {
        if (!/^image\/(jpeg|png|webp)/.test(file.type)) return ok(fr.result);
        const img = new Image();
        img.onload = () => {
          const k = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement("canvas");
          c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
          c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
          ok(c.toDataURL("image/jpeg", 0.86));
        };
        img.onerror = () => ok(fr.result);
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }

  /* ================= GALLERY (office) ================= */
  const G = { filter: "all", data: null, pid: null };
  const FILTERS = [["all", "All"], ["selection", "For selection"], ["selected", "Selected"], ["reference", "Reference"], ["rooms", "By room"], ["random", "Not sorted"], ["client", "From client"]];

  async function loadGallery(pid, sub, body) {
    G.pid = pid;
    G.data = await api(`/api/projects/${pid}/gallery${sub ? "/" + sub : ""}`, body || {});
    drawGallery();
  }

  function shown() {
    const it = G.data.items;
    switch (G.filter) {
      case "selection": case "selected": case "reference": return it.filter((x) => x.bucket === G.filter);
      case "rooms": return it.filter((x) => x.bucket === "room" && x.room);
      case "random": return it.filter((x) => x.bucket === "room" && !x.room);
      case "client": return it.filter((x) => x.source === "client");
      default: return it;
    }
  }

  function linkUrl(tok) { return (G.data.share_base || location.origin) + "/c/" + tok; }

  function drawGallery() {
    const box = $("#gallery-panel"); if (!box) return;
    const d = G.data, pid = G.pid;
    const roomOpts = (sel, inRoom) => `<option value="" ${inRoom ? "" : "selected disabled"}>${inRoom ? "Not sorted" : "Move to a room…"}</option>${[...new Set([...(d.rooms || []), ...d.items.map((x) => x.room).filter(Boolean)])].map((r) => `<option ${r === sel ? "selected" : ""}>${esc(r)}</option>`).join("")}`;
    const count = (f) => f === "all" ? d.items.length : (G.filter = f, shown().length);
    const keep = G.filter; const counts = FILTERS.map(([f]) => count(f)); G.filter = keep;
    const fromClient = d.items.filter((x) => x.source === "client").length;
    const picks = d.items.filter((x) => x.pick === "yes").length;
    const list = shown();
    const live = d.links.filter((l) => l.on);
    box.innerHTML = `
      <h3>Gallery <span class="h-note">10 Gallery · ${d.items.length} picture${d.items.length === 1 ? "" : "s"}${fromClient ? ` · ${fromClient} from client` : ""}${picks ? ` · client chose ${picks}` : ""}</span></h3>
      <div class="g-add">
        <label class="btn">Add pictures<input type="file" accept="image/*" multiple hidden id="g-files"></label>
        <select id="g-bucket" aria-label="Put them in">
          <option value="sort">Let the Gallery Bot sort them by room</option>
          <option value="selection">For selection (client chooses)</option>
          <option value="reference">Reference images</option>
          ${(d.rooms || []).map((r) => `<option value="room:${esc(r)}">Room: ${esc(r)}</option>`).join("")}
        </select>
        <input id="g-caption" placeholder="A few words, e.g. kitchen tiles option" aria-label="Words about the pictures">
      </div>
      <div class="g-filters">${FILTERS.map(([f, label], i) => `<button class="chip ${G.filter === f ? "on" : ""}" data-gf="${f}">${label} <b>${counts[i]}</b></button>`).join("")}</div>
      ${list.length ? `<div class="g-grid">${list.map((x) => `
        <figure class="g-tile ${x.pick === "yes" ? "picked" : x.pick === "no" ? "nope" : ""}" data-gid="${esc(x.id)}">
          <a href="${url(pid, x.rel)}" target="_blank" rel="noopener"><img src="${url(pid, x.rel)}" alt="${esc(x.caption || x.folder)}" loading="lazy"></a>
          <figcaption>
            <span class="g-where">${esc(x.folder)}${x.source === "client" ? ` · <b>from client</b>` : ""}</span>
            ${x.pick ? `<span class="g-pick">${x.pick === "yes" ? "Client chose this" : "Client said no"}</span>` : ""}
            ${x.caption ? `<span class="g-cap">${esc(x.caption)}</span>` : ""}
            ${(x.comments || []).slice(-2).map((c) => `<span class="g-com"><b>${esc(c.by)}:</b> ${esc(c.text)}</span>`).join("")}
            <span class="g-acts">
              <select data-gmove aria-label="Room">${roomOpts(x.bucket === "room" ? x.room : "", x.bucket === "room")}</select>
              <button class="chip ${x.bucket === "selection" ? "on" : ""}" data-gbucket="selection" title="Put up for the client to choose">For selection</button>
              <button class="chip ${x.bucket === "selected" ? "on" : ""}" data-gbucket="selected">Selected</button>
              <button class="chip ${x.shared ? "on" : ""}" data-gshare title="Client can see it">${x.shared ? "Client sees it" : "Hidden from client"}</button>
              <button class="chip" data-gcomment>Comment</button>
              <button class="x" data-grm aria-label="Remove">×</button>
            </span>
          </figcaption>
        </figure>`).join("")}</div>` : `<p class="empty">${d.items.length ? "Nothing here." : "No pictures yet. Add some, or send your client their link so they can send theirs."}</p>`}

      <div class="g-client">
        <h4>Client access <span class="h-note">a private link for this project — no password needed</span></h4>
        <p class="hint-text">With the link your client can see the pictures you share, choose what they like, comment, send their own pictures from the phone, approve drawings you send for sign-off — and open the folders you choose (drawings, 3D, site photos…) so they don't need to call. Switch a link off any time.</p>
        ${d.links.length ? `<ul class="list">${d.links.map((l) => `<li><span class="what"><b>${esc(l.name)}</b> ${l.on ? "" : `<i class="tag">off</i>`}<span class="where">made by ${esc(l.by)} · ${esc(fmtDate(l.created))}${l.last_seen ? ` · last opened ${esc(fmtDate(l.last_seen))}` : " · not opened yet"}</span></span>
          ${l.on ? `<button class="btn small" data-lcopy="${esc(l.token)}">Copy link</button><button class="btn small ghost" data-lwa="${esc(l.token)}">WhatsApp</button>` : ""}
          <button class="btn small ghost" data-lon="${esc(l.token)}" data-on="${l.on ? "" : "1"}">${l.on ? "Switch off" : "Switch on"}</button>
          <details class="l-access" data-ltok="${esc(l.token)}"><summary>Folders this client can open: <b>${(l.folders || []).length ? esc(l.folders.join(", ")) : "none — only shared pictures and drawings for sign-off"}</b>${l.expires ? ` · until ${esc(fmtDate(l.expires))}` : ""}</summary>
            <p class="hint-text">Read-only: they can open and download, never change or delete. Bills &amp; Quotes, Vendors, the Inbox and superseded drawings are never shown.</p>
            <div class="l-folders">${(d.client_folders || []).map((f) => `<label class="chk"><input type="checkbox" value="${esc(f)}" ${(l.folders || []).includes(f) ? "checked" : ""}> ${esc(f.replace(/^\d+ /, ""))}</label>`).join("")}</div>
            <div class="inline-form" style="grid-template-columns:auto 1fr auto"><span class="hint-text">Link works until</span><input type="date" data-lexp value="${esc(l.expires || "")}" aria-label="Link works until (leave empty for no end)"><button class="btn small" data-lsave>Save</button></div>
            ${(l.opened || []).length ? `<p class="hint-text"><b>What they opened</b></p><ul class="list tight">${l.opened.slice(0, 12).map((o) => `<li><span class="when">${esc(fmtDate(o.time))}</span><span class="what">${esc(o.rel)}</span></li>`).join("")}</ul>` : `<p class="hint-text">They haven't opened any files yet.</p>`}
          </details></li>`).join("")}</ul>` : ""}
        <div class="inline-form"><input id="g-lname" placeholder="Client's name (optional)" aria-label="Client name"><button class="btn" data-lnew>${d.links.length ? "Make another link" : "Make client link"}</button></div>
        <p class="hint-text small">${d.share_base ? `Links use your studio's online address (sharing is on). If you stop sharing, links stop working until you share again.`
          : `Right now links work only on your studio Wi-Fi. For a client at home, double-click <b>SHARE MY REAL STUDIO</b> first, then copy the link again.`}</p>
      </div>`;
  }

  async function addPictures(files) {
    const sel = $("#g-bucket").value;
    const body = { images: [], caption: $("#g-caption").value, bucket: sel.startsWith("room:") ? "room" : sel, room: sel.startsWith("room:") ? sel.slice(5) : "" };
    toast(`Preparing ${files.length} picture${files.length === 1 ? "" : "s"}…`);
    for (const f of [...files].slice(0, 12)) body.images.push({ name: f.name, data: await shrink(f) });
    try {
      await loadGallery(G.pid, "add", body);
      const r = G.data.result || {};
      $("#g-caption").value = "";
      toast(sel === "sort" ? (r.sorted ? `Added ${r.added} — the bot put ${r.sorted} in ${(r.rooms || []).join(", ")}` : `Added ${r.added} to Not sorted — choose a room on each`) : `Added ${r.added} to the Gallery`);
    } catch (x) { toast(x.message); }
  }

  function bindGallery() {
    const box = $("#gallery-panel"); if (!box || box.dataset.bound) return;
    box.dataset.bound = "1";
    box.addEventListener("change", async (e) => {
      if (e.target.id === "g-files" && e.target.files.length) return addPictures(e.target.files);
      const mv = e.target.closest("[data-gmove]");
      if (mv) {
        const id = mv.closest("[data-gid]").dataset.gid;
        try { await loadGallery(G.pid, "move", { id, bucket: "room", room: mv.value }); toast(mv.value ? `Moved to ${mv.value}` : "Moved to Not sorted"); } catch (x) { toast(x.message); }
      }
    });
    box.addEventListener("click", async (e) => {
      const t = e.target;
      try {
        const f = t.closest("[data-gf]"); if (f) { G.filter = f.dataset.gf; return drawGallery(); }
        const tile = t.closest("[data-gid]"); const id = tile && tile.dataset.gid;
        const bk = t.closest("[data-gbucket]");
        if (bk) { const it = G.data.items.find((x) => x.id === id); const to = it.bucket === bk.dataset.gbucket ? "room" : bk.dataset.gbucket; return await loadGallery(G.pid, "move", { id, bucket: to, room: it.room }); }
        if (t.closest("[data-gshare]")) { const it = G.data.items.find((x) => x.id === id); return await loadGallery(G.pid, "share", { id, on: !it.shared }); }
        if (t.closest("[data-grm]")) {
          if (t.dataset.sure !== "1") { t.dataset.sure = "1"; t.textContent = "Sure?"; t.classList.add("sure"); setTimeout(() => { t.dataset.sure = ""; t.textContent = "×"; t.classList.remove("sure"); }, 3000); return; }
          await loadGallery(G.pid, "remove", { id }); toast("Moved to the bin (30 days)"); return;
        }
        if (t.closest("[data-gcomment]")) {
          const cap = tile.querySelector("figcaption");
          if (cap.querySelector(".g-cbox")) return;
          cap.insertAdjacentHTML("beforeend", `<form class="g-cbox"><input placeholder="Write a comment" aria-label="Comment"><button class="btn small">Save</button></form>`);
          const fm = cap.querySelector(".g-cbox"); fm.querySelector("input").focus();
          fm.addEventListener("submit", async (ev) => { ev.preventDefault(); try { await loadGallery(G.pid, "comment", { id, text: fm.querySelector("input").value }); } catch (x) { toast(x.message); } });
          return;
        }
        if (t.closest("[data-lnew]")) { const r = await api(`/api/projects/${G.pid}/gallery/link-new`, { name: $("#g-lname").value }); G.data = r; drawGallery(); copy(linkUrl(r.links[r.links.length - 1].token)); return; }
        const lc = t.closest("[data-lcopy]"); if (lc) return copy(linkUrl(lc.dataset.lcopy));
        const lw = t.closest("[data-lwa]");
        if (lw) {
          const p = X.office.data || {};
          const c = (p.contacts || []).find((c) => c.kind === "client" && c.phone);
          const ph = c ? c.phone.replace(/\D/g, "") : "";
          const msg = `Hello${c && c.name ? " " + c.name : ""}, here is your private link for ${p.name || "your project"} — see the pictures and options we share, choose what you like, send us your pictures, and approve drawings:\n${linkUrl(lw.dataset.lwa)}`;
          window.open(`https://wa.me/${ph.length === 10 ? "91" + ph : ph}?text=${encodeURIComponent(msg)}`, "_blank", "noopener"); return;
        }
        const ls = t.closest("[data-lsave]");
        if (ls) { const box2 = ls.closest("[data-ltok]"); await loadGallery(G.pid, "link-set", { token: box2.dataset.ltok, folders: [...box2.querySelectorAll("input[type=checkbox]:checked")].map((i) => i.value), expires: box2.querySelector("[data-lexp]").value }); toast("Client access saved"); return; }
        const lo = t.closest("[data-lon]"); if (lo) { await loadGallery(G.pid, "link-on", { token: lo.dataset.lon, on: !!lo.dataset.on }); return; }
      } catch (x) { toast(x.message); }
    });
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); toast("Link copied — paste it in WhatsApp or email"); }
    catch (e) { window.prompt("Copy this link:", text); }
  }

  /* ================= DRAWINGS (office) ================= */
  const D = { data: null, pid: null };
  async function loadDrawings(pid, sub, body) {
    D.pid = pid;
    D.data = await api(`/api/projects/${pid}/drawings${sub ? "/" + sub : ""}`, body || {});
    drawDrawings();
  }
  const signTxt = (s) => !s ? "" : s.status === "waiting" ? `<i class="tag warn">waiting for client</i>` : s.status === "approved" ? `<i class="tag ok">client approved</i>` : `<i class="tag warn">client asked for a change</i>`;

  function drawDrawings() {
    const box = $("#drawings-panel"); if (!box) return;
    const d = D.data, pid = D.pid;
    const open = d.corrections.filter((c) => c.status === "open"), done = d.corrections.filter((c) => c.status !== "open");
    const corrRow = (c) => `<li class="corr ${c.status}">
        ${c.picture ? `<a href="${url(pid, c.picture)}" target="_blank" rel="noopener"><img src="${url(pid, c.picture)}" alt="" loading="lazy"></a>` : `<span class="ficon">NOTE</span>`}
        <span class="what"><b>${esc(c.title)}</b>${c.rev ? ` <i class="tag">${esc(c.rev)}</i>` : ""} · ${esc(c.room || "General")} · ${esc(c.type)}${c.source === "client" ? ` · <b>from client</b>` : ""}
          <span class="c-note">${esc(c.note || "(see marks on the drawing)")}</span>
          <span class="where">${esc(c.by)} · ${esc(fmtDate(c.time))}${c.status !== "open" ? ` · closed${c.closed_by ? " by " + esc(c.closed_by) : ""}${c.closed_note ? " — " + esc(c.closed_note) : ""}` : ""}</span></span>
        ${c.status === "open" ? `<select data-cassign="${esc(c.id)}" aria-label="Who does it"><option value="">Who does it?</option>${(d.team || []).map((n) => `<option ${n === c.assigned ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
          <button class="btn small" data-cdone="${esc(c.id)}">Done</button>` : `<button class="btn small ghost" data-creopen="${esc(c.id)}">Open again</button>`}
      </li>`;
    box.innerHTML = `
      <h3>Drawings and corrections <span class="h-note">01 Drawings · latest revision only · ${open.length} correction${open.length === 1 ? "" : "s"} to do</span></h3>
      ${d.drawings.length ? `<ul class="list drw">${d.drawings.map((g) => `<li data-dkey="${esc(g.key)}">
          <span class="ficon">${esc((g.main.name.split(".").pop() || "").toUpperCase().slice(0, 4))}</span>
          <span class="what"><a href="${url(pid, g.main.rel)}" target="_blank" rel="noopener"><b>${esc(g.title)}</b></a> ${g.main.rev ? `<i class="tag">${esc(g.main.rev)}</i>` : ""} ${signTxt(g.signoff)}
            <span class="where">${esc(g.folder)} · ${esc(fmtDate(g.main.time))}${g.older ? ` · ${g.older} older in Superseded` : ""}${g.open ? ` · <b>${g.open} open correction${g.open === 1 ? "" : "s"}</b>` : ""}</span>
            <span class="d-rooms">${g.rooms.length ? g.rooms.map((r) => `<span class="rchip">${esc(r)}</span>`).join("") : `<span class="where">No rooms linked</span>`} <button class="linkish" data-drooms>Rooms…</button></span>
            ${g.needs_copy ? `<span class="d-remind">To mark corrections on this ${g.main.kind === "cad" ? "CAD file" : "PDF"}, save a JPG copy of it here.
              <label class="btn small ghost">Add JPG copy<input type="file" accept="image/*" hidden data-dcopy></label></span>` : ""}
          </span>
          ${g.mark ? `<button class="btn small" data-dmark>Mark correction</button>` : ""}
          <button class="btn small ghost" data-dsign>${g.signoff && g.signoff.status === "waiting" ? "Sent for sign-off" : "Send for client sign-off"}</button>
        </li>`).join("")}</ul>`
      : `<p class="empty">No drawings yet. Drop drawings into 00 Inbox — they are filed here, and older revisions move to Superseded.</p>`}
      <h4>Corrections <span class="h-note">office tasks — each one closes by itself when a new revision of that drawing comes in</span></h4>
      ${open.length ? `<ul class="list corrs">${open.map(corrRow).join("")}</ul>` : `<p class="empty">No corrections to do.</p>`}
      ${done.length ? `<details><summary>Closed (${done.length})</summary><ul class="list corrs">${done.map(corrRow).join("")}</ul></details>` : ""}`;
  }

  function roomsEditor(li, g) {
    if (li.querySelector(".d-redit")) return;
    const all = [...new Set([...(D.data.rooms || []), ...g.rooms])];
    li.querySelector(".what").insertAdjacentHTML("beforeend", `<form class="d-redit">${all.map((r) => `<label class="chk"><input type="checkbox" value="${esc(r)}" ${g.rooms.includes(r) ? "checked" : ""}> ${esc(r)}</label>`).join("")}
      <input placeholder="Other room" aria-label="Other room"><button class="btn small">Save rooms</button></form>`);
    const f = li.querySelector(".d-redit");
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      const rooms = $$("input[type=checkbox]", f).filter((c) => c.checked).map((c) => c.value);
      const extra = f.querySelector("input:not([type])").value.trim(); if (extra) rooms.push(...extra.split(",").map((s) => s.trim()).filter(Boolean));
      try { await loadDrawings(D.pid, "rooms", { key: g.key, rooms }); toast("Rooms linked"); } catch (x) { toast(x.message); }
    });
  }

  function bindDrawings() {
    const box = $("#drawings-panel"); if (!box || box.dataset.bound) return;
    box.dataset.bound = "1";
    box.addEventListener("change", async (e) => {
      const t = e.target;
      if (t.matches("[data-dcopy]") && t.files[0]) {
        const g = D.data.drawings.find((x) => x.key === t.closest("[data-dkey]").dataset.dkey);
        try { await loadDrawings(D.pid, "copy", { key: g.key, data: await shrink(t.files[0], 3000) }); toast("Copy saved — you can mark corrections now"); } catch (x) { toast(x.message); }
      }
      if (t.matches("[data-cassign]")) { try { await loadDrawings(D.pid, "update", { id: t.dataset.cassign, assigned: t.value }); toast(t.value ? `Given to ${t.value}` : "Unassigned"); } catch (x) { toast(x.message); } }
    });
    box.addEventListener("click", async (e) => {
      const t = e.target;
      try {
        const li = t.closest("[data-dkey]"); const g = li && D.data.drawings.find((x) => x.key === li.dataset.dkey);
        if (t.closest("[data-drooms]")) return roomsEditor(li, g);
        if (t.closest("[data-dmark]")) return openMarker({ pid: D.pid, g, rooms: g.rooms.length ? g.rooms : D.data.rooms, room: g.rooms[0] || "", types: D.data.types, team: D.data.team, done: () => loadDrawings(D.pid) });
        if (t.closest("[data-dsign]")) { await loadDrawings(D.pid, "signoff", { key: g.key }); toast("Sent — your client sees it on their link"); return; }
        const dn = t.closest("[data-cdone]"); if (dn) { await loadDrawings(D.pid, "update", { id: dn.dataset.cdone, status: "closed", note: "Done" }); toast("Correction closed"); return; }
        const ro = t.closest("[data-creopen]"); if (ro) { await loadDrawings(D.pid, "update", { id: ro.dataset.creopen, status: "open" }); return; }
      } catch (x) { toast(x.message); }
    });
  }

  /* ================= MARK A CORRECTION (draw on the drawing) ================= */
  function openMarker(o) {
    const ov = document.createElement("div");
    ov.className = "marker";
    ov.innerHTML = `
      <div class="mk-bar">
        <b>${esc(o.g.title)}</b>${o.g.main.rev ? ` <i class="tag">${esc(o.g.main.rev)}</i>` : ""}
        <span class="mk-tools"><button class="chip on" data-tool="pen">Draw</button><button class="chip" data-tool="pin">Number pin</button><button class="chip" data-tool="undo">Undo</button><button class="chip" data-tool="clear">Clear</button></span>
        <button class="btn small ghost" data-mk-close>Close</button>
      </div>
      <div class="mk-stage"><canvas></canvas></div>
      <form class="mk-form">
        <select name="room" aria-label="Room"><option value="">Room: General</option>${(o.rooms || []).map((r) => `<option ${r === o.room ? "selected" : ""}>${esc(r)}</option>`).join("")}</select>
        <select name="type" aria-label="Type">${o.types.map((t) => `<option>${esc(t)}</option>`).join("")}</select>
        ${o.team ? `<select name="assigned" aria-label="Who does it"><option value="">Who does it?</option>${o.team.map((n) => `<option>${esc(n)}</option>`).join("")}</select>` : ""}
        <textarea name="note" rows="2" placeholder="What needs to change? e.g. 1 — shift switchboard 300 mm left. (Tap the mic on your keyboard to speak.)"></textarea>
        <button class="btn orange" type="submit">Save correction</button>
      </form>`;
    document.body.appendChild(ov);
    const cv = ov.querySelector("canvas"), ctx = cv.getContext("2d");
    const img = new Image();
    let marks = [], cur = null, tool = "pen";
    function paint() {
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      const w = Math.max(3, cv.width / 300);
      marks.forEach((m) => {
        ctx.strokeStyle = "#e0161b"; ctx.fillStyle = "#e0161b"; ctx.lineWidth = w; ctx.lineCap = ctx.lineJoin = "round";
        if (m.t === "pen") { ctx.beginPath(); m.p.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.stroke(); }
        else { const r = w * 5; ctx.beginPath(); ctx.arc(m.x, m.y, r, 0, 7); ctx.fill(); ctx.fillStyle = "#fff"; ctx.font = `bold ${r * 1.2}px sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(m.n, m.x, m.y + 1); }
      });
    }
    function fit() {   // show the drawing as big as the screen allows
      const st = ov.querySelector(".mk-stage").getBoundingClientRect();
      const k = Math.min((st.width - 20) / cv.width, (st.height - 20) / cv.height);
      cv.style.width = Math.round(cv.width * k) + "px"; cv.style.height = Math.round(cv.height * k) + "px";
    }
    img.onload = () => { const k = Math.min(1, 2400 / Math.max(img.width, img.height)); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); paint(); fit(); };
    window.addEventListener("resize", () => cv.width && fit());
    img.onerror = () => toast("Couldn't open the drawing picture.");
    img.src = url(o.pid, o.g.mark.rel);
    const at = (e) => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
    cv.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      if (tool === "pin") { const [x, y] = at(e); marks.push({ t: "pin", x, y, n: marks.filter((m) => m.t === "pin").length + 1 }); paint(); return; }
      cv.setPointerCapture(e.pointerId); cur = { t: "pen", p: [at(e)] }; marks.push(cur);
    });
    cv.addEventListener("pointermove", (e) => { if (cur) { cur.p.push(at(e)); paint(); } });
    const up = () => { cur = null; };
    cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
    ov.addEventListener("click", (e) => {
      const tb = e.target.closest("[data-tool]");
      if (tb) {
        const k = tb.dataset.tool;
        if (k === "undo") { marks.pop(); paint(); return; }
        if (k === "clear") { marks = []; paint(); return; }
        tool = k; $$("[data-tool]", ov).forEach((b) => b.classList.toggle("on", b.dataset.tool === k)); return;
      }
      if (e.target.closest("[data-mk-close]")) ov.remove();
    });
    ov.querySelector(".mk-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = e.target, btn = f.querySelector("button[type=submit]");
      if (!marks.length && !f.note.value.trim()) { toast("Draw on the drawing or write what needs to change."); return; }
      btn.disabled = true; btn.textContent = "Saving…";
      try {
        await api(`/api/projects/${o.pid}/drawings/correct`, { key: o.g.key, room: f.room.value, type: f.type.value, note: f.note.value,
          assigned: f.assigned ? f.assigned.value : "", marks: marks.map((m) => m.t), image: marks.length ? cv.toDataURL("image/jpeg", 0.85) : "" });
        ov.remove(); toast("Correction saved — office task made, picture in 01 Drawings/Site corrections"); o.done && o.done();
      } catch (x) { toast(x.message); btn.disabled = false; btn.textContent = "Save correction"; }
    });
  }

  /* ================= SITE (phone): drawings for the room you're in ================= */
  X.afterSite = async (p, roomName) => {
    const host = $("#site-body .s-actions"); if (!host) return;
    let st;
    try { st = await api(`/api/projects/${p.id}/drawings`, {}); } catch (e) { return; }
    const list = st.drawings.filter((g) => !roomName || !g.rooms.length || g.rooms.includes(roomName));
    const sec = document.createElement("section");
    sec.className = "s-draw";
    const openN = st.corrections.filter((c) => c.status === "open" && (!roomName || c.room === roomName)).length;
    sec.innerHTML = `<h3>Drawings${roomName ? ` for ${esc(roomName)}` : ""} <span class="h-note">latest revision${openN ? ` · ${openN} correction${openN === 1 ? "" : "s"} open` : ""}</span></h3>
      ${list.length ? `<ul class="s-list">${list.map((g) => `<li data-skey="${esc(g.key)}"><span><a href="${url(p.id, g.main.rel)}" target="_blank" rel="noopener">${esc(g.title)}</a> ${g.main.rev ? `<i class="tag">${esc(g.main.rev)}</i>` : ""}${g.open ? ` <em>${g.open} open</em>` : ""}</span>
        ${g.mark ? `<button class="btn orange small" data-smark>Mark correction</button>` : `<em>PDF — office to add a JPG copy</em>`}</li>`).join("")}</ul>`
      : `<p class="empty">${st.drawings.length ? "No drawings linked to this room yet." : "No drawings in 01 Drawings yet."}</p>`}`;
    host.insertAdjacentElement("afterend", sec);
    sec.addEventListener("click", (e) => {
      const b = e.target.closest("[data-smark]"); if (!b) return;
      const g = st.drawings.find((x) => x.key === b.closest("[data-skey]").dataset.skey);
      openMarker({ pid: p.id, g, rooms: st.rooms, room: roomName, types: st.types, team: null, done: () => X.renderSiteProject() });
    });
  };

  /* ================= vendor orders (from makers on Design Lab) ================= */
  async function vendorOrders(p) {
    if (!(X.me() || {}).courtyard) return;
    let r;
    try { r = await api(`/api/cy/orders?project=${encodeURIComponent(p.name)}`); } catch (e) { return; }
    if (!r.orders.length) return;
    const anchor = $("#drawings-panel"); if (!anchor) return;
    const sec = document.createElement("section");
    sec.className = "panel"; sec.id = "vorders-panel";
    const step = ["Confirmed", "In production", "Ready", "Dispatched", "Delivered", "Installed"];
    sec.innerHTML = `<h3>Orders from makers <span class="h-note">status sent by vendors who use Design Lab</span></h3>
      <ul class="list vord">${r.orders.map((o) => {
        const k = step.indexOf(o.status);
        const d = o.dispatch || {};
        return `<li><span class="what"><b>${esc(o.vendor_name)}</b> · ${esc(o.ref)} — ${esc(o.item || "")}
          <span class="vsteps">${step.map((s2, i) => `<i class="${i <= k ? "done" : ""}${i === k ? " now" : ""}">${esc(s2)}</i>`).join("")}</span>
          <span class="where">${o.eta ? "Promised " + esc(fmtDate(o.eta)) + " · " : ""}${d.status ? `Delivery: ${esc(d.status)}${d.date ? " " + esc(fmtDate(d.date)) : ""}${d.slot ? " " + esc(d.slot) : ""}${d.vehicle ? " · vehicle " + esc(d.vehicle) : ""}${d.received_by ? " · received by " + esc(d.received_by) : ""} · ` : ""}updated ${esc(fmtDate(o.time))}</span></span></li>`;
      }).join("")}</ul>`;
    anchor.insertAdjacentElement("beforebegin", sec);
  }

  /* ================= hook into the project page ================= */
  const prev = X.afterProject;
  X.afterProject = (p) => {
    if (prev) prev(p);
    bindGallery(); bindDrawings(); vendorOrders(p);
    loadGallery(p.id).catch((x) => { const b = $("#gallery-panel"); if (b) b.innerHTML = `<h3>Gallery</h3><p class="empty">${esc(x.message)}</p>`; });
    loadDrawings(p.id).catch((x) => { const b = $("#drawings-panel"); if (b) b.innerHTML = `<h3>Drawings and corrections</h3><p class="empty">${esc(x.message)}</p>`; });
  };
})();
