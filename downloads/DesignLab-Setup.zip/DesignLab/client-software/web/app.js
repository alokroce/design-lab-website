/* =========================================================
   DESIGN LAB — studio app (v0.1)
   Pendulum → sign in (or first-time setup) → firm home → Office / Site.
   Talks only to the Design Lab server running on the studio's own
   computer. Nothing is sent anywhere else.
   ========================================================= */
(function () {
  "use strict";

  if (!document.querySelector('link[href^="fast.css"]')) {   // v0.11.1: fast mode even if an old page is still open
    const l = document.createElement("link"); l.rel = "stylesheet"; l.href = "fast.css"; document.head.appendChild(l);
  }
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const SPEED = reduce ? 0.15 : 1;
  const T = { rise: 0, afterRise: 0, viewFade: 0, introOut: 450 };   // v0.11 fast mode: screens open at once
  const wait = (ms) => new Promise((r) => setTimeout(r, ms * SPEED));
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const surfaces = $("#surfaces");
  const intro = $("#intro");
  const cradle = $("#cradle");
  const views = { login: $("#view-login"), welcome: $("#view-welcome"), office: $("#view-office"), site: $("#view-site"), courtyard: $("#view-courtyard") };
  const themeOf = { login: "black", welcome: "office", office: "office", site: "site", courtyard: "courtyard" };
  window.DLX = window.DLX || { tabs: {} };   // extra screens (more.js) plug in here
  let current = null;
  let DLX_cyAccessForm = null;
  let busy = false;

  /* ---------------- Server connection ---------------- */
  const TOKEN_KEY = "designlab_token";
  const store = {
    get() { try { return localStorage.getItem(TOKEN_KEY) || ""; } catch (e) { return ""; } },
    set(t) { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch (e) {} },
  };
  let token = store.get();
  let me = { name: "", firm: "" };
  let serverState = null;
  const REG_ID = Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  let MAIN = true;   // true on the studio computer (folders live there); false on a phone or other device
  function applyMain() {
    MAIN = !serverState || serverState.main !== false;
    const demo = !!(serverState && serverState.demo);
    document.body.classList.toggle("on-device", !MAIN);
    document.body.classList.toggle("is-demo", demo);
    $("#go-register").hidden = !MAIN && !demo;
    $("#register-elsewhere").hidden = MAIN || demo;
    $("#new-q").hidden = !MAIN && !demo;
    if (demo) { $("#new-q").textContent = "New here? Try Design Lab:"; $("#go-register").textContent = "Try it · Register"; }
  }

  async function api(path, body) {
    const opts = { method: body === undefined ? "GET" : "POST", headers: { "Content-Type": "application/json" } };
    if (token) opts.headers["X-Token"] = token;
    if (path.startsWith("/api/register")) opts.headers["X-Reg"] = REG_ID;
    if (body !== undefined) opts.body = JSON.stringify(body);
    let res;
    try { res = await fetch(path, opts); } catch (e) { throw new Error("Can't reach the Design Lab server. Is it running on the studio computer?"); }
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && token && !path.endsWith("/login")) { token = ""; store.set(""); }
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    return data;
  }
  let fkey = "";      // file key: opens pictures/files without putting the sign-in itself into links
  const fileUrl = (pid, rel) => `/files/${encodeURIComponent(pid)}/${rel.split("/").map(encodeURIComponent).join("/")}?f=${encodeURIComponent(fkey)}`;
  const readFile = (file) => new Promise((ok, bad) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = bad; r.readAsDataURL(file); });

  // Shrink phone photos before upload (keeps the folder light, uploads fast on site)
  async function photoData(file, max = 2000) {
    const url = await readFile(file);
    if (!/^image\/(jpeg|png|webp)/.test(file.type)) return url;
    return new Promise((ok) => {
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height));
        if (k === 1 && file.size < 1.5e6) return ok(url);
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        ok(c.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = () => ok(url);
      img.src = url;
    });
  }

  let toastTimer = 0;
  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg; t.classList.add("on");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("on"), 2600);
  }

  /* ---------------- Pendulum ---------------- */
  const WORDS = ["You", "Design", "We", "Handle", "The rest"];
  const AMP_MAX = 26 * Math.PI / 180;
  let AMP = AMP_MAX;
  const HALF = 1900;
  const pends = WORDS.map((w, i) => {
    const p = document.createElement("div");
    p.className = "pend";
    p.innerHTML = `<span class="string"></span><span class="ring"></span><span class="word">${w}</span>`;
    p.style.left = `calc(${i} * (var(--d) + 2px))`;
    cradle.appendChild(p);
    return { el: p, word: p.querySelector(".word") };
  });
  let raf = 0, t0 = 0, running = false, lastSide = -1;
  function fitSwing() {
    const r = cradle.getBoundingClientRect();
    const len = pends[0].el.offsetHeight - pends[0].el.querySelector(".ring").offsetHeight / 2;
    const room = Math.max(0, r.left - 14);
    AMP = Math.min(AMP_MAX, Math.asin(Math.min(1, room / Math.max(1, len))));
  }
  window.addEventListener("resize", fitSwing);
  function setAngle(i, a) {
    pends[i].el.style.transform = `rotate(${a}rad)`;
    pends[i].word.style.transform = `translateX(-50%) rotate(${-a}rad)`;
  }
  function frame(now) {
    if (!t0) t0 = now;
    const p = ((now - t0) / HALF) % 2;
    const side = p < 1 ? 0 : 1;
    const a = AMP * Math.sin(Math.PI * (p % 1));
    setAngle(0, side === 0 ? a : 0);
    setAngle(4, side === 1 ? -a : 0);
    if (side !== lastSide) {
      pends[0].el.classList.toggle("lit", side === 0);
      pends[4].el.classList.toggle("lit", side === 1);
      if (lastSide !== -1) pulseBrand();
      lastSide = side;
    }
    if (running) raf = requestAnimationFrame(frame);
  }
  function startPendulum() { if (running) return; running = true; t0 = 0; lastSide = -1; pends.forEach((_, i) => setAngle(i, 0)); raf = requestAnimationFrame(frame); }
  function stopPendulum() { running = false; cancelAnimationFrame(raf); }

  const GL = {
    D: [44, "M2 2 H30 A12 12 0 0 1 42 14 V26 A12 12 0 0 1 30 38 H2 Z"],
    E: [40, "M2 2 H38 M2 20 H30 M2 38 H38"],
    S: [44, "M42 2 H13 A9 9 0 0 0 13 20 H31 A9 9 0 0 1 31 38 H2"],
    I: [4, "M2 2 V38"],
    G: [44, "M42 2 H14 A12 12 0 0 0 2 14 V26 A12 12 0 0 0 14 38 H42 V21 H27"],
    N: [42, "M2 38 V2 L40 38 V2"],
    L: [36, "M2 2 V38 H34"],
    A: [44, "M2 38 L22 2 L42 38"],
    B: [42, "M2 2 H29 A9 9 0 0 1 29 20 H2 V2 M2 20 H31 A9 9 0 0 1 31 38 H2 V20"],
  };
  function brandSvg(cls) {
    let x = 0, k = 0, out = "";
    for (const ch of "DESIGN LAB") {
      if (ch === " ") { x += 30; continue; }
      const [w, d] = GL[ch];
      out += `<path class="stroke" pathLength="1" style="--d:${600 + k * 140}ms" transform="translate(${x} 0)" d="${d}"/>`;
      x += w + 16; k++;
    }
    return `<svg class="${cls || ""}" viewBox="-3 -3 ${x - 10} 46" aria-hidden="true">${out}</svg>`;
  }
  function buildBrand() {
    const brand = $("#brand");
    brand.innerHTML = `<svg width="0" height="0" style="position:absolute"><defs><linearGradient id="dl-orange" x1="0" y1="0" x2="0" y2="40" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ffb070"/><stop offset=".5" stop-color="#ff6a13"/><stop offset="1" stop-color="#e04e00"/></linearGradient></defs></svg>` +
      brandSvg() + `<span class="brand-sub">Studio intelligence for architects</span>`;
  }
  let hitTimer = 0;
  function pulseBrand() { const b = $("#brand"); b.classList.add("hit"); clearTimeout(hitTimer); hitTimer = setTimeout(() => b.classList.remove("hit"), 260); }

  /* ---------------- Surfaces and views ---------------- */
  function prep(root) {
    $$("[data-flicker]", root).forEach((el, i) => el.style.setProperty("--d", Math.round((350 + i * 450) * SPEED) + "ms"));
  }
  function setTheme(theme) {
    const keep = ["on-device", "ask-on", "is-vendor", "is-demo"].filter((c) => document.body.classList.contains(c));
    document.body.className = ["theme-" + theme, ...((theme === "office" || theme === "site") ? ["sk"] : []), ...((current === "office" || current === "site" || current === "courtyard") ? ["in-area"] : []), ...keep].join(" ");
  }
  function rise(theme) {
    const s = document.createElement("div");
    s.className = "surface s-" + theme;
    s.style.transition = "none"; s.style.animation = "none";   // v0.11.1: background changes at once, never half-way
    surfaces.appendChild(s);
    void s.offsetHeight;
    s.classList.add("up");
    setTheme(theme);
    return wait(T.rise).then(() => { [...surfaces.children].forEach((c) => { if (c !== s) c.remove(); }); });
  }
  async function hideCurrent() {
    if (!current) return;
    const v = views[current];
    v.classList.add("out");
    await wait(T.viewFade);
    v.hidden = true;
    v.classList.remove("in", "out");
    current = null;
  }
  function show(name) {
    const v = views[name];
    prep(v);
    v.classList.remove("in", "out");
    v.hidden = false;
    v.scrollTop = 0;
    void v.offsetHeight;
    v.classList.add("in");
    current = name;
    setTheme(themeOf[name]);
    savePlace();
  }
  /* refresh keeps you where you were (this tab only; cleared on sign-out) */
  let restoring = false;
  function savePlace() {
    try {
      sessionStorage.setItem("dl_place", JSON.stringify({ area: current, mode: office.mode, tab: office.tab, project: office.project,
        sp: site.project, sr: site.room, cy: DLX.cyState ? DLX.cyState() : null }));
    } catch (e) {}
  }
  function readPlace() { try { return JSON.parse(sessionStorage.getItem("dl_place") || "null"); } catch (e) { return null; } }
  async function goBack() {
    const p = readPlace();
    if (!p || !["office", "site", "courtyard"].includes(p.area)) return go("welcome");
    restoring = true;
    office.mode = p.mode || "office"; office.tab = p.tab || "home"; office.project = p.project || null;
    site.project = p.sp || null; site.room = p.sr || null;
    if (p.cy && DLX.cyRestore) DLX.cyRestore(p.cy);
    try { await go(p.area === "office" && office.mode !== "office" ? office.mode : p.area); } finally { restoring = false; }
  }
  async function go(name) {
    if (name === "works") name = "voffice";
    if (name === "showroom" || name === "voffice") {
      office.mode = name; if (!restoring) office.project = null;
      if (!TABSETS[name].some(([k]) => k === office.tab)) office.tab = TABSETS[name][0][0];
      name = "office";
      if (current === "office" && !busy) { officeTabs(); return renderOffice(); }
    } else if (name === "office") { office.mode = "office"; }
    if (busy || name === current) return;
    busy = true;
    await hideCurrent();
    $$(".tile.on").forEach((t) => t.classList.remove("on"));
    await rise(themeOf[name]);
    await wait(T.afterRise);
    if (name === "office") { officeTabs(); await renderOffice(); startAsk(); }
    if (name === "courtyard" && DLX.renderCourtyard) await DLX.renderCourtyard();
    if (name === "site") await renderSite();
    show(name);
    busy = false;
  }

  /* ---------------- Sign in / setup ---------------- */
  function fillFirm() {
    $("#user-name").textContent = me.name || "";
    $("#firm-name").textContent = me.firm || "";
    const vendor = me.kind === "vendor";
    document.body.classList.toggle("is-vendor", vendor);
    const tiles = $$("#view-welcome .tile");
    if (tiles[0]) { tiles[0].dataset.go = vendor ? "voffice" : "office"; $(".tile-label", tiles[0]).textContent = "Office"; tiles[0].setAttribute("aria-label", "Open Office"); }
    if (tiles[1]) { tiles[1].dataset.go = vendor ? "showroom" : "site"; $(".tile-label", tiles[1]).textContent = vendor ? "Showroom" : "Site"; tiles[1].setAttribute("aria-label", "Open " + (vendor ? "Showroom" : "Site")); }
    if (DLX.welcomePhoto) DLX.welcomePhoto(me);
  }
  async function refreshMe() {
    try { const h = await api("/api/home"); fkey = h.fk || ""; me = { name: h.user, firm: h.firm, kind: h.kind, role: h.role, courtyard: h.courtyard, cy_url: h.cy_url, welcome_photo: h.welcome_photo, cy_access: h.cy_access || null }; } catch (e) {}
  }
  async function enterFirm() {
    await refreshMe(); fillFirm();
    busy = true;
    await hideCurrent();
    intro.classList.remove("dim", "tall");
    if (window.DLXMotion) await window.DLXMotion.exitIntro(intro);
    else { intro.classList.add("gone"); await wait(T.introOut); }
    stopPendulum();
    busy = false;
    await goBack();
  }
  async function checkSession() {
    if (!token) return false;
    try { const h = await api("/api/home"); fkey = h.fk || ""; me = { name: h.user, firm: h.firm, kind: h.kind, role: h.role, courtyard: h.courtyard, cy_url: h.cy_url, welcome_photo: h.welcome_photo, cy_access: h.cy_access || null }; return true; } catch (e) { return false; }
  }

  /* ---------------- sign in, forgot password, registration ---------------- */
  let side = "design";
  let formNow = "login";
  const FORMS = ["login", "forgot", "reg1", "reg2", "reg3", "reg4", "join"];
  function showForm(which) {
    formNow = which;
    const vendor = side === "vendor";
    $("#vendor-soon").hidden = true;
    FORMS.forEach((f) => ($("#f-" + f).hidden = f !== which));
    if (window.DLXMotion) window.DLXMotion.revealLogin($("#f-" + which));
    profChips(vendor);
    const first = { login: "#login-user", forgot: "#fg-user", reg1: "#r-firm", reg3: "#r-uid", join: "#j-code" }[which];
    if (first && !vendor && window.matchMedia("(min-width: 700px)").matches) setTimeout(() => $(first).focus({ preventScroll: true }), 300);
  }
  const PROF = {
    design: ["Architect", "Interior designer", "Stylist", "Lighting designer", "Landscape designer", "Other"],
    vendor: ["Marble & stone", "Tiles", "Lighting", "Furniture", "Fabric & furnishing", "Laminates & veneers", "Hardware", "Sanitaryware", "Manufacturer", "Other"],
  };
  function profChips(vendor) {
    const box = $('[data-chips="profession"]');
    const want = vendor ? "vendor" : "design";
    if (!box || box.dataset.side === want) return;
    box.dataset.side = want;
    box.innerHTML = PROF[want].map((v, i) => `<button type="button" class="chip ${i ? "" : "on"}" data-v="${v}">${v}</button>`).join("");
    $("#r-prof-other").hidden = true;
    const POSTS = vendor ? ["Owner / Proprietor", "Partner", "Director", "CEO / MD", "Sales head", "Sales manager", "Showroom manager", "Accounts", "Other"]
      : ["Principal", "Partner", "Associate", "Senior designer", "Designer", "Junior designer", "Site supervisor", "Draughtsman", "Office admin", "Accounts", "Other"];
    $("#r-desig").innerHTML = POSTS.map((d) => `<option>${d}</option>`).join("");
    $("#r-desig-other-wrap").hidden = true;
    $("#r-desig-label").textContent = vendor ? "Your position in the company" : "Your designation in the firm";
    $("#r-firm-label").textContent = vendor ? "Company name *" : "Firm name *";
    const t = $("#f-reg1 .setup-title"); if (t) t.textContent = vendor ? "Welcome to Design Lab — vendors & makers" : "Welcome to Design Lab";
    const sub = $("#f-reg1 .setup-title + .soon-text"); if (sub) sub.textContent = vendor ? "Tell us about your company. What do you supply?" : "Tell us about you and your firm.";
  }
  $$("[data-side]").forEach((b) => b.addEventListener("click", () => {
    side = b.dataset.side;
    $$("[data-side]").forEach((x) => x.classList.toggle("on", x === b));
    showForm(formNow);
  }));
  $$("[data-show]").forEach((b) => b.addEventListener("click", () => showForm(b.dataset.show)));
  $$("[data-eye]").forEach((b) => b.addEventListener("click", () => {
    const i = $("#" + b.dataset.eye);
    const showIt = i.type === "password";
    i.type = showIt ? "text" : "password";
    b.textContent = showIt ? "Hide" : "Show";
    b.setAttribute("aria-label", showIt ? "Hide password" : "Show password");
  }));
  $$("[data-chips]").forEach((g) => g.addEventListener("click", (e) => {
    const c = e.target.closest(".chip"); if (!c) return;
    $$(".chip", g).forEach((x) => x.classList.toggle("on", x === c));
    $("#r-prof-other").hidden = c.dataset.v !== "Other";
    if (!$("#r-prof-other").hidden) $("#r-prof-other").focus();
  }));
  $("#r-desig").addEventListener("change", () => { $("#r-desig-other-wrap").hidden = $("#r-desig").value !== "Other"; });
  const inr = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 });

  function showBill(o) {
    $("#reg-bill").innerHTML = `
      <tr><td>Design Lab setup, one time</td><td>${inr(o.amount)}</td></tr>
      <tr><td>GST</td><td>${inr(o.gst)}</td></tr>
      <tr><td>Payment gateway charge</td><td>${inr(o.gateway)}</td></tr>
      <tr><td>Total</td><td>${inr(o.total)}</td></tr>`;
  }

  $("#go-register").addEventListener("click", async () => {
    try { serverState = await api("/api/state"); } catch (e) { serverState = null; }
    if (!serverState) { $("#login-error").textContent = "Can't reach Design Lab on this computer. Start it with START DESIGN LAB.bat."; return; }
    if (serverState.registered && !serverState.testing && !serverState.demo) {
      $("#login-error").textContent = "This computer already has a studio. Ask your studio owner to add you in Office → Team.";
      return;
    }
    const note = $("#reg-replace-note");
    note.hidden = !serverState.registered || !!serverState.demo;
    note.textContent = serverState.registered
      ? `Testing: this computer already has “${serverState.firm}”. Registering a new firm keeps the old one safe in a backup folder.` : "";
    const step = { details: "reg1", pay: "reg2", create: "reg3" }[serverState.register_step] || "reg1";
    if (step === "reg2" && serverState.pending_order) { showBill(serverState.pending_order); showQr(serverState.pending_pay, serverState.pending_order); }
    showForm(step);
  });

  cradle.addEventListener("click", async () => {
    if (busy || current) return;
    if (await checkSession()) { try { serverState = await api("/api/state"); applyMain(); } catch (e) {} fillFirm(); enterFirm(); return; }
    try { serverState = await api("/api/state"); } catch (e) { serverState = null; }
    applyMain();
    const start = "login";   // sign-in box always first; "New user · Register" opens registration
    $("#login-error").textContent = serverState ? "" : "Can't reach Design Lab on this computer. Start it with START DESIGN LAB.bat.";
    intro.classList.add("dim");
    show("login");
    showForm(start);
  });

  $$("[data-cancel]").forEach((b) => b.addEventListener("click", async () => {
    if (busy) return;
    await hideCurrent();
    intro.classList.remove("dim", "tall");
    setTheme("black");
  }));

  // Sign in
  $("#f-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#login-error");
    const user_id = $("#login-user").value.trim(), password = $("#login-pass").value;
    if (!user_id || !password) { err.textContent = "Enter your user ID, phone or email, and your password."; return; }
    err.textContent = "";
    try {
      const r = await api("/api/login", { user_id, password, remember: $("#login-remember").checked });
      token = r.token; store.set(token); me = { name: r.name, firm: r.firm };
      $("#login-pass").value = ""; $("#login-pass").blur();
      fillFirm(); enterFirm();
    } catch (x) { err.textContent = x.message; }
  });

  // Join a team with the owner's invitation code
  $("#f-join").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#j-error"); err.textContent = "";
    try {
      const r = await api("/api/join", { code: $("#j-code").value, name: $("#j-name").value, user_id: $("#j-uid").value, phone: $("#j-phone").value,
        email: $("#j-email").value, password: $("#j-pass").value, password2: $("#j-pass2").value });
      token = r.token; store.set(token); me = { name: r.name, firm: r.firm };
      $("#j-pass").value = $("#j-pass2").value = "";
      fillFirm(); enterFirm();
    } catch (x) { err.textContent = x.message; }
  });

  // Forgot password (owner, with recovery code)
  $("#f-forgot").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#forgot-error"); err.textContent = "";
    try {
      await api("/api/recover", { user_id: $("#fg-user").value, code: $("#fg-code").value, password: $("#fg-pass").value, password2: $("#fg-pass2").value });
      $("#f-forgot").reset();
      showForm("login");
      $("#login-error").textContent = "Password changed. Sign in with your new password.";
    } catch (x) { err.textContent = x.message; }
  });

  // Register 1: details
  $("#f-reg1").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#reg1-error"); err.textContent = "";
    const chip = $("[data-chips] .chip.on");
    const other = chip && chip.dataset.v === "Other";
    if (other && !$("#r-prof-other").value.trim()) { err.textContent = "Please type what you are under Other."; $("#r-prof-other").focus(); return; }
    const desig = $("#r-desig").value === "Other" ? $("#r-desig-other").value.trim() : $("#r-desig").value;
    const v = (id) => $(id).value.trim();
    const bad = (id, msg) => { err.textContent = msg; $(id).focus(); $(id).closest(".field").classList.add("bad"); return true; };
    $$("#f-reg1 .field.bad").forEach((f) => f.classList.remove("bad"));
    const phone = v("#r-phone").replace(/[\s\-()]/g, "").replace(/^(\+?91)(?=\d{10}$)/, "");
    if (!v("#r-firm")) return bad("#r-firm", side === "vendor" ? "Please enter your company name." : "Please enter your firm name.");
    if (!/^[A-Za-z][A-Za-z .'-]{1,79}$/.test(v("#r-name"))) return bad("#r-name", "Please enter your name (letters only).");
    if ($("#r-desig").value === "Other" && !v("#r-desig-other")) return bad("#r-desig-other", "Please type your post.");
    if (!v("#r-city")) return bad("#r-city", "Please enter your city.");
    if (!/^[6-9]\d{9}$/.test(phone)) return bad("#r-phone", "Please enter a 10-digit mobile number (starting 6, 7, 8 or 9).");
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(v("#r-email"))) return bad("#r-email", "That email doesn't look right — please check it.");
    try {
      const r = await api("/api/register/start", {
        kind: side === "vendor" ? "vendor" : "designer",
        profession: other ? $("#r-prof-other").value.trim() : chip.dataset.v,
        firm: v("#r-firm"), name: v("#r-name"), designation: desig,
        city: v("#r-city"), address: v("#r-address"), phone: phone, email: v("#r-email"),
      });
      showBill(r.order); showQr(r.pay, r.order);
      showForm("reg2");
    } catch (x) { err.textContent = x.message; }
  });

  function showQr(p, o) {
    const box = $("#reg-qr");
    if (!p || !p.upi || typeof qrcode !== "function") { box.innerHTML = ""; return; }
    const qr = qrcode(0, "M"); qr.addData(p.upi); qr.make();
    box.innerHTML = `<div class="qr-img">${qr.createSvgTag({ cellSize: 5, margin: 3, scalable: true })}</div>
      <div class="qr-text"><b>Scan to pay ${inr(o.total)}</b><span>with any UPI app: Google Pay, PhonePe, Paytm, BHIM</span>
      ${p.test ? `<span class="qr-test">TEST QR: pays no one. Use “I've paid” to continue.</span>` : `<span>Paying to ${esc(p.payee)}</span>`}</div>`;
  }
  // Register 2: payment (test) or start without paying while testing
  async function pay(skip) {
    const err = $("#reg2-error"); err.textContent = "";
    try {
      const r = await api("/api/register/pay", { skip });
      $("#reg-code").textContent = r.code;
      $("#reg3-paid").textContent = skip ? "Started without paying (testing). You can create your user now." : "Payment received. You can create your user now.";
      showForm("reg3");
    } catch (x) { err.textContent = x.message; }
  }
  $("#f-reg2").addEventListener("submit", (e) => { e.preventDefault(); pay(false); });
  $("[data-skip-pay]").addEventListener("click", () => pay(true));

  // Register 3: choose user ID and password
  $("#f-reg3").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#reg3-error"); err.textContent = "";
    try {
      const r = await api("/api/register/finish", { user_id: $("#r-uid").value, password: $("#r-pass").value, password2: $("#r-pass2").value });
      token = r.token; store.set(token); me = { name: r.name, firm: r.firm };
      if (String(r.recovery_code).startsWith("DEMO")) { fillFirm(); enterFirm(); return; }   // demo: no recovery code needed
      $("#reg-recovery").textContent = r.recovery_code;
      showForm("reg4");
    } catch (x) { err.textContent = x.message; }
  });
  $("#reg-done").addEventListener("click", () => { fillFirm(); enterFirm(); });

  $("#sign-out").addEventListener("click", async () => {
    if (busy) return;
    busy = true;
    try { await api("/api/logout", {}); } catch (e) {}
    token = ""; store.set(""); try { sessionStorage.removeItem("dl_place"); } catch (e) {}
    await hideCurrent();
    await rise("black");
    surfaces.innerHTML = "";
    intro.classList.remove("gone", "dim");
    startPendulum();
    busy = false;
  });

  document.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-go]");
    if (!b || busy) return;
    if (b.classList.contains("tile")) {
      if ($(".tile.on")) return;
      b.classList.add("on");
      await wait(650);   // the symbol lights up, then the area opens
    }
    go(b.dataset.go);
  });

  /* =========================================================
     OFFICE
     ========================================================= */
  const office = { tab: "home", project: null };
  const officeBody = $("#office-body");
  const fmtDate = (iso) => { if (!iso) return ""; const d = new Date(iso.length === 10 ? iso + "T00:00:00" : iso); return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }); };
  const fmtTime = (iso) => new Date(iso).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" });
  const todayIso = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };

  const TABSETS = {
    office: [["home", "Today"], ["projects", "Projects"], ["schedule", "Schedule"], ["people", "Vendors & contractors"], ["business", "Business"], ["social", "Social media"], ["team", "Team & wallet"], ["profile", "My profile"]],
    voffice: [["vtoday", "Today"], ["rec:orders", "Orders"], ["rec:dispatch", "Logistics"], ["rec:sitejobs", "Site jobs"], ["rec:quotes", "Quotes"], ["rec:samples", "Samples"], ["rec:accounts", "Accounts"], ["team", "Team & wallet"], ["profile", "My profile"]],
    showroom: [["supdates", "Today & updates"], ["rec:catalog", "Catalog"], ["rec:visits", "Visits"], ["rec:v_architects", "Architects"], ["social", "Social media"]],
  };
  function officeTabs() {
    const set = TABSETS[office.mode || "office"] || TABSETS.office;
    if (!set.some(([k]) => k === office.tab)) office.tab = set[0][0];
    $("#office-tabs").innerHTML = set.map(([k, l]) => `<button data-otab="${k}">${esc(l)}</button>`).join("");
  }
  $("#office-tabs").addEventListener("click", (e) => {
    const b = e.target.closest("[data-otab]");
    if (!b) return;
    office.tab = b.dataset.otab; office.project = null;
    renderOffice();
  });
  function markTab() {          // the menu stays lit inside a feature and its inner pages (a project lights "Projects")
    const lit = office.project && $('#office-tabs [data-otab="projects"]') ? "projects" : office.tab;
    $$("#office-tabs button").forEach((b) => b.classList.toggle("on", b.dataset.otab === lit));
  }

  async function renderOffice() {
    officeBody.onclick = null; officeBody.onchange = null;
    markTab(); if (current === "office") savePlace();
    try {
      if (office.project) return await renderProject(office.project);
      if (office.tab === "home") return await renderHome();
      if (office.tab === "projects") return await renderProjects();
      if (office.tab === "schedule") return await renderSchedule();
      if (office.tab === "bots") return await renderBots();
      if (office.tab === "team") return await renderTeam();
      if (office.tab === "people") return await renderPeople();
      const extra = DLX.tabs[office.tab] || (office.tab.startsWith("rec:") && DLX.tabs["rec:"]);
      if (extra) return await extra(officeBody, office.tab);
    } catch (x) {
      officeBody.innerHTML = `<div class="empty">${esc(x.message)}</div>`;
    }
  }

  async function renderHome() {
    const h = await api("/api/home");
    const show = h.dash_show || {};
    const t = todayIso();
    const todays = h.events.filter((e) => e.date === t);
    officeBody.innerHTML = `
      <div class="o-head">
        <div><p class="eyebrow">${esc(fmtDate(t))}</p><h2 class="o-title">Good ${new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}, ${esc(h.user)}</h2></div>
        <span class="btn-row">${MAIN && serverState && (serverState.lan || []).length ? `<button class="btn ghost" data-act="phone-link">Open on your phone</button>` : ""}${h.dash ? `<a class="btn ghost" href="${esc(h.dash)}" target="_blank" rel="noopener">My dashboard</a>` : ""}<button class="btn" data-act="new-project">+ New project</button></span>
      </div>
      <div id="phone-slot"></div>
      <div id="owner-alerts"></div>
      ${show.kpis === false ? "" : `<div class="kpis">
        <button class="kpi" data-otab-go="schedule"><b>${todays.length}</b><span>meeting${todays.length === 1 ? "" : "s"} today</span></button>
        <button class="kpi ${h.open_snags ? "warn" : ""}" data-otab-go="projects"><b>${h.open_snags}</b><span>open snag${h.open_snags === 1 ? "" : "s"}</span></button>
        <button class="kpi ${h.inbox ? "warn" : ""}" data-act="sort-all"><b>${h.inbox}</b><span>file${h.inbox === 1 ? "" : "s"} in Inbox ${h.inbox ? "· sort now" : ""}</span></button>
        <button class="kpi" data-otab-go="projects"><b>${h.projects}</b><span>project${h.projects === 1 ? "" : "s"}</span></button>
      </div>`}
      <div class="cols">
        ${show.coming === false ? "" : `<section class="panel">
          <h3>Coming up</h3>
          ${h.events.length ? `<ul class="list">${h.events.slice(0, 6).map((e) => `
            <li><button class="row-link" data-open-project="${esc(e.project_id)}"><span class="when">${esc(fmtDate(e.date))}${e.time ? " · " + esc(e.time) : ""}</span><span class="what">${esc(e.title)}</span><span class="where">${esc(e.project)}</span></button></li>`).join("")}</ul>`
          : `<p class="empty">No meetings or reminders yet. Add one inside a project.</p>`}
        </section>`}
        ${show.happened === false ? "" : `<section class="panel">
          <h3>What happened</h3>
          ${h.activity.length ? `<ul class="list feed">${h.activity.slice(0, 10).map((a) => `
            <li><span class="dot k-${esc(a.kind)}"></span><span class="what">${esc(a.text)}</span><span class="where">${esc(a.project)} · ${esc(fmtDate(a.time))} ${esc(fmtTime(a.time))}</span></li>`).join("")}</ul>`
          : `<p class="empty">Nothing yet. Create your first project to begin.</p>`}
        </section>`}
      </div>
      <div id="new-project-slot"></div>`;
    ownerAlerts($("#owner-alerts"), h.alerts);
    const pb = $('[data-act="phone-link"]', officeBody);
    if (pb) pb.onclick = () => phoneLink($("#phone-slot"));
  }
  /* v0.11 — open Design Lab on a phone: same Wi-Fi, scan the code, sign in with your own user ID */
  function phoneLink(box) {
    if (!box) return;
    if (box.innerHTML) { box.innerHTML = ""; return; }
    const urls = (serverState && serverState.lan) || [];
    const url = urls.find((u) => /\/\/(192\.168|10\.|172\.)/.test(u)) || urls[0];
    if (!url) return;
    let svg = "";
    try { const qr = qrcode(0, "M"); qr.addData(url); qr.make(); svg = qr.createSvgTag({ cellSize: 5, margin: 3, scalable: true }); } catch (e) {}
    box.innerHTML = `<section class="panel phone-link">
      <h3>Open Design Lab on your phone</h3>
      <div class="phone-link-row">
        <div class="qr-img phone-qr">${svg}</div>
        <ol class="phone-steps">
          <li>Connect the phone to the <b>same Wi-Fi</b> as this computer (or this computer to the phone's hotspot).</li>
          <li>Open the phone camera and point it at this code, then tap the link. Or type <b class="mono">${esc(url)}</b> in the phone's browser.</li>
          <li>Sign in with your own user ID and password.</li>
        </ol>
      </div>
      <p class="h-note">Keep this computer switched on and Design Lab open while the phone is in use.</p>
      <div class="btn-row"><button class="btn ghost small" data-act="phone-close">Close</button></div>
    </section>`;
    $('[data-act="phone-close"]', box).onclick = () => { box.innerHTML = ""; };
  }
  /* the owner is asked — never automatic — whether a new member may use The Courtyard */
  async function ownerAlerts(box, alerts) {
    if (!box || !(alerts || []).length) return;
    const t = await api("/api/users").catch(() => null); if (!t) return;
    box.innerHTML = alerts.filter((a) => a.kind === "joined").map((a) => `<section class="panel attention" data-alert="${esc(a.id)}">
      <h3>${esc(a.name)} joined your team <span class="h-note">${esc(fmtDate(a.time))}</span></h3>
      <p>Let ${esc(a.name)} into The Courtyard? Tick the parts they may use — nothing is opened until you save.</p>
      <div class="l-folders">${t.cy_sections.map(([k, l]) => `<label class="chk"><input type="checkbox" value="${esc(k)}" ${k === "perspective_read" ? "checked" : ""}> ${esc(l)}</label>`).join("")}</div>
      <div class="btn-row"><button class="btn" data-al-ok="${esc(a.user)}">Save</button><button class="btn ghost" data-al-no="${esc(a.user)}">Not now (no Courtyard)</button></div></section>`).join("");
    box.onclick = async (e) => {
      const ok = e.target.closest("[data-al-ok]"), no = e.target.closest("[data-al-no]");
      if (!ok && !no) return;
      const card = e.target.closest("[data-alert]"); const sec = {};
      $$("input", card).forEach((i) => { sec[i.value] = ok ? i.checked : false; });
      try { await api("/api/users/cy-access", { id: (ok || no).dataset[ok ? "alOk" : "alNo"], sections: sec }); card.remove(); toast(ok ? "Saved — you can change it in Team & wallet" : "No Courtyard for now — change it any time in Team & wallet"); } catch (x) { toast(x.message); }
    };
  }

  const RELATIONS = ["", "Owner", "Husband", "Wife", "Son", "Daughter", "Father", "Mother", "Brother", "Sister", "Family member", "Representative", "Other"];
  function memberRow(m, i) {
    return `<div class="m-row">
      <input class="m-name" placeholder="Name${i ? " (optional)" : ""}" value="${esc(m.name || "")}" aria-label="Client member name">
      <select class="m-rel" aria-label="Relationship">${RELATIONS.map((r) => `<option value="${r}" ${r === (m.relation || "") ? "selected" : ""}>${r || "Relationship"}</option>`).join("")}</select>
      <input class="m-phone" placeholder="Phone" inputmode="tel" value="${esc(m.phone || "")}" aria-label="Phone">
      <input class="m-email" placeholder="Email" inputmode="email" value="${esc(m.email || "")}" aria-label="Email">
      <button type="button" class="x" data-m-del aria-label="Remove member">×</button>
    </div>`;
  }
  function newProjectForm() {
    return `<form class="panel form" id="np-form">
      <h3>New project</h3>
      <p class="hint-text">Design Lab will create the project's folders on this computer. Only the project name is needed; everything else can be added later.</p>
      <div class="grid2">
        <label class="f"><span>Project name</span><input id="np-name" required placeholder="Bandra Residence"></label>
        <label class="f"><span>Site address <i>optional</i></span><input id="np-address" placeholder="Pali Hill, Bandra West"></label>
      </div>
      <h4 class="sub-h">Client family or team <i>optional — add everyone you coordinate with</i></h4>
      <div id="m-rows">${memberRow({}, 0)}</div>
      <button type="button" class="btn ghost small" data-m-add>+ Add another member</button>
      <div class="form-row"><p class="form-error" id="np-error"></p><button class="btn" type="submit">Create project and folders</button></div>
    </form>`;
  }
  function bindNewProject() {
    const f = $("#np-form");
    f.addEventListener("click", (e) => {
      if (e.target.closest("[data-m-add]")) { $("#m-rows").insertAdjacentHTML("beforeend", memberRow({}, 1)); $$("#m-rows .m-name").pop().focus(); }
      if (e.target.closest("[data-m-del]")) { const rows = $$("#m-rows .m-row"); if (rows.length > 1) e.target.closest(".m-row").remove(); else $$("input", rows[0]).forEach((i) => (i.value = "")); }
    });
    f.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const members = $$("#m-rows .m-row").map((r) => ({ name: $(".m-name", r).value, relation: $(".m-rel", r).value, phone: $(".m-phone", r).value, email: $(".m-email", r).value })).filter((m) => m.name.trim());
      try {
        const r = await api("/api/projects", { name: $("#np-name").value, address: $("#np-address").value, client: members.map((m) => m.name.trim()).join(", "), members });
        toast("Project and folders created"); office.project = r.project.id; renderOffice();
      } catch (x) { $("#np-error").textContent = x.message; }
    });
  }

  async function renderProjects() {
    const { projects } = await api("/api/projects");
    officeBody.innerHTML = `
      <div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">Projects</h2></div><button class="btn" data-act="new-project">+ New project</button></div>
      <div id="new-project-slot"></div>
      ${projects.length ? `<div class="cards">${projects.map((p) => `
        <button class="card" data-open-project="${esc(p.id)}">
          <span class="card-name">${esc(p.name)}</span>
          <span class="card-sub">${esc(p.client || "")}${p.address ? " · " + esc(p.address) : ""}</span>
          <span class="card-stats">
            <span>${p.stats.notes} notes</span>
            <span class="${p.stats.open_snags ? "warn" : ""}">${p.stats.open_snags} open snags</span>
            ${p.stats.inbox ? `<span class="warn">${p.stats.inbox} in Inbox</span>` : ""}
          </span>
          ${p.stats.next_event ? `<span class="card-next">Next: ${esc(fmtDate(p.stats.next_event.date))} ${esc(p.stats.next_event.time || "")} · ${esc(p.stats.next_event.title)}</span>` : ""}
        </button>`).join("")}</div>`
      : `<p class="empty">No projects yet. Create one and Design Lab will build its folders.</p>`}`;
  }

  async function renderProject(pid) {
    const { project: p } = await api(`/api/projects/${pid}`);
    office.data = p;
    const open = p.snags.filter((s) => s.status !== "closed");
    const closed = p.snags.filter((s) => s.status === "closed");
    const last = (p.bot_log || [])[0];
    const upcoming = p.events.filter((e) => e.date >= todayIso()).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
    const notes = [...p.notes].reverse();
    officeBody.innerHTML = `
      <div class="o-head">
        <div><button class="crumb" data-otab-go="projects">&larr; Projects</button><h2 class="o-title">${esc(p.name)}</h2>
        <p class="o-sub">${esc(p.client || "")}${p.address ? " · " + esc(p.address) : ""}</p></div>
        <div class="head-acts">${MAIN ? `<button class="btn ghost" data-act="open-folder" data-folder="">Open folder</button>` : ""}<button class="btn" data-act="to-site">Go to Site</button></div>
      </div>
      ${MAIN ? `<p class="path" title="Project folder on this computer">${esc(p.folder)}</p>` : ""}

      ${!MAIN ? `<section class="panel device-note"><h3>Files</h3>
        <p class="hint-text">This project's files are kept on your studio computer${p.folders.reduce((a, f) => a + f.files, 0) ? ` (${p.folders.reduce((a, f) => a + f.files, 0)} files)` : ""}. Ask your assistant and it does the work there.</p>
        <div class="btn-row"><button class="btn" data-ask="sort ${esc(p.name)}">Ask: sort this project's files</button><button class="btn ghost" data-ask-open>Ask something else</button></div>
      </section>` : `<div class="cols">
        <section class="panel">
          <h3>Folders <span class="h-note">on this computer</span></h3>
          <ul class="folders">${p.folders.map((f) => `<li><button class="row-link" data-act="browse" data-folder="${esc(f.name)}"><span class="what">${esc(f.name)}</span><span class="num ${f.name === "00 Inbox" && f.files ? "warn" : ""}">${f.files}</span></button></li>`).join("")}</ul>
        </section>
        <section class="panel bot-panel">
          <h3>Auto-filing</h3>
          <p class="hint-text">Drop any file into <b>00 Inbox</b>. Within a minute it is filed in the right folder; older drawing revisions move to Superseded. Nothing is ever deleted.</p>
          <div class="btn-row"><button class="btn" data-act="sort">Sort Inbox now</button><button class="btn ghost" data-act="ai-sort" title="For files with unclear names">Smart sort (AI)</button>${last ? `<button class="btn ghost" data-act="undo-sort">Undo last sort</button>` : ""}</div>
          <div id="sort-report">${last ? botRunHtml(last) : `<p class="empty">No files sorted yet.</p>`}</div>
        </section>
      </div>`}

      <section class="panel">
        <h3>Project card <span class="h-note">client, contractors, vendors — used for MOMs and messages</span></h3>
        <div id="contacts">${contactsView(p.contacts)}</div>
      </section>

      <section class="panel" id="drawings-panel"></section>
      <section class="panel" id="gallery-panel"></section>
      <section class="panel" id="mood-panel"></section>

      <div class="cols">
        <section class="panel">
          <h3>Meetings and reminders</h3>
          <form class="inline-form" id="ev-form">
            <input id="ev-title" placeholder="Site visit with client" aria-label="Title">
            <input id="ev-date" type="date" value="${todayIso()}" aria-label="Date">
            <input id="ev-time" type="time" aria-label="Time">
            <select id="ev-kind" aria-label="Type"><option value="meeting">Meeting</option><option value="reminder">Reminder</option></select>
            <button class="btn" type="submit">Add</button>
          </form>
          ${upcoming.length ? `<ul class="list">${upcoming.map((e) => `<li><span class="when">${esc(fmtDate(e.date))}${e.time ? " · " + esc(e.time) : ""}</span><span class="what">${esc(e.title)} <i class="tag">${esc(e.kind)}</i></span><button class="x" data-act="del-event" data-id="${esc(e.id)}" aria-label="Remove">×</button></li>`).join("")}</ul>` : `<p class="empty">Nothing scheduled.</p>`}
        </section>
        <section class="panel">
          <h3>Snags <span class="h-note">${open.length} open · ${closed.length} closed</span></h3>
          ${open.length ? `<ul class="list">${open.map((s) => `<li><span class="what"><b>${esc(s.room || "General")}</b> — ${esc(s.text)}</span><span class="where">${esc(s.owner || "No owner")}${s.due ? " · by " + esc(fmtDate(s.due)) : ""}</span><button class="btn small ghost" data-act="close-snag" data-id="${esc(s.id)}">Close</button><button class="x" data-act="rm" data-kind="snag" data-id="${esc(s.id)}" aria-label="Remove">×</button></li>`).join("")}</ul>` : `<p class="empty">No open snags.</p>`}
        </section>
      </div>

      <div class="cols">
        <section class="panel">
          <h3>From site <span class="h-note">notes, changes and photos, newest first</span></h3>
          ${notes.length ? `<ul class="list feed">${notes.slice(0, 30).map((n) => `<li><span class="dot k-${esc(n.kind)}"></span><span class="what">${n.kind === "photo" ? `<a href="${fileUrl(p.id, n.file)}" target="_blank" rel="noopener">Photo</a>${n.text ? " — " + esc(n.text) : ""}` : `${n.kind !== "note" ? `<i class="tag">${esc(n.kind)}</i> ` : ""}${esc(n.text)}`}</span><span class="where">${esc(n.room || "General")} · ${esc(n.by)} · ${esc(fmtDate(n.time))} ${esc(fmtTime(n.time))}</span><button class="x" data-act="rm" data-kind="note" data-id="${esc(n.id)}" aria-label="Remove">×</button></li>`).join("")}</ul>` : `<p class="empty">Nothing from site yet. Use Site on your phone.</p>`}
        </section>
        <section class="panel">
          <h3>MOMs <span class="h-note">saved in 04 MOM</span></h3>
          ${p.moms.length ? `<ul class="list">${p.moms.map((m) => `<li><span class="what"><a href="${fileUrl(p.id, m.file)}" target="_blank" rel="noopener">${esc(m.file.split("/").pop())}</a></span><span class="where">${esc(m.by)} · ${esc(fmtDate(m.saved))}</span></li>`).join("")}</ul>` : `<p class="empty">No MOMs yet. Write one from Site after a visit.</p>`}
        </section>
      </div>
      ${p.layout ? `<section class="panel"><h3>Site plan and rooms <span class="h-note">used on the phone at site</span></h3>
        <div class="room-chips">${(p.rooms || []).map((r) => `<span class="rchip">${esc(r.name)}<button class="x" data-act="rm" data-kind="room" data-id="${esc(r.id)}" aria-label="Remove room">×</button></span>`).join("") || `<span class="empty">No rooms marked yet.</span>`}</div>
        <div class="btn-row"><button class="btn ghost small" data-act="rm" data-kind="layout">Remove site plan</button></div></section>` : ""}
      <section class="panel bin-panel" id="bin-panel"><h3>Removed <span class="h-note">kept for 30 days — bring anything back</span></h3><div id="bin-list"><p class="empty">Loading…</p></div></section>`;

    $("#ev-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        await api(`/api/projects/${p.id}/events`, { title: $("#ev-title").value, date: $("#ev-date").value, time: $("#ev-time").value, kind: $("#ev-kind").value });
        toast("Added to the schedule"); renderProject(p.id);
      } catch (x) { toast(x.message); }
    });
    bindContacts(p.id, p.contacts);
    if (DLX.afterProject) DLX.afterProject(p);
    loadBin(p.id);
  }

  async function loadBin(pid) {
    const box = $("#bin-list"); if (!box) return;
    try {
      const r = await api(`/api/projects/${pid}/bin`, {});
      box.innerHTML = r.bin.length ? `<ul class="list">${r.bin.map((b) => `<li><span class="what"><b>${esc(String(b.title).slice(0, 80))}</b> <i class="tag">${esc(b.kind)}</i></span><span class="where">removed by ${esc(b.by)} · ${esc(fmtDate(b.time))} · kept until ${esc(fmtDate(b.until))}</span><button class="btn small ghost" data-act="restore" data-id="${esc(b.id)}">Bring back</button></li>`).join("")}</ul>
        <div class="btn-row"><button class="btn ghost small" data-act="bin-empty">Empty the bin for good</button></div>` : `<p class="empty">Nothing removed.</p>`;
    } catch (x) { box.innerHTML = `<p class="empty">${esc(x.message)}</p>`; }
  }
  async function browseFolder(pid, folder) {
    const r = await api(`/api/projects/${pid}/files`, { folder });
    let box = $("#browse");
    if (!box) { $("#sort-report").closest(".cols").insertAdjacentHTML("afterend", `<section class="panel" id="browse"></section>`); box = $("#browse"); }
    const live = r.files.filter((f) => !f.superseded), old = r.files.filter((f) => f.superseded);
    const row = (f) => `<li class="file-row">${f.image ? `<img src="${fileUrl(pid, f.rel)}" alt="" loading="lazy">` : `<span class="ficon">${esc((f.name.split(".").pop() || "").toUpperCase().slice(0, 4))}</span>`}
      <span class="what"><a href="${fileUrl(pid, f.rel)}" target="_blank" rel="noopener">${esc(f.name)}</a><span class="where">${esc(f.folder)} · ${esc(fmtDate(f.time))} · ${Math.max(1, Math.round(f.size / 1024))} KB</span></span>
      <label class="btn small ghost">Replace<input type="file" hidden data-replace="${esc(f.rel)}"></label><button class="x" data-act="rm" data-kind="file" data-rel="${esc(f.rel)}" aria-label="Remove">×</button></li>`;
    box.innerHTML = `<h3>${esc(folder)} <span class="h-note">${live.length} file${live.length === 1 ? "" : "s"}</span></h3>
      <div class="btn-row">${MAIN ? `<button class="btn ghost small" data-act="open-folder" data-folder="${esc(folder)}">Open in File Explorer</button>` : ""}<button class="btn ghost small" data-act="browse-close">Close</button></div>
      ${live.length ? `<ul class="list files">${live.map(row).join("")}</ul>` : `<p class="empty">This folder is empty.</p>`}
      ${old.length ? `<details><summary>Superseded (${old.length})</summary><ul class="list files">${old.map(row).join("")}</ul></details>` : ""}`;
    box.dataset.folder = folder;
    box.onchange = async (e) => {
      const inp = e.target.closest("[data-replace]"); if (!inp || !inp.files[0]) return;
      const f = inp.files[0];
      if (f.size > 55 * 1024 * 1024) { toast("That file is too big (over 55 MB)."); return; }
      const data = await new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(f); });
      try { const rr = await api(`/api/projects/${pid}/replace`, { rel: inp.dataset.replace, name: f.name, data }); toast(`Replaced — old one is in ${rr.old_went_to}`); browseFolder(pid, folder); loadBin(pid); }
      catch (x) { toast(x.message); }
    };
    box.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function botRunHtml(run) {
    const moved = run.moved || [];
    return `<p class="run-meta">${esc(run.by)} · ${esc(fmtDate(run.time))} ${esc(fmtTime(run.time))}</p>
      <ul class="list tight">${moved.slice(0, 8).map((m) => `<li><span class="what">${esc(m.file)}</span><span class="where">→ ${esc(m.to)}</span></li>`).join("")}
      ${(run.superseded || []).map((s) => `<li><span class="what">${esc(s.file)}</span><span class="where">→ Superseded</span></li>`).join("")}</ul>
      ${moved.length > 8 ? `<p class="run-meta">and ${moved.length - 8} more</p>` : ""}`;
  }

  /* ---------- Project card: Client / Contractors / Vendors ---------- */
  let BOOK = null;   // studio list of vendors and contractors + trade names
  async function loadBook(force) { if (!BOOK || force) BOOK = await api("/api/book"); return BOOK; }
  const KIND_LABEL = { client: "Client", contractor: "Contractors", vendor: "Vendors" };
  const opt = (list, val, ph) => `<option value="">${ph}</option>` + list.map((t) => `<option ${t === val ? "selected" : ""}>${esc(t)}</option>`).join("") + (val && !list.includes(val) ? `<option selected>${esc(val)}</option>` : "");
  function contactRow(c) {
    const k = c.kind || "client";
    const trades = k === "vendor" ? BOOK.vendor_trades : BOOK.contractor_trades;
    return `<div class="c-row k-${k}" data-kind="${k}">
      ${k === "client"
        ? `<input class="c-name" placeholder="Name" value="${esc(c.name)}" aria-label="Name">
           <select class="c-rel" aria-label="Relationship">${RELATIONS.map((r) => `<option value="${r}" ${r === (c.relation || "") ? "selected" : ""}>${r || "Relationship"}</option>`).join("")}</select>`
        : `<select class="c-trade" aria-label="${k === "vendor" ? "What they supply" : "Trade"}">${opt(trades, c.trade, k === "vendor" ? "Supplies…" : "Trade…")}</select>
           <input class="c-company" placeholder="Company" value="${esc(c.company)}" aria-label="Company">
           <input class="c-name" placeholder="Contact person" value="${esc(c.name)}" aria-label="Contact person">`}
      <input class="c-phone" placeholder="Phone" inputmode="tel" value="${esc(c.phone)}" aria-label="Phone">
      <input class="c-email" placeholder="Email" inputmode="email" value="${esc(c.email)}" aria-label="Email">
      <button type="button" class="x" data-c-del aria-label="Remove">×</button>
    </div>`;
  }
  function personLine(c) {
    const who = c.kind === "client" ? esc(c.name || "—") : `${esc(c.company || c.name || "—")}${c.company && c.name ? ` <span class="pc-sub">${esc(c.name)}</span>` : ""}`;
    const tag = c.kind === "client" ? c.relation : c.trade;
    return `<div class="pc-person"><b>${who}</b>${tag ? ` <span class="tag">${esc(tag)}</span>` : ""}
      <span class="pc-line">${c.phone ? `<a class="pc-wa" href="https://wa.me/${(() => { const d = c.phone.replace(/\D/g, ""); return d.length === 10 ? "91" + d : d; })()}" target="_blank" rel="noopener" title="Open a WhatsApp chat — you write and press Send">WhatsApp</a> · <a href="tel:${esc(c.phone)}">${esc(c.phone)}</a>` : ""}${c.phone && c.email ? " · " : ""}${c.email ? `<a href="mailto:${esc(c.email)}">${esc(c.email)}</a>` : ""}</span></div>`;
  }
  function contactsView(list) {
    return `<div class="pc-cols">${["client", "contractor", "vendor"].map((k) => {
      const cs = list.filter((c) => c.kind === k);
      return `<div class="pc-group"><p class="eyebrow">${KIND_LABEL[k]} <span class="count">${cs.length || ""}</span></p>
        ${cs.length ? cs.map(personLine).join("") : `<p class="empty small">None added yet.</p>`}</div>`;
    }).join("")}</div>
      <div class="btn-row"><button class="btn ghost" data-c-edit>${list.length ? "Edit project card" : "Add client, contractors and vendors"}</button></div>`;
  }
  function contactsEditor(list) {
    const groups = ["client", "contractor", "vendor"].map((k) => {
      const cs = list.filter((c) => c.kind === k);
      const fromBook = k === "client" ? [] : BOOK.people.filter((p) => p.kind === k);
      return `<div class="pc-edit" data-group="${k}">
        <p class="eyebrow">${KIND_LABEL[k]}</p>
        <div class="c-rows">${cs.map(contactRow).join("")}</div>
        <div class="btn-row tight">
          <button type="button" class="btn small ghost" data-c-add="${k}">+ Add ${k === "client" ? "client member" : k === "vendor" ? "vendor" : "contractor"}</button>
          ${fromBook.length ? `<select class="pick" data-c-pick="${k}" aria-label="Pick from my list"><option value="">Pick from my ${k}s…</option>${fromBook.map((p) => `<option value="${esc(p.id)}">${esc((p.trade ? p.trade + " — " : "") + (p.company || p.name))}</option>`).join("")}</select>` : ""}
        </div></div>`;
    }).join("");
    return `${groups}<p class="hint-text">New contractors and vendors are also saved to your studio's <b>Vendors &amp; contractors</b> list, so next time you can just pick them.</p>
      <div class="btn-row"><button class="btn" data-c-save>Save project card</button><button class="btn ghost" data-c-cancel>Cancel</button></div>`;
  }
  function readContacts(box) {
    return $$(".c-row", box).map((r) => {
      const v = (sel) => ($(sel, r) ? $(sel, r).value : "");
      return { kind: r.dataset.kind, name: v(".c-name"), relation: v(".c-rel"), trade: v(".c-trade"), company: v(".c-company"), phone: v(".c-phone"), email: v(".c-email") };
    });
  }
  function bindContacts(pid, list) {
    const box = $("#contacts");
    box.addEventListener("change", (e) => {
      const pick = e.target.closest("[data-c-pick]");
      if (!pick || !pick.value) return;
      const p = BOOK.people.find((x) => x.id === pick.value);
      if (p) $(`[data-group="${pick.dataset.cPick}"] .c-rows`, box).insertAdjacentHTML("beforeend", contactRow(p));
      pick.value = "";
    });
    box.addEventListener("click", async (e) => {
      if (e.target.closest("[data-c-edit]")) {
        try { await loadBook(true); } catch (x) { toast(x.message); return; }
        box.innerHTML = contactsEditor(list);
        if (!list.length) $(`[data-group="client"] .c-rows`, box).innerHTML = contactRow({ kind: "client" });
        return;
      }
      if (e.target.closest("[data-c-cancel]")) { box.innerHTML = contactsView(list); return; }
      const add = e.target.closest("[data-c-add]");
      if (add) { $(`[data-group="${add.dataset.cAdd}"] .c-rows`, box).insertAdjacentHTML("beforeend", contactRow({ kind: add.dataset.cAdd })); return; }
      if (e.target.closest("[data-c-del]")) { e.target.closest(".c-row").remove(); return; }
      if (e.target.closest("[data-c-save]")) {
        try {
          const r = await api(`/api/projects/${pid}/contacts`, { contacts: readContacts(box) });
          list = r.project.contacts; box.innerHTML = contactsView(list); toast("Project card saved"); BOOK = null;
        } catch (x) { toast(x.message); }
      }
    });
  }

  /* ---------- Talk to your assistant ---------- */
  const ask = { open: false, seen: 0, data: null, timer: null, first: true };
  const md = (t) => esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>");
  function drawAsk(d) {
    ask.data = d;
    const log = $("#ask-log");
    const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
    log.innerHTML = d.messages.map((m) => `<div class="ask-msg from-${m.from}">
        <div class="ask-bubble">${md(m.text)}</div>
        ${m.choices ? `<div class="choices">${m.choices.map((c) => `<button type="button" class="choice" data-choice="${esc(c.value)}" ${m.answered ? "disabled" : ""}>${esc(c.label)}</button>`).join("")}</div>` : ""}
      </div>`).join("");
    if (atBottom || ask.first) log.scrollTop = log.scrollHeight;
    ask.first = false;
    const j = d.job;
    $("#ask-job").hidden = !j;
    if (j) { $("#ask-bar").style.width = Math.min(100, Math.round((j.files / Math.max(1, j.total)) * 100)) + "%"; $("#ask-job-text").textContent = `Copying ${j.current || ""} · ${j.files} of ${j.total} files`; }
    const bots = d.messages.filter((m) => m.from === "bot").length;
    if (ask.open) ask.seen = bots;
    const unread = bots - ask.seen;
    $("#ask-badge").hidden = ask.open || unread <= 0;
    $("#ask-badge").textContent = unread > 9 ? "9+" : unread;
    schedulePoll();
  }
  async function pollAsk() {
    if (!token || $("#view-office").hidden) { schedulePoll(); return; }
    try { drawAsk(await api("/api/assistant")); } catch (x) { schedulePoll(); }
  }
  function schedulePoll() {
    clearTimeout(ask.timer);
    ask.timer = setTimeout(pollAsk, ask.data && ask.data.job ? 2000 : ask.open ? 6000 : 20000);
  }
  function openAsk(on) {
    ask.open = on;
    $("#ask").hidden = !on;
    $("#ask-fab").hidden = on;
    document.body.classList.toggle("ask-on", on);
    if (on) { if (ask.data) { ask.first = true; drawAsk(ask.data); } setTimeout(() => $("#ask-in").focus({ preventScroll: true }), 50); }
  }
  async function startAsk() {   // called when Office opens: first time, the assistant opens itself with its question
    try {
      const d = await api("/api/assistant");
      const last = d.messages[d.messages.length - 1];
      ask.seen = ask.seen || d.messages.filter((m) => m.from === "bot").length - (last && last.choices && !last.answered ? 1 : 0);
      drawAsk(d);
      if (last && last.choices && !last.answered && d.owner) openAsk(true);
    } catch (x) { /* assistant is optional */ }
  }
  $("#ask-fab").addEventListener("click", () => openAsk(true));
  officeBody.addEventListener("click", (e) => {
    const a = e.target.closest("[data-ask]"), o = e.target.closest("[data-ask-open]");
    if (a) { openAsk(true); sendAsk({ text: a.dataset.ask }); }
    if (o) openAsk(true);
  });
  $("#ask-close").addEventListener("click", () => openAsk(false));
  async function sendAsk(payload) {
    $("#ask-form .btn").disabled = true;
    try { drawAsk(await api("/api/assistant", payload)); $("#ask-log").scrollTop = $("#ask-log").scrollHeight; if (!office.project && ["home", "projects"].includes(office.tab)) renderOffice(); }
    catch (x) { toast(x.message); }
    $("#ask-form .btn").disabled = false;
  }
  $("#ask-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const t = $("#ask-in").value.trim();
    if (!t) return;
    $("#ask-in").value = "";
    sendAsk({ text: t });
  });
  $("#ask-log").addEventListener("click", (e) => {
    const c = e.target.closest("[data-choice]");
    if (!c || c.disabled) return;
    $$(".choice", c.parentElement).forEach((b) => (b.disabled = true));
    sendAsk({ choice: c.dataset.choice });
  });

  /* ---------- Office tab: the studio's Vendors & contractors ---------- */
  async function renderPeople() {
    const b = await loadBook(true);
    const section = (k) => {
      const ps = b.people.filter((p) => p.kind === k);
      return `<section class="panel">
        <h3>${KIND_LABEL[k]} <span class="h-note">${ps.length}</span></h3>
        ${ps.length ? `<div class="scroll-x"><table class="team"><thead><tr><th>${k === "vendor" ? "Supplies" : "Trade"}</th><th>Company</th><th>Contact person</th><th>Phone</th><th>Email</th><th>City</th><th>Projects</th><th></th></tr></thead><tbody>
          ${ps.map((p) => `<tr><td>${esc(p.trade || "—")}</td><td><b>${esc(p.company || "—")}</b></td><td>${esc(p.name)}</td><td class="nowrap">${p.phone ? `<a href="tel:${esc(p.phone)}">${esc(p.phone)}</a>` : ""}</td><td>${p.email ? `<a href="mailto:${esc(p.email)}">${esc(p.email)}</a>` : ""}</td><td>${esc(p.city)}</td><td>${esc(p.projects.join(", "))}</td>
            <td class="nowrap"><button class="btn small ghost" data-p-edit="${esc(p.id)}">Edit</button> <button class="x" data-p-del="${esc(p.id)}" aria-label="Remove">×</button></td></tr>`).join("")}
        </tbody></table></div>` : `<p class="empty">No ${k}s yet.</p>`}
        <div class="btn-row"><button class="btn ghost" data-p-new="${k}">+ Add ${k}</button></div>
      </section>`;
    };
    officeBody.innerHTML = `
      <div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">Vendors &amp; contractors</h2>
        <p class="o-sub">Your studio's list. Add someone once, then pick them on any project.</p></div></div>
      <div id="p-form"></div>
      ${section("contractor")}${section("vendor")}`;
  }
  function personForm(p) {
    const trades = p.kind === "vendor" ? BOOK.vendor_trades : BOOK.contractor_trades;
    return `<form class="panel form" id="person-form" data-id="${esc(p.id || "")}" data-kind="${p.kind}"><h3>${p.id ? "Edit" : "Add a"} ${p.kind}</h3>
      <div class="grid2">
        <label class="f"><span>${p.kind === "vendor" ? "What they supply" : "Trade"}</span><select id="pf-trade">${opt(trades, p.trade, "Choose…")}</select></label>
        <label class="f"><span>Company</span><input id="pf-company" value="${esc(p.company || "")}"></label>
        <label class="f"><span>Contact person</span><input id="pf-name" value="${esc(p.name || "")}"></label>
        <label class="f"><span>Phone</span><input id="pf-phone" type="tel" inputmode="tel" value="${esc(p.phone || "")}"></label>
        <label class="f"><span>Email</span><input id="pf-email" type="email" inputmode="email" value="${esc(p.email || "")}"></label>
        <label class="f"><span>City</span><input id="pf-city" value="${esc(p.city || "")}"></label>
      </div>
      <label class="f full"><span>Notes <i>(rates, quality, payment terms…)</i></span><input id="pf-notes" value="${esc(p.notes || "")}"></label>
      <div class="form-row"><p class="form-error" id="pf-error"></p><span class="btn-row tight"><button class="btn ghost" type="button" data-p-cancel>Cancel</button><button class="btn" type="submit">Save</button></span></div>
    </form>`;
  }
  officeBody.addEventListener("click", async (e) => {
    const n = e.target.closest("[data-p-new]"), ed = e.target.closest("[data-p-edit]"), del = e.target.closest("[data-p-del]");
    if (n || ed) {
      const p = ed ? BOOK.people.find((x) => x.id === ed.dataset.pEdit) : { kind: n.dataset.pNew };
      $("#p-form").innerHTML = personForm(p); $("#p-form").scrollIntoView({ behavior: "smooth", block: "start" }); $("#pf-company").focus();
      return;
    }
    if (e.target.closest("[data-p-cancel]")) { $("#p-form").innerHTML = ""; return; }
    if (del) {
      if (!confirmInline(del)) return;
      try { await api("/api/book/delete", { id: del.dataset.pDel }); toast("Removed from your list"); renderPeople(); } catch (x) { toast(x.message); }
    }
  });
  officeBody.addEventListener("submit", async (e) => {
    if (e.target.id !== "person-form") return;
    e.preventDefault();
    const f = e.target;
    const person = { id: f.dataset.id || undefined, kind: f.dataset.kind, trade: $("#pf-trade").value, company: $("#pf-company").value, name: $("#pf-name").value, phone: $("#pf-phone").value, email: $("#pf-email").value, city: $("#pf-city").value, notes: $("#pf-notes").value };
    try { await api("/api/book", { person }); toast("Saved"); renderPeople(); } catch (x) { $("#pf-error").textContent = x.message; }
  });
  function confirmInline(btn) {   // first tap turns the × into "Sure?", second tap does it (no pop-up boxes)
    if (btn.dataset.sure) return true;
    btn.dataset.sure = "1"; btn.textContent = "Sure?"; btn.classList.add("sure");
    setTimeout(() => { delete btn.dataset.sure; btn.textContent = "×"; btn.classList.remove("sure"); }, 3000);
    return false;
  }

  async function renderSchedule() {
    const h = await api("/api/home");
    officeBody.innerHTML = `
      <div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">Schedule</h2></div></div>
      <section class="panel">
        ${h.events.length ? `<ul class="list">${h.events.map((e) => `<li><button class="row-link" data-open-project="${esc(e.project_id)}"><span class="when">${esc(fmtDate(e.date))}${e.time ? " · " + esc(e.time) : ""}</span><span class="what">${esc(e.title)} <i class="tag">${esc(e.kind || "meeting")}</i></span><span class="where">${esc(e.project)}</span></button></li>`).join("")}</ul>`
        : `<p class="empty">No meetings or reminders. Open a project to add one; it appears here and on Today.</p>`}
      </section>`;
  }

  async function renderBots() {
    const b = await api("/api/bots");
    const last = b.folder_last;
    officeBody.innerHTML = `
      <div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">Your bots</h2><p class="o-sub">Each bot's job and limits are fixed before it runs. Bots work for you; they never act outside their role.</p></div></div>
      <div class="bots">${b.bots.map((bot) => `
        <article class="bot ${esc(bot.status)}">
          <header><h3>${esc(bot.name)}</h3><span class="pill ${esc(bot.status)}">${bot.status === "active" ? "Working" : bot.status === "planned" ? "Coming next" : "Add-on"}</span></header>
          <p class="bot-role">${esc(bot.role)}</p>
          <p class="bot-meta">${esc(bot.side)} · ${esc(bot.engine)} · ${esc(bot.cost)}</p>
          <h4>Does</h4><ul>${bot.does.map((d) => `<li>${esc(d)}</li>`).join("")}</ul>
          <h4>Allowed to touch</h4><p>${esc(bot.allowed)}</p>
          <h4>Never</h4><ul class="never">${bot.never.map((d) => `<li>${esc(d)}</li>`).join("")}</ul>
          <p class="bot-ask">${esc(bot.asks_you)}</p>
          ${bot.id === "folder" ? `<p class="bot-meta">${b.folder_runs} sorting run${b.folder_runs === 1 ? "" : "s"} so far${last ? ` · last: ${esc(last.project)}, ${esc(fmtDate(last.time))} ${esc(fmtTime(last.time))}` : ""}</p>` : ""}
        </article>`).join("")}</div>`;
  }

  function cloudPanel(c, owner) {
    if (!c.connected) {
      return owner ? `<form class="panel form" id="cloud-form"><h3>Design Lab Cloud <span class="h-note">connect once with the code and key from your sign-up</span></h3>
        <p class="hint-text">Connecting registers your team with Design Lab, gives each user their bot, and turns on the prepaid wallet for paid bot work. Until then, everything here runs free on this computer.</p>
        <div class="grid2">
          <label class="f"><span>Cloud address</span><input id="cl-url" value="http://localhost:8800" spellcheck="false"></label>
          <label class="f"><span>Firm code</span><input id="cl-code" placeholder="DL-0001" autocapitalize="characters" spellcheck="false"></label>
          <label class="f"><span>Activation key</span><input id="cl-key" placeholder="XXXX-XXXX-XXXX-XXXX" autocapitalize="characters" spellcheck="false"></label>
        </div>
        <div class="form-row"><p class="form-error" id="cl-error"></p><button class="btn" type="submit">Connect</button></div></form>`
        : `<section class="panel"><h3>Design Lab Cloud</h3><p class="empty">Not connected yet. The studio owner connects it here.</p></section>`;
    }
    if (!c.online) return `<section class="panel"><h3>Design Lab Cloud <span class="h-note">${esc(c.code)}</span></h3><p class="empty">${esc(c.error)}</p></section>`;
    const f = c.firm;
    return `<section class="panel"><h3>Wallet <span class="h-note">connected to Design Lab</span></h3>
      <div class="kpis">
        <div class="kpi ${f.status === "paused" ? "warn" : ""}"><b>₹${Number(f.balance).toLocaleString("en-IN")}</b><span>balance · ${esc(f.status === "paused" ? "paid features paused — please top up" : "all features working")}</span></div>
        <div class="kpi"><b>₹${Number(f.month_usage).toLocaleString("en-IN")}</b><span>used this month</span></div>
        <div class="kpi"><b>₹${Number(f.monthly.base).toLocaleString("en-IN")}</b><span>monthly fee + GST</span></div>
        <div class="kpi"><b>${esc(f.code)}</b><span>your firm code</span></div>
      </div>
      ${f.alerts.length ? `<ul class="list">${f.alerts.map((a) => `<li><span class="what"><b>${esc(a.text)}</b></span></li>`).join("")}</ul>` : ""}
      ${owner ? `<form class="inline-form" id="topup-form" style="grid-template-columns:1fr auto auto">
        <input id="tu-amt" type="number" min="${c.pricing.min_topup || 1000}" step="100" value="${c.pricing.min_topup || 1000}" aria-label="Top-up amount">
        <button class="btn" type="submit">Top up (test payment)</button>
        <button class="btn ghost" type="button" data-act="cloud-off">Disconnect</button></form>
        <p class="hint-text">Prototype: top-ups are test payments, no money moves. The wallet is prepaid: minimum ₹${c.pricing.min_topup || 1000}. What you don't use carries forward. You get a warning when it runs low, and paid bots stop — never overspend — when it is empty.</p>` : ""}
      <h3 style="margin-top:18px">Where the wallet went <span class="h-note">every paid bot task, newest first</span></h3>
      ${(c.spend || []).length ? `<div class="scroll-x"><table class="team"><thead><tr><th>When</th><th>What</th><th>Project</th><th>By</th><th>Cost</th></tr></thead><tbody>${c.spend.map((u) => `<tr><td>${esc(fmtDate(u.time))}</td><td>${esc(u.label || "")}</td><td>${esc(u.project || "")}</td><td>${esc(u.user || "")}</td><td>₹${Number(u.total || 0).toLocaleString("en-IN")}</td></tr>`).join("")}</tbody></table></div>` : `<p class="empty">Nothing spent yet. Free features never use the wallet; paid AI work is only switched on after you approve it.</p>`}
    </section>`;
  }

  async function cyAccessClick(e) {
    const b = e.target.closest("[data-cyacc]"); if (!b) return;
    const t = await api("/api/users");
    const u = (await api("/api/team/usage")).members.find((m) => m.id === b.dataset.cyacc) || { cy: {} };
    cyAccessForm($("#cyacc-box") || officeBody, b.dataset.cyacc, b.dataset.name, u.cy, t.cy_sections, () => renderTeam());
  }
  function cyAccessForm(box, id, name, cur, sections, after) {
    box.innerHTML = `<section class="panel attention cyacc"><h3>The Courtyard for ${esc(name)}</h3>
      <p class="hint-text">Tick what ${esc(name)} may use. You can change this any time. Perspective reading and commenting are separate.</p>
      <div class="l-folders">${sections.map(([k, l]) => `<label class="chk"><input type="checkbox" value="${esc(k)}" ${cur && cur[k] ? "checked" : ""}> ${esc(l)}</label>`).join("")}</div>
      <div class="btn-row"><button class="btn" data-cyok>Save</button><button class="btn ghost" data-cynone>No Courtyard for now</button></div></section>`;
    box.scrollIntoView({ behavior: "smooth", block: "start" });
    const save = async (all) => {
      const sec = {}; $$(".cyacc input", box).forEach((i) => { sec[i.value] = all === false ? false : i.checked; });
      try { await api("/api/users/cy-access", { id, sections: sec }); toast("Saved"); box.innerHTML = ""; after && after(); } catch (x) { toast(x.message); }
    };
    $("[data-cyok]", box).onclick = () => save();
    $("[data-cynone]", box).onclick = () => save(false);
  }
  DLX_cyAccessForm = cyAccessForm;
  const DESIGNATIONS = ["Principal", "Partner", "Associate", "Senior designer", "Designer", "Junior designer", "Site supervisor", "Draughtsman", "Office admin", "Accounts", "Other"];
  async function renderTeam() {
    const t = await api("/api/users");
    const c = await api("/api/cloud").catch(() => ({ connected: false }));
    const pending = t.users.filter((u) => u.pending);
    const active = t.users.filter((u) => !u.pending);
    const extra = active.filter((u) => u.seat > 1).length;
    officeBody.innerHTML = `
      <div class="o-head"><div><p class="eyebrow">Office</p><h2 class="o-title">Team</h2>
        <p class="o-sub">Your subscription includes 1 user. Each extra user is ₹199 a month — you see the new monthly total before anyone is invited. Users sign in with their user ID, phone or email.</p></div></div>
      <div id="cyacc-box"></div>
      ${pending.length && t.owner ? `<section class="panel attention"><h3>Waiting for your approval <span class="h-note">${pending.length} new user${pending.length === 1 ? "" : "s"}</span></h3>
        <ul class="list">${pending.map((u) => `<li><span class="what"><b>${esc(u.name)}</b> — ${esc(u.designation || "No designation")}${u.profession ? ", " + esc(u.profession) : ""} · <code>${esc(u.id)}</code></span>
          <button class="btn small" data-act="approve-user" data-id="${esc(u.id)}">Approve</button><button class="btn small ghost" data-act="decline-user" data-id="${esc(u.id)}">Decline</button></li>`).join("")}</ul></section>` : ""}
      <section class="panel">
        <div class="scroll-x"><table class="team"><thead><tr><th>#</th><th>Name</th><th>Designation</th><th>User ID</th><th>Phone</th><th>Email</th><th>Plan</th><th>Registered</th>${t.owner ? "<th>Courtyard</th>" : ""}<th></th></tr></thead>
        <tbody>${active.map((u) => `<tr><td>${u.seat}</td><td>${esc(u.name)}${u.role === "owner" ? ` <span class="tag">owner</span>` : ""}</td><td>${esc(u.designation || "")}</td><td><code>${esc(u.id)}</code></td><td>${esc(u.phone || "")}</td><td>${esc(u.email || "")}</td><td>${u.seat <= 1 ? "Included" : "₹199 / month"}</td><td>${u.registered ? `<span class="pill active">Yes</span>` : `<span class="pill planned">Not yet</span>`}</td>${t.owner ? `<td>${u.role === "owner" ? "All" : `<button class="btn small ghost" data-cyacc="${esc(u.id)}" data-name="${esc(u.name)}">Choose</button>`}</td>` : ""}<td class="nowrap">${t.owner && u.id !== t.me ? `<button class="btn small ghost" data-act="reset-pw" data-id="${esc(u.id)}" data-name="${esc(u.name)}">Reset password</button> <button class="x" data-act="del-user" data-id="${esc(u.id)}" aria-label="Remove ${esc(u.name)}">×</button>` : ""}</td></tr>`).join("")}</tbody></table></div>
        <form class="inline-form reset-row" id="reset-form" hidden style="grid-template-columns:1fr 1fr auto auto">
          <span class="hint-text" id="reset-who"></span>
          <span class="pw light"><input id="reset-pw" type="password" placeholder="New password" autocomplete="new-password"><button type="button" class="eye" data-eye-in="reset-pw">Show</button></span>
          <button class="btn" type="submit">Set password</button><button class="btn ghost" type="button" data-act="reset-cancel">Cancel</button>
        </form>
        <p class="hint-text">${extra ? `${extra} extra user${extra === 1 ? "" : "s"}: ₹${extra * 199} a month on top of the subscription.` : "Only the included user so far — no extra charge."} To give someone access, add them below; they sign in with their user ID, phone or email.</p>
      </section>
      ${t.owner ? `<form class="panel form" id="u-form"><h3>Invite someone to your team <span class="h-note">they make their own user ID and password</span></h3>
        <div class="grid2">
          <label class="f"><span>Name</span><input id="u-name" placeholder="Priya"></label>
          <label class="f"><span>Job title</span><select id="u-desig">${t.roles.map((d) => `<option>${esc(d)}</option>`).join("")}<option value="__new">+ Add a new job title…</option></select></label>
          <label class="f" id="u-desig-new-wrap" hidden><span>New job title</span><input id="u-desig-new" placeholder="e.g. Purchase manager"></label>
          <label class="f"><span>Access</span><select id="u-role"><option value="designer">Office and ${me.kind === "vendor" ? "Showroom" : "Site"}</option><option value="site">${me.kind === "vendor" ? "Showroom" : "Site"} only</option></select></label>
        </div>
        <p class="hint-text">You get an invitation code to send them. On the sign-in page they tap <b>Join a team</b>, type the code and make their own password. The code works for ${7} days. When they join you'll be asked whether to let them into The Courtyard.</p>
        <div class="form-row"><p class="form-error" id="u-error"></p><button class="btn" type="submit">Make invitation</button></div>
        <div id="inv-out"></div>
        ${(t.invites || []).length ? `<h3 style="margin-top:14px">Waiting to join</h3><ul class="list">${t.invites.map((i) => `<li><span class="what"><b>${esc(i.name)}</b> · ${esc(i.designation || "")} · code <code>${esc(i.code)}</code><span class="where">until ${esc(fmtDate(i.expires))}</span></span><button type="button" class="btn small ghost" data-inv-wa="${esc(i.code)}" data-inv-name="${esc(i.name)}">WhatsApp</button><button type="button" class="btn small ghost" data-inv-cancel="${esc(i.code)}">Cancel</button></li>`).join("")}</ul>` : ""}
      </form>
      <section class="panel" id="usage-panel"><h3>Who used what this month <span class="h-note">seat fee + paid bot work for each person</span></h3><p class="empty">Loading…</p></section>` : ""}
      <form class="panel form" id="pw-form"><h3>Change my password</h3>
        <div class="grid2">
          <label class="f"><span>Current password</span><input id="pw-old" type="password" autocomplete="current-password"></label>
          <label class="f"><span>New password (8+ letters and numbers)</span><input id="pw-new" type="password" autocomplete="new-password"></label>
          <label class="f"><span>Confirm new password</span><input id="pw-new2" type="password" autocomplete="new-password"></label>
        </div>
        <div class="form-row"><p class="form-error" id="pw-error"></p><button class="btn" type="submit">Change password</button></div></form>
      ${cloudPanel(c, t.owner)}
      ${t.owner ? `<section class="panel"><h3>Security <span class="h-note">recent sign-ins and account changes on this computer</span></h3><div id="sec-log"><p class="empty">Loading…</p></div></section>` : ""}`;
    $("#pw-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const r = await api("/api/me/password", { old: $("#pw-old").value, new: $("#pw-new").value, new2: $("#pw-new2").value });
        token = r.token; store.set(token); $("#pw-form").reset(); toast("Password changed. Other devices have been signed out.");
      } catch (x) { $("#pw-error").textContent = x.message; }
    });
    const rf = $("#reset-form");
    rf.addEventListener("submit", async (e) => {
      e.preventDefault();
      try { await api("/api/users/reset", { id: rf.dataset.id, password: $("#reset-pw").value }); rf.hidden = true; $("#reset-pw").value = ""; toast("Password reset. Tell them their new password."); }
      catch (x) { toast(x.message); }
    });
    if (t.owner && DLX.bookSetup) DLX.bookSetup(officeBody);
    if (t.owner) api("/api/security").then((s) => {
      $("#sec-log").innerHTML = s.log.length ? `<ul class="list tight">${s.log.slice(0, 25).map((l) => `<li><span class="when">${esc(fmtDate(l.time))} ${esc(fmtTime(l.time))}</span><span class="what">${esc(l.event)}${l.who ? " — " + esc(l.who) : ""}</span><span class="where">${esc(l.ip || "")}</span></li>`).join("")}</ul>` : `<p class="empty">No sign-ins recorded yet.</p>`;
    }).catch(() => {});
    const uf = $("#u-form");
    if (uf) {
      $("#u-desig").addEventListener("change", () => { $("#u-desig-new-wrap").hidden = $("#u-desig").value !== "__new"; });
      const shareInv = (code, name) => {
        const msg = `Hello ${name}, you're invited to join ${me.firm || "our studio"} on Design Lab.\nOpen Design Lab, tap "Join a team" and type this code: ${code}\nThen choose your own user ID and password.`;
        window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank", "noopener");
      };
      uf.addEventListener("click", async (e) => {
        const w = e.target.closest("[data-inv-wa]"); if (w) return shareInv(w.dataset.invWa, w.dataset.invName);
        const c = e.target.closest("[data-inv-cancel]");
        if (c) { try { await api("/api/users/invite-cancel", { code: c.dataset.invCancel }); toast("Invitation cancelled"); renderTeam(); } catch (x) { toast(x.message); } }
      });
      uf.addEventListener("submit", async (e) => {
        e.preventDefault();
        const desig = $("#u-desig").value === "__new" ? $("#u-desig-new").value : $("#u-desig").value;
        const payload = { name: $("#u-name").value, designation: desig, role: $("#u-role").value };
        try {
          let r = await api("/api/users/invite", payload);
          if (r.confirm) {
            const ok = await new Promise((res) => {
              const box = document.createElement("div"); box.className = "panel attention seat-confirm";
              box.innerHTML = `<h3>New monthly total</h3><p>${esc(r.text)}</p><p class="kpi-line"><b>₹${r.monthly.toLocaleString("en-IN")} / month</b> for extra users, plus GST, from the next bill.</p>
                <div class="btn-row"><button type="button" class="btn" data-y>Yes, invite and charge ₹${r.fee}/month</button><button type="button" class="btn ghost" data-n>Cancel</button></div>`;
              $("#inv-out").replaceChildren(box); box.scrollIntoView({ behavior: "smooth", block: "center" });
              box.onclick = (ev) => { if (ev.target.closest("[data-y]")) { box.remove(); res(true); } if (ev.target.closest("[data-n]")) { box.remove(); res(false); } };
            });
            if (!ok) return;
            r = await api("/api/users/invite", Object.assign(payload, { confirm: true }));
          }
          const i = r.invite;
          $("#inv-out").innerHTML = `<div class="panel attention"><h3>Invitation for ${esc(i.name)}</h3><p class="inv-code">${esc(i.code)}</p>
            <p class="hint-text">Send this code to ${esc(i.name)}. It works for 7 days, once.</p>
            <div class="btn-row"><button type="button" class="btn" data-inv-wa="${esc(i.code)}" data-inv-name="${esc(i.name)}">Send on WhatsApp</button><button type="button" class="btn ghost" data-inv-copy="${esc(i.code)}">Copy code</button></div></div>`;
          $("[data-inv-copy]", uf).onclick = async (ev) => { try { await navigator.clipboard.writeText(ev.target.dataset.invCopy); toast("Code copied"); } catch (x) { window.prompt("Copy this code:", ev.target.dataset.invCopy); } };
          $("#u-name").value = "";
        } catch (x) { $("#u-error").textContent = x.message; }
      });
      api("/api/team/usage").then((u) => {
        const tot = u.members.reduce((a, m) => a + m.total, 0);
        $("#usage-panel").innerHTML = `<h3>Who used what this month <span class="h-note">seat fee + paid bot work for each person</span></h3>
          <div class="scroll-x"><table class="team"><thead><tr><th>Name</th><th>Seat</th><th>Paid bot work</th><th>Total</th><th>Last signed in</th></tr></thead><tbody>
          ${u.members.map((m) => `<tr><td>${esc(m.name)}</td><td>${m.seat ? "₹" + m.seat : "Included"}</td><td>₹${m.ai.toLocaleString("en-IN")}</td><td><b>₹${m.total.toLocaleString("en-IN")}</b></td><td>${m.last_in ? esc(fmtDate(m.last_in)) : "—"}</td></tr>`).join("")}
          </tbody></table></div><p class="hint-text">Total this month: <b>₹${tot.toLocaleString("en-IN")}</b> plus your subscription and GST. Seats and bot work are counted separately; bot work comes from the prepaid wallet.</p>`;
      }).catch(() => { $("#usage-panel").innerHTML = ""; });
    }
    const cf = $("#cloud-form");
    if (cf) cf.addEventListener("submit", async (e) => {
      e.preventDefault();
      try { await api("/api/cloud/connect", { url: $("#cl-url").value, code: $("#cl-code").value, key: $("#cl-key").value }); toast("Connected to Design Lab Cloud"); renderTeam(); }
      catch (x) { $("#cl-error").textContent = x.message; }
    });
    const tf = $("#topup-form");
    if (tf) tf.addEventListener("submit", async (e) => {
      e.preventDefault();
      try { await api("/api/cloud/topup", { amount: Number($("#tu-amt").value) }); toast("Wallet topped up (test)"); renderTeam(); }
      catch (x) { toast(x.message); }
    });
  }

  officeBody.addEventListener("click", (e) => { if (office.tab === "team" && !office.project) cyAccessClick(e); });
  officeBody.addEventListener("click", (e) => {
    const eye = e.target.closest("[data-eye-in]");
    if (!eye) return;
    const i = $("#" + eye.dataset.eyeIn);
    i.type = i.type === "password" ? "text" : "password";
    eye.textContent = i.type === "password" ? "Show" : "Hide";
  });
  officeBody.addEventListener("click", async (e) => {
    const goTab = e.target.closest("[data-otab-go]");
    if (goTab) { office.tab = goTab.dataset.otabGo; office.project = null; return renderOffice(); }
    const op = e.target.closest("[data-open-project]");
    if (op) { office.project = op.dataset.openProject; markTab(); renderOffice(); views.office.scrollTop = 0; return; }
    const a = e.target.closest("[data-act]");
    if (!a) return;
    const act = a.dataset.act, pid = office.project;
    try {
      if (act === "new-project") {
        const slot = $("#new-project-slot");
        if (slot.innerHTML) { slot.innerHTML = ""; return; }
        slot.innerHTML = newProjectForm();
        $("#np-name").focus();
        bindNewProject();
      } else if (act === "sort-all") {
        const r = await api("/api/sort-all", {});
        toast(r.moved ? `Folder Bot filed ${r.moved} file${r.moved === 1 ? "" : "s"}` : "Nothing to sort");
        renderOffice();
      } else if (act === "sort") {
        const r = await api(`/api/projects/${pid}/sort`, {});
        const n = r.report.moved.length, u = r.report.unsure.length;
        toast(n ? `Filed ${n} file${n === 1 ? "" : "s"}${u ? `; ${u} left for you` : ""}` : u ? `${u} file${u === 1 ? "" : "s"} need you — left in Inbox` : "Inbox is empty");
        renderProject(pid);
      } else if (act === "ai-sort") {
        toast("Smart Sorting Bot is looking at the Inbox…");
        const r = await api(`/api/projects/${pid}/ai-sort`, {});
        toast(r.message);
        if (r.moved.length) renderProject(pid);
      } else if (act === "undo-sort") {
        const r = await api(`/api/projects/${pid}/undo-sort`, {});
        toast(`Moved ${r.report.undone} file${r.report.undone === 1 ? "" : "s"} back to Inbox`); renderProject(pid);
      } else if (act === "open-folder") {
        await api(`/api/projects/${pid}/open`, { folder: a.dataset.folder || "" });
        toast("Opened in File Explorer on the studio computer");
      } else if (act === "close-snag") {
        await api(`/api/projects/${pid}/snags/${a.dataset.id}`, { status: "closed" }); toast("Snag closed"); renderProject(pid);
      } else if (act === "browse") {
        await browseFolder(pid, a.dataset.folder);
      } else if (act === "browse-close") {
        const b = $("#browse"); if (b) b.remove();
      } else if (act === "rm") {
        const r = await api(`/api/projects/${pid}/remove`, { kind: a.dataset.kind, id: a.dataset.id, rel: a.dataset.rel });
        toast(`Removed — it's in the bin for 30 days`);
        const folder = ($("#browse") || {}).dataset ? $("#browse") && $("#browse").dataset.folder : null;
        await renderProject(pid); if (folder) browseFolder(pid, folder);
      } else if (act === "restore") {
        const r = await api(`/api/projects/${pid}/restore`, { id: a.dataset.id }); toast("Brought back"); renderProject(pid);
      } else if (act === "bin-empty") {
        if (!a.dataset.sure) { a.dataset.sure = "1"; a.textContent = "Sure? Tap again — this can't be undone"; setTimeout(() => { delete a.dataset.sure; a.textContent = "Empty the bin for good"; }, 4000); return; }
        await api(`/api/projects/${pid}/bin-empty`, {}); toast("Bin emptied"); loadBin(pid);
      } else if (act === "del-event") {
        await api(`/api/projects/${pid}/events/delete`, { id: a.dataset.id }); renderProject(pid);
      } else if (act === "reset-pw") {
        const rf = $("#reset-form"); rf.hidden = false; rf.dataset.id = a.dataset.id;
        $("#reset-who").textContent = "New password for " + a.dataset.name + ":"; $("#reset-pw").focus();
      } else if (act === "reset-cancel") {
        $("#reset-form").hidden = true;
      } else if (act === "approve-user" || act === "decline-user") {
        await api(act === "approve-user" ? "/api/users/approve" : "/api/users/decline", { id: a.dataset.id });
        toast(act === "approve-user" ? "Approved — they can sign in now" : "Request declined"); renderTeam();
      } else if (act === "cloud-off") {
        await api("/api/cloud/disconnect", {}); toast("Disconnected from the Cloud"); renderTeam();
      } else if (act === "del-user") {
        await api("/api/users/remove", { id: a.dataset.id }); toast("User removed"); renderTeam();
      } else if (act === "to-site") {
        site.project = pid; site.room = null; go("site");
      }
    } catch (x) { toast(x.message); }
  });

  /* =========================================================
     SITE
     ========================================================= */
  const site = { project: null, room: null, data: null, mode: null };
  const siteBody = $("#site-body");

  async function renderSite() {
    if (current === "site") savePlace();
    try {
      if (site.project) return await renderSiteProject();
      const { projects } = await api("/api/projects");
      $("#site-crumb").textContent = "Site";
      siteBody.innerHTML = `
        <h2 class="s-title">Which house are you at?</h2>
        ${projects.length ? `<div class="s-projects">${projects.map((p) => `
          <button class="s-proj" data-site-project="${esc(p.id)}"><b>${esc(p.client || p.name)}</b><span>${esc(p.name)}${p.address ? " · " + esc(p.address) : ""}</span></button>`).join("")}</div>`
        : `<p class="empty">No projects yet. Create one in Office first.</p>`}`;
    } catch (x) { siteBody.innerHTML = `<p class="empty">${esc(x.message)}</p>`; }
  }

  async function renderSiteProject() {
    const { project: p } = await api(`/api/projects/${site.project}`);
    site.data = p;
    $("#site-crumb").textContent = p.client || p.name;
    const t = todayIso();
    const todayNotes = p.notes.filter((n) => n.time.startsWith(t)).reverse();
    const roomName = site.room ? (p.rooms.find((r) => r.id === site.room) || {}).name : null;
    siteBody.innerHTML = `
      <div class="s-head">
        <button class="crumb light" data-site-back>&larr; All houses</button>
        <h2 class="s-title">${esc(p.name)}</h2>
        <p class="s-sub">${esc(p.address || "")}</p>
      </div>

      <section class="s-layout">
        ${p.layout ? `
          <div class="plan" id="plan"${p.layout_ratio ? ` style="aspect-ratio:${p.layout_ratio}"` : ""}>
            <img src="${fileUrl(p.id, p.layout)}&v=${p.layout_v || 0}" alt="Layout plan of ${esc(p.name)}" draggable="false">
            ${p.rooms.map((r) => `<button class="pin ${r.id === site.room ? "on" : ""}" style="left:${r.x * 100}%;top:${r.y * 100}%" data-room="${esc(r.id)}"><span>${esc(r.name)}</span></button>`).join("")}
          </div>
          <p class="s-help">${p.rooms.length ? "Tap a dot to choose the room you're in, or tap an empty spot to add a room." : "Tap the plan where a room is, then name it."}</p>`
        : `<div class="plan-empty">
            <p>Add the layout plan once. Then tap a room to pin everything you record to it.</p>
            <label class="btn orange">Add layout plan (photo or image)<input type="file" accept="image/*" id="layout-file" hidden></label>
          </div>`}
      </section>

      <div class="room-sheet" id="room-sheet" hidden>
        <input id="room-name" placeholder="Room name, e.g. Kids' room" aria-label="Room name">
        <button class="btn orange" data-room-save>Add room</button>
        <button class="btn ghost light" data-room-cancel>Cancel</button>
      </div>

      <section class="s-actions">
        <p class="s-room">${roomName ? `In <b>${esc(roomName)}</b>` : `<b>General</b> · no room chosen`}</p>
        <div class="s-btns">
          <button class="s-btn" data-mode="note">Note</button>
          <button class="s-btn" data-mode="change">Change</button>
          <label class="s-btn">Photo<input type="file" accept="image/*" capture="environment" id="photo-file" hidden></label>
          <button class="s-btn" data-mode="snag">Snag</button>
          <button class="s-btn s-meet" data-meeting>Meeting</button>
        </div>
        <form class="s-form" id="s-form" hidden>
          <textarea id="s-text" rows="3" placeholder=""></textarea>
          <div class="snag-extra" id="snag-extra" hidden>
            <select id="s-owner" aria-label="Who fixes it"><option value="">Who fixes it?</option>${p.contacts.filter((c) => c.role !== "Client").map((c) => `<option>${esc(c.name || c.role)}${c.role && c.name ? " (" + esc(c.role) + ")" : ""}</option>`).join("")}</select>
            <input id="s-due" type="date" aria-label="Fix by">
          </div>
          <div class="s-form-row"><span class="s-tip">Tip: tap the microphone on your phone keyboard to speak instead of typing.</span><button class="btn orange" type="submit">Save</button></div>
        </form>
      </section>

      <section class="s-today">
        <div class="s-today-head"><h3>Today on site</h3><button class="btn orange" data-mom>Write MOM</button></div>
        ${todayNotes.length ? `<ul class="s-list">${todayNotes.map((n) => `<li><i class="tag">${esc(n.kind)}</i><span>${n.kind === "photo" ? `<a href="${fileUrl(p.id, n.file)}" target="_blank" rel="noopener">Photo filed</a>` : esc(n.text)}</span><em>${esc(n.room || "General")} · ${esc(fmtTime(n.time))}</em></li>`).join("")}</ul>` : `<p class="empty">Nothing recorded today yet.</p>`}
      </section>

      <section class="s-meeting" id="s-meeting" hidden></section>
      <section class="s-mom" id="s-mom" hidden></section>`;
    bindSite(p);
    if (DLX.afterSite) DLX.afterSite(p, site.room ? ((p.rooms.find((r) => r.id === site.room) || {}).name || "") : "");
    const mb = siteBody.querySelector("[data-meeting]");
    if (mb && DLX.meeting) mb.addEventListener("click", () => DLX.meeting(p, site.room, () => siteBody.querySelector("[data-mom]").click()));
  }

  function bindSite(p) {
    const lf = $("#layout-file");
    if (lf) lf.addEventListener("change", async () => {
      const f = lf.files[0]; if (!f) return;
      try {
        toast("Uploading plan…");
        const data = await photoData(f, 2400);
        const ratio = await new Promise((ok) => { const im = new Image(); im.onload = () => ok(im.width / im.height); im.onerror = () => ok(0); im.src = data; });
        await api(`/api/projects/${p.id}/layout`, { name: f.name, data, ratio });
        renderSiteProject();
      }
      catch (x) { toast(x.message); }
    });
    const plan = $("#plan");
    if (plan) plan.addEventListener("click", (e) => {
      const pin = e.target.closest(".pin");
      if (pin) { site.room = site.room === pin.dataset.room ? null : pin.dataset.room; renderSiteProject(); return; }
      const r = plan.getBoundingClientRect();
      site.pending = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
      $("#room-sheet").hidden = false;
      $("#room-name").value = "";
      $("#room-name").focus();
    });
    $("#room-sheet").addEventListener("click", async (e) => {
      if (e.target.closest("[data-room-cancel]")) { $("#room-sheet").hidden = true; return; }
      if (e.target.closest("[data-room-save]")) {
        const name = $("#room-name").value.trim(); if (!name || !site.pending) return;
        const id = Math.random().toString(16).slice(2, 8);
        const rooms = [...p.rooms, { id, name, x: site.pending.x, y: site.pending.y }];
        try { await api(`/api/projects/${p.id}/rooms`, { rooms }); site.room = id; renderSiteProject(); } catch (x) { toast(x.message); }
      }
    });
    const roomName = () => (site.room ? (p.rooms.find((r) => r.id === site.room) || {}).name : "") || "";
    $$(".s-btn[data-mode]").forEach((b) => b.addEventListener("click", () => {
      site.mode = b.dataset.mode;
      $$(".s-btn").forEach((x) => x.classList.toggle("on", x === b));
      $("#s-form").hidden = false;
      $("#snag-extra").hidden = site.mode !== "snag";
      $("#s-text").placeholder = { note: "What was discussed or decided?", change: "What is changing? e.g. Move study table to the window wall", snag: "What's wrong? e.g. Wardrobe shutter misaligned" }[site.mode];
      $("#s-text").focus();
    }));
    $("#s-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const text = $("#s-text").value.trim(); if (!text) return;
      try {
        if (site.mode === "snag") await api(`/api/projects/${p.id}/snags`, { room: roomName(), text, owner: $("#s-owner").value, due: $("#s-due").value });
        else await api(`/api/projects/${p.id}/notes`, { room: roomName(), text, kind: site.mode === "change" ? "change" : "note" });
        toast(site.mode === "snag" ? "Snag added to 05 Snags" : "Saved to the project"); site.mode = null; renderSiteProject();
      } catch (x) { toast(x.message); }
    });
    const pf = $("#photo-file");
    pf.addEventListener("change", async () => {
      const f = pf.files[0]; if (!f) return;
      try { toast("Filing photo…"); await api(`/api/projects/${p.id}/photos`, { room: roomName(), name: f.name, data: await photoData(f) }); toast("Photo filed in 03 Site Photos"); renderSiteProject(); }
      catch (x) { toast(x.message); }
    });
    siteBody.querySelector("[data-mom]").addEventListener("click", () => openMom(p));
  }

  async function openMom(p) {
    const box = $("#s-mom");
    try {
      const r = await api(`/api/projects/${p.id}/mom`, { date: todayIso() });
      box.hidden = false;
      box.innerHTML = `
        <h3>Minutes of meeting <span class="h-note">check and edit, then save or send</span></h3>
        <textarea id="mom-text" rows="16">${esc(r.text)}</textarea>
        <div class="mom-send">
          <select id="mom-to" aria-label="Send to">${r.to.length ? r.to.map((c, i) => `<option value="${i}">${esc(c.name || c.role)} (${esc(c.role)})</option>`).join("") : `<option value="">Add contacts to the project card to send</option>`}</select>
          <button class="btn ghost light" data-mom-ai>Tidy with AI (Hindi → English)</button>
          <button class="btn ghost light" data-mom-save>Save to 04 MOM</button>
          <button class="btn orange" data-mom-wa>Send on WhatsApp</button>
          <button class="btn ghost light" data-mom-mail>Email</button>
        </div>
        <p class="s-tip">Sending opens WhatsApp or your email app with the MOM filled in. You press Send there.</p>`;
      box.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
      const target = () => r.to[Number($("#mom-to").value)] || {};
      let aiQ = "", aiA = "";
      const save = async () => {
        await api(`/api/projects/${p.id}/mom/save`, { date: r.date, text: $("#mom-text").value });
        if (aiA && $("#mom-text").value.trim() !== aiA.trim()) { api("/api/bot-learn", { bot: "mom", q: aiQ, a: $("#mom-text").value }).catch(() => {}); aiA = $("#mom-text").value; }   // your corrections teach the MOM bot
      };
      box.addEventListener("click", async (e) => {
        try {
          const ai = e.target.closest("[data-mom-ai]");
          if (ai) {
            ai.disabled = true; ai.textContent = "Tidying…";
            try { aiQ = $("#mom-text").value; const t = await api(`/api/projects/${p.id}/mom-tidy`, { text: aiQ }); aiA = t.text; $("#mom-text").value = t.text; toast(t.charged ? `Tidied by AI (₹${t.charged})` : "Tidied by AI"); }
            catch (x) { toast(x.message); }
            ai.disabled = false; ai.textContent = "Tidy with AI (Hindi → English)";
          }
          if (e.target.closest("[data-mom-save]")) { await save(); toast("MOM saved in 04 MOM"); }
          if (e.target.closest("[data-mom-wa]")) {
            await save();
            const phone = (target().phone || "").replace(/[^\d]/g, "");
            const num = phone.length === 10 ? "91" + phone : phone;
            window.open(`https://wa.me/${num}?text=${encodeURIComponent($("#mom-text").value)}`, "_blank", "noopener");
          }
          if (e.target.closest("[data-mom-mail]")) {
            await save();
            location.href = `mailto:${encodeURIComponent(target().email || "")}?subject=${encodeURIComponent("MOM — " + p.name + " — " + fmtDate(r.date))}&body=${encodeURIComponent($("#mom-text").value)}`;
          }
        } catch (x) { toast(x.message); }
      });
    } catch (x) { toast(x.message); }
  }

  siteBody.addEventListener("click", (e) => {
    const sp = e.target.closest("[data-site-project]");
    if (sp) { site.project = sp.dataset.siteProject; site.room = null; renderSite(); views.site.scrollTop = 0; return; }
    if (e.target.closest("[data-site-back]")) { site.project = null; site.room = null; renderSite(); }
  });

  /* ---------------- Start ---------------- */
  document.documentElement.style.setProperty("--tiles-at", Math.round(1700 * SPEED) + "ms");
  setTheme("black");
  Object.assign(DLX, { setToken: (t) => { token = t; store.set(t); }, savePlace: () => savePlace(), ownerAlerts: (b, a) => ownerAlerts(b, a), api, esc, toast, $, $$, officeBody, office, renderOffice, openAsk, sendAsk, fmtDate, todayIso, go,
    token: () => token, fkey: () => fkey, me: () => me, isMain: () => MAIN, renderSiteProject, fileUrl: (pid, f) => fileUrl(pid, f) });
  buildBrand();
  fitSwing();
  startPendulum();
  requestAnimationFrame(() => intro.classList.add("ready"));
})();
