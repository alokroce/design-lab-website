/* DESIGN LAB v0.12 — two helpers, kept apart from app.js so they can be changed on their own.
   1. FROM PHONE CONTACTS: wherever you add a person (client, contractor, vendor, architect, team member…)
      a "From phone contacts" button fills the name, phone and email for you.
        - Android phone in Chrome (opened through the secure share link): opens the phone's own contact list.
        - iPhone, or a computer: choose a contact card file (.vcf) — on iPhone: Contacts → the person →
          Share Contact → Save to Files; on a computer: export from Google Contacts / Outlook. Many people at once is fine.
   2. TODAY TALK BOX: on the Office "Today" page, type or tap the microphone and say what you want —
      "open Site", "open Schedule", "open Worli flat", "task call the marble vendor tomorrow at 11 for Worli flat",
      "new project Bandra flat for Mrs Mehta", "find kitchen elevation". Opening is done here at once;
      everything else goes to your assistant, whose answer opens beside you. */
(() => {
  "use strict";
  const X = window.DLX || {};
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const toast = (m) => (X.toast ? X.toast(m) : console.log(m));

  /* ======================= 1. phone contacts ======================= */
  const PICKER = "contacts" in navigator && "ContactsManager" in window && window.isSecureContext;
  const LABEL = "From phone contacts";

  const cleanPhone = (p) => {
    let d = String(p || "").replace(/[^\d+]/g, "");
    if (d.startsWith("0091")) d = "+91" + d.slice(4);
    if (/^91\d{10}$/.test(d)) d = "+" + d;
    if (/^0\d{10}$/.test(d)) d = d.slice(1);
    return d;
  };

  function parseVcf(txt) {
    const out = [];
    const unfolded = String(txt).replace(/\r\n[ \t]/g, "").replace(/\n[ \t]/g, "");
    for (const card of unfolded.split(/BEGIN:VCARD/i).slice(1)) {
      const lines = card.split(/\r?\n/);
      const get = (key) => { const l = lines.find((x) => new RegExp("^(item\\d+\\.)?" + key + "[;:]", "i").test(x)); return l ? l.slice(l.indexOf(":") + 1).trim() : ""; };
      const dec = (v) => v.replace(/\\,/g, ",").replace(/\\;/g, ";").replace(/\\n/gi, " ").trim();
      let name = dec(get("FN"));
      if (!name) { const n = get("N").split(";"); name = dec([n[1], n[0]].filter(Boolean).join(" ")); }
      const company = dec((get("ORG").split(";")[0]) || "");
      const phone = cleanPhone(get("TEL"));
      const email = dec(get("EMAIL"));
      if (name || phone || email) out.push({ name, phone, email, company });
    }
    return out;
  }

  function pickFile(multiple) {
    return new Promise((ok) => {
      const i = document.createElement("input");
      i.type = "file"; i.accept = ".vcf,.vcard,text/vcard,text/x-vcard"; i.multiple = multiple; i.hidden = true;
      document.body.appendChild(i);
      i.onchange = async () => {
        let out = [];
        for (const f of i.files) { try { out = out.concat(parseVcf(await f.text())); } catch (x) {} }
        i.remove(); ok(out);
      };
      i.addEventListener("cancel", () => { i.remove(); ok([]); });
      i.click();
    });
  }

  async function pickContacts(multiple) {
    if (PICKER) {
      try {
        const have = await navigator.contacts.getProperties().catch(() => ["name", "tel", "email"]);
        const props = ["name", "tel", "email"].filter((p) => have.includes(p));
        const list = await navigator.contacts.select(props, { multiple });
        return list.map((c) => ({ name: (c.name || [])[0] || "", phone: cleanPhone((c.tel || [])[0] || ""), email: (c.email || [])[0] || "", company: "" }));
      } catch (x) { return []; }
    }
    const got = await pickFile(multiple);
    if (!got.length) toast("No contact found in that file. On iPhone: Contacts → the person → Share Contact → Save to Files, then choose it here.");
    return got;
  }

  const setVal = (el, v, onlyIfEmpty) => {
    if (!el || !v || (onlyIfEmpty && el.value)) return;
    el.value = v;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const fillRow = (row, c, pre) => {
    setVal($(`.${pre}-name`, row), c.name);
    setVal($(`.${pre}-phone`, row), c.phone);
    setVal($(`.${pre}-email`, row), c.email);
    setVal($(`.${pre}-company`, row), c.company);
  };

  function makeBtn(cls, text) {
    const b = document.createElement("button");
    b.type = "button"; b.className = cls; b.textContent = text;
    b.title = PICKER ? "Opens this phone's contact list" : "Choose a contact card (.vcf). On iPhone: Contacts → the person → Share Contact → Save to Files.";
    return b;
  }

  function decorate() {
    if (!document.body.classList.contains("sk") && !$("#view-courtyard:not([hidden])")) { /* still fine: buttons only appear where forms are */ }
    // a) project card: "+ Add client member / contractor / vendor"
    $$("[data-c-add]").forEach((add) => {
      if (add.dataset.cpDone) return; add.dataset.cpDone = "1";
      const kind = add.dataset.cAdd;
      const b = makeBtn("btn small ghost dl-cp", LABEL);
      add.insertAdjacentElement("afterend", b);
      b.addEventListener("click", async () => {
        const list = await pickContacts(true);
        const group = add.closest("[data-group]") || document;
        for (const c of list) {
          add.click();
          const rows = $$(".c-row", group); const row = rows[rows.length - 1];
          if (row) fillRow(row, kind === "client" ? { ...c, company: "" } : c, "c");
        }
        if (list.length) toast(`${list.length} added from contacts — choose the trade, then Save project card`);
      });
    });
    // b) new project: "+ Add another member"
    $$("[data-m-add]").forEach((add) => {
      if (add.dataset.cpDone) return; add.dataset.cpDone = "1";
      const b = makeBtn("btn small ghost dl-cp", LABEL);
      add.insertAdjacentElement("afterend", b);
      b.addEventListener("click", async () => {
        const list = await pickContacts(true);
        for (const c of list) {
          const rows = $$("#m-rows .m-row");
          let row = rows[rows.length - 1];
          if (row && $$("input", row).some((i) => i.value)) { add.click(); row = $$("#m-rows .m-row").pop(); }
          if (row) fillRow(row, c, "m");
        }
      });
    });
    // c) every other phone box (vendor/contractor list, vendor's architects & clients, courtyard, team…)
    $$('input[type="tel"], input[inputmode="tel"]').forEach((inp) => {
      if (inp.dataset.cpDone || inp.closest(".c-row, .m-row, #view-login, .login, #ask, .dl-talk")) return;
      inp.dataset.cpDone = "1";
      const b = makeBtn("dl-cp-mini", "↳ " + LABEL);
      inp.insertAdjacentElement("afterend", b);
      b.addEventListener("click", async (e) => {
        e.preventDefault(); e.stopPropagation();
        const [c] = await pickContacts(false);
        if (!c) return;
        setVal(inp, c.phone);
        const scope = inp.closest("form, .cv-sheet, .panel, section, .cv-grid2, .grid2") || document;
        const scope2 = inp.closest("form, .cv-sheet, .panel, section") || scope;
        const field = (re) => $$("input", scope2).find((i) => i !== inp && i.type !== "hidden" && re.test((i.id || "") + " " + (i.className || "") + " " + (i.name || "") + " " + (i.getAttribute("aria-label") || "")));
        setVal(field(/(^|[-_ ])(name|n)($|[-_ ])|contact person|\bname\b/i), c.name, true);
        setVal($$("input", scope2).find((i) => i.type === "email" || i.inputMode === "email") || field(/email/i), c.email, true);
        setVal(field(/company|firm|org/i), c.company, true);
      });
    });
  }

  /* ======================= 2. Today talk box ======================= */
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const CAN_SPEAK = !!SR && window.isSecureContext;
  const ON_TODAY = () => X.office && ["home", "vtoday", "supdates"].includes(X.office.tab) && !X.office.project
    && $("#view-office") && !$("#view-office").hidden;

  const TAB_WORDS = [
    [/\b(today|dashboard|home page)\b/, "home"], [/\bprojects?\b(?!\s+\w)/, "projects"], [/\bschedule|calendar|meetings?\b/, "schedule"],
    [/\b(vendors?|contractors?|suppliers?)\b/, "people"], [/\bbusiness|accounts?|money|bills?\b/, "business"],
    [/\bsocial( media)?|instagram\b/, "social"], [/\bteam|wallet|users?\b/, "team"], [/\b(my )?profile\b/, "profile"],
    [/\borders?\b/, "rec:orders"], [/\blogistics|dispatch|deliver(y|ies)\b/, "rec:dispatch"], [/\bsite jobs?\b/, "rec:sitejobs"],
    [/\bquotes?|quotations?\b/, "rec:quotes"], [/\bsamples?\b/, "rec:samples"], [/\bcatalog(ue)?\b/, "rec:catalog"],
    [/\bvisits?\b/, "rec:visits"], [/\barchitects?\b/, "rec:v_architects"],
  ];

  async function tryOpen(text) {
    const low = text.toLowerCase().replace(/[.!?]+$/, "").trim();
    const m = low.match(/^(?:please\s+)?(?:open|go to|goto|show(?: me)?|take me to|switch to)\s+(?:the\s+|my\s+)?(.+)$/);
    if (!m) return false;
    const what = m[1].trim();
    const vendor = X.me && X.me() && X.me().kind === "vendor";
    if (/^(home|start|main)( screen| page)?$/.test(what)) { await X.go("welcome"); return true; }
    if (/^(the )?courtyard$/.test(what)) { await X.go("courtyard"); return true; }
    if (/^site$/.test(what)) { await X.go(vendor ? "showroom" : "site"); return true; }
    if (/^showroom$/.test(what)) { await X.go(vendor ? "showroom" : "site"); return true; }
    if (/^(office|works|workshop)$/.test(what)) { await X.go(vendor ? "voffice" : "office"); return true; }
    // a project by name or client
    try {
      const { projects } = await X.api("/api/projects");
      const hit = (projects || []).find((p) => [p.name, p.client].some((n) => n && (n.toLowerCase().includes(what) || what.includes(n.toLowerCase()))));
      if (hit) {
        if (/\bsite\b/.test(what) && !vendor) { await X.go("site"); const b = $(`[data-site-project="${CSS.escape(hit.id)}"]`); if (b) b.click(); return true; }
        if (X.office) { X.office.mode = vendor ? "voffice" : "office"; X.office.tab = "projects"; X.office.project = hit.id; }
        await X.go(vendor ? "voffice" : "office"); await X.renderOffice(); return true;
      }
    } catch (x) {}
    const tab = TAB_WORDS.find(([re]) => re.test(what));
    if (tab) {
      const btn = $(`#office-tabs [data-otab="${CSS.escape(tab[1])}"]`);
      if (btn) { btn.click(); return true; }
    }
    return false;
  }

  async function submit(text) {
    text = (text || "").trim(); if (!text) return;
    if (await tryOpen(text)) return;
    if (X.openAsk && X.sendAsk) { X.openAsk(true); X.sendAsk({ text }); }
  }

  function talkBox() {
    const wrap = document.createElement("form");
    wrap.className = "dl-talk"; wrap.autocomplete = "off";
    wrap.innerHTML = `
      <span class="dl-talk-dot" aria-hidden="true"></span>
      <input class="dl-talk-in" aria-label="Tell Design Lab what to do" placeholder="Type or speak — “open Site”, “task call the marble vendor tomorrow at 11”, “new project Bandra flat for Mrs Mehta”">
      ${CAN_SPEAK ? `<button type="button" class="dl-mic" aria-label="Speak" title="Tap and speak">
        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>` : ""}
      <button type="submit" class="dl-send">Go</button>`;
    const inp = $(".dl-talk-in", wrap), mic = $(".dl-mic", wrap);
    wrap.addEventListener("submit", (e) => { e.preventDefault(); const t = inp.value; inp.value = ""; submit(t); });
    if (mic) {
      let rec = null;
      mic.addEventListener("click", () => {
        if (rec) { try { rec.stop(); } catch (x) {} return; }
        rec = new SR(); rec.lang = "en-IN"; rec.interimResults = true; rec.maxAlternatives = 1;
        mic.classList.add("on"); inp.placeholder = "Listening… speak now";
        let finalText = "";
        rec.onresult = (ev) => {
          let t = ""; for (const r of ev.results) { t += r[0].transcript; if (r.isFinal) finalText = t; }
          inp.value = t;
        };
        rec.onerror = (ev) => { if (ev.error === "not-allowed") toast("Allow the microphone for Design Lab in the browser, then tap the mic again."); };
        rec.onend = () => {
          mic.classList.remove("on"); rec = null; inp.placeholder = "Type or speak";
          const t = (finalText || inp.value).trim();
          if (t) { inp.value = ""; submit(t); }
        };
        try { rec.start(); } catch (x) { mic.classList.remove("on"); rec = null; }
      });
    }
    return wrap;
  }

  function placeTalk() {
    const body = $("#office-body");
    if (!body) return;
    const existing = $(".dl-talk", body);
    if (!ON_TODAY()) { if (existing) existing.remove(); return; }
    if (existing) return;
    const head = $(".o-head", body);
    const box = talkBox();
    if (head) head.insertAdjacentElement("afterend", box); else body.prepend(box);
  }

  /* ======================= Site: no project yet → show every Site feature + make the first project here ======================= */
  const SITE_FEATS = [
    ["Layout plan", "Add the plan once, tap a room, pin everything to it"],
    ["Note", "Quick note for the room or the whole site"],
    ["Change", "Client decision or change — recorded with date"],
    ["Photo", "Site photos go straight into the project folder"],
    ["Snag", "Snag list with room, person and due date"],
    ["Meeting", "Record the meeting by voice — the MOM is written for you"],
    ["Drawings", "Latest revision of every drawing, on site"],
    ["Today on site", "Everything recorded today, in one list"],
  ];
  function siteEmpty() {
    const sb = $("#site-body"); if (!sb) return;
    const e = $(":scope > .empty", sb);
    if (!e || !/No projects yet/.test(e.textContent)) return;
    e.outerHTML = `
      <form class="dl-site-new" autocomplete="off">
        <p class="s-help">Every Site record belongs to a project. Make the first one here — it appears in <b>Office</b> and <b>Site</b> together, with all its folders.</p>
        <div class="dl-site-row"><input id="dl-sn-name" placeholder="Project name — e.g. Worli flat" required><input id="dl-sn-client" placeholder="Client (optional)"><button class="btn orange" type="submit">Create project</button></div>
      </form>
      <div class="dl-site-feats">${SITE_FEATS.map(([t, d]) => `<button type="button" class="dl-feat"><b>${t}</b><span>${d}</span></button>`).join("")}</div>`;
    sb.addEventListener("click", (ev) => {
      if (!ev.target.closest(".dl-feat")) return;
      const n = $("#dl-sn-name", sb); if (n) { n.focus(); toast("Make the project first — then this opens inside it"); }
    });
    $(".dl-site-new", sb).addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const name = $("#dl-sn-name").value.trim(), client = $("#dl-sn-client").value.trim();
      try {
        const r = await X.api("/api/projects", { name, client, members: client ? [{ name: client }] : [] });
        toast("Project created — it's in Office too");
        const pid = (r.project || r).id;
        const btn = document.createElement("button"); btn.hidden = true; btn.dataset.siteProject = pid; sb.appendChild(btn); btn.click();
      } catch (x) { toast(x.message); }
    });
  }

  /* ======================= Site → inside a project: Make MOM · Files · Snag list · People ======================= */
  const esc = (t) => String(t == null ? "" : t).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fdate = (t) => (X.fmtDate ? X.fmtDate(t) : String(t || "").slice(0, 10));
  const furl = (pid, rel) => (X.fileUrl ? X.fileUrl(pid, rel) : "#");
  const waNum = (ph) => { const d = String(ph || "").replace(/\D/g, ""); return d.length === 10 ? "91" + d : d; };

  function siteTools(p) {
    const sb = $("#site-body"); const head = sb && $(".s-head", sb);
    if (!head || $(".dl-sbar", sb)) return;
    const open = (p.snags || []).filter((x) => x.status !== "closed").length;
    head.insertAdjacentHTML("afterend", `
      <div class="dl-sbar">
        <button type="button" class="dl-sb orange" data-sb="mom"><b>Make MOM</b><span>Record the meeting · MOM is written</span></button>
        <button type="button" class="dl-sb" data-sb="files"><b>Files</b><span>Project folders on the studio computer</span></button>
        <button type="button" class="dl-sb" data-sb="snags"><b>Snag list${open ? ` <i class="dl-count">${open}</i>` : ""}</b><span>Every snag · mark done</span></button>
        <button type="button" class="dl-sb" data-sb="people"><b>People</b><span>Client, contractors, vendors</span></button>
      </div>
      <section class="dl-spanel" id="dl-spanel" hidden></section>`);
    const panel = $("#dl-spanel", sb);
    let cur = null;
    const show = (html) => { panel.hidden = false; panel.innerHTML = html; panel.scrollIntoView({ behavior: "smooth", block: "start" }); };
    const reload = async () => { try { p = (await X.api(`/api/projects/${p.id}`)).project; } catch (x) {} };

    async function files(folder) {
      if (!folder) {
        await reload();
        show(`<div class="dl-ph"><h3>Files</h3><button type="button" class="btn ghost light small" data-sp-close>Close</button></div>
          <p class="s-help">These are this project's folders on the studio computer. Tap a folder to see and open its files.</p>
          <div class="dl-folders">${(p.folders || []).map((f) => `<button type="button" class="dl-folder" data-fold="${esc(f.name)}"><b>${esc(f.name)}</b><span>${f.files} file${f.files === 1 ? "" : "s"}</span></button>`).join("")}</div>`);
        return;
      }
      let r = { files: [] };
      try { r = await X.api(`/api/projects/${p.id}/files`, { folder }); } catch (x) { toast(x.message); }
      const live = (r.files || []).filter((f) => !f.superseded);
      show(`<div class="dl-ph"><button type="button" class="crumb light" data-fold="">&larr; All folders</button><button type="button" class="btn ghost light small" data-sp-close>Close</button></div>
        <h3>${esc(folder)} <span class="h-note">${live.length} file${live.length === 1 ? "" : "s"}</span></h3>
        <label class="btn orange dl-add">Add files from this ${matchMedia("(pointer: coarse)").matches ? "phone" : "computer"}<input type="file" multiple hidden data-up="${esc(folder)}"></label>
        ${folder === "00 Inbox" ? `<p class="s-help">Files added to the Inbox are sorted into the right folders by Design Lab.</p>` : ""}
        ${live.length ? `<ul class="dl-files">${live.map((f) => `<li>${f.image ? `<img src="${furl(p.id, f.rel)}" alt="" loading="lazy">` : `<span class="dl-ficon">${esc((f.name.split(".").pop() || "").toUpperCase().slice(0, 4))}</span>`}
          <a href="${furl(p.id, f.rel)}" target="_blank" rel="noopener"><b>${esc(f.name)}</b><span>${esc(f.folder || folder)} · ${esc(fdate(f.time))}</span></a></li>`).join("")}</ul>` : `<p class="empty">This folder is empty.</p>`}`);
    }

    async function snags() {
      await reload();
      const all = (p.snags || []).slice().reverse();
      const op = all.filter((x) => x.status !== "closed"), cl = all.filter((x) => x.status === "closed");
      const row = (x, done) => `<li class="${done ? "done" : ""}"><div><b>${esc(x.text)}</b>
          <span>${esc(x.room || "General")}${x.owner ? " · " + esc(x.owner) : ""}${x.due ? " · fix by " + esc(fdate(x.due)) : ""} · ${esc(x.by || "")} ${esc(fdate(x.time))}${done && x.closed ? " · done " + esc(fdate(x.closed)) : ""}</span></div>
          ${done ? "" : `<button type="button" class="btn small" data-snag-done="${esc(x.id)}">Done</button>`}</li>`;
      show(`<div class="dl-ph"><h3>Snag list <span class="h-note">${op.length} open · ${cl.length} done</span></h3><button type="button" class="btn ghost light small" data-sp-close>Close</button></div>
        <p class="s-help">Add a snag with the <b>Snag</b> button below (choose the room on the plan first). The list is also kept in the project's <b>05 Snags</b> folder.</p>
        ${op.length ? `<ul class="dl-snags">${op.map((x) => row(x, false)).join("")}</ul>` : `<p class="empty">No open snags.</p>`}
        ${cl.length ? `<details class="dl-done"><summary>Done (${cl.length})</summary><ul class="dl-snags">${cl.map((x) => row(x, true)).join("")}</ul></details>` : ""}`);
    }

    function people() {
      const cs = p.contacts || [];
      const grp = { client: "Client", contractor: "Contractors", vendor: "Vendors" };
      const kindOf = (c) => c.kind || (/client/i.test(c.role || "") ? "client" : "contractor");
      show(`<div class="dl-ph"><h3>People on this project</h3><button type="button" class="btn ghost light small" data-sp-close>Close</button></div>
        ${cs.length ? Object.entries(grp).map(([k, l]) => { const list = cs.filter((c) => kindOf(c) === k); return list.length ? `<p class="eyebrow">${l}</p><ul class="dl-people">${list.map((c) => `<li><div><b>${esc(c.company || c.name || "—")}</b><span>${esc([c.company && c.name ? c.name : "", c.trade || c.relation || c.role || ""].filter(Boolean).join(" · "))}</span></div>
          ${c.phone ? `<a class="btn small ghost light" href="tel:${esc(c.phone)}">Call</a><a class="btn small ghost light" href="https://wa.me/${waNum(c.phone)}" target="_blank" rel="noopener">WhatsApp</a>` : ""}</li>`).join("")}</ul>` : ""; }).join("")
        : `<p class="empty">No one added yet. Add the client, contractors and vendors on the project's card in Office (with <b>From phone contacts</b>).</p>`}`);
    }

    sb.querySelector(".dl-sbar").addEventListener("click", (e) => {
      const b = e.target.closest("[data-sb]"); if (!b) return;
      const k = b.dataset.sb;
      $$(".dl-sb", sb).forEach((x) => x.classList.toggle("on", x === b && k !== "mom"));
      if (k === "mom") { panel.hidden = true; const m = $("[data-meeting]", sb); if (m) m.click(); return; }
      cur = k;
      if (k === "files") files(""); else if (k === "snags") snags(); else people();
    });
    panel.addEventListener("click", async (e) => {
      if (e.target.closest("[data-sp-close]")) { panel.hidden = true; $$(".dl-sb", sb).forEach((x) => x.classList.remove("on")); return; }
      const f = e.target.closest("[data-fold]"); if (f) { files(f.dataset.fold); return; }
      const d = e.target.closest("[data-snag-done]");
      if (d) {
        try { await X.api(`/api/projects/${p.id}/snags/${d.dataset.snagDone}`, { status: "closed" }); toast("Snag marked done"); } catch (x) { toast(x.message); return; }
        await snags();
        const n = (p.snags || []).filter((x) => x.status !== "closed").length, c = $(".dl-sb[data-sb=snags] b", sb);
        if (c) c.innerHTML = "Snag list" + (n ? ` <i class="dl-count">${n}</i>` : "");
      }
    });
    panel.addEventListener("change", async (e) => {
      const inp = e.target.closest("[data-up]"); if (!inp || !inp.files.length) return;
      const folder = inp.dataset.up; let n = 0;
      for (const fl of inp.files) {
        if (fl.size > 55 * 1024 * 1024) { toast(`${fl.name} is too big (over 55 MB)`); continue; }
        const data = await new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(fl); });
        try { toast(`Adding ${fl.name}…`); await X.api(`/api/projects/${p.id}/upload`, { folder, name: fl.name, data }); n++; } catch (x) { toast(x.message); }
      }
      if (n) toast(`${n} file${n === 1 ? "" : "s"} added to ${folder}`);
      files(folder);
    });
  }
  const prevAfter = X.afterSite;
  X.afterSite = (p, room) => { try { if (prevAfter) prevAfter(p, room); } finally { siteTools(p); } };

  /* ======================= Registration: "Code from the website" → payment skipped ======================= */
  const AL = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const codeOk = (raw) => {
    const c = String(raw || "").toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/^DL/, "");
    if (c.length !== 8 || [...c].some((x) => AL.indexOf(x) < 0)) return false;
    const body = c.slice(0, 7);
    return AL[[...body].reduce((t, x, i) => t + (i + 1) * AL.indexOf(x), 0) % AL.length] === c[7];
  };
  let webCode = "";
  function regCode() {
    const f = $("#f-reg1"); if (!f || $("#r-webcode")) return;
    const grid = $(".setup-grid", f); if (!grid) return;
    grid.insertAdjacentHTML("beforeend", `<label class="field wide"><span>Code from the website <i style="font-style:normal;opacity:.7">(if you signed up on the Design Lab website)</i></span><input id="r-webcode" placeholder="DL-XXXX-XXXX" autocapitalize="characters" spellcheck="false" maxlength="14"></label>`);
  }
  document.addEventListener("submit", (e) => {
    if (e.target.id !== "f-reg1") return;
    const i = $("#r-webcode"); const v = i ? i.value.trim() : "";
    if (v && !codeOk(v)) {
      e.preventDefault(); e.stopImmediatePropagation();
      const err = $("#reg1-error"); if (err) err.textContent = "That code doesn't look right. Check it on the website (Sign up → Show my code), or leave it empty.";
      i.focus(); return;
    }
    webCode = v ? v.toUpperCase() : "";
  }, true);
  function regSkip() {
    const f2 = $("#f-reg2");
    if (!webCode || !f2 || f2.hidden || f2.dataset.auto === webCode) return;
    f2.dataset.auto = webCode;
    const b = $("[data-skip-pay]", f2); if (b) b.click();
    setTimeout(() => { const t = $("#reg3-paid"); if (t) t.textContent = `Code ${webCode} accepted — payment skipped for the pilot. Now create your user with the same user ID you chose on the website.`; }, 600);
  }

  /* ======================= Vendor: products & brands (asked once, then in My profile) ======================= */
  const CATS = ["Marble & stone", "Tiles", "Flooring", "Lighting", "Furniture", "Fabric & furnishing", "Wallpaper", "Laminates & veneers", "Paint & finishes",
    "Hardware", "Sanitaryware & bath", "Kitchen & appliances", "Glass & mirrors", "Art & décor", "Outdoor & landscape", "Other"];
  function productForm(pr, first) {
    pr = pr || {};
    const on = new Set(pr.categories || []);
    const extra = (pr.categories || []).filter((c) => !CATS.includes(c));
    return `<form class="dl-prod" autocomplete="off">
      ${first ? `<p class="dl-prod-eyebrow">One last step</p><h2>What does your company deal in?</h2><p class="dl-prod-sub">Architects in The Courtyard will find you by these. You can change them any time in <b>My profile</b>.</p>` : `<h3>Products &amp; brands</h3>`}
      <p class="dl-prod-l">Categories <i>(choose all that apply)</i></p>
      <div class="dl-chips">${CATS.map((c) => `<button type="button" class="dl-chip ${on.has(c) || (c === "Other" && extra.length) ? "on" : ""}" data-cat="${esc(c)}">${esc(c)}</button>`).join("")}</div>
      <input class="dl-in" id="dp-other" placeholder="Other — type it" value="${esc(extra.join(", "))}" ${extra.length ? "" : "hidden"}>
      <p class="dl-prod-l">Brands</p>
      <div class="dl-seg"><button type="button" data-bt="single" class="${pr.brand_type === "multi" ? "" : "on"}">Single brand (our own)</button><button type="button" data-bt="multi" class="${pr.brand_type === "multi" ? "on" : ""}">Multi-brand (we carry several)</button></div>
      <label class="dl-lab"><span id="dp-brands-l">${pr.brand_type === "multi" ? "Brand names you carry" : "Your brand name"}</span><input class="dl-in" id="dp-brands" value="${esc(pr.brands || "")}" placeholder="e.g. Kajaria, Simpolo, Somany"></label>
      <label class="dl-lab"><span>Your products <i>(one per line — size, finish, price range if you like)</i></span><textarea class="dl-in" id="dp-details" rows="5" placeholder="Italian marble slabs — Statuario, Calacatta — 18 mm&#10;Large-format porcelain tiles — 1200 × 2400">${esc(pr.details || "")}</textarea></label>
      <label class="dl-lab"><span>Cities you supply</span><input class="dl-in" id="dp-cities" value="${esc(pr.cities || "")}" placeholder="e.g. Mumbai, Pune, Bengaluru — or All India"></label>
      <p class="dl-err" id="dp-err"></p>
      <div class="dl-prod-act"><button class="btn orange" type="submit">${first ? "Save and open Design Lab" : "Save products & brands"}</button></div>
    </form>`;
  }
  function bindProductForm(f, done) {
    let bt = $(".dl-seg .on", f).dataset.bt;
    f.addEventListener("click", (e) => {
      const c = e.target.closest("[data-cat]");
      if (c) { c.classList.toggle("on"); if (c.dataset.cat === "Other") { $("#dp-other", f).hidden = !c.classList.contains("on"); if (!$("#dp-other", f).hidden) $("#dp-other", f).focus(); } return; }
      const b = e.target.closest("[data-bt]");
      if (b) { bt = b.dataset.bt; $$("[data-bt]", f).forEach((x) => x.classList.toggle("on", x === b)); $("#dp-brands-l", f).textContent = bt === "multi" ? "Brand names you carry" : "Your brand name"; }
    });
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      let cats = $$(".dl-chip.on", f).map((c) => c.dataset.cat).filter((c) => c !== "Other");
      if ($('[data-cat="Other"]', f).classList.contains("on")) cats = cats.concat($("#dp-other", f).value.split(",").map((x) => x.trim()).filter(Boolean));
      const err = $("#dp-err", f); err.textContent = "";
      if (!cats.length) { err.textContent = "Choose at least one category."; return; }
      if (!$("#dp-brands", f).value.trim()) { err.textContent = bt === "multi" ? "Type the brands you carry." : "Type your brand name."; $("#dp-brands", f).focus(); return; }
      if (!$("#dp-details", f).value.trim()) { err.textContent = "Add at least one product."; $("#dp-details", f).focus(); return; }
      if (!$("#dp-cities", f).value.trim()) { err.textContent = "Type the cities you supply."; $("#dp-cities", f).focus(); return; }
      try {
        const r = await X.api("/api/firm/products", { categories: cats, brand_type: bt, brands: $("#dp-brands", f).value, details: $("#dp-details", f).value, cities: $("#dp-cities", f).value });
        toast("Products & brands saved"); if (done) done(r.products);
      } catch (x) { err.textContent = x.message; }
    });
  }
  let prodChecked = "";
  async function vendorFirstRun() {
    const tok = X.token && X.token();
    if (!tok || prodChecked === tok || !document.body.classList.contains("is-vendor") || document.body.classList.contains("is-demo")) return;
    const w = $("#view-welcome"); if (!w || w.hidden) return;
    prodChecked = tok;
    let r; try { r = await X.api("/api/firm/products"); } catch (x) { return; }
    if (r.kind !== "vendor" || r.products || !r.owner) return;
    const sh = document.createElement("div"); sh.className = "dl-prod-sheet"; sh.innerHTML = `<div class="dl-prod-box">${productForm(null, true)}</div>`;
    document.body.appendChild(sh);
    bindProductForm($("form", sh), () => sh.remove());
  }
  async function vendorProfile() {
    const box = $("#office-body");
    if (!box || !X.office || X.office.tab !== "profile" || !document.body.classList.contains("is-vendor") || $(".dl-prod-panel", box) || !$("#pf-form", box)) return;
    const slot = document.createElement("section"); slot.className = "panel dl-prod-panel"; slot.innerHTML = `<p class="hint-text">Loading…</p>`;
    $("#pf-form", box).insertAdjacentElement("afterend", slot);
    let r; try { r = await X.api("/api/firm/products"); } catch (x) { slot.remove(); return; }
    if (r.kind !== "vendor") { slot.remove(); return; }
    slot.innerHTML = productForm(r.products, false) + (r.owner ? "" : `<p class="hint-text">Only the company owner can change these.</p>`);
    if (r.owner) bindProductForm($("form", slot), null); else $$("input, textarea, button", slot).forEach((x) => (x.disabled = true));
  }

  let raf = 0;
  new MutationObserver(() => {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; decorate(); placeTalk(); siteEmpty(); regCode(); regSkip(); vendorFirstRun(); vendorProfile(); });
  }).observe(document.body, { childList: true, subtree: true });
})();
