/* DESIGN LAB v0.12 — two helpers, kept apart from app.js so they can be changed on their own.
   1. FROM PHONE CONTACTS: wherever you add a person (client, contractor, vendor, architect, team member…)
      a "From phone contacts" button fills the name, phone and email for you.
        - Android phone in Chrome (opened through the secure share link): opens the phone's own contact list.
        - iPhone, or a computer: choose a contact card file (.vcf) — on iPhone: Contacts → the person →
          Share Contact → Save to Files; on a computer: export from Google Contacts / Outlook. Many people at once is fine.
   2. TODAY TALK BOX: on the Office "Today" page, type or tap the microphone and say what you want —
      "open Site", "open Schedule", "open Worli flat", "task call the marble vendor tomorrow at 11 for Worli flat",
      "new project Bandra flat for Mrs Mehta", "find kitchen elevation". Opening is done here at once;
      everything else goes to your assistant, whose answer opens beside you. */
(() => {
  "use strict";
  const X = window.DLX || {};
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const toast = (m) => (X.toast ? X.toast(m) : console.log(m));

  /* ======================= 1. phone contacts ======================= */
  const PICKER = "contacts" in navigator && "ContactsManager" in window && window.isSecureContext;
  const LABEL = "From phone contacts";

  const cleanPhone = (p) => {
    let d = String(p || "").replace(/[^\d+]/g, "");
    if (d.startsWith("0091")) d = "+91" + d.slice(4);
    if (/^91\d{10}$/.test(d)) d = "+" + d;
    if (/^0\d{10}$/.test(d)) d = d.slice(1);
    return d;
  };

  function parseVcf(txt) {
    const out = [];
    const unfolded = String(txt).replace(/\r\n[ \t]/g, "").replace(/\n[ \t]/g, "");
    for (const card of unfolded.split(/BEGIN:VCARD/i).slice(1)) {
      const lines = card.split(/\r?\n/);
      const get = (key) => { const l = lines.find((x) => new RegExp("^(item\\d+\\.)?" + key + "[;:]", "i").test(x)); return l ? l.slice(l.indexOf(":") + 1).trim() : ""; };
      const dec = (v) => v.replace(/\\,/g, ",").replace(/\\;/g, ";").replace(/\\n/gi, " ").trim();
      let name = dec(get("FN"));
      if (!name) { const n = get("N").split(";"); name = dec([n[1], n[0]].filter(Boolean).join(" ")); }
      const company = dec((get("ORG").split(";")[0]) || "");
      const phone = cleanPhone(get("TEL"));
      const email = dec(get("EMAIL"));
      if (name || phone || email) out.push({ name, phone, email, company });
    }
    return out;
  }

  function pickFile(multiple) {
    return new Promise((ok) => {
      const i = document.createElement("input");
      i.type = "file"; i.accept = ".vcf,.vcard,text/vcard,text/x-vcard"; i.multiple = multiple; i.hidden = true;
      document.body.appendChild(i);
      i.onchange = async () => {
        let out = [];
        for (const f of i.files) { try { out = out.concat(parseVcf(await f.text())); } catch (x) {} }
        i.remove(); ok(out);
      };
      i.addEventListener("cancel", () => { i.remove(); ok([]); });
      i.click();
    });
  }

  async function pickContacts(multiple) {
    if (PICKER) {
      try {
        const have = await navigator.contacts.getProperties().catch(() => ["name", "tel", "email"]);
        const props = ["name", "tel", "email"].filter((p) => have.includes(p));
        const list = await navigator.contacts.select(props, { multiple });
        return list.map((c) => ({ name: (c.name || [])[0] || "", phone: cleanPhone((c.tel || [])[0] || ""), email: (c.email || [])[0] || "", company: "" }));
      } catch (x) { return []; }
    }
    const got = await pickFile(multiple);
    if (!got.length) toast("No contact found in that file. On iPhone: Contacts → the person → Share Contact → Save to Files, then choose it here.");
    return got;
  }

  const setVal = (el, v, onlyIfEmpty) => {
    if (!el || !v || (onlyIfEmpty && el.value)) return;
    el.value = v;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const fillRow = (row, c, pre) => {
    setVal($(`.${pre}-name`, row), c.name);
    setVal($(`.${pre}-phone`, row), c.phone);
    setVal($(`.${pre}-email`, row), c.email);
    setVal($(`.${pre}-company`, row), c.company);
  };

  function makeBtn(cls, text) {
    const b = document.createElement("button");
    b.type = "button"; b.className = cls; b.textContent = text;
    b.title = PICKER ? "Opens this phone's contact list" : "Choose a contact card (.vcf). On iPhone: Contacts → the person → Share Contact → Save to Files.";
    return b;
  }

  function decorate() {
    if (!document.body.classList.contains("sk") && !$("#view-courtyard:not([hidden])")) { /* still fine: buttons only appear where forms are */ }
    // a) project card: "+ Add client member / contractor / vendor"
    $$("[data-c-add]").forEach((add) => {
      if (add.dataset.cpDone) return; add.dataset.cpDone = "1";
      const kind = add.dataset.cAdd;
      const b = makeBtn("btn small ghost dl-cp", LABEL);
      add.insertAdjacentElement("afterend", b);
      b.addEventListener("click", async () => {
        const list = await pickContacts(true);
        const group = add.closest("[data-group]") || document;
        for (const c of list) {
          add.click();
          const rows = $$(".c-row", group); const row = rows[rows.length - 1];
          if (row) fillRow(row, kind === "client" ? { ...c, company: "" } : c, "c");
        }
        if (list.length) toast(`${list.length} added from contacts — choose the trade, then Save project card`);
      });
    });
    // b) new project: "+ Add another member"
    $$("[data-m-add]").forEach((add) => {
      if (add.dataset.cpDone) return; add.dataset.cpDone = "1";
      const b = makeBtn("btn small ghost dl-cp", LABEL);
      add.insertAdjacentElement("afterend", b);
      b.addEventListener("click", async () => {
        const list = await pickContacts(true);
        for (const c of list) {
          const rows = $$("#m-rows .m-row");
          let row = rows[rows.length - 1];
          if (row && $$("input", row).some((i) => i.value)) { add.click(); row = $$("#m-rows .m-row").pop(); }
          if (row) fillRow(row, c, "m");
        }
      });
    });
    // c) every other phone box (vendor/contractor list, vendor's architects & clients, courtyard, team…)
    $$('input[type="tel"], input[inputmode="tel"]').forEach((inp) => {
      if (inp.dataset.cpDone || inp.closest(".c-row, .m-row, #view-login, .login, #ask, .dl-talk")) return;
      inp.dataset.cpDone = "1";
      const b = makeBtn("dl-cp-mini", "↳ " + LABEL);
      inp.insertAdjacentElement("afterend", b);
      b.addEventListener("click", async (e) => {
        e.preventDefault(); e.stopPropagation();
        const [c] = await pickContacts(false);
        if (!c) return;
        setVal(inp, c.phone);
        const scope = inp.closest("form, .cv-sheet, .panel, section, .cv-grid2, .grid2") || document;
        const scope2 = inp.closest("form, .cv-sheet, .panel, section") || scope;
        const field = (re) => $$("input", scope2).find((i) => i !== inp && i.type !== "hidden" && re.test((i.id || "") + " " + (i.className || "") + " " + (i.name || "") + " " + (i.getAttribute("aria-label") || "")));
        setVal(field(/(^|[-_ ])(name|n)($|[-_ ])|contact person|\bname\b/i), c.name, true);
        setVal($$("input", scope2).find((i) => i.type === "email" || i.inputMode === "email") || field(/email/i), c.email, true);
        setVal(field(/company|firm|org/i), c.company, true);
      });
    });
  }

  /* ======================= 2. Today talk box ======================= */
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const CAN_SPEAK = !!SR && window.isSecureContext;
  const ON_TODAY = () => X.office && ["home", "vtoday", "supdates"].includes(X.office.tab) && !X.office.project
    && $("#view-office") && !$("#view-office").hidden;

  const TAB_WORDS = [
    [/\b(today|dashboard|home page)\b/, "home"], [/\bprojects?\b(?!\s+\w)/, "projects"], [/\bschedule|calendar|meetings?\b/, "schedule"],
    [/\b(vendors?|contractors?|suppliers?)\b/, "people"], [/\bbusiness|accounts?|money|bills?\b/, "business"],
    [/\bsocial( media)?|instagram\b/, "social"], [/\bteam|wallet|users?\b/, "team"], [/\b(my )?profile\b/, "profile"],
    [/\borders?\b/, "rec:orders"], [/\blogistics|dispatch|deliver(y|ies)\b/, "rec:dispatch"], [/\bsite jobs?\b/, "rec:sitejobs"],
    [/\bquotes?|quotations?\b/, "rec:quotes"], [/\bsamples?\b/, "rec:samples"], [/\bcatalog(ue)?\b/, "rec:catalog"],
    [/\bvisits?\b/, "rec:visits"], [/\barchitects?\b/, "rec:v_architects"],
  ];

  async function tryOpen(text) {
    const low = text.toLowerCase().replace(/[.!?]+$/, "").trim();
    const m = low.match(/^(?:please\s+)?(?:open|go to|goto|show(?: me)?|take me to|switch to)\s+(?:the\s+|my\s+)?(.+)$/);
    if (!m) return false;
    const what = m[1].trim();
    const vendor = X.me && X.me() && X.me().kind === "vendor";
    if (/^(home|start|main)( screen| page)?$/.test(what)) { await X.go("welcome"); return true; }
    if (/^(the )?courtyard$/.test(what)) { await X.go("courtyard"); return true; }
    if (/^site$/.test(what)) { await X.go(vendor ? "showroom" : "site"); return true; }
    if (/^showroom$/.test(what)) { await X.go(vendor ? "showroom" : "site"); return true; }
    if (/^(office|works|workshop)$/.test(what)) { await X.go(vendor ? "voffice" : "office"); return true; }
    // a project by name or client
    try {
      const { projects } = await X.api("/api/projects");
      const hit = (projects || []).find((p) => [p.name, p.client].some((n) => n && (n.toLowerCase().includes(what) || what.includes(n.toLowerCase()))));
      if (hit) {
        if (/\bsite\b/.test(what) && !vendor) { await X.go("site"); const b = $(`[data-site-project="${CSS.escape(hit.id)}"]`); if (b) b.click(); return true; }
        if (X.office) { X.office.mode = vendor ? "voffice" : "office"; X.office.tab = "projects"; X.office.project = hit.id; }
        await X.go(vendor ? "voffice" : "office"); await X.renderOffice(); return true;
      }
    } catch (x) {}
    const tab = TAB_WORDS.find(([re]) => re.test(what));
    if (tab) {
      const btn = $(`#office-tabs [data-otab="${CSS.escape(tab[1])}"]`);
      if (btn) { btn.click(); return true; }
    }
    return false;
  }

  async function submit(text) {
    text = (text || "").trim(); if (!text) return;
    if (await tryOpen(text)) return;
    if (X.openAsk && X.sendAsk) { X.openAsk(true); X.sendAsk({ text }); }
  }

  function talkBox() {
    const wrap = document.createElement("form");
    wrap.className = "dl-talk"; wrap.autocomplete = "off";
    wrap.innerHTML = `
      <span class="dl-talk-dot" aria-hidden="true"></span>
      <input class="dl-talk-in" aria-label="Tell Design Lab what to do" placeholder="Type or speak — “open Site”, “task call the marble vendor tomorrow at 11”, “new project Bandra flat for Mrs Mehta”">
      ${CAN_SPEAK ? `<button type="button" class="dl-mic" aria-label="Speak" title="Tap and speak">
        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>` : ""}
      <button type="submit" class="dl-send">Go</button>`;
    const inp = $(".dl-talk-in", wrap), mic = $(".dl-mic", wrap);
    wrap.addEventListener("submit", (e) => { e.preventDefault(); const t = inp.value; inp.value = ""; submit(t); });
    if (mic) {
      let rec = null;
      mic.addEventListener("click", () => {
        if (rec) { try { rec.stop(); } catch (x) {} return; }
        rec = new SR(); rec.lang = "en-IN"; rec.interimResults = true; rec.maxAlternatives = 1;
        mic.classList.add("on"); inp.placeholder = "Listening… speak now";
        let finalText = "";
        rec.onresult = (ev) => {
          let t = ""; for (const r of ev.results) { t += r[0].transcript; if (r.isFinal) finalText = t; }
          inp.value = t;
        };
        rec.onerror = (ev) => { if (ev.error === "not-allowed") toast("Allow the microphone for Design Lab in the browser, then tap the mic again."); };
        rec.onend = () => {
          mic.classList.remove("on"); rec = null; inp.placeholder = "Type or speak";
          const t = (finalText || inp.value).trim();
          if (t) { inp.value = ""; submit(t); }
        };
        try { rec.start(); } catch (x) { mic.classList.remove("on"); rec = null; }
      });
    }
    return wrap;
  }

  function placeTalk() {
    const body = $("#office-body");
    if (!body) return;
    const existing = $(".dl-talk", body);
    if (!ON_TODAY()) { if (existing) existing.remove(); return; }
    if (existing) return;
    const head = $(".o-head", body);
    const box = talkBox();
    if (head) head.insertAdjacentElement("afterend", box); else body.prepend(box);
  }

  /* ======================= Site: nothing there yet → make the first project right here ======================= */
  function siteEmpty() {
    const sb = $("#site-body"); if (!sb) return;
    const e = $(":scope > .empty", sb);
    if (!e || sb.dataset.helped === "1" || !/No projects yet/.test(e.textContent)) return;
    sb.dataset.helped = "1";
    e.insertAdjacentHTML("afterend", `
      <form class="dl-site-new" autocomplete="off">
        <p class="s-help">Make the project here — it appears in <b>Office</b> and <b>Site</b> together, with all its folders.</p>
        <div class="dl-site-row"><input id="dl-sn-name" placeholder="Project name — e.g. Worli flat" required><input id="dl-sn-client" placeholder="Client (optional)"><button class="btn orange" type="submit">Create project</button></div>
        <ul class="dl-site-list"><li>Pin notes, photos and snags to each room</li><li>Record the site meeting by voice — the MOM is written for you</li><li>See the latest drawings on site</li><li>Today on site: everything recorded, by date</li></ul>
      </form>`);
    e.remove();
    $(".dl-site-new", sb).addEventListener("submit", async (ev) => {
      ev.preventDefault();
      try {
        const r = await X.api("/api/projects", { name: $("#dl-sn-name").value.trim(), client: $("#dl-sn-client").value.trim(), members: $("#dl-sn-client").value.trim() ? [{ name: $("#dl-sn-client").value.trim() }] : [] });
        toast("Project created — it's in Office too");
        const pid = (r.project || r).id;
        const btn = document.createElement("button"); btn.hidden = true; btn.dataset.siteProject = pid; sb.appendChild(btn); btn.click();
      } catch (x) { toast(x.message); }
    });
  }

  let raf = 0;
  new MutationObserver(() => {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; decorate(); placeTalk(); siteEmpty(); });
  }).observe(document.body, { childList: true, subtree: true });
})();
