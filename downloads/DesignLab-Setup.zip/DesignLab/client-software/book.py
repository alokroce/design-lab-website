"""
Design Lab - the studio's Vendors & contractors list (one list for the whole studio).

Stored in <projects folder>/.designlab/book.json.  Projects keep their own copy of the people on them
(proj["contacts"]); anyone added on a project is also added here, so the studio builds its list once.
"""
import os
import re
import secrets

S = None   # set by server.py

CONTRACTOR_TRADES = ["Civil", "Electrical", "Plumbing", "Carpentry", "Painting", "False ceiling", "HVAC / AC",
                     "Flooring", "Fabrication", "Site supervisor", "Other"]
VENDOR_TRADES = ["Marble & stone", "Tiles", "Veneer", "Laminate", "Plywood & boards", "Hardware", "Lighting",
                 "Sanitaryware & CP", "Furniture", "Fabric & upholstery", "Curtains & blinds", "Wallpaper",
                 "Glass & mirrors", "Paint", "Appliances", "Art & decor", "Other"]
KINDS = ("contractor", "vendor")


def _file():
    root = S.projects_root()
    return os.path.join(root, ".designlab", "book.json") if root else None


def load():
    return S.load_json(_file(), {"people": []}) if _file() else {"people": []}


def clean(p):
    kind = str(p.get("kind", "")).lower()
    if kind not in KINDS:
        kind = "vendor" if "vendor" in kind else "contractor"
    out = {k: str(p.get(k, "") or "").strip()[:120] for k in ("trade", "company", "name", "phone", "email", "city", "notes")}
    out["kind"] = kind
    out["id"] = p.get("id") or secrets.token_hex(5)
    return out


def _same(a, b):
    pa, pb = re.sub(r"\D", "", a.get("phone", ""))[-10:], re.sub(r"\D", "", b.get("phone", ""))[-10:]
    if pa and pa == pb:
        return True
    return bool(a.get("name")) and a.get("name", "").lower() == b.get("name", "").lower() and \
        a.get("company", "").lower() == b.get("company", "").lower()


def save_person(person):
    p = clean(person)
    if not (p["name"] or p["company"]):
        raise ValueError("Please enter a name or a company.")
    book = load()
    for i, old in enumerate(book["people"]):
        if old["id"] == p["id"]:
            book["people"][i] = p
            break
    else:
        book["people"].append(p)
    S.save_json(_file(), book)
    return p


def delete_person(pid):
    book = load()
    book["people"] = [p for p in book["people"] if p["id"] != pid]
    S.save_json(_file(), book)


def learn(contacts):
    """Add contractors/vendors from a project card to the studio list (skips ones already there)."""
    book = load()
    added = 0
    for c in contacts:
        if c.get("kind") not in KINDS or not (c.get("name") or c.get("company")):
            continue
        if any(_same(c, old) for old in book["people"]):
            continue
        book["people"].append(clean({k: c.get(k, "") for k in ("kind", "trade", "company", "name", "phone", "email")}))
        added += 1
    if added:
        S.save_json(_file(), book)
    return added


def with_projects():
    """Studio list plus which projects each person is on."""
    people = load()["people"]
    for p in people:
        p["projects"] = []
    projs = [S.load_project(d) for d in S.project_dirs()]
    for proj in projs:
        for c in (proj or {}).get("contacts", []):
            for p in people:
                if c.get("kind") == p["kind"] and _same(c, p) and proj["name"] not in p["projects"]:
                    p["projects"].append(proj["name"])
    people.sort(key=lambda p: (p["kind"], p["trade"].lower(), (p["name"] or p["company"]).lower()))
    return people


TRIGGERS = ("vendor", "contractor", "supplier", "who is", "who's", "electrician", "plumber", "carpenter", "painter",
            "mason", "civil", "marble", "tile", "veneer", "laminate", "ply", "hardware", "light", "sanitary", "furniture",
            "fabric", "curtain", "blind", "wallpaper", "glass", "mirror", "paint", "ac ", "hvac", "ceiling", "phone of",
            "number of", "contact")


def search(text):
    """None if the text isn't about people; otherwise a (possibly empty) list."""
    low = " " + text.lower() + " "
    if not any(t in low for t in TRIGGERS):
        return None
    stop = {"vendor", "vendors", "contractor", "contractors", "supplier", "who", "is", "the", "our", "my", "on", "for",
            "of", "a", "an", "phone", "number", "contact", "what", "s", "who's", "give", "me", "find", "show"}
    words = [w for w in re.findall(r"[a-z0-9]+", low) if w not in stop]
    alias = {"electrician": "electrical", "plumber": "plumbing", "carpenter": "carpentry", "painter": "painting",
             "mason": "civil", "tile": "tiles", "light": "lighting", "lights": "lighting", "sanitary": "sanitaryware",
             "ply": "plywood", "curtain": "curtains", "blind": "blinds", "ac": "hvac"}
    words = [alias.get(w, w) for w in words]
    people = with_projects()
    want_kind = "vendor" if "vendor" in low or "supplier" in low else ("contractor" if "contractor" in low else None)
    out = []
    for p in people:
        if want_kind and p["kind"] != want_kind:
            continue
        hay = " ".join([p["trade"], p["company"], p["name"], p["city"], " ".join(p["projects"])]).lower()
        if all(any(w[:5] in h for h in hay.split()) or w in hay for w in words):
            out.append(p)
    return out
