"""
Design Lab - the studio assistant ("Talk to your assistant" on the Office dashboard).

What it does (all free rules on this computer, no AI cost):
  1. First time: asks where to keep the Design Lab folders (C:, another drive, Google Drive / OneDrive).
  2. Asks: bring your old project folders in, or start fresh?  Old folders are COPIED, never moved or changed.
     Every file is sorted into the right Design Lab folder; anything it isn't sure about waits in 00 Inbox.
  3. Watches the folders: if a file is put in the wrong folder it asks "shall I move it?" (moves only on yes).
  4. Tells the studio, and the Design Lab dashboard, when a project / client is added.
  5. Small commands: find a file, find a vendor or contractor, start a new project.

This file only talks to server.py through S (the server module), so it can be changed on its own.
"""
import os
import re
import secrets
import shutil
import string
import threading
import time

S = None            # set by server.py:  assistant.S = <server module>
JOB_LOCK = threading.Lock()
WATCH_TOPS = ("01 Drawings", "02 3D", "03 Site Photos", "04 MOM", "06 Bills & Quotes")
LOOKS_LIKE = {"01 Drawings": "a drawing", "02 3D": "a 3D model or render", "03 Site Photos": "a photo",
              "04 MOM": "minutes of a meeting", "06 Bills & Quotes": "a bill or quote", "07 Client Docs": "a document"}
SKIP_FILES = ("thumbs.db", "desktop.ini", ".ds_store")


# ---------------------------------------------------------------- storage

def _file():
    root = S.projects_root()
    return os.path.join(root, ".designlab", "assistant.json") if root else None


def load():
    st = S.load_json(_file(), None) if _file() else None
    st = st or {}
    st.setdefault("step", "start")
    st.setdefault("messages", [])
    st.setdefault("flags", {})
    st.setdefault("imported", [])
    return st


def save(st):
    st["messages"] = st["messages"][-300:]
    S.save_json(_file(), st)


def say(st, text, choices=None, frm="bot", who=""):
    msg = {"id": secrets.token_hex(5), "time": S.now_iso(), "from": frm, "text": text}
    if who:
        msg["who"] = who
    if choices:
        msg["choices"] = choices
    st["messages"].append(msg)
    return msg


def close_choices(st):
    """Once answered, old buttons stop working (they are shown greyed out)."""
    for m in st["messages"]:
        if m.get("choices"):
            m["answered"] = True


def notify(text, choices=None):
    """Post a bot message from anywhere in the server (e.g. a project was added)."""
    try:
        with S.LOCK:
            st = load()
            say(st, text, choices)
            save(st)
    except Exception as exc:  # the assistant must never break the main software
        print("Assistant:", exc)


def report(kind, text, project="", client=""):
    """Tell the Design Lab dashboard (business side). Quietly skipped when not connected."""
    firm = S.load_firm()
    if not S.cloud_cfg(firm).get("url"):
        return
    def go():
        try:
            S.cloud_call(firm, "/api/studio/activity", {"kind": kind, "text": text, "project": project, "client": client})
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


# ---------------------------------------------------------------- where to keep the folders

def _drive_type(root):
    try:
        import ctypes
        return ctypes.windll.kernel32.GetDriveTypeW(root)   # 2 removable, 3 fixed, 4 network, 5 CD
    except Exception:
        return 3


def _free_gb(path):
    try:
        return int(shutil.disk_usage(path).free / 1e9)
    except OSError:
        return None


def places():
    out = [{"label": "Inside the Design Lab folder (simplest, moves with the software)", "path": S.default_root()}]
    seen = set()
    if os.name == "nt":
        for letter in string.ascii_uppercase:
            root = letter + ":\\"
            t = _drive_type(root)
            if t not in (2, 3, 4) or not os.path.isdir(root):
                continue
            gdrive = os.path.join(root, "My Drive")
            if os.path.isdir(gdrive):
                out.append({"label": f"Google Drive ({letter}:) - kept online in the cloud",
                            "path": os.path.join(gdrive, "Design Lab Projects"), "cloud": True})
                continue
            free = _free_gb(root)
            kind = " - office server / network drive" if t == 4 else (" - pen drive / external" if t == 2 else "")
            out.append({"label": f"{letter}: drive{kind}" + (f" ({free} GB free)" if free is not None else ""),
                        "path": root + "Design Lab Projects"})
    home = os.path.expanduser("~")
    for env, name in (("OneDrive", "OneDrive"),):
        p = os.environ.get(env)
        if p and os.path.isdir(p):
            out.append({"label": f"{name} - kept online in the cloud", "path": os.path.join(p, "Design Lab Projects"), "cloud": True})
    for sub, name in (("Google Drive", "Google Drive"), ("My Drive", "Google Drive"), ("Dropbox", "Dropbox")):
        p = os.path.join(home, sub)
        if os.path.isdir(p):
            out.append({"label": f"{name} - kept online in the cloud", "path": os.path.join(p, "Design Lab Projects"), "cloud": True})
    clean = []
    for p in out:
        k = os.path.normcase(os.path.normpath(p["path"]))
        if k not in seen:
            seen.add(k)
            clean.append(p)
    return clean


def set_place(path):
    """Use `path` for the Design Lab folders. Anything already there is moved along (nothing is deleted)."""
    new = os.path.normpath(os.path.abspath(os.path.expanduser(path.strip().strip('"'))))
    old = os.path.normpath(S.projects_root() or S.default_root())
    if os.path.normcase(new) == os.path.normcase(old):
        return new, 0
    if os.path.normcase(new).startswith(os.path.normcase(old) + os.sep):
        raise ValueError("That folder is inside the current Design Lab folder. Please pick another place.")
    try:
        os.makedirs(new, exist_ok=True)
        test = os.path.join(new, ".designlab-test")
        with open(test, "w") as f:
            f.write("ok")
        os.remove(test)
    except OSError:
        raise ValueError("I couldn't make a folder there (no permission, or the drive isn't connected).")
    moved = 0
    with S.LOCK:
        if os.path.isdir(old):
            for name in os.listdir(old):
                src = os.path.join(old, name)
                dst = os.path.join(new, name)
                if name == ".designlab" and os.path.isdir(dst):
                    for f in os.listdir(src):        # merge our own settings folder
                        if not os.path.exists(os.path.join(dst, f)):
                            shutil.move(os.path.join(src, f), os.path.join(dst, f))
                    continue
                if os.path.exists(dst):
                    dst = S.unique_path(dst)
                shutil.move(src, dst)
                if name != ".designlab":
                    moved += 1
        cfg = S.config()
        cfg["projects_root"] = S.store_root(new)
        S.save_json(S.CONFIG_FILE, cfg)
    return new, moved


# ---------------------------------------------------------------- old folders: scan and copy in

def _count_files(folder, cap=50000):
    n = 0
    for _, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        n += sum(1 for f in files if not f.startswith(".") and f.lower() not in SKIP_FILES)
        if n >= cap:
            break
    return n


def scan_old(path):
    path = os.path.normpath(path.strip().strip('"'))
    if not os.path.isdir(path):
        return None
    subs = [d for d in sorted(os.listdir(path))
            if os.path.isdir(os.path.join(path, d)) and not d.startswith((".", "$")) and d.lower() != "system volume information"]
    root = os.path.normcase(os.path.normpath(S.projects_root() or ""))
    found = []
    if subs:
        for d in subs:
            full = os.path.join(path, d)
            if root and os.path.normcase(full).startswith(root):
                continue
            found.append({"name": d, "path": full, "files": _count_files(full)})
    else:
        found.append({"name": os.path.basename(path) or path, "path": path, "files": _count_files(path)})
    return [f for f in found if f["files"]]


def _target_for(rel_path, mtime):
    """Decide the Design Lab folder for an old file, using the file name AND the old folder names as hints."""
    name = os.path.basename(rel_path)
    hint = rel_path.replace("\\", " ").replace("/", " ")
    target = S.classify(hint, mtime)
    if target is None:
        target = S.classify(name, mtime)
    return target


def run_import(items, who):
    """Copy each old project folder into a new Design Lab project. Runs in the background."""
    try:                       # JOB_LOCK was taken in _start_import
        _run_import(items, who)
    finally:
        JOB_LOCK.release()


def _run_import(items, who):
    owner = {"id": "assistant", "name": who}
    summary = []
    st = None
    done_before = 0
    for it in items:
        try:
            proj = S.new_project({"name": it["name"]}, owner, imported_from=it["path"], quiet=True)
            pdir = proj["_dir"]
            counts, unsure, skipped, total = {}, 0, 0, 0
            known = set()
            for base, dirs, files in os.walk(it["path"]):
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for f in files:
                    if f.startswith(".") or f.lower() in SKIP_FILES or f.startswith("~$"):
                        continue
                    src = os.path.join(base, f)
                    rel = os.path.relpath(src, it["path"])
                    try:
                        target = _target_for(rel, os.path.getmtime(src))
                        folder = os.path.join(pdir, *(target or "00 Inbox").split("/"))
                        os.makedirs(folder, exist_ok=True)
                        dst = S.unique_path(os.path.join(folder, f))
                        shutil.copy2(src, dst)
                        known.add(os.path.relpath(dst, pdir).replace("\\", "/"))
                        top = (target or "00 Inbox").split("/")[0]
                        counts[top] = counts.get(top, 0) + 1
                        unsure += 0 if target else 1
                        total += 1
                    except OSError:
                        skipped += 1
                _progress(it["name"], done_before + total)
            done_before += total
            _save_known(pdir, known)
            with S.LOCK:
                proj = S.load_project(pdir)
                S.add_log(proj, "bot", f"Assistant copied {total} files in from {it['path']} (original folder untouched)")
                S.save_project(proj)
            summary.append((it, proj, counts, unsure, skipped, total))
            report("project", f"Project added by copying old folder ({total} files)", it["name"])
        except Exception as exc:
            summary.append((it, None, {}, 0, 0, 0))
            print("Assistant import:", exc)
    with S.LOCK:
        st = load()
        lines = []
        for it, proj, counts, unsure, skipped, total in summary:
            if not proj:
                lines.append(f"**{it['name']}**: I couldn't copy this one. Please check the folder and try again.")
                continue
            parts = [f"{n} {short(top, n)}" for top, n in sorted(counts.items()) if top != "00 Inbox"]
            line = f"**{it['name']}**: {total} files copied. " + (", ".join(parts) + "." if parts else "")
            if unsure:
                line += (f" {unsure} file{'s' if unsure != 1 else ''} I wasn't sure about {'are' if unsure != 1 else 'is'} "
                         "waiting in 00 Inbox for you to check.")
            if skipped:
                line += f" {skipped} couldn't be read (open in another program, or no permission)."
            lines.append(line)
        st.pop("job", None)
        st["imported"] += [it["path"] for it, proj, *_ in summary if proj]
        say(st, "All done. Your old folders are exactly as they were; everything was copied.\n\n" + "\n".join(lines) +
            "\n\nOpen **Projects** to see them. From now on, drop new files in a project's **00 Inbox** and I'll file them.")
        st["step"] = "ready"
        save(st)


def _progress(name, n):
    with S.LOCK:
        st = load()
        if st.get("job"):
            st["job"]["current"] = name
            st["job"]["files"] = n
            save(st)


def short(top, n=2):
    one, many = {"01 Drawings": ("drawing", "drawings"), "02 3D": ("3D file", "3D files"), "03 Site Photos": ("photo", "photos"),
                 "04 MOM": ("MOM", "MOMs"), "05 Snags": ("snag file", "snag files"), "06 Bills & Quotes": ("bill/quote", "bills/quotes"),
                 "07 Client Docs": ("document", "documents"), "08 Vendors": ("vendor file", "vendor files")}.get(top, (top, top))
    return one if n == 1 else many


# ---------------------------------------------------------------- wrong-folder watch

def _known_file(pdir):
    return os.path.join(pdir, ".designlab", "watch.json")


def _save_known(pdir, known):
    old = S.load_json(_known_file(pdir), {"known": []})
    S.save_json(_known_file(pdir), {"known": sorted(set(old.get("known", [])) | set(known))})


def watch():
    """Called every minute by the server. New files in a clearly wrong folder -> ask before moving."""
    with S.LOCK:            # never at the same time as moving the folders to a new place
        _watch()


def _watch():
    if not S.load_firm() or load().get("job"):
        return
    found = []
    for pdir in S.project_dirs():
        proj = S.load_project(pdir)
        if not proj:
            continue
        data = S.load_json(_known_file(pdir), None)
        first = data is None
        known = set((data or {}).get("known", []))
        now_files = set()
        for top in WATCH_TOPS + ("05 Snags", "07 Client Docs", "08 Vendors"):
            base = os.path.join(pdir, top)
            for b, dirs, files in os.walk(base):
                dirs[:] = [d for d in dirs if not d.startswith(".") and d != "Superseded"]
                for f in files:
                    if f.startswith(".") or f.lower() in SKIP_FILES or f.startswith("~$"):
                        continue
                    rel = os.path.relpath(os.path.join(b, f), pdir).replace("\\", "/")
                    if first or rel in known:
                        now_files.add(rel)
                        continue
                    try:
                        if time.time() - os.path.getmtime(os.path.join(b, f)) < 5:
                            continue   # still being copied: look again next minute
                    except OSError:
                        continue
                    now_files.add(rel)
                    cur = rel.split("/")[0]
                    sug = S.classify(f, os.path.getmtime(os.path.join(b, f)))
                    if not sug or cur not in WATCH_TOPS:
                        continue
                    sug_top = sug.split("/")[0]
                    if sug_top == cur or sug_top == "07 Client Docs" or {cur, sug_top} <= {"02 3D", "03 Site Photos"}:
                        continue
                    found.append({"pid": proj["id"], "project": proj["name"], "file": f, "rel": rel, "from": cur, "to": sug})
        S.save_json(_known_file(pdir), {"known": sorted(now_files)})
    if not found:
        return
    with S.LOCK:
        st = load()
        ids = []
        for fl in found:
            fid = secrets.token_hex(4)
            st["flags"][fid] = fl
            ids.append(fid)
        if len(found) == 1:
            fl = found[0]
            say(st, f"In **{fl['project']}**, “{fl['file']}” was put in **{fl['from']}**, but it looks like "
                    f"{LOOKS_LIKE.get(fl['to'].split('/')[0], 'something else')}. Shall I move it to **{fl['to'].split('/')[0]}**?",
                [{"label": "Yes, move it", "value": "fix:" + ids[0]}, {"label": "Leave it there", "value": "keep:" + ids[0]}])
        else:
            rows = "\n".join(f"• {fl['project']}: “{fl['file']}” is in {fl['from']}, looks like it belongs in {fl['to'].split('/')[0]}"
                             for fl in found[:12])
            more = f"\n…and {len(found) - 12} more." if len(found) > 12 else ""
            say(st, f"I think {len(found)} files went into the wrong folder:\n{rows}{more}\n\nShall I move them?",
                [{"label": f"Move all {len(found)}", "value": "fix:" + ",".join(ids)}, {"label": "Leave them", "value": "keep:" + ",".join(ids)}])
        save(st)


def fix_flags(st, ids, move):
    done = 0
    for fid in ids:
        fl = st["flags"].pop(fid, None)
        if not fl or not move:
            continue
        proj = S.find_project(fl["pid"])
        if not proj:
            continue
        pdir = proj["_dir"]
        src = os.path.join(pdir, *fl["rel"].split("/"))
        if not os.path.isfile(src):
            continue
        dst_dir = os.path.join(pdir, *fl["to"].split("/"))
        os.makedirs(dst_dir, exist_ok=True)
        dst = S.unique_path(os.path.join(dst_dir, fl["file"]))
        shutil.move(src, dst)
        _save_known(pdir, {os.path.relpath(dst, pdir).replace("\\", "/")})
        S.add_log(proj, "bot", f"Assistant moved “{fl['file']}” from {fl['from']} to {fl['to']} (you said yes)")
        S.save_project(proj)
        done += 1
    return done


# ---------------------------------------------------------------- conversation

def greet(st, user, firm):
    what = ("bring in your old files, and keep catalogs, photos and bills in the right place" if (firm or {}).get("kind") == "vendor"
            else "bring in your old projects, and keep everything in the right place")
    say(st, f"Hello {user['name'].split(' ')[0]}! I'm your Design Lab assistant. I'll set up your folders, {what}.\n\n"
            "First: **where should I keep your Design Lab folders?**", place_choices())
    st["step"] = "where"


def place_choices():
    ch = [{"label": p["label"], "value": "place:" + p["path"]} for p in places()]
    ch.append({"label": "Somewhere else (I'll type it)", "value": "place:?"})
    return ch


def ask_old(st):
    say(st, "Do you have **old project folders** you want to bring in? I'll copy them in and sort every file. "
            "Your old folders stay exactly as they are.",
        [{"label": "Yes, bring my old folders in", "value": "old:yes"}, {"label": "No, start fresh", "value": "old:no"}])
    st["step"] = "old"


def help_text():
    return ("Here's what I can do right now:\n"
            "• **bring old folders** – copy and sort your old projects\n"
            "• **new project Worli flat for Mr Shah** – make a project with all its folders\n"
            "• **find kitchen elevation** – find a file in any project\n"
            "• **sort my folders** or **sort Worli flat** – file everything waiting in 00 Inbox\n"
            "• **marble vendor** or **electrician** – find vendors and contractors\n"
            "• **change folder location** – move your Design Lab folders to another drive or the cloud\n"
            "I also watch your folders and tell you if a file goes into the wrong one.\n\n"
            "Talking freely (like ChatGPT) and reading inside files will come when the AI is switched on; "
            "that will be charged from your Design Lab balance, and I'll tell you the cost before doing anything.")


def _clear_stale(st):
    """A copy that stopped because Design Lab was closed: say so, and let them start again."""
    if st.get("job") and not JOB_LOCK.locked():
        st.pop("job", None)
        st["step"] = "ready"
        say(st, "The copying of your old folders stopped because Design Lab was closed. "
                "Type **bring old folders** to finish it (files already copied are kept).")
        return True
    return False


def state_for(user):
    with S.LOCK:
        st = load()
        if _clear_stale(st):
            save(st)
        firm = S.load_firm()
        if st["step"] == "start" and firm:
            if user.get("role") == "owner":
                greet(st, user, firm)
            else:
                say(st, f"Hello {user['name'].split(' ')[0]}! I'm the studio assistant. Type **help** to see what I can do.")
                st["step"] = "ready"
            save(st)
        return public(st, user)


def public(st, user):
    return {"messages": st["messages"][-120:], "step": st["step"], "job": st.get("job"),
            "owner": user.get("role") == "owner", "folder": S.projects_root()}


_REMOTE = {"owner": False}


def handle(user, text="", choice="", main=True):
    text = (text or "").strip()[:500]
    choice = (choice or "").strip()
    # folder changes (where folders live, bringing in old folders) only from the studio computer itself
    _REMOTE["owner"] = user.get("role") == "owner" and not main
    owner = user.get("role") == "owner" and main
    with S.LOCK:
        st = load()
        if text:
            say(st, text, frm="user", who=user["name"])
        elif choice:
            label = next((c["label"] for m in reversed(st["messages"]) for c in m.get("choices", []) if c["value"] == choice), choice)
            say(st, label, frm="user", who=user["name"])
        start_job = None
        try:
            start_job = _reply(st, user, owner, text, choice)
        except ValueError as e:
            say(st, str(e))
        ask = st.pop("_ask_ai", None)
        save(st)
        out = public(st, user)
        if ask:
            out["_ask_ai"] = ask
    if start_job:
        threading.Thread(target=run_import, args=(start_job, user["name"]), daemon=True).start()
    if out.get("_ask_ai"):
        q = out.pop("_ask_ai")
        try:
            r = S.ai_bot(S.load_firm(), user, "assistant", q)
            answer = r.get("answer") or ""
        except Exception:
            answer = ""
        with S.LOCK:
            st = load()
            if answer:
                say(st, answer + ("\n\n(answered by AI)" if r.get("ai") else ""))
            else:
                say(st, "I didn't understand that yet. " + help_text())
            save(st)
            out = public(st, user)
    return out


def _owner_only(st, owner):
    if not owner and _REMOTE["owner"]:
        say(st, "For safety, folder changes are done on the studio computer itself. Ask me there.")
    elif not owner:
        say(st, "Only the studio owner can change this. Ask them to do it from their dashboard.")
    return owner


def _reply(st, user, owner, text, choice):
    low = text.lower()
    # ---- buttons
    if choice.startswith("place:"):
        if not _owner_only(st, owner):
            return
        close_choices(st)
        path = choice[6:]
        if path == "?":
            say(st, "Type the full folder, for example **D:\\Design Lab Projects** or **G:\\My Drive\\Design Lab Projects**.")
            st["step"] = "where_type"
            return
        return _do_place(st, path)
    if choice.startswith("old:"):
        if not _owner_only(st, owner):
            return
        close_choices(st)
        if choice == "old:no":
            say(st, "Great, a fresh start. Make your first project with **+ New project** on the Today page, "
                    "or type it here, like **new project Worli flat for Mr Shah**. Type **help** any time.")
            st["step"] = "ready"
            return
        say(st, "Where are your old projects? Type the folder that holds them, for example **D:\\Projects** or "
                "**C:\\Users\\Aalok\\Documents\\Clients**.\n\nTip: open that folder in File Explorer, click the address bar at the top, "
                "copy it (Ctrl+C) and paste it here (Ctrl+V).")
        st["step"] = "old_path"
        return
    if choice.startswith("import:"):
        if not _owner_only(st, owner):
            return
        close_choices(st)
        if choice == "import:cancel":
            st.pop("pending_import", None)
            say(st, "OK, nothing copied. Type **bring old folders** whenever you're ready.")
            st["step"] = "ready"
            return
        if choice == "import:choose":
            names = ", ".join(i["name"] for i in st.get("pending_import", []))
            say(st, f"Type the names you want, separated by commas. For example: **{names[:80]}**")
            st["step"] = "old_pick"
            return
        return _start_import(st, st.get("pending_import", []))
    if choice.startswith("fix:") or choice.startswith("keep:"):
        close_choices_for(st, choice)
        ids = choice.split(":", 1)[1].split(",")
        n = fix_flags(st, ids, choice.startswith("fix:"))
        say(st, f"Done, moved {n} file{'s' if n != 1 else ''}. I've noted it in the project's activity." if choice.startswith("fix:")
            else "OK, I'll leave it where it is.")
        return
    if not text:
        return
    # ---- typed answers to a question
    looks_path = bool(re.match(r"^\s*\"?([a-zA-Z]:[\\/]|\\\\|/|~)", text))
    if st["step"] in ("where_type", "where") and owner and (looks_path or st["step"] == "where_type"):
        close_choices(st)
        return _do_place(st, text)
    if st.get("job"):
        say(st, "I'm still copying your old folders. I'll tell you here as soon as it's done.")
        return
    if st["step"] == "old_path" and owner and not looks_path and not re.search(r"\b(help|cancel|no)\b", low):
        say(st, "Please type the folder, starting with the drive letter, for example **D:\\Projects**. Or type **cancel**.")
        return
    if st["step"] == "old_path" and owner and re.search(r"\bcancel\b", low):
        say(st, "OK. Type **bring old folders** whenever you're ready.")
        st["step"] = "ready"
        return
    if st["step"] == "old_path" and owner and looks_path:
        found = scan_old(text)
        if found is None:
            say(st, "I can't find that folder on this computer. Please check the spelling, or copy it from the File Explorer address bar.")
            return
        if not found:
            say(st, "That folder has no files in it. Try the folder one level up, the one that holds all your projects.")
            return
        done = set(os.path.normcase(p) for p in st.get("imported", []))
        fresh = [f for f in found if os.path.normcase(f["path"]) not in done]
        if not fresh:
            say(st, "I've already copied all the projects in that folder.")
            st["step"] = "ready"
            return
        st["pending_import"] = fresh
        total = sum(f["files"] for f in fresh)
        rows = "\n".join(f"• {f['name']} — {f['files']} file{'s' if f['files'] != 1 else ''}" for f in fresh[:25])
        more = f"\n…and {len(fresh) - 25} more." if len(fresh) > 25 else ""
        say(st, f"I found **{len(fresh)} project{'s' if len(fresh) != 1 else ''}** ({total} files):\n{rows}{more}\n\n"
                "I'll make a Design Lab project for each, copy the files in and sort them. "
                "Your old folders stay exactly as they are. Sorting by file name and type is free.",
            [{"label": f"Copy all {len(fresh)}", "value": "import:all"}, {"label": "Let me choose", "value": "import:choose"},
             {"label": "Cancel", "value": "import:cancel"}])
        st["step"] = "old_confirm"
        return
    if st["step"] == "old_pick" and owner:
        want = [w.strip().lower() for w in re.split(r"[,\n]", text) if w.strip()]
        pick = [i for i in st.get("pending_import", []) if any(w in i["name"].lower() for w in want)]
        if not pick:
            say(st, "None of those names match. Please type them as they appear in the list.")
            return
        close_choices(st)
        return _start_import(st, pick)
    # ---- commands
    if re.search(r"\b(help|what can you do|hi|hello)\b", low):
        say(st, help_text())
        return
    m = re.match(r"^(?:new|create|make|start)\s+(?:a\s+)?project\s+(.+?)(?:\s+for\s+(.+))?$", text, re.IGNORECASE)
    if m:
        name, client = m.group(1).strip(" .\"'"), (m.group(2) or "").strip(" .\"'")
        proj = S.new_project({"name": name, "client": client}, user, quiet=True)
        report("project", f"Project added by {user['name']} (through the assistant)", name, client)
        say(st, f"Done: project **{proj['name']}**{' for ' + client if client else ''} is ready with all its folders. "
                "Open it from **Projects** to add the client, contractors and vendors.")
        return
    m = re.match(r"^(?:please\s+)?(?:sort|arrange|organi[sz]e|file)\b(.*)$", low)
    if m:
        return _sort(st, m.group(1))
    m = re.match(r"^(?:find|search|where is|where's|look for)\s+(?:the\s+)?(.+)$", low)
    if m:
        return _find_files(st, m.group(1))
    if re.search(r"(old|bring|import|transfer).*(folder|project)", low):
        if not _owner_only(st, owner):
            return
        st["step"] = "old"
        return _reply(st, user, owner, "", "old:yes")
    if re.search(r"(change|move).*(folder|location|drive)|where.*(keep|store).*folders", low):
        if not _owner_only(st, owner):
            return
        say(st, f"Your Design Lab folders are now in **{S.projects_root()}**. Where should they go? "
                "Everything will be moved there together.", place_choices())
        st["step"] = "where"
        return
    people = S.book_search(low)
    if people is not None:
        if people:
            rows = "\n".join(f"• **{p['name'] or p['company']}**{' (' + p['company'] + ')' if p['name'] and p['company'] else ''} — "
                             f"{p['trade'] or p['kind']}{' · ' + p['phone'] if p['phone'] else ''}{' · ' + p['email'] if p['email'] else ''}"
                             f"{' · ' + ', '.join(p['projects']) if p.get('projects') else ''}" for p in people[:10])
            say(st, f"Here's who I found:\n{rows}")
        else:
            say(st, "I couldn't find anyone like that. Add vendors and contractors in **Vendors & contractors**, or on a project.")
        return
    st["_ask_ai"] = text      # not a command I know: ask the AI assistant (outside the lock), or show help


def close_choices_for(st, choice):
    for m in st["messages"]:
        if any(c["value"] == choice for c in m.get("choices", [])):
            m["answered"] = True


def _do_place(st, path):
    if JOB_LOCK.locked():
        say(st, "I'm still copying your old folders. Ask me again when that's done.")
        return
    if not re.match(r"^([a-zA-Z]:[\\/]|\\\\|/|~)", path.strip().strip('"')):
        say(st, "Please type a full folder, starting with the drive, for example **D:\\Design Lab Projects**.")
        return
    try:
        new, moved = set_place(path)
    except ValueError as e:
        say(st, str(e) + " Choose another place:", place_choices())
        st["step"] = "where"
        return
    cloud = any(w in new.lower() for w in ("my drive", "google drive", "onedrive", "dropbox"))
    say(st, f"Done. Your Design Lab folders are in **{new}**" + (f" ({moved} project{'s' if moved != 1 else ''} moved there)" if moved else "") +
        (". Because it's a cloud folder, your files are also kept online." if cloud else "."))
    report("setup", f"Folders set to {new}")
    if st["step"] in ("where", "where_type") and not st.get("asked_old"):
        st["asked_old"] = True
        ask_old(st)
    else:
        st["step"] = "ready"


def _start_import(st, items):
    if not items:
        say(st, "There's nothing to copy.")
        st["step"] = "ready"
        return
    if not JOB_LOCK.acquire(blocking=False):   # released when the copy finishes
        say(st, "I'm already copying. I'll tell you when it's done.")
        return
    total = sum(i["files"] for i in items)
    st["job"] = {"status": "running", "projects": len(items), "total": total, "files": 0, "base": 0, "current": items[0]["name"]}
    st.pop("pending_import", None)
    st["step"] = "importing"
    say(st, f"Copying {len(items)} project{'s' if len(items) != 1 else ''} ({total} files) now. "
            "You can keep working; I'll write here when it's done.")
    return items


def _sort(st, rest):
    """'sort my folders' / 'sort Worli flat': file everything waiting in 00 Inbox (on the studio computer)."""
    words = [w for w in re.findall(r"[a-z0-9]+", rest) if w not in ("my", "the", "all", "folders", "folder", "files", "file", "inbox", "project", "projects", "please", "now", "this", "s")]
    projs = [S.load_project(d) for d in S.project_dirs()]
    projs = [p for p in projs if p]
    if words:
        pick = [p for p in projs if all(w in (p["name"] + " " + p.get("client", "")).lower() for w in words)]
        if not pick:
            say(st, f"I couldn't find a project called “{rest.strip()}”. Type **sort my folders** to sort every project.")
            return
        projs = pick
    moved, unsure, lines = 0, 0, []
    for p in projs:
        r = S.sort_project(p, "Assistant (asked)")
        moved += len(r["moved"])
        unsure += len(r["unsure"])
        if r["moved"] or r["unsure"]:
            lines.append(f"• {p['name']}: {len(r['moved'])} filed" + (f", {len(r['unsure'])} still in 00 Inbox (not sure)" if r["unsure"] else ""))
    if not lines:
        say(st, "Everything is already in place. Nothing was waiting in 00 Inbox.")
        return
    say(st, f"Done on the studio computer: {moved} file{'s' if moved != 1 else ''} filed.\n" + "\n".join(lines) +
        ("\nFiles I'm not sure about stay in 00 Inbox; open them on the studio computer, or rename them so I can tell what they are." if unsure else ""))


def _find_files(st, query):
    words = [w for w in re.split(r"\s+", query.lower()) if w and w not in ("the", "a", "file", "drawing", "of", "for", "in")]
    if not words:
        say(st, "What should I look for? For example **find kitchen elevation**.")
        return
    hits = []
    for pdir in S.project_dirs():
        proj = S.load_project(pdir)
        if not proj:
            continue
        for b, dirs, files in os.walk(pdir):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for f in files:
                lf = f.lower()
                if all(w in lf for w in words):
                    hits.append((os.path.getmtime(os.path.join(b, f)), proj["name"], os.path.relpath(b, pdir), f))
    hits.sort(reverse=True)
    if not hits:
        say(st, f"I couldn't find a file with “{query}” in its name.")
        return
    rows = "\n".join(f"• **{f}** — {p} › {d}" for _, p, d, f in hits[:10])
    say(st, f"Found {len(hits)} file{'s' if len(hits) != 1 else ''}, newest first:\n{rows}")
