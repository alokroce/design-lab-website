"""
Design Lab - simple records for the business side of a firm (kept on the studio computer).

Architects (Office -> Business):  hours, expenses, fees (password-locked)
Vendors (Showroom / Works):        architects, catalog, samples, quotes, orders, dispatch, site jobs, accounts
Both:                              private ledger (password-locked), Capture -> Social media board

Each kind is described once in SCHEMAS; the screens are drawn from that description,
so a list can be changed here without touching anything else.
Data: <Design Lab folders>/.designlab/records/<kind>.json   Photos: .../records/files/
"""
import base64
import os
import re
import secrets
import threading
import urllib.parse
import shutil
import time
from datetime import datetime

S = None   # server module (set by server.py)

T, N, D, SEL, AREA, FILE, MONEY, PHONE, EMAIL, PROJ = "text", "number", "date", "select", "area", "file", "money", "phone", "email", "project"
CYA = "cyarch"    # an architect in The Courtyard: the order's progress shows inside their project


def F(k, label, t=T, opts=None, wide=False, req=False):
    return {"k": k, "label": label, "t": t, "opts": opts or [], "wide": wide, "req": req}


SCHEMAS = {
    # ---------------- architect: Office -> Business
    "hours": {"side": "architect", "label": "Hours", "one": "time entry", "private": False,
              "fields": [F("date", "Date", D, req=True), F("person", "Who"), F("project", "Project", PROJ),
                         F("hours", "Hours", N, req=True), F("work", "What was done", T, wide=True)],
              "cols": ["date", "person", "project", "hours", "work"], "sum": "hours", "group": "project"},
    "expenses": {"side": "architect", "label": "Expenses", "one": "expense", "private": False,
                 "fields": [F("date", "Date", D, req=True), F("project", "Project (or office)", PROJ),
                            F("category", "Type", SEL, ["Site travel", "Printing", "Samples", "Office", "Software", "Food", "Other"]),
                            F("amount", "Amount (₹)", MONEY, req=True), F("paid_by", "Paid by"), F("bill", "Bill photo", FILE), F("note", "Note", T, wide=True)],
                 "cols": ["date", "project", "category", "amount", "paid_by"], "sum": "amount", "group": "project"},
    "fees": {"side": "architect", "label": "Fees", "one": "fee entry", "private": True,
             "fields": [F("date", "Date", D, req=True), F("project", "Project", PROJ, req=True), F("client", "Client"),
                        F("type", "Entry", SEL, ["Fee agreed", "Payment received", "Deduction"], req=True),
                        F("amount", "Amount (₹)", MONEY, req=True), F("mode", "How", SEL, ["Bank", "UPI", "Cheque", "Cash", "Other"]),
                        F("note", "Note", T, wide=True)],
             "cols": ["date", "project", "client", "type", "amount", "mode"], "group": "project"},
    # ---------------- both: private ledger
    "ledger": {"side": "both", "label": "Private book", "one": "entry", "private": True, "keep": True,
               "fields": [F("date", "Date", D, req=True), F("what", "What", SEL, ["Cash", "Commission", "Bill", "Cash note", "Other"], req=True),
                          F("party", "Name (person or firm)", T, req=True), F("bill_no", "Bill number"), F("project", "Project / reference"),
                          F("direction", "Money", SEL, ["Received", "Paid", "Just a note"], req=True), F("amount", "Amount (₹)", MONEY),
                          F("photo", "Photo of the bill", FILE), F("note", "Note", T, wide=True)],
               "cols": ["entry_no", "date", "what", "party", "bill_no", "direction", "amount"]},
    # ---------------- vendor: Showroom
    "v_architects": {"side": "vendor", "label": "Architects", "one": "architect", "private": False,
                     "fields": [F("name", "Architect / designer", T, req=True), F("firm", "Firm"), F("city", "City"), F("phone", "Phone", PHONE),
                                F("email", "Email", EMAIL), F("projects", "Their projects with you", T, wide=True),
                                F("specified", "What they specified", T, wide=True), F("last_contact", "Last spoke", D),
                                F("next_step", "Next step", T), F("note", "Notes", AREA, wide=True)],
                     "cols": ["name", "firm", "city", "phone", "last_contact", "next_step"]},
    "catalog": {"side": "vendor", "label": "Catalog", "one": "product", "private": False,
                "fields": [F("name", "Product", T, req=True), F("category", "Category"), F("code", "Code / SKU"), F("price", "Price (₹)", MONEY),
                           F("unit", "Per", SEL, ["sq ft", "sq m", "piece", "running ft", "metre", "set", "kg", "box"]),
                           F("stock", "In stock", N), F("lot", "Lot / shade / batch"), F("reserved", "Reserved for (project)"),
                           F("photo", "Photo", FILE), F("note", "Details", AREA, wide=True)],
                "cols": ["photo", "name", "category", "code", "price", "unit", "stock", "lot", "reserved"]},
    "samples": {"side": "vendor", "label": "Samples", "one": "sample", "private": False,
                "fields": [F("item", "Sample", T, req=True), F("architect", "To (architect / firm)", T, req=True), F("project", "For project"),
                           F("sent", "Sent on", D), F("follow_up", "Follow up on", D),
                           F("status", "Status", SEL, ["Sent", "Followed up", "Approved", "Not selected", "Returned", "Lost"]),
                           F("note", "Note", T, wide=True)],
                "cols": ["item", "architect", "project", "sent", "follow_up", "status"], "status": "status",
                "open": ["Sent", "Followed up"]},
    "quotes": {"side": "vendor", "label": "Quotes", "one": "quote", "private": False,
               "fields": [F("ref", "Quote no.", T), F("party", "For (architect / client)", T, req=True), F("project", "Project"),
                          F("date", "Date", D), F("amount", "Amount (₹)", MONEY), F("version", "Version", N),
                          F("status", "Status", SEL, ["Enquiry", "Quoted", "Revised", "Approved", "Lost"]),
                          F("file", "Quote file / photo", FILE), F("note", "Note", T, wide=True)],
               "cols": ["ref", "party", "project", "date", "amount", "version", "status"], "status": "status",
               "open": ["Enquiry", "Quoted", "Revised"], "sum": "amount"},
    "visits": {"side": "vendor", "label": "Showroom visits", "one": "visit", "private": False,
               "fields": [F("date", "Date", D, req=True), F("time", "Time"), F("architect", "Architect / designer", T, req=True), F("client", "With client"),
                          F("phone", "Phone", PHONE), F("looking_for", "Looking for", T, wide=True),
                          F("status", "Status", SEL, ["Booked", "Visited", "Follow up", "Cancelled"]), F("note", "Note", T, wide=True)],
               "cols": ["date", "time", "architect", "client", "looking_for", "status"], "status": "status", "open": ["Booked", "Follow up"]},
    # ---------------- vendor: Office (orders, logistics, accounts)
    "orders": {"side": "vendor", "label": "Orders", "one": "order", "private": False,
               "fields": [F("ref", "Order no.", T), F("party", "Architect / client", T, req=True), F("project", "Project / site"),
                          F("dl_architect", "Architect on Design Lab (they see this order's progress in their project)", CYA, wide=True),
                          F("items", "Items", T, wide=True), F("amount", "Amount (₹)", MONEY), F("due", "Promised date", D),
                          F("status", "Status", SEL, ["Confirmed", "In production", "Ready", "Dispatched", "Delivered", "Installed"]),
                          F("note", "Note", T, wide=True)],
               "cols": ["ref", "party", "project", "items", "amount", "due", "status"], "status": "status",
               "open": ["Confirmed", "In production", "Ready", "Dispatched"], "sum": "amount"},
    "dispatch": {"side": "vendor", "label": "Dispatch", "one": "dispatch", "private": False,
                 "fields": [F("order", "Order / items", T, req=True), F("date", "Date", D, req=True), F("slot", "Time slot"),
                            F("vehicle", "Vehicle no."), F("driver", "Driver"), F("driver_phone", "Driver phone", PHONE),
                            F("site", "Site address", T, wide=True), F("site_contact", "Site contact"), F("site_phone", "Site phone", PHONE),
                            F("loading", "Loading / unloading", SEL, ["Our team", "Site team", "Hired labour", "Not needed"]),
                            F("status", "Status", SEL, ["Planned", "Loaded", "On the way", "Delivered", "Problem"]),
                            F("received_by", "Received at site by"), F("pod", "Proof of delivery (photo)", FILE), F("note", "Note", T, wide=True)],
                 "cols": ["date", "slot", "order", "vehicle", "driver_phone", "site_contact", "status", "pod"], "status": "status",
                 "open": ["Planned", "Loaded", "On the way", "Problem"]},
    "sitejobs": {"side": "vendor", "label": "Site jobs", "one": "site job", "private": False,
                 "fields": [F("type", "Job", SEL, ["Measurement", "Installation", "Complaint / snag", "Service"], req=True),
                            F("site", "Site / project", T, req=True), F("date", "Date", D), F("team", "Team"),
                            F("contact", "Site contact", PHONE), F("status", "Status", SEL, ["Planned", "Done", "Pending", "Problem"]),
                            F("note", "Note", T, wide=True)],
                 "cols": ["date", "type", "site", "team", "contact", "status"], "status": "status", "open": ["Planned", "Pending", "Problem"]},
    "accounts": {"side": "vendor", "label": "Accounts", "one": "invoice", "private": False,
                 "fields": [F("ref", "Invoice no.", T, req=True), F("party", "Party", T, req=True), F("date", "Date", D),
                            F("amount", "Amount with GST (₹)", MONEY, req=True), F("received", "Received so far (₹)", MONEY),
                            F("due", "Due by", D), F("status", "Status", SEL, ["Due", "Part paid", "Paid"]), F("note", "Note", T, wide=True)],
                 "cols": ["ref", "party", "date", "amount", "received", "due", "status"], "status": "status", "open": ["Due", "Part paid"],
                 "sum": "amount"},
}

UNLOCKED = {}       # session token -> unlocked-until (epoch seconds)
UNLOCK_MINUTES = 15


# ---------------------------------------------------------------- storage

def _dir():
    return os.path.join(S.projects_root(), ".designlab", "records")


def _file(kind):
    return os.path.join(_dir(), kind + ".json")


def side_of(firm):
    return "vendor" if (firm or {}).get("kind") == "vendor" else "architect"


def schemas_for(firm):
    side = side_of(firm)
    return {k: v for k, v in SCHEMAS.items() if v["side"] in (side, "both")}


def can_private(firm, user):
    return user.get("role") == "owner" or user["id"] in (firm.get("private_access") or [])


def _k(token):
    """Unlocking belongs to one sign-in (kept by its file key, so files opened by link follow the same lock)."""
    t = str(token or "")
    return t[3:] if t.startswith("fk:") else (S.session_fk(t) or t)


def is_unlocked(token):
    t = UNLOCKED.get(_k(token))
    return bool(t) and t > time.time()


def unlock(firm, user, token, password):
    if not can_private(firm, user):
        raise S.ApiError(403, "Your studio owner hasn't given you access to private pages.")
    _, digest = S.hash_password(password or "", user["salt"])
    import hmac
    if not hmac.compare_digest(digest, user["hash"]):
        S.security_log("private pages: wrong password", user["id"])
        raise S.ApiError(401, "That password isn't right.")
    UNLOCKED[_k(token)] = time.time() + UNLOCK_MINUTES * 60
    S.security_log("private pages opened", user["id"])
    return {"unlocked": True, "minutes": UNLOCK_MINUTES}


# ---------------------------------------------------------------- the hidden private book
# The book's button only appears after the secret phrase (typed or spoken) is checked here;
# opening it still needs the person's own password. Nothing in the book is ever erased.
PHRASE_TRIES = {}


def _phrase_norm(p):
    return " ".join(re.sub(r"[^\w\s]", " ", str(p or "").lower()).split())


def phrase_status(firm, user):
    return {"set": bool(firm.get("book_phrase")), "owner": user.get("role") == "owner"}


def phrase_set(firm, user, password, phrase):
    if user.get("role") != "owner":
        raise S.ApiError(403, "Only the studio owner can set the secret phrase.")
    import hmac
    _, digest = S.hash_password(password or "", user["salt"])
    if not hmac.compare_digest(digest, user["hash"]):
        S.security_log("private book: wrong password when setting phrase", user["id"])
        raise S.ApiError(401, "That password isn't right.")
    p = _phrase_norm(phrase)
    if len(p) < 4:
        raise S.ApiError(400, "Choose a secret word or phrase of at least 4 letters.")
    salt, h = S.hash_password(p)
    firm["book_phrase"] = {"salt": salt, "hash": h, "set": S.now_iso()}
    S.save_json(S.firm_file(), firm)
    S.security_log("private book: secret phrase set", user["id"])
    return {"ok": True}


def phrase_check(firm, user, phrase):
    now = time.time()
    tries = [t for t in PHRASE_TRIES.get(user["id"], []) if now - t < 600]
    if len(tries) >= 10:
        raise S.ApiError(429, "Please wait a few minutes.")
    bp = firm.get("book_phrase")
    ok = False
    if bp and can_private(firm, user):
        import hmac
        _, h = S.hash_password(_phrase_norm(phrase), bp["salt"])
        ok = hmac.compare_digest(h, bp["hash"])
    if not ok:
        PHRASE_TRIES[user["id"]] = tries + [now]
    return {"show": ok}


def lock(token):
    UNLOCKED.pop(_k(token), None)
    return {"unlocked": False}


def guard(kind, firm, user, token):
    sc = schemas_for(firm).get(kind)
    if not sc:
        raise S.ApiError(404, "Unknown list.")
    if sc["private"] and not (can_private(firm, user) and is_unlocked(token)):
        raise S.ApiError(423, "This page is locked. Enter your password to open it.")
    return sc


def save_upload(data_url):
    m = re.match(r"^data:([\w/+.\-]+);base64,(.+)$", data_url or "", re.S)
    if not m:
        return ""
    ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "application/pdf": ".pdf"}.get(m.group(1))
    if not ext:
        raise S.ApiError(400, "Please add a photo or a PDF.")
    os.makedirs(os.path.join(_dir(), "files"), exist_ok=True)
    name = secrets.token_hex(10) + ext
    with open(os.path.join(_dir(), "files", name), "wb") as f:
        f.write(base64.b64decode(m.group(2)))
    return name


def file_for(name, firm, user, token):
    if not re.match(r"^[0-9a-f]{20}\.(jpg|png|webp|pdf)$", name or ""):
        return None
    # files of private lists are only served while unlocked
    for kind, sc in schemas_for(firm).items():
        if not sc["private"]:
            continue
        if any(name in (it.get(f["k"]) for f in sc["fields"] if f["t"] == FILE) for it in S.load_json(_file(kind), [])):
            if not (can_private(firm, user) and is_unlocked(token)):
                return None
    p = os.path.join(_dir(), "files", name)
    return p if os.path.isfile(p) else None


def num(v):
    try:
        return float(str(v).replace(",", "").strip() or 0)
    except ValueError:
        return 0.0


# ---------------------------------------------------------------- lists

def summary(kind, sc, items):
    out = {"count": len(items)}
    if sc.get("status"):
        counts = {}
        for it in items:
            counts[it.get(sc["status"]) or "—"] = counts.get(it.get(sc["status"]) or "—", 0) + 1
        out["by_status"] = counts
        out["open"] = sum(n for s_, n in counts.items() if s_ in sc.get("open", []))
    if sc.get("sum"):
        out["total"] = round(sum(num(it.get(sc["sum"])) for it in items), 2)
    if kind == "fees":
        per = {}
        for it in items:
            p = per.setdefault(it.get("project") or "—", {"agreed": 0, "received": 0, "deduction": 0})
            key = {"Fee agreed": "agreed", "Payment received": "received", "Deduction": "deduction"}.get(it.get("type"))
            if key:
                p[key] += num(it.get("amount"))
        for p in per.values():
            p["pending"] = round(p["agreed"] - p["received"] - p["deduction"], 2)
        out["projects"] = per
    if kind == "ledger":
        out["received"] = round(sum(num(i.get("amount")) for i in items if i.get("direction") == "Received"), 2)
        out["paid"] = round(sum(num(i.get("amount")) for i in items if i.get("direction") == "Paid"), 2)
    if kind == "accounts":
        out["pending"] = round(sum(num(i.get("amount")) - num(i.get("received")) for i in items if i.get("status") != "Paid"), 2)
    return out


def _book_meta():
    return S.load_json(os.path.join(_dir(), "ledger_meta.json"), {"entry": 0, "bill": {}})


def _book_next(meta, what):
    if what == "entry":
        meta["entry"] = meta.get("entry", 0) + 1
        return f"PB-{meta['entry']:04d}"
    yr = datetime.now().strftime("%Y")
    meta.setdefault("bill", {})[yr] = meta.get("bill", {}).get(yr, 0) + 1
    return f"B-{yr}-{meta['bill'][yr]:04d}"


def _book_number(items):
    """Every entry has its own number, in the order it was written. Older entries are numbered once."""
    meta, changed = _book_meta(), False
    for it in sorted(items, key=lambda x: x.get("created", "")):
        if not it.get("entry_no"):
            it["entry_no"] = _book_next(meta, "entry")
            changed = True
    if changed:
        S.save_json(os.path.join(_dir(), "ledger_meta.json"), meta)
    return changed


def list_kind(kind, firm, user, token):
    sc = guard(kind, firm, user, token)
    items = S.load_json(_file(kind), [])
    if kind == "ledger":
        if _book_number(items):
            S.save_json(_file(kind), items)
        bal = 0.0          # running balance, like an account book: money received minus money paid
        for it in sorted(items, key=lambda x: (x.get("date") or "", x.get("created", ""))):
            if it.get("direction") == "Received":
                bal += num(it.get("amount"))
            elif it.get("direction") == "Paid":
                bal -= num(it.get("amount"))
            it["balance"] = round(bal, 2)
    items.sort(key=lambda it: (it.get("date") or it.get("sent") or it.get("due") or "", it.get("created", "")), reverse=True)
    return {"kind": kind, "schema": sc, "items": items, "summary": summary(kind, sc, items)}


def save_item(kind, firm, user, token, item):
    sc = guard(kind, firm, user, token)
    items = S.load_json(_file(kind), [])
    clean = {}
    for f in sc["fields"]:
        v = item.get(f["k"])
        if f["t"] == FILE:
            if isinstance(v, str) and v.startswith("data:"):
                v = save_upload(v)
            elif not (isinstance(v, str) and re.match(r"^[0-9a-f]{20}\.\w+$", v or "")):
                v = ""
        elif f["t"] in (N, MONEY):
            v = "" if v in (None, "") else num(v)
        else:
            v = str(v or "").strip()[:1000 if f["t"] == AREA else 300]
        if f["req"] and v in ("", None):
            raise S.ApiError(400, f"Please fill in: {f['label']}.")
        clean[f["k"]] = v
    iid = item.get("id")
    old = next((x for x in items if x["id"] == iid), None) if iid else None
    st_key = sc.get("status")
    if st_key and clean.get(st_key) and (not old or old.get(st_key) != clean.get(st_key)):
        # every status change is kept with time and person — this is how orders and deliveries are traced
        hist = (old or {}).get("history", [])
        clean["history"] = [{"status": clean[st_key], "time": S.now_iso(), "by": user["name"]}] + hist[:49]
    if old and sc.get("keep"):
        clean["versions"] = ([{k: v for k, v in old.items() if k != "versions"}] + old.get("versions", []))[:50]
    if old:
        old.update(clean)
        old["edited"] = S.now_iso()
        old["edited_by"] = user["name"]
    else:
        clean.update({"id": secrets.token_hex(5), "created": S.now_iso(), "by": user["name"]})
        if kind == "ledger":
            _book_number(items)             # older entries are numbered first, so numbers follow the order they were written
            meta = _book_meta()
            clean["entry_no"] = _book_next(meta, "entry")
            S.save_json(os.path.join(_dir(), "ledger_meta.json"), meta)
        items.append(clean)
    S.save_json(_file(kind), items)
    if kind in ("orders", "dispatch"):
        _share_order(kind, old or clean, firm, user)
    if sc["private"]:
        S.security_log(f"private page '{sc['label']}' changed", user["id"])
    return list_kind(kind, firm, user, token)


def _share_order(kind, it, firm, user):
    """Send an order's progress to the architect's Design Lab (through The Courtyard). Runs in the background."""
    if kind == "dispatch":
        txt = (it.get("order") or "").lower()
        order = next((o for o in S.load_json(_file("orders"), []) if o.get("dl_architect") and o.get("ref") and o["ref"].lower() in txt), None)
        disp = {k: it.get(k, "") for k in ("date", "slot", "vehicle", "driver", "status", "received_by")}
    else:
        order, disp = it, None
    if not order or not order.get("dl_architect") or not S.cloud_cfg(firm).get("url"):
        return
    if disp is None:
        ds = [d for d in S.load_json(_file("dispatch"), []) if order.get("ref") and order["ref"].lower() in (d.get("order") or "").lower()]
        ds.sort(key=lambda d: d.get("date", ""), reverse=True)
        disp = {k: ds[0].get(k, "") for k in ("date", "slot", "vehicle", "driver", "status", "received_by")} if ds else {}
    body = {"to": order["dl_architect"], "ref": order.get("ref") or order["id"], "item": order.get("items", ""), "project": order.get("project", ""),
            "status": order.get("status", ""), "eta": order.get("due", ""), "history": order.get("history", [])[:12], "dispatch": disp}
    hdr = {"X-User-Id": urllib.parse.quote(user["id"]), "X-User-Name": urllib.parse.quote(user["name"]), "X-User-Role": user.get("role", "")}

    def go():
        try:
            S.cloud_call(firm, "/api/studio/courtyard/order-share", body, headers=hdr)
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def make_bill(firm, user, token, body):
    """A bill made in the app: numbered, printable, and written into the private book as an entry."""
    guard("ledger", firm, user, token)
    party = str(body.get("party") or "").strip()[:120]
    if not party:
        raise S.ApiError(400, "Write who the bill is for.")
    lines = []
    for x in (body.get("items") or [])[:40]:
        desc = str(x.get("desc") or "").strip()[:200]
        qty, rate = num(x.get("qty") or 1), num(x.get("rate"))
        if desc and rate:
            lines.append({"desc": desc, "qty": qty, "rate": rate, "amount": round(qty * rate, 2)})
    if not lines:
        raise S.ApiError(400, "Add at least one line with a description and a rate.")
    sub = round(sum(l["amount"] for l in lines), 2)
    gst_pct = max(0.0, min(28.0, num(body.get("gst_pct")))) if body.get("gst") else 0.0
    gst = round(sub * gst_pct / 100, 2)
    direction = "Paid" if body.get("direction") == "Paid" else "Received"
    meta = _book_meta()
    bill_no = _book_next(meta, "bill")
    S.save_json(os.path.join(_dir(), "ledger_meta.json"), meta)
    date = str(body.get("date") or "")[:10] or S.today_iso()
    bill = {"no": bill_no, "date": date, "party": party, "phone": str(body.get("phone") or "")[:30],
            "address": str(body.get("address") or "")[:200], "lines": lines, "subtotal": sub, "gst_pct": gst_pct, "gst": gst,
            "total": round(sub + gst, 2), "direction": direction, "note": str(body.get("note") or "")[:300],
            "from": firm.get("firm", ""), "by": user["name"], "made": S.now_iso()}
    save_item("ledger", firm, user, token, {"date": date, "what": "Bill", "party": party, "bill_no": bill_no, "direction": direction,
                                             "amount": bill["total"], "note": bill["note"], "project": str(body.get("project") or "")[:120]})
    items = S.load_json(_file("ledger"), [])
    it = next((x for x in items if x.get("bill_no") == bill_no), None)
    if it:
        it["bill"] = bill
        S.save_json(_file("ledger"), items)
    S.security_log(f"private book: bill {bill_no} made", user["id"])
    out = list_kind("ledger", firm, user, token)
    out["bill"] = bill
    return out


def delete_item(kind, firm, user, token, iid):
    sc = guard(kind, firm, user, token)
    if sc.get("keep"):
        raise S.ApiError(400, "Entries in the private book are never erased. Edit the entry, or add a correcting entry.")
    items = [x for x in S.load_json(_file(kind), []) if x["id"] != iid]
    S.save_json(_file(kind), items)
    return list_kind(kind, firm, user, token)


UPDATE_KINDS = {"orders": ("Order", "ref", "party"), "dispatch": ("Delivery", "order", "site_contact"), "samples": ("Sample", "item", "architect"),
                "quotes": ("Quote", "ref", "party"), "sitejobs": ("Site job", "type", "site"), "visits": ("Showroom visit", "architect", "client")}


def vendor_updates(limit=60):
    """Everything the Office did (orders, deliveries, samples…) as one feed for the Showroom."""
    out = []
    for kind, (label, a, b) in UPDATE_KINDS.items():
        for it in S.load_json(_file(kind), []):
            for h in it.get("history", [])[:6]:
                out.append({"time": h["time"], "kind": kind, "what": label, "title": " · ".join(x for x in (str(it.get(a) or ""), str(it.get(b) or "")) if x),
                            "status": h["status"], "by": h.get("by", ""), "pod": it.get("pod") if kind == "dispatch" and h["status"] == "Delivered" else ""})
    out.sort(key=lambda x: x["time"], reverse=True)
    return out[:limit]


def vendor_today(firm, user, token):
    today = datetime.now().strftime("%Y-%m-%d")
    L = lambda k: S.load_json(_file(k), [])
    samples = [s for s in L("samples") if s.get("status") in ("Sent", "Followed up") and (s.get("follow_up") or "9999") <= today]
    quotes = [q for q in L("quotes") if q.get("status") in ("Enquiry", "Quoted", "Revised")]
    orders = L("orders")
    dispatch = [d for d in L("dispatch") if d.get("date") == today or d.get("status") == "Problem"]
    accounts = [a for a in L("accounts") if a.get("status") != "Paid"]
    overdue = [a for a in accounts if a.get("due") and a["due"] < today]
    jobs = [j for j in L("sitejobs") if j.get("date") == today or j.get("status") == "Problem"]
    stage = {}
    for o in orders:
        stage[o.get("status") or "—"] = stage.get(o.get("status") or "—", 0) + 1
    visits = [v for v in L("visits") if v.get("date") == today or v.get("status") == "Follow up"]
    return {"visits_today": visits[:10], "updates": vendor_updates(8), "samples_due": samples[:10], "quotes_open": len(quotes), "quotes_value": round(sum(num(q.get("amount")) for q in quotes), 2),
            "orders_by_stage": stage, "dispatch_today": dispatch[:10], "jobs_today": jobs[:10],
            "pending": round(sum(num(a.get("amount")) - num(a.get("received")) for a in accounts), 2),
            "overdue": [{"ref": a.get("ref"), "party": a.get("party"), "due": a.get("due"),
                         "left": round(num(a.get("amount")) - num(a.get("received")), 2)} for a in overdue][:10],
            "architects": len(L("v_architects")), "products": len(L("catalog"))}


def business_overview(firm, user, token):
    """Hours and expenses per project (+ fees when unlocked) -> what each project really earns."""
    hours = S.load_json(_file("hours"), [])
    exp = S.load_json(_file("expenses"), [])
    per = {}
    for h in hours:
        per.setdefault(h.get("project") or "Office", {"hours": 0, "expenses": 0})["hours"] += num(h.get("hours"))
    for e in exp:
        per.setdefault(e.get("project") or "Office", {"hours": 0, "expenses": 0})["expenses"] += num(e.get("amount"))
    unlocked = can_private(firm, user) and is_unlocked(token)
    if unlocked:
        fees = summary("fees", SCHEMAS["fees"], S.load_json(_file("fees"), [])).get("projects", {})
        for p, f in fees.items():
            row = per.setdefault(p, {"hours": 0, "expenses": 0})
            row.update(f)
            row["profit"] = round(f["received"] - row["expenses"], 2)
    month = datetime.now().strftime("%Y-%m")
    return {"projects": per, "unlocked": unlocked, "can_private": can_private(firm, user),
            "month_hours": round(sum(num(h.get("hours")) for h in hours if (h.get("date") or "").startswith(month)), 1),
            "month_expenses": round(sum(num(e.get("amount")) for e in exp if (e.get("date") or "").startswith(month)), 2)}


# ---------------------------------------------------------------- Capture -> Social media board / project / bills

SOCIAL = "Social Media"
IMG = (".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp")
VID = (".mp4", ".mov", ".m4v", ".3gp", ".avi", ".webm")


def social_root():
    return os.path.join(S.projects_root(), SOCIAL)


def capture(firm, user, body):
    """A photo / video / bill from the phone, filed on the studio computer where the owner said."""
    name = os.path.basename(str(body.get("name") or "capture")).strip() or "capture"
    m = re.match(r"^data:([\w/+.\-]*);base64,(.+)$", body.get("data") or "", re.S)
    if not m:
        raise S.ApiError(400, "Please choose a photo, video or file.")
    raw = base64.b64decode(m.group(2))
    stem, ext = os.path.splitext(name)
    S.safe_ext(name, "")                   # never save a file that could run a program
    if not ext:
        ext = {"image/jpeg": ".jpg", "image/png": ".png", "video/mp4": ".mp4", "video/quicktime": ".mov", "application/pdf": ".pdf"}.get(m.group(1), "")
    stamp = datetime.now().strftime("%Y-%m-%d %H%M%S")
    fname = S.safe_name(f"{stamp} {stem}")[:90] + ext.lower()
    note = str(body.get("note") or "").strip()[:300]
    to = body.get("to") or "social"
    if to == "social":
        kind = "Videos" if ext.lower() in VID else ("Photos" if ext.lower() in IMG else "Other")
        folder = os.path.join(social_root(), "To review", kind)
    elif to == "bills":
        folder = os.path.join(S.projects_root(), "Bills", datetime.now().strftime("%Y-%m"))
    elif to == "project":
        proj = S.find_project(str(body.get("project") or ""))
        if not proj:
            raise S.ApiError(400, "Choose the project.")
        folder = os.path.join(proj["_dir"], "00 Inbox")      # the Folder Bot files it from here
    else:
        raise S.ApiError(400, "Choose where it goes.")
    os.makedirs(folder, exist_ok=True)
    path = S.unique_path(os.path.join(folder, fname))
    with open(path, "wb") as f:
        f.write(raw)
    if note:
        notes = S.load_json(os.path.join(social_root(), ".notes.json"), {}) if to == "social" else None
        if notes is not None:
            notes[os.path.relpath(path, social_root()).replace("\\", "/")] = note
            S.save_json(os.path.join(social_root(), ".notes.json"), notes)
    if to == "project":
        p = S.find_project(str(body.get("project")))
        S.add_log(p, "bot", f"{user['name']} sent “{fname}” from the phone (Capture){' — ' + note if note else ''}")
        S.save_project(p)
        S.sort_project(S.find_project(str(body.get("project"))), "Folder Bot (capture)")
    where = {"social": "Social media board › To review", "bills": "Bills", "project": "the project"}[to]
    return {"ok": True, "saved": where, "file": os.path.basename(path)}


SOCIAL_BASE = ["To review", "Wanted", "Not wanted", "Posted"]


def social_folders():
    """The four standard places plus the folders the studio made itself (e.g. Diwali 2026, Project reels)."""
    extra = S.load_json(os.path.join(social_root(), ".folders.json"), [])
    return SOCIAL_BASE + [f for f in extra if f not in SOCIAL_BASE]


def social_folder_new(name):
    name = re.sub(r"[\\/:*?\"<>|.]+", " ", str(name or "")).strip()[:40]
    if len(name) < 2:
        raise S.ApiError(400, "Give the folder a name.")
    root = social_root()
    extra = S.load_json(os.path.join(root, ".folders.json"), [])
    if name.lower() in (f.lower() for f in social_folders()):
        raise S.ApiError(409, "There is already a folder with that name.")
    os.makedirs(os.path.join(root, name), exist_ok=True)
    S.save_json(os.path.join(root, ".folders.json"), extra + [name])
    return social_board()


def social_folder_remove(name):
    """Only an empty folder can be removed — files are never deleted from here."""
    root = social_root()
    extra = S.load_json(os.path.join(root, ".folders.json"), [])
    if name not in extra:
        raise S.ApiError(404, "That folder isn't one you made.")
    base = os.path.join(root, name)
    if os.path.isdir(base) and any(f for _, _, fs in os.walk(base) for f in fs if not f.startswith(".")):
        raise S.ApiError(400, "Move the files out first — a folder with files in it can't be removed.")
    S.save_json(os.path.join(root, ".folders.json"), [f for f in extra if f != name])
    return social_board()


def social_board():
    root = social_root()
    notes = S.load_json(os.path.join(root, ".notes.json"), {})
    out = []
    for bucket in social_folders():
        base = os.path.join(root, bucket)
        if not os.path.isdir(base):
            continue
        for b, dirs, files in os.walk(base):
            for f in files:
                if f.startswith("."):
                    continue
                full = os.path.join(b, f)
                rel = os.path.relpath(full, root).replace("\\", "/")
                ext = os.path.splitext(f)[1].lower()
                out.append({"rel": rel, "name": f, "bucket": bucket, "kind": "video" if ext in VID else ("photo" if ext in IMG else "file"),
                            "time": datetime.fromtimestamp(os.path.getmtime(full)).isoformat(timespec="seconds"),
                            "size": os.path.getsize(full), "note": notes.get(rel, "")})
    out.sort(key=lambda x: x["time"], reverse=True)
    counts = {}
    for x in out:
        counts[x["bucket"]] = counts.get(x["bucket"], 0) + 1
    return {"items": out[:400], "counts": counts, "folder": root, "folders": social_folders(), "base": SOCIAL_BASE}


def social_move(rel, bucket):
    if bucket not in social_folders():
        raise S.ApiError(400, "Unknown place.")
    root = social_root()
    src = os.path.normpath(os.path.join(root, rel))
    if not src.startswith(os.path.normpath(root)) or not os.path.isfile(src):
        raise S.ApiError(404, "That file has moved.")
    parts = rel.split("/")
    kind = parts[1] if len(parts) > 2 else "Other"
    dst_dir = os.path.join(root, bucket, kind)
    os.makedirs(dst_dir, exist_ok=True)
    dst = S.unique_path(os.path.join(dst_dir, os.path.basename(src)))
    shutil.move(src, dst)
    notes = S.load_json(os.path.join(root, ".notes.json"), {})
    if rel in notes:
        notes[os.path.relpath(dst, root).replace("\\", "/")] = notes.pop(rel)
        S.save_json(os.path.join(root, ".notes.json"), notes)
    return social_board()


def social_file(rel):
    root = social_root()
    p = os.path.normpath(os.path.join(root, rel))
    return p if S.inside(root, p) and os.path.isfile(p) else None
