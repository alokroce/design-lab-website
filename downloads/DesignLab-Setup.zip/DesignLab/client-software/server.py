"""
Design Lab — local studio server (prototype v0.1)

Runs on the studio's own computer. Uses only Python's standard library:
nothing to install, no internet needed, no paid services.

  * Serves the Design Lab app to this computer and to phones on the same Wi-Fi.
  * Creates a standard folder tree for every project on THIS computer.
  * The Folder Bot keeps each project's "00 Inbox" sorted by rules.
  * Site notes, photos, rooms, snags, meetings and MOMs are saved inside the
    project's own folder (project.json + real files), so the data never leaves.

Start it with start.bat (Windows) or:  python server.py
"""

import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import shutil
import socket
import sys
import threading
import time
import urllib.parse
from datetime import datetime, date
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

APP_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(APP_DIR, "web")
DEMO = bool(os.environ.get("DESIGNLAB_DEMO"))          # the shared demo copy (see demo.py)
HOME_DIR = os.environ.get("DESIGNLAB_HOME") or APP_DIR   # where this copy keeps its settings and folders
os.makedirs(HOME_DIR, exist_ok=True)
CONFIG_FILE = os.path.join(HOME_DIR, "designlab_config.json")
PORT = int(os.environ.get("DESIGNLAB_PORT", "8750"))
VERSION = "0.1"

LOCK = threading.RLock()

# ---------------------------------------------------------------- folders

FOLDER_TREE = [
    "00 Inbox",
    "01 Drawings/Plans", "01 Drawings/Elevations", "01 Drawings/Sections",
    "01 Drawings/Details", "01 Drawings/Ceiling", "01 Drawings/Electrical",
    "01 Drawings/Plumbing", "01 Drawings/Working", "01 Drawings/Superseded", "01 Drawings/Site corrections",
    "02 3D/Models", "02 3D/Renders",
    "03 Site Photos",
    "04 MOM",
    "05 Snags",
    "06 Bills & Quotes",
    "07 Client Docs",
    "08 Vendors",
    "09 Mood Board",
    "10 Gallery/For selection", "10 Gallery/Selected", "10 Gallery/Reference images", "10 Gallery/Rooms", "10 Gallery/Random",
]

TOP_FOLDERS = ["00 Inbox", "01 Drawings", "02 3D", "03 Site Photos", "04 MOM",
               "05 Snags", "06 Bills & Quotes", "07 Client Docs", "08 Vendors", "09 Mood Board", "10 Gallery"]


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def today_iso():
    return date.today().isoformat()


def inside(base, full):
    """True only if 'full' is inside the folder 'base' (not a look-alike folder next to it)."""
    base = os.path.normcase(os.path.normpath(base))
    full = os.path.normcase(os.path.normpath(full))
    return full == base or full.startswith(base.rstrip("\\/") + os.sep)


RISKY_EXT = {".exe", ".bat", ".cmd", ".com", ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh", ".msi", ".msp",
             ".scr", ".lnk", ".hta", ".cpl", ".dll", ".jar", ".reg", ".url", ".pif", ".gadget", ".application", ".html", ".htm",
             ".svg", ".xhtml", ".mht", ".sh", ".py", ".pyw"}


def safe_ext(name, fallback=".jpg"):
    """File types that could run programs are never saved from an upload."""
    ext = os.path.splitext(str(name or ""))[1].lower()
    if ext in RISKY_EXT:
        raise ApiError(400, "That kind of file can't be added (it could run a program). Use a photo, PDF, drawing or document.")
    return ext or fallback


def safe_name(text, fallback="Untitled"):
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", str(text or "")).strip().strip(".")
    text = re.sub(r"\s+", " ", text)
    return text[:80] or fallback


def unique_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{base} ({n}){ext}"):
        n += 1
    return f"{base} ({n}){ext}"


# ---------------------------------------------------------------- config / firm

def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(path, data):
    if isinstance(data, dict) and "_real_kind" in data:   # demo vendor view: never store the borrowed kind
        data = dict(data)
        data["kind"] = data.pop("_real_kind")
        data["firm"] = data.pop("_real_firm", data.get("firm"))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def config():
    return load_json(CONFIG_FILE, {})


SYSTEM_DIR = HOME_DIR   # the client software's own folder: projects live inside it, so it can be moved


# ---------------------------------------------------------------- security

SESSIONS_FILE = os.path.join(HOME_DIR, "designlab_sessions.json")
FAILS = {}          # identifier -> list of failed attempt times
LOCK_TRIES, LOCK_MINUTES = 5, 15


def password_problem(pw):
    if len(pw or "") < 8:
        return "Password must be at least 8 characters."
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"[0-9]", pw):
        return "Password must have both letters and numbers."
    return None


def norm_phone(p):
    d = re.sub(r"\D", "", p or "")
    return d[-10:] if len(d) >= 10 else d


def norm_email(e):
    return (e or "").strip().lower()


def sessions():
    data = load_json(SESSIONS_FILE, {})
    now = time.time()
    return {t: s for t, s in data.items() if s.get("exp", 0) > now and len(t) == 64}   # only fingerprints (older plain entries are dropped)


def _fp(tok):
    """Sign-ins are stored only as a fingerprint: someone who copies the sessions file can't use it."""
    return hashlib.sha256(("dl-session:" + str(tok or "")).encode()).hexdigest()


def session_new(uid, remember=True):
    data = sessions()
    tok = secrets.token_urlsafe(32)
    data[_fp(tok)] = {"uid": uid, "exp": time.time() + (30 * 86400 if remember else 12 * 3600), "made": now_iso(),
                      "fk": secrets.token_urlsafe(18)}
    save_json(SESSIONS_FILE, data)
    return tok


def session_uid(tok):
    if not tok:
        return None
    s = sessions().get(_fp(tok))
    return s["uid"] if s else None


def session_fk(tok):
    s = sessions().get(_fp(tok)) if tok else None
    return (s or {}).get("fk", "")


def uid_from_fk(fk):
    """Pictures and files are opened with a separate 'file key', so the sign-in itself never appears in a link."""
    if not fk or len(fk) < 16:
        return None
    for s in sessions().values():
        if s.get("fk") and hmac.compare_digest(s["fk"], fk):
            return s["uid"]
    return None


def session_end(tok=None, uid=None):
    data = sessions()
    fp = _fp(tok) if tok else None
    data = {t: s for t, s in data.items() if t != fp and (uid is None or s["uid"] != uid)}
    save_json(SESSIONS_FILE, data)


def security_log(event, who="", ip=""):
    root = projects_root()
    if not root:
        return
    try:
        os.makedirs(os.path.join(root, ".designlab"), exist_ok=True)
        with open(os.path.join(root, ".designlab", "security.log"), "a", encoding="utf-8") as f:
            f.write(json.dumps({"time": now_iso(), "event": event, "who": who, "ip": ip}) + "\n")
    except OSError:
        pass


def read_security_log(n=60):
    root = projects_root()
    try:
        with open(os.path.join(root, ".designlab", "security.log"), encoding="utf-8") as f:
            lines = f.readlines()[-n:]
        return [json.loads(x) for x in reversed(lines)]
    except (OSError, ValueError, TypeError):
        return []


def locked_out(ident):
    now = time.time()
    tries = [t for t in FAILS.get(ident, []) if now - t < LOCK_MINUTES * 60]
    FAILS[ident] = tries
    if len(tries) >= LOCK_TRIES:
        return int((LOCK_MINUTES * 60 - (now - tries[0])) // 60) + 1
    return 0


def find_user(firm, ident):
    ident = (ident or "").strip()
    if not ident:
        return None
    low, ph = ident.lower(), norm_phone(ident)
    for u in firm.get("users", []):
        if u["id"] == low or (u.get("email") and u["email"] == low) or (len(ph) >= 10 and u.get("phone") and norm_phone(u["phone"]) == ph):
            return u
    return None


def contact_taken(firm, phone, email, except_id=None):
    for u in firm.get("users", []):
        if u["id"] == except_id:
            continue
        if email and u.get("email") == norm_email(email):
            return "That email is already used by another user."
        if phone and u.get("phone") and norm_phone(u["phone"]) == norm_phone(phone):
            return "That phone number is already used by another user."
    return None


def cloud_url():
    return os.environ.get("DESIGNLAB_CLOUD_URL") or config().get("cloud_url") or "http://localhost:8800"


def projects_root():
    """Projects live inside the Design Lab folder unless the owner chose an outside folder."""
    root = config().get("projects_root")
    if not root:
        return None
    return root if os.path.isabs(root) else os.path.normpath(os.path.join(SYSTEM_DIR, root))


def store_root(path):
    """Save the projects folder relative to the Design Lab folder when it is inside it (portable)."""
    full = os.path.normpath(os.path.abspath(path))
    try:
        rel = os.path.relpath(full, SYSTEM_DIR)
    except ValueError:  # different drive on Windows
        return full
    return full if rel.startswith("..") else rel


def firm_file():
    root = projects_root()
    return os.path.join(root, ".designlab", "firm.json") if root else None


def testing_mode():
    """While testing, a new studio can be registered on a computer that already has one (old one goes to a backup).
    Before launch set "testing_mode": false in designlab_config.json."""
    return config().get("testing_mode", True)


def load_firm():
    f = firm_file()
    return load_json(f, None) if f else None


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 120_000)
    return salt, digest.hex()


def default_root():
    return os.path.join(SYSTEM_DIR, "projects")


# ---------------------------------------------------------------- projects

def project_dirs():
    root = projects_root()
    if not root or not os.path.isdir(root):
        return []
    out = []
    for name in sorted(os.listdir(root)):
        p = os.path.join(root, name)
        if os.path.isfile(os.path.join(p, ".designlab", "project.json")):
            out.append(p)
    return out


def project_file(pdir):
    return os.path.join(pdir, ".designlab", "project.json")


def load_project(pdir):
    data = load_json(project_file(pdir), None)
    if data is not None:
        data["_dir"] = pdir
    return data


def save_project(proj):
    pdir = proj.pop("_dir")
    try:
        save_json(project_file(pdir), proj)
    finally:
        proj["_dir"] = pdir


def find_project(pid):
    for pdir in project_dirs():
        proj = load_project(pdir)
        if proj and proj.get("id") == pid:
            return proj
    return None


def ensure_tree(pdir):
    for rel in FOLDER_TREE:
        os.makedirs(os.path.join(pdir, *rel.split("/")), exist_ok=True)


def folder_summary(pdir):
    out = []
    for top in TOP_FOLDERS:
        p = os.path.join(pdir, top)
        count = 0
        if os.path.isdir(p):
            for _, _, files in os.walk(p):
                count += sum(1 for f in files if not f.startswith("."))
        out.append({"name": top, "files": count})
    return out


def public_project(proj, full=False):
    p = {k: v for k, v in proj.items() if not k.startswith("_")}
    open_snags = [s for s in proj.get("snags", []) if s.get("status") != "closed"]
    upcoming = sorted(
        [e for e in proj.get("events", []) if e.get("date", "") >= today_iso()],
        key=lambda e: (e.get("date", ""), e.get("time", "")),
    )
    p["stats"] = {
        "notes": len(proj.get("notes", [])),
        "open_snags": len(open_snags),
        "rooms": len(proj.get("rooms", [])),
        "next_event": upcoming[0] if upcoming else None,
        "inbox": count_inbox(proj["_dir"]),
    }
    p["folder"] = proj["_dir"]
    p["contacts"] = [clean_contact(c) for c in proj.get("contacts", [])]
    if full:
        p["folders"] = folder_summary(proj["_dir"])
    else:
        for k in ("notes", "snags", "events", "moms", "contacts", "rooms", "bot_log"):
            p.pop(k, None)
    return p


def add_log(proj, kind, text):
    proj.setdefault("activity", []).insert(0, {"time": now_iso(), "kind": kind, "text": text})
    proj["activity"] = proj["activity"][:200]


CLIENT_ROLES = ("client",)


def contact_kind(c):
    """client / contractor / vendor (older project cards only had a role)."""
    k = (c.get("kind") or "").lower()
    if k in ("client", "contractor", "vendor"):
        return k
    role = (c.get("role") or "").lower()
    if role == "client":
        return "client"
    if "vendor" in role or "supplier" in role:
        return "vendor"
    return "contractor"


def clean_contact(c):
    kind = contact_kind(c)
    out = {k: str(c.get(k, "") or "").strip()[:80] for k in ("name", "company", "trade", "relation", "phone", "email")}
    out["kind"] = kind
    out["role"] = "Client" if kind == "client" else (out["trade"] or str(c.get("role", "")).strip()[:40] or kind.title())
    if kind == "contractor" and not out["trade"] and c.get("role") not in (None, "", "Vendor"):
        out["trade"] = str(c.get("role")).strip()[:40]
    return out


def new_project(body, user, imported_from=None, quiet=False):
    name = (body.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Give the project a name.")
    client = (body.get("client") or "").strip()
    root = projects_root()
    folder = safe_name(f"{name} - {client}" if client else name)
    with LOCK:
        pdir = unique_path(os.path.join(root, folder))
        ensure_tree(pdir)
    pid = (re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:30] or "project") + "-" + secrets.token_hex(2)
    proj = {
        "id": pid, "name": name, "client": client,
        "address": (body.get("address") or "").strip(),
        "created": now_iso(), "created_by": user["name"],
        "contacts": [], "rooms": [], "layout": None,
        "notes": [], "snags": [], "events": [], "moms": [], "activity": [], "bot_log": [],
    }
    if imported_from:
        proj["imported_from"] = imported_from
    members = [m for m in body.get("members", []) if (m.get("name") or "").strip()]
    if client and not members:
        members = [{"name": client, "relation": "", "phone": body.get("phone", ""), "email": ""}]
    for m in members:
        proj["contacts"].append(clean_contact(dict(m, kind="client")))
    proj["_dir"] = pdir
    add_log(proj, "project", f"Project created with {len(FOLDER_TREE)} folders by {user['name']}")
    save_project(proj)
    if not quiet:
        assistant.notify(f"New project **{name}**{' for ' + client if client else ''} was added by {user['name']}. "
                         f"All {len(FOLDER_TREE)} folders are ready.")
        assistant.report("project", f"Project added by {user['name']}", name, client)
    return proj


# ---------------------------------------------------------------- the Folder Bot (rules)

DRAW_EXT = {".dwg", ".dxf", ".dwf", ".dgn"}
MODEL_EXT = {".skp", ".3ds", ".max", ".blend", ".fbx", ".obj", ".rvt", ".rfa", ".3dm", ".c4d", ".glb", ".gltf", ".ifc"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp", ".tif", ".tiff", ".bmp"}
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".avi", ".3gp"}
SHEET_EXT = {".xls", ".xlsx", ".csv", ".ods"}
DOC_EXT = {".doc", ".docx", ".txt", ".rtf", ".odt", ".ppt", ".pptx"}

RENDER_WORDS = ("render", "3d", "view", "camera", "cam", "vray", "lumion", "enscape", "d5", "twinmotion", "visual")
BILL_WORDS = ("invoice", "bill", "quote", "quotation", "estimate", "boq", "po ", "po_", "po-", "proforma", "receipt", "payment")
MOM_WORDS = ("mom", "minutes", "meeting")
DRAW_WORDS = (
    ("Plans", ("plan", "layout", "floor", "flr", "furniture layout")),
    ("Elevations", ("elev", "elevation")),
    ("Sections", ("section", "sect")),
    ("Details", ("detail", "dtl", "joinery")),
    ("Ceiling", ("ceiling", "rcp")),
    ("Electrical", ("elect", "electrical", "lighting", "light", "power", "switch")),
    ("Plumbing", ("plumb", "plumbing", "drain", "water supply", "sanitary")),
)
PDF_DRAWING_HINTS = ("plan", "elev", "section", "detail", "layout", "rcp", "gfc", "issued", "dwg", "drawing", "ceiling", "elect", "plumb")
REV_RE = re.compile(r"[\s_\-]*(rev|r)[\s_\-]?\d+[a-z]?$", re.IGNORECASE)


def has_any(name, words):
    return any(w in name for w in words)


def drawing_subfolder(lname):
    for sub, words in DRAW_WORDS:
        if has_any(lname, words):
            return sub
    return "Working"


def classify(filename, mtime):
    """Return a folder path (relative, '/'-separated) for this file, or None if unsure."""
    lname = filename.lower()
    ext = os.path.splitext(lname)[1]
    day = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d")
    if ext in DRAW_EXT:
        return "01 Drawings/" + drawing_subfolder(lname)
    if ext in MODEL_EXT:
        return "02 3D/Models"
    if ext in IMAGE_EXT:
        if has_any(lname, PDF_DRAWING_HINTS) and REV_RE.search(os.path.splitext(lname)[0]):
            return "01 Drawings/" + drawing_subfolder(lname)    # e.g. "Kitchen plan R2.jpg" is a drawing, not a site photo
        if has_any(lname, RENDER_WORDS):
            return "02 3D/Renders"
        return "03 Site Photos/" + day
    if ext in VIDEO_EXT:
        return "03 Site Photos/" + day
    if ext == ".pdf":
        if has_any(lname, BILL_WORDS):
            return "06 Bills & Quotes"
        if has_any(lname, MOM_WORDS):
            return "04 MOM"
        if has_any(lname, PDF_DRAWING_HINTS):
            return "01 Drawings/" + drawing_subfolder(lname)
        return "07 Client Docs"
    if ext in SHEET_EXT:
        return "06 Bills & Quotes" if has_any(lname, BILL_WORDS) else "07 Client Docs"
    if ext in DOC_EXT:
        if has_any(lname, MOM_WORDS):
            return "04 MOM"
        if has_any(lname, BILL_WORDS):
            return "06 Bills & Quotes"
        return "07 Client Docs"
    return None


def base_without_rev(filename):
    stem, _ = os.path.splitext(filename)
    return REV_RE.sub("", stem).strip().lower()


def count_inbox(pdir):
    p = os.path.join(pdir, "00 Inbox")
    if not os.path.isdir(p):
        return 0
    return sum(1 for f in os.listdir(p) if os.path.isfile(os.path.join(p, f)) and not f.startswith("."))


def sort_project(proj, who="Folder Bot"):
    """Move files out of '00 Inbox' into the right folders. Never deletes anything."""
    pdir = proj["_dir"]
    ensure_tree(pdir)
    inbox = os.path.join(pdir, "00 Inbox")
    run_id = secrets.token_hex(4)
    moved, unsure, superseded = [], [], []
    for name in sorted(os.listdir(inbox)):
        src = os.path.join(inbox, name)
        if not os.path.isfile(src) or name.startswith(".") or name.endswith((".tmp", ".crdownload", ".part")):
            continue
        # skip files still being copied in (changed in the last 5 seconds)
        if time.time() - os.path.getmtime(src) < 5:
            continue
        rel = classify(name, os.path.getmtime(src))
        if rel is None:
            unsure.append(name)
            continue
        target_dir = os.path.join(pdir, *rel.split("/"))
        os.makedirs(target_dir, exist_ok=True)
        # Latest drawing only: an older revision of the same drawing moves to Superseded
        if rel.startswith("01 Drawings/"):
            key = base_without_rev(name)
            for existing in os.listdir(target_dir):
                ep = os.path.join(target_dir, existing)
                if os.path.isfile(ep) and base_without_rev(existing) == key and existing != name:
                    sup_dir = os.path.join(pdir, "01 Drawings", "Superseded")
                    dst_old = unique_path(os.path.join(sup_dir, existing))
                    shutil.move(ep, dst_old)
                    superseded.append({"file": existing, "to": os.path.relpath(dst_old, pdir),
                                       "from": os.path.relpath(ep, pdir)})
        dst = unique_path(os.path.join(target_dir, name))
        shutil.move(src, dst)
        moved.append({"file": name, "to": os.path.relpath(os.path.dirname(dst), pdir).replace("\\", "/"),
                      "src": os.path.relpath(src, pdir), "dst": os.path.relpath(dst, pdir)})
    if moved or superseded:
        entry = {"run": run_id, "time": now_iso(), "by": who, "moved": moved, "superseded": superseded}
        proj.setdefault("bot_log", []).insert(0, entry)
        proj["bot_log"] = proj["bot_log"][:50]
        parts = [f"filed {len(moved)} file{'s' if len(moved) != 1 else ''}"]
        if superseded:
            parts.append(f"marked {len(superseded)} old drawing{'s' if len(superseded) != 1 else ''} superseded")
        add_log(proj, "bot", "Auto-filing " + " and ".join(parts))
        save_project(proj)
    return {"moved": moved, "unsure": unsure, "superseded": superseded}


AI_SORT_FOLDERS = [f for f in FOLDER_TREE if f not in ("00 Inbox", "01 Drawings/Superseded", "01 Drawings/Site corrections", "05 Snags")]


def ai_sort_inbox(firm, user, proj):
    """v0.11 Smart sorting: files the free rules left in 00 Inbox are shown to the AI Smart Sorting Bot,
    which chooses a folder for each. Without an AI connection nothing moves and the studio is told how to switch it on."""
    pdir = proj["_dir"]
    ensure_tree(pdir)
    inbox = os.path.join(pdir, "00 Inbox")
    names = [n for n in sorted(os.listdir(inbox)) if os.path.isfile(os.path.join(inbox, n)) and not n.startswith(".")][:60]
    if not names:
        return {"moved": [], "left": [], "ai": True, "message": "The Inbox is empty — nothing to sort."}
    off = {"moved": [], "left": names, "ai": False,
           "message": "Smart sorting needs the AI switched on. Connect your AI in the Design Lab dashboard (Bots & AI); until then these files wait in 00 Inbox for you."}
    try:
        r = ai_bot(firm, user, "sorter", "Project: " + proj.get("name", "") + "\nFiles:\n" + "\n".join("- " + n for n in names), proj.get("name", ""))
    except ApiError as e:
        if e.status == 402:
            off["message"] = e.message
        return off
    if not r.get("ai"):
        return off
    m = re.search(r"\{.*\}", r.get("answer") or "", re.S)
    try:
        plan = json.loads(m.group(0)) if m else {}
    except ValueError:
        plan = {}
    run_id = secrets.token_hex(4)
    moved, left = [], []
    for name in names:
        rel = str(plan.get(name) or "")
        if rel not in AI_SORT_FOLDERS:
            left.append(name)
            continue
        src = os.path.join(inbox, name)
        if rel == "03 Site Photos":
            rel = "03 Site Photos/" + datetime.fromtimestamp(os.path.getmtime(src)).strftime("%Y-%m-%d")
        target_dir = os.path.join(pdir, *rel.split("/"))
        os.makedirs(target_dir, exist_ok=True)
        dst = unique_path(os.path.join(target_dir, name))
        shutil.move(src, dst)
        moved.append({"file": name, "to": rel, "src": os.path.relpath(src, pdir), "dst": os.path.relpath(dst, pdir)})
    with LOCK:
        p2 = load_project(pdir)
        if moved:
            p2.setdefault("bot_log", []).insert(0, {"run": run_id, "time": now_iso(), "by": "Smart Sorting Bot (AI)", "moved": moved, "superseded": []})
            p2["bot_log"] = p2["bot_log"][:50]
            add_log(p2, "bot", f"Smart Sorting Bot filed {len(moved)} unclear file{'s' if len(moved) != 1 else ''}")
            save_project(p2)
    msg = f"Smart Sorting Bot filed {len(moved)} file{'s' if len(moved) != 1 else ''}." + (f" {len(left)} still need you in 00 Inbox." if left else "")
    if r.get("charged"):
        msg += f" Rs {r['charged']:.2f} from the wallet."
    return {"moved": moved, "left": left, "ai": True, "message": msg}


def undo_last_sort(proj):
    log = proj.get("bot_log", [])
    if not log:
        return {"undone": 0}
    entry = log.pop(0)
    pdir = proj["_dir"]
    undone = 0
    for m in reversed(entry.get("moved", [])):
        src = os.path.join(pdir, m["dst"])
        if os.path.exists(src):
            shutil.move(src, unique_path(os.path.join(pdir, m["src"])))
            undone += 1
    for sp in entry.get("superseded", []):
        old = os.path.join(pdir, sp["to"])
        if sp.get("from") and os.path.exists(old):
            shutil.move(old, unique_path(os.path.join(pdir, sp["from"])))
    add_log(proj, "bot", f"Folder Bot run undone ({undone} file{'s' if undone != 1 else ''} back to Inbox)")
    save_project(proj)
    return {"undone": undone}


def bot_loop():
    """Every 60 seconds, sort every project's Inbox (only files that have stopped changing)."""
    while True:
        time.sleep(60)
        try:
            with LOCK:
                for pdir in project_dirs():
                    proj = load_project(pdir)
                    if proj and count_inbox(pdir):
                        sort_project(proj, "Folder Bot (auto)")
            assistant.watch()
        except Exception as exc:  # keep the bot alive whatever happens
            print("Folder Bot:", exc)


# ---------------------------------------------------------------- bot roles (defined before any bot runs)

BOT_ROLES = [
    {
        "id": "folder", "name": "Folder Bot", "side": "Office", "status": "active", "engine": "Rules on this computer",
        "role": "Keeps every project's folders in order.",
        "does": [
            "Creates the standard folder set for each new project",
            "Every minute, files anything dropped in 00 Inbox into the right folder",
            "Moves an older revision of a drawing to 01 Drawings/Superseded",
            "Writes a log of every move; one tap undoes the last run",
        ],
        "allowed": "Only inside the Design Lab projects folder on this computer",
        "never": [
            "Deletes a file",
            "Opens or reads what is inside a file",
            "Sends any file off this computer",
            "Touches folders outside the projects folder",
        ],
        "asks_you": "Files it is unsure about stay in 00 Inbox and are listed for you.",
        "cost": "Free",
    },
    {
        "id": "site", "name": "Site Bot", "side": "Site", "status": "active", "engine": "Rules on this computer (AI later)",
        "role": "Turns what happens on site into a clean record.",
        "does": [
            "Pins notes, changes, photos and snags to the room you tapped",
            "Files site photos by date and room in 03 Site Photos",
            "Writes the MOM grouped by room, with snags and the next meeting",
            "Keeps 05 Snags/Snag list.txt up to date",
        ],
        "allowed": "Only the project you are working in",
        "never": [
            "Sends a MOM without you pressing Send",
            "Changes or deletes a note someone else wrote",
        ],
        "asks_you": "You check every MOM before it goes to the client.",
        "cost": "Free now; AI clean-up of recordings will be charged from the wallet",
    },
    {
        "id": "office", "name": "Office Bot", "side": "Office", "status": "planned", "engine": "Design Lab Gateway (AI)",
        "role": "Routes site material to the right person and drafts follow-ups.",
        "does": [
            "Reads the Site Bot's MOMs and sketches and files them to the right person",
            "Drafts meeting mails, vendor and contractor follow-ups, thank-you notes",
            "Names unclear files by looking at a small preview",
        ],
        "allowed": "Only what a task needs; sees a preview, never the whole folder",
        "never": [
            "Sends anything without your approval (until you switch on auto-send)",
            "Keeps a copy of your files",
        ],
        "asks_you": "Every draft waits for your tap.",
        "cost": "Charged from the wallet per task",
    },
    {
        "id": "layout", "name": "Layout Bot", "side": "Site", "status": "planned", "engine": "Design Lab Gateway (AI)",
        "role": "Turns your plan into a tappable layout with named rooms.",
        "does": ["Reads the plan image once per project and marks the rooms"],
        "allowed": "Only the plan image you give it",
        "never": ["Changes your drawing files"],
        "asks_you": "You confirm the room names.",
        "cost": "Charged once per layout",
    },
    {
        "id": "social", "name": "Social Bot", "side": "Office", "status": "add-on", "engine": "Design Lab Gateway (AI)",
        "role": "Runs the studio's Instagram.",
        "does": ["Final edit of chosen images, captions, hashtags, scheduling and posting"],
        "allowed": "Only images you send it and the Instagram account you connect",
        "never": ["Posts without your approval"],
        "asks_you": "You approve every post.",
        "cost": "Add-on, charged from the wallet",
    },
]

# ---------------------------------------------------------------- MOM (Site bot, rule-based for now)

def pretty_date(iso):
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d %b %Y")
    except ValueError:
        return iso


FILLERS = re.compile(r"\b(umm+|uh+|hmm+|haan|han ji|ok ok|achha|accha|matlab|you know|basically|like i said)\b[,.]?\s*", re.I)
CHANGE_W = ("change", "instead", "replace", "shift", "move the", "badal", "hata", "remove", "add one more", "extra")
DECIDE_W = ("decided", "final", "finalised", "finalized", "confirm", "approved", "fixed", "done deal", "go ahead", "pakka", "theek hai")
ACTION_W = ("will ", "should", "need to", "needs to", "has to", "have to", "please", "by monday", "by tomorrow", "send", "deliver",
            "karna", "karo", "bhejo", "dena", "tomorrow", "next week")


def meeting_points(text):
    """Free (no AI): split a spoken meeting into points and tag changes, decisions and actions."""
    text = FILLERS.sub("", text.replace("\r", "\n"))
    raw = re.split(r"(?<=[.?!\u0964])\s+|\n+|\s+(?:and then|after that|next point|point number \w+)\s+", text)
    out = []
    for r in raw:
        r = r.strip(" ,;-").strip()
        if len(r.split()) < 2:
            continue
        r = r[0].upper() + r[1:]
        low = r.lower()
        kind = ("change" if any(w in low for w in CHANGE_W) else "decision" if any(w in low for w in DECIDE_W)
                else "action" if any(w in low for w in ACTION_W) else "note")
        out.append((kind, r if r[-1] in ".?!\u0964" else r + "."))
    return out[:120]


def build_mom(proj, day, firm):
    notes = [n for n in proj.get("notes", []) if n.get("time", "").startswith(day)]
    snags = [s for s in proj.get("snags", []) if s.get("time", "").startswith(day)]
    contacts = proj.get("contacts", [])
    client = proj.get("client") or ""
    lines = [
        "MINUTES OF MEETING",
        "",
        f"Project:  {proj.get('name', '')}",
        f"Client:   {client}",
        f"Site:     {proj.get('address', '')}",
        f"Date:     {pretty_date(day)}",
        f"Prepared: {firm.get('firm', '')}",
        "",
    ]
    rooms = []
    for n in notes:
        r = n.get("room") or "General"
        if r not in rooms:
            rooms.append(r)
    point = 1
    if notes:
        lines.append("DISCUSSED AND DECIDED")
        for r in rooms:
            lines.append("")
            lines.append(f"{r}")
            for n in [x for x in notes if (x.get("room") or "General") == r]:
                if n.get("kind") == "photo":
                    continue
                tag = {"change": "Change", "decision": "Decision", "action": "Action"}.get(n.get("kind"), "")
                text = n.get("text", "").strip()
                if not text:
                    continue
                lines.append(f"  {point}. " + (f"{tag}: " if tag else "") + text)
                point += 1
            photos = [x for x in notes if (x.get("room") or "General") == r and x.get("kind") == "photo"]
            if photos:
                lines.append(f"     ({len(photos)} photo{'s' if len(photos) != 1 else ''} filed in 03 Site Photos)")
    if snags:
        lines += ["", "SNAGS RAISED"]
        for s in snags:
            who = f" — {s['owner']}" if s.get("owner") else ""
            due = f", by {pretty_date(s['due'])}" if s.get("due") else ""
            lines.append(f"  • [{s.get('room') or 'General'}] {s.get('text', '')}{who}{due}")
    upcoming = sorted([e for e in proj.get("events", []) if e.get("date", "") > day],
                      key=lambda e: (e.get("date", ""), e.get("time", "")))
    if upcoming:
        e = upcoming[0]
        lines += ["", f"NEXT MEETING: {pretty_date(e['date'])} {e.get('time', '')} — {e.get('title', '')}".rstrip()]
    if not notes and not snags:
        lines += ["No site notes were recorded for this date."]
    lines += ["", "Please reply to confirm, or let us know of any correction within 24 hours.",
              "", f"— {firm.get('firm', '')}"]
    to = [c for c in contacts if c.get("phone") or c.get("email")]
    return "\n".join(lines), to


# ---------------------------------------------------------------- Design Lab Cloud link

import urllib.request
import urllib.error


class CloudError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


def cloud_cfg(firm):
    c = dict((firm or {}).get("cloud") or {})
    if c.get("key"):
        c["key"] = vault.reveal(c["key"])
    return c


def cloud_call(firm, path, body=None, cfg=None, headers=None, timeout=8):
    """Call the Design Lab Cloud with this studio's firm code and activation key."""
    cfg = cfg or cloud_cfg(firm)
    if not cfg.get("url"):
        raise CloudError(0, "Not connected to Design Lab Cloud.")
    req = urllib.request.Request(
        cfg["url"].rstrip("/") + path,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json", "X-Firm": cfg.get("code", ""), "X-Key": cfg.get("key", ""), **(headers or {})},
        method="POST" if body is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("error")
        except ValueError:
            msg = None
        raise CloudError(e.code, msg or f"Design Lab Cloud said {e.code}.")
    except (urllib.error.URLError, OSError):
        raise CloudError(0, "Can't reach Design Lab Cloud right now. Free features keep working.")


def cloud_sync_users(firm):
    """Register this studio's users with the Cloud; it assigns each a bot seat."""
    if not cloud_cfg(firm).get("url"):
        return None
    users = [{"id": u["id"], "name": u["name"], "role": u.get("role", "designer"), "designation": u.get("designation", "")}
             for u in firm.get("users", []) if u.get("status", "active") == "active"]
    try:
        r = cloud_call(firm, "/api/studio/users", {"users": users})
    except CloudError:
        return None
    firm["cloud"]["users"] = r.get("users", [])
    firm["cloud"]["synced"] = now_iso()
    save_json(firm_file(), firm)
    return r


def cloud_charge(firm, task, user, project):
    """Meter a paid bot task. Free when not connected (local prototype mode)."""
    if not cloud_cfg(firm).get("url"):
        return None
    try:
        return cloud_call(firm, "/api/studio/usage", {"task": task, "user": user, "project": project})
    except CloudError as e:
        if e.status == 402:
            raise ApiError(402, e.message)
        raise ApiError(503, e.message + " The bot will work again once the Cloud is reachable.")


def ai_bot(firm, user, bot, text, project="", history=None):
    """Ask one of Design Lab's bots (runs on Design Lab's server; AI use is charged to the firm's balance)."""
    if not cloud_cfg(firm).get("url"):
        raise ApiError(409, "Connect this studio to Design Lab to use the AI bots.")
    try:
        return cloud_call(firm, "/api/studio/bot", {"bot": bot, "text": text, "project": project, "user": user.get("id", ""),
                                                    "history": history or []}, timeout=200)
    except CloudError as e:
        raise ApiError(e.status or 503, e.message)


# ---------------------------------------------------------------- team and bot seats

INCLUDED_USERS = 1
EXTRA_USER_FEE = 199


def share_base():
    """The studio's online address while 'SHARE MY REAL STUDIO' is on (client links use it)."""
    try:
        with open(os.path.join(os.path.dirname(APP_DIR), "MY SHARING LINK.txt"), encoding="utf-8", errors="ignore") as f:
            t = f.read()
    except OSError:
        return ""
    m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", t)
    return m.group(0) if m and "REAL STUDIO" in t else ""


def team_view(firm):
    out = []
    code = cloud_cfg(firm).get("code") or firm.get("code", "DL-LOCAL")
    active = [u for u in firm.get("users", []) if u.get("status", "active") == "active"]
    for u in firm.get("users", []):
        if u.get("status") == "pending":
            out.append({"id": u["id"], "name": u["name"], "role": u.get("role", "designer"), "seat": None,
                        "designation": u.get("designation", ""), "profession": u.get("profession", ""),
                        "pending": True, "bot": "", "fee": "", "registered": False})
    for i, u in enumerate(active):
        n = i + 1
        included = n <= INCLUDED_USERS
        out.append({
            "id": u["id"], "name": u["name"], "role": u.get("role", "designer"), "seat": n,
            "designation": u.get("designation", ""), "profession": u.get("profession", ""), "pending": False,
            "phone": u.get("phone", ""), "email": u.get("email", ""),
            "private": u.get("role") == "owner" or u["id"] in (firm.get("private_access") or []),
            "bot": f"{code} company bot" if included else f"{code}-{n:02d} own bot",
            "fee": "Included" if included else f"Rs {EXTRA_USER_FEE} / month",
            "registered": False,
        })
    reg = {u["id"]: u for u in cloud_cfg(firm).get("users", [])}
    for u in out:
        if u["id"] in reg:
            u["registered"] = True
            u["bot"] = reg[u["id"]].get("bot", u["bot"])
    return out


# ---------------------------------------------------------------- network helpers

def local_ips():
    ips = {"127.0.0.1", "::1", "::ffff:127.0.0.1"}
    for u in lan_addresses():
        ips.add(u.split("//")[1].rsplit(":", 1)[0])
    return ips


def lan_addresses():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    ips.discard("127.0.0.1")
    return [f"http://{ip}:{PORT}" for ip in sorted(ips)]


# ---------------------------------------------------------------- HTTP

class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


class Handler(BaseHTTPRequestHandler):
    server_version = "DesignLab/" + VERSION

    def log_message(self, fmt, *args):  # quieter console
        if "/api/" in str(args[0] if args else ""):
            return
        sys.stderr.write("  " + (fmt % args) + "\n")

    # -- helpers
    def end_headers(self):
        # standard protections every web app should send
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                         "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; "
                         "object-src 'none'; base-uri 'none'")
        self.send_header("Permissions-Policy", "camera=(self), microphone=(self), geolocation=(self), payment=()")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        super().end_headers()

    def send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > 60 * 1024 * 1024:
            raise ApiError(413, "That file is too large (limit 60 MB).")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            return json.loads(raw.decode("utf-8") or "{}")
        except ValueError:
            raise ApiError(400, "The request could not be read.")

    def is_main(self):
        """True when the request comes from the studio computer itself (where Design Lab and the folders are)."""
        if os.environ.get("DESIGNLAB_TEST_AS_PHONE"):   # only for testing the phone screens on one computer
            return False
        if self.headers.get("Cf-Connecting-Ip") or self.headers.get("X-Forwarded-For"): return False   # came in through a sharing link
        ip = self.client_address[0]
        return ip in local_ips() or ip.replace("::ffff:", "") in local_ips()

    def need_main(self):
        if DEMO:
            return
        if not self.is_main():
            raise ApiError(403, "Please register on your studio computer, the main computer where Design Lab is installed. "
                                "After that you can sign in from your phone.")

    def user(self):
        tok = self.headers.get("X-Token", "")
        uid = session_uid(tok)
        if not uid:
            raise ApiError(401, "Please sign in again.")
        firm = load_firm() or {}
        for u in firm.get("users", []):
            if u["id"] == uid:
                if u.get("status", "active") != "active":
                    raise ApiError(401, "This account is not active. Please ask the studio owner.")
                if u.get("demo_until") and u["demo_until"] < now_iso():
                    raise ApiError(401, "Your demo has ended.")
                if DEMO and u.get("demo_kind") == "vendor":     # demo: a vendor visitor sees the vendor side
                    return u, dict(firm, kind="vendor", _real_kind=firm.get("kind"), firm="Design Lab Demo Showroom", _real_firm=firm.get("firm"))
                return u, firm
        raise ApiError(401, "Please sign in again.")

    def serve_file(self, path):
        if not os.path.isfile(path):
            self.send_error(404)
            return
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        with open(path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    # -- routing
    def courtyard_proxy(self, path, query, body=None):
        """The Courtyard lives on Design Lab's server; the studio software passes requests on with its firm key."""
        user, firm = self.user()
        if not cloud_cfg(firm).get("url"):
            raise ApiError(409, "Connect this studio to Design Lab to join The Courtyard.")
        team.cy_guard(user, path, body is not None)
        hdr = {"X-User-Id": urllib.parse.quote(user["id"]), "X-User-Name": urllib.parse.quote(user["name"]),
               "X-User-Role": user.get("role", "")}
        try:
            return cloud_call(firm, "/api/studio/courtyard" + path[len("/api/cy"):] + ("?" + query if query else ""),
                              body, headers=hdr, timeout=25)
        except CloudError as e:
            raise ApiError(e.status or 503, e.message)

    def ai_route(self, path, body):
        user, firm = self.user()
        if path == "/api/bot-learn":
            try:
                return cloud_call(firm, "/api/studio/bot-learn", {"bot": str(body.get("bot", ""))[:30], "q": body.get("q", ""), "a": body.get("a", "")})
            except CloudError:
                return {"ok": False}
        proj = find_project(path.split("/")[3])
        if not proj:
            raise ApiError(404, "Project not found.")
        text = str(body.get("text") or "").strip()
        if len(text) < 10:
            raise ApiError(400, "Nothing to tidy yet.")
        r = ai_bot(firm, user, "mom", "Project: " + proj["name"] + "\n\n" + text, proj["name"])
        if not r.get("ai"):
            raise ApiError(409, "The AI isn't switched on yet. The MOM above is ready to edit and send as it is.")
        return {"text": r["answer"], "charged": r.get("charged")}

    def cloud_file(self, path):
        """Photos, PDFs and the magazine from The Courtyard, passed through so phones can see them."""
        if not re.match(r"^/(cy/files/[0-9a-f]{20}\.(jpg|png|webp|pdf|doc|docx|xls|xlsx|ppt|pptx|dwg|dxf|txt|csv|zip)|magazine/i[0-9a-f]{10}|shared/perspective/[a-z0-9\-]{1,40}\.jpg)$", path):
            return self.send_error(404)
        base = (cloud_cfg(load_firm()).get("url") or cloud_url()).rstrip("/")
        try:
            with urllib.request.urlopen(base + path, timeout=20) as r:
                data, ctype = r.read(), r.headers.get("Content-Type", "application/octet-stream")
                disp = r.headers.get("Content-Disposition", "")
        except (urllib.error.URLError, OSError):
            return self.send_error(404)
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        if disp:
            self.send_header("Content-Disposition", disp)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "private, max-age=86400")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(url.path)
        try:
            if path.startswith("/api/cy/") or path == "/api/cy":
                return self.send_json(200, self.courtyard_proxy(path, url.query))
            if path.startswith("/c/"):
                return self.serve_file(os.path.join(WEB_DIR, "client.html"))
            if path.startswith("/api/client/"):
                with LOCK:
                    return self.send_json(200, self.client_api(path.split("/")[3], "", {}))
            if path.startswith("/cfile/"):
                return self.client_file(path)
            if path.startswith("/cy/files/") or path.startswith("/magazine/") or path.startswith("/shared/perspective/"):
                return self.cloud_file(path)
            if path.startswith("/api/"):
                with LOCK:
                    self.send_json(200, self.api_get(path, urllib.parse.parse_qs(url.query)))
                return
            if path.startswith("/files/"):
                self.user_from_query(url)
                return self.serve_project_file(path)
            if path.startswith("/recfiles/") or path in ("/social-file", "/brand-photo"):
                return self.serve_private_file(path, url)
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            full = os.path.normpath(os.path.join(WEB_DIR, rel))
            if not inside(WEB_DIR, full):
                return self.send_error(403)
            return self.serve_file(full)
        except ApiError as e:
            self.send_json(e.status, {"error": e.message})
        except Exception as e:  # pragma: no cover
            self.send_json(500, {"error": f"Something went wrong: {e}"})

    def do_POST(self):
        path = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        try:
            body = self.read_body()
            if path.startswith("/api/cy/"):
                return self.send_json(200, self.courtyard_proxy(path, urllib.parse.urlparse(self.path).query, body))
            if path.endswith("/mom-tidy") or path == "/api/bot-learn":
                return self.send_json(200, self.ai_route(path, body))
            if path.startswith("/api/client/"):
                parts = path.split("/")
                with LOCK:
                    return self.send_json(200, self.client_api(parts[3], parts[4] if len(parts) > 4 else "", body))
            with LOCK:
                self.send_json(200, self.api_post(path, body))
        except ApiError as e:
            self.send_json(e.status, {"error": e.message})
        except Exception as e:  # pragma: no cover
            self.send_json(500, {"error": f"Something went wrong: {e}"})

    def serve_private_file(self, path, url):
        try:
            user, firm = self.user_from_query(url)
        except ApiError:
            return self.send_error(401)
        tok = "fk:" + urllib.parse.parse_qs(url.query).get("f", [""])[0]     # private files: open only while that sign-in has unlocked them
        if path == "/brand-photo":
            p = os.path.join(projects_root(), ".designlab", firm.get("welcome_photo") or "-")
            return self.serve_file(p) if firm.get("welcome_photo") and os.path.isfile(p) else self.send_error(404)
        if path == "/social-file":
            p = records.social_file(urllib.parse.parse_qs(url.query).get("rel", [""])[0])
        else:
            p = records.file_for(path.split("/")[-1], firm, user, tok)
        return self.serve_file(p) if p else self.send_error(404)

    def user_from_query(self, url):
        fk = urllib.parse.parse_qs(url.query).get("f", [""])[0]
        uid = uid_from_fk(fk)
        firm = load_firm() or {}
        u = next((x for x in firm.get("users", []) if x["id"] == uid), None)
        if not u or u.get("status", "active") != "active":
            raise ApiError(401, "Please sign in again.")
        return u, firm

    def serve_project_file(self, path):
        # /files/<project id>/<relative path>
        parts = path.split("/", 3)
        if len(parts) < 4:
            return self.send_error(404)
        proj = find_project(parts[2])
        if not proj:
            return self.send_error(404)
        full = os.path.normpath(os.path.join(proj["_dir"], parts[3]))
        if not inside(proj["_dir"], full) or ".designlab" in full.replace("\\", "/").split("/"):
            return self.send_error(403)
        return self.serve_file(full)

    # -- GET API
    def api_get(self, path, query):
        if path == "/api/state":
            firm = load_firm()
            return {
                "version": VERSION,
                "setup": bool(firm),
                "registered": bool(firm), "testing": testing_mode(), "main": self.is_main(), "demo": DEMO,
                "register_step": ("create" if (config().get("pending") or {}).get("activation")
                                                    else "pay" if (config().get("pending") or {}).get("order") else "details"),
                "pending_order": (config().get("pending") or {}).get("order"),
                "pending_pay": (config().get("pending") or {}).get("pay"),
                "firm": firm.get("firm") if firm else None,
                "projects_root": projects_root() or default_root(),
                "lan": lan_addresses(),
                "port": PORT,
            }
        user, firm = self.user()
        if path == "/api/projects":
            projs = [load_project(d) for d in project_dirs()]
            return {"projects": [public_project(p) for p in projs if p]}
        if path.startswith("/api/projects/"):
            proj = find_project(path.split("/")[3])
            if not proj:
                raise ApiError(404, "Project not found.")
            return {"project": public_project(proj, full=True)}
        if path == "/api/users":
            return {"users": team_view(firm), "me": user["id"], "owner": user.get("role") == "owner",
                    "invites": team.invites_view(firm) if user.get("role") == "owner" else [],
                    "roles": team.roles_for(firm), "cy_sections": team.CY_SECTIONS, "included": INCLUDED_USERS, "fee": EXTRA_USER_FEE}
        if path == "/api/team/usage":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the owner can see this.")
            spend = []
            try:
                spend = cloud_call(firm, "/api/studio/wallet").get("spend", []) if cloud_cfg(firm).get("url") else []
            except CloudError:
                pass
            return {"members": team.member_usage(firm, spend)}
        if path == "/api/me/profile":
            n = sum(1 for x in sessions().values() if x.get("uid") == user["id"])
            return team.profile(firm, user, n)
        if path == "/api/cloud":
            return self.cloud_status(firm)
        if path == "/api/security":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can see this.")
            return {"log": read_security_log()}
        if path == "/api/bots":
            runs, last = 0, None
            for d in project_dirs():
                p = load_project(d)
                for e in (p or {}).get("bot_log", []):
                    runs += 1
                    if not last or e["time"] > last["time"]:
                        last = dict(e, project=p["name"])
            return {"bots": BOT_ROLES, "folder_runs": runs, "folder_last": last}
        if path == "/api/assistant":
            return assistant.state_for(user)
        tok = self.headers.get("X-Token", "")
        if path == "/api/rec-schemas":
            return {"schemas": records.schemas_for(firm), "side": records.side_of(firm),
                    "can_private": records.can_private(firm, user), "unlocked": records.is_unlocked(tok),
                    "book": records.phrase_status(firm, user)}
        if path.startswith("/api/rec/"):
            return records.list_kind(path.split("/")[3], firm, user, tok)
        if path == "/api/vendor/today":
            return records.vendor_today(firm, user, tok)
        if path == "/api/vendor/updates":
            return {"updates": records.vendor_updates(120)}
        if path == "/api/business":
            return records.business_overview(firm, user, tok)
        if path == "/api/social":
            return records.social_board()
        if path == "/api/book":
            return {"people": book.with_projects(), "contractor_trades": book.CONTRACTOR_TRADES,
                    "vendor_trades": book.VENDOR_TRADES}
        if path == "/api/home":
            today = today_iso()
            events, snags, activity, inbox = [], 0, [], 0
            for d in project_dirs():
                p = load_project(d)
                if not p:
                    continue
                for e in p.get("events", []):
                    if e.get("date", "") >= today:
                        events.append(dict(e, project=p["name"], project_id=p["id"]))
                snags += sum(1 for s in p.get("snags", []) if s.get("status") != "closed")
                inbox += count_inbox(d)
                for a in p.get("activity", [])[:15]:
                    activity.append(dict(a, project=p["name"], project_id=p["id"]))
            events.sort(key=lambda e: (e.get("date", ""), e.get("time", "")))
            activity.sort(key=lambda a: a["time"], reverse=True)
            return {"fk": session_fk(self.headers.get("X-Token", "")), "dash": self.dash_here(user),
                    "alerts": team.owner_alerts(firm, user), "cy_access": team.cy_access(user), "dash_show": user.get("dash") or {},
                    "user": user["name"], "firm": firm.get("firm"), "today": today, "kind": firm.get("kind") or "designer",
                    "role": user.get("role"), "welcome_photo": bool(firm.get("welcome_photo")),
                    "courtyard": bool(cloud_cfg(firm).get("url")), "cy_url": cloud_cfg(firm).get("url", ""),
                    "events": events[:12], "open_snags": snags, "inbox": inbox,
                    "activity": activity[:20], "projects": len(project_dirs())}
        raise ApiError(404, "Unknown request.")

    # -- POST API
    def api_post(self, path, body):
        if path == "/api/register/start":
            self.need_main()
            return self.register_start(body)
        if path == "/api/register/pay":
            self.need_main()
            return self.register_pay(body)
        if path == "/api/register/finish":
            self.need_main()
            return self.register_finish(body)
        if path == "/api/login":
            return self.studio_login(body)
        if path == "/api/recover":
            return self.recover(body)
        if path == "/api/join":
            return team.join(self, body)
        user, firm = self.user()
        if path == "/api/users/invite":
            return team.invite_new(firm, user, body)
        if path == "/api/users/invite-cancel":
            return team.invite_cancel(firm, user, body)
        if path == "/api/users/cy-access":
            return team.cy_set(firm, user, body)
        if path == "/api/alerts/dismiss":
            return team.alert_dismiss(firm, user, body)
        if path == "/api/me/profile":
            return team.profile_save(firm, user, body)
        if path == "/api/me/feature":
            return team.feature_request(firm, user, body)
        if path == "/api/me/signout-others":
            session_end(uid=user["id"])
            security_log("signed out on all other devices", user["id"], self.client_address[0])
            return {"token": session_new(user["id"], True)}
        if path == "/api/logout":
            session_end(self.headers.get("X-Token", ""))
            security_log("signed out", user["id"], self.client_address[0])
            return {"ok": True}
        if path == "/api/projects":
            return self.create_project(body, user)
        if path == "/api/assistant":
            return assistant.handle(user, body.get("text", ""), body.get("choice", ""), main=self.is_main())
        tok = self.headers.get("X-Token", "")
        if path.startswith("/api/rec/"):
            parts = path.split("/")
            if len(parts) > 4 and parts[4] == "delete":
                return records.delete_item(parts[3], firm, user, tok, str(body.get("id", "")))
            return records.save_item(parts[3], firm, user, tok, body.get("item") or {})
        if path == "/api/private/unlock":
            return records.unlock(firm, user, tok, body.get("password", ""))
        if path == "/api/private/lock":
            return records.lock(tok)
        if path == "/api/private/bill":
            return records.make_bill(firm, user, tok, body)
        if path == "/api/private/reveal":
            return records.phrase_check(firm, user, body.get("phrase", ""))
        if path == "/api/private/phrase":
            return records.phrase_set(firm, user, body.get("password", ""), body.get("phrase", ""))
        if path == "/api/private/access":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can do this.")
            acc = set(firm.get("private_access") or [])
            (acc.add if body.get("on") else acc.discard)(str(body.get("id", "")))
            firm["private_access"] = sorted(acc)
            save_json(firm_file(), firm)
            security_log(f"private pages access {'given to' if body.get('on') else 'removed from'} {body.get('id')}", user["id"], self.client_address[0])
            return {"private_access": firm["private_access"]}
        if path == "/api/capture":
            return records.capture(firm, user, body)
        if path == "/api/cy-to-project":     # a Courtyard pin / postcard -> a project's mood board (pictures copied in)
            proj = find_project(str(body.get("project") or ""))
            if not proj:
                raise ApiError(404, "Choose a project.")
            base = cloud_cfg(firm).get("url", "").rstrip("/")
            mdir = os.path.join(proj["_dir"], "09 Mood Board")
            os.makedirs(mdir, exist_ok=True)
            mb = proj.setdefault("moodboard", {"words": "", "images": []})
            n = 0
            for name in (body.get("images") or [])[:6]:
                if not re.match(r"^[0-9a-f]{20}\.(jpg|png|webp)$", str(name)):
                    continue
                try:
                    with urllib.request.urlopen(base + "/cy/files/" + name, timeout=20) as r:
                        data = r.read()
                except Exception:
                    continue
                label = safe_name(str(body.get("title") or "Courtyard pin"))[:50]
                fn = os.path.basename(unique_path(os.path.join(mdir, f"{label} {secrets.token_hex(2)}{os.path.splitext(name)[1]}")))
                with open(os.path.join(mdir, fn), "wb") as f:
                    f.write(data)
                mb["images"].append(fn)
                n += 1
            if not n:
                raise ApiError(503, "Couldn't fetch the picture from The Courtyard. Try again.")
            note = str(body.get("note") or "").strip()
            if note:
                mb["words"] = (mb.get("words", "") + ("\n" if mb.get("words") else "") + note)[:1500]
            add_log(proj, "courtyard", f"{user['name']} saved “{str(body.get('title') or 'a pin')[:60]}” from The Courtyard to the mood board")
            save_project(proj)
            return {"saved": n, "project": proj["name"]}
        if path == "/api/social/move":
            return records.social_move(str(body.get("rel", "")), str(body.get("bucket", "")))
        if path == "/api/social/folder":
            return records.social_folder_new(body.get("name"))
        if path == "/api/social/folder-remove":
            return records.social_folder_remove(str(body.get("name", "")))
        if path == "/api/brand/photo":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can change the welcome picture.")
            if body.get("clear"):
                firm.pop("welcome_photo", None)
            else:
                name = records.save_upload(body.get("data") or "")
                if not name:
                    raise ApiError(400, "Please choose a photo.")
                src = os.path.join(projects_root(), ".designlab", "records", "files", name)
                os.replace(src, os.path.join(projects_root(), ".designlab", "welcome-" + name))
                firm["welcome_photo"] = "welcome-" + name
            save_json(firm_file(), firm)
            return {"welcome_photo": bool(firm.get("welcome_photo"))}
        if path == "/api/book":
            try:
                p = book.save_person(body.get("person") or {})
            except ValueError as e:
                raise ApiError(400, str(e))
            return {"person": p, "people": book.with_projects()}
        if path == "/api/book/delete":
            book.delete_person(str(body.get("id", "")))
            return {"people": book.with_projects()}
        if path == "/api/cloud/connect":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can connect to Design Lab Cloud.")
            cfg = {"url": (body.get("url") or "").strip().rstrip("/"), "code": (body.get("code") or "").strip().upper(),
                   "key": (body.get("key") or "").strip().upper()}
            if not cfg["url"].startswith(("http://", "https://")):
                raise ApiError(400, "The Cloud address should start with http:// or https://")
            try:
                r = cloud_call(firm, "/api/studio/link", {"version": VERSION}, cfg)
            except CloudError as e:
                raise ApiError(400, e.message)
            firm["cloud"] = dict(cfg, key=vault.lock(cfg["key"]), linked=now_iso(), firm_name=r["firm"]["name"])
            firm["code"] = cfg["code"]
            save_json(firm_file(), firm)
            cloud_sync_users(firm)
            return self.cloud_status(firm)
        if path == "/api/cloud/disconnect":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can do this.")
            firm.pop("cloud", None)
            save_json(firm_file(), firm)
            return {"connected": False}
        if path == "/api/cloud/topup":
            try:
                cloud_call(firm, "/api/studio/topup", {"amount": body.get("amount")})
            except CloudError as e:
                raise ApiError(400, e.message)
            return self.cloud_status(firm)
        if path == "/api/users/reset":
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can reset passwords.")
            target = next((u for u in firm["users"] if u["id"] == (body.get("id") or "").lower()), None)
            if not target:
                raise ApiError(404, "User not found.")
            problem = password_problem(body.get("password") or "")
            if problem:
                raise ApiError(400, problem)
            target["salt"], target["hash"] = hash_password(body["password"])
            save_json(firm_file(), firm)
            session_end(uid=target["id"])
            FAILS.pop("user:" + target["id"], None)
            security_log(f"password of {target['id']} reset by owner", user["id"], self.client_address[0])
            return {"ok": True}
        if path == "/api/me/password":
            _, digest = hash_password(body.get("old") or "", user["salt"])
            if not hmac.compare_digest(digest, user["hash"]):
                raise ApiError(401, "Your current password is wrong.")
            if (body.get("new") or "") != (body.get("new2") or ""):
                raise ApiError(400, "The two new passwords don't match.")
            problem = password_problem(body.get("new") or "")
            if problem:
                raise ApiError(400, problem)
            for u in firm["users"]:
                if u["id"] == user["id"]:
                    u["salt"], u["hash"] = hash_password(body["new"])
            save_json(firm_file(), firm)
            session_end(uid=user["id"])
            security_log("changed own password", user["id"], self.client_address[0])
            return {"token": session_new(user["id"], True)}
        if path in ("/api/users/approve", "/api/users/decline"):
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can approve new users.")
            uid = (body.get("id") or "").strip().lower()
            if path.endswith("approve"):
                for u in firm["users"]:
                    if u["id"] == uid:
                        u["status"] = "active"
                        u["role"] = "site" if (u.get("designation") or "").lower() == "site supervisor" else u.get("role", "designer")
            else:
                firm["users"] = [u for u in firm["users"] if not (u["id"] == uid and u.get("status") == "pending")]
            save_json(firm_file(), firm)
            cloud_sync_users(firm)
            return {"users": team_view(firm)}
        if path in ("/api/users", "/api/users/remove"):
            if user.get("role") != "owner":
                raise ApiError(403, "Only the studio owner can manage the team.")
            if path.endswith("/remove"):
                uid = (body.get("id") or "").strip().lower()
                if uid == user["id"]:
                    raise ApiError(400, "You can't remove yourself.")
                firm["users"] = [u for u in firm["users"] if u["id"] != uid]
            else:
                uid = (body.get("id") or "").strip().lower()
                name = (body.get("name") or "").strip()
                pw = body.get("password") or ""
                role = body.get("role") if body.get("role") in ("designer", "site") else "designer"
                if not name or not re.match(r"^[a-z0-9._\-]{3,30}$", uid):
                    raise ApiError(400, "Give a name and a user ID of 3–30 letters or numbers, no spaces.")
                if any(u["id"] == uid for u in firm["users"]):
                    raise ApiError(409, "That user ID is already in use.")
                phone, email = (body.get("phone") or "").strip(), norm_email(body.get("email"))
                if phone and len(norm_phone(phone)) < 10:
                    raise ApiError(400, "Please enter a 10-digit phone number.")
                taken = contact_taken(firm, phone, email)
                if taken:
                    raise ApiError(409, taken)
                problem = password_problem(pw)
                if problem:
                    raise ApiError(400, problem)
                active_n = sum(1 for u in firm["users"] if u.get("status", "active") == "active")
                if active_n + 1 > INCLUDED_USERS and not body.get("confirm"):
                    extra = active_n + 1 - INCLUDED_USERS
                    return {"confirm": True, "extra": extra, "fee": EXTRA_USER_FEE, "monthly": extra * EXTRA_USER_FEE,
                            "text": f"Adding {name} makes {extra} extra user{'s' if extra != 1 else ''}. "
                                    f"Your monthly bill goes up by Rs {EXTRA_USER_FEE} — extra users will cost Rs {extra * EXTRA_USER_FEE} a month "
                                    f"on top of your subscription (Rs {(extra - 1) * EXTRA_USER_FEE} now)."}
                salt, digest = hash_password(pw)
                firm["users"].append({"id": uid, "name": name, "role": role, "salt": salt, "hash": digest,
                                      "designation": team.remember_role(firm, body.get("designation")),
                                      "profession": (body.get("profession") or "").strip()[:60],
                                      "phone": phone, "email": email,
                                      "status": "active", "added": now_iso()})
                team.on_user_added(firm, uid)
                security_log(f"user {uid} added by owner", user["id"], self.client_address[0])
            save_json(firm_file(), firm)
            cloud_sync_users(firm)
            return {"users": team_view(firm)}
        if path == "/api/sort-all":
            report = {"moved": 0, "unsure": 0}
            for d in project_dirs():
                p = load_project(d)
                if p:
                    r = sort_project(p, f"Folder Bot (run by {user['name']})")
                    report["moved"] += len(r["moved"])
                    report["unsure"] += len(r["unsure"])
            return report
        m = re.match(r"^/api/projects/([^/]+)/([a-z\-]+)(?:/([^/]+))?$", path)
        if not m:
            raise ApiError(404, "Unknown request.")
        proj = find_project(m.group(1))
        if not proj:
            raise ApiError(404, "Project not found.")
        action, sub = m.group(2), m.group(3)
        return self.project_action(proj, action, sub, body, user, firm)

    # -------- registration: details -> payment -> choose user ID and password -> dashboard
    def register_start(self, body):
        if DEMO:
            return demo.reg_start(self.headers.get("X-Reg", ""), body)
        if load_firm() and not testing_mode():
            raise ApiError(409, "This computer is already registered. Please sign in.")
        d = {k: str(body.get(k) or "").strip()[:200] for k in
             ("kind", "profession", "firm", "name", "designation", "city", "address", "phone", "email")}
        if not d["profession"]:
            raise ApiError(400, "Choose what you are, or type it under Other.")
        if not d["firm"] or not d["name"]:
            raise ApiError(400, "Please enter your firm name and your name.")
        if not d["phone"] and not d["email"]:
            raise ApiError(400, "Please enter a phone number or an email.")
        if d["phone"] and len(norm_phone(d["phone"])) < 10:
            raise ApiError(400, "Please enter a 10-digit phone number.")
        if d["email"] and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", d["email"]):
            raise ApiError(400, "That email address doesn't look right.")
        try:
            r = cloud_call(None, "/api/signup", {"name": d["name"], "firm": d["firm"], "email": d["email"] or f"{norm_phone(d['phone'])}@phone.designlab",
                                                 "phone": d["phone"], "city": d["city"], "address": d["address"], "kind": d["kind"] or "designer",
                                                 "profession": d["profession"], "designation": d["designation"]}, {"url": cloud_url()})
        except CloudError as e:
            raise ApiError(503, "Can't reach Design Lab to register right now. " + (e.message if e.status else "Please check the connection and try again."))
        cfg = config()
        cfg["pending"] = {"details": d, "order": r["order"], "pay": r.get("pay")}
        save_json(CONFIG_FILE, cfg)
        return {"order": r["order"], "pay": r.get("pay")}

    def register_pay(self, body):
        if DEMO:
            return demo.reg_pay(self.headers.get("X-Reg", ""), body)
        if load_firm() and not testing_mode():
            raise ApiError(409, "This computer is already registered.")
        cfg = config()
        pend = cfg.get("pending") or {}
        if not pend.get("order"):
            raise ApiError(400, "Please fill in your details first.")
        if not pend.get("activation"):
            try:
                r = cloud_call(None, "/api/pay/test", {"order": pend["order"]["id"], "skip": bool(body.get("skip"))}, {"url": cloud_url()})
            except CloudError as e:
                raise ApiError(503, e.message)
            pend["activation"] = {"url": cloud_url(), "code": r["code"], "key": vault.lock(r["key"]), "paid": now_iso(),
                                  "skipped": bool(body.get("skip"))}
            cfg["pending"] = pend
            save_json(CONFIG_FILE, cfg)
        return {"code": pend["activation"]["code"]}

    def register_finish(self, body):
        if DEMO:
            return demo.reg_finish(self.headers.get("X-Reg", ""), body, self.client_address[0])
        if load_firm() and not testing_mode():
            raise ApiError(409, "This computer is already registered. Please sign in.")
        cfg = config()
        pend = cfg.get("pending") or {}
        act = pend.get("activation")
        if not act:
            raise ApiError(402, "Please complete payment first.")
        d = pend["details"]
        uid = (body.get("user_id") or "").strip().lower()
        pw = body.get("password") or ""
        if not re.match(r"^[a-z0-9._\-]{3,30}$", uid):
            raise ApiError(400, "User ID: 3–30 letters, numbers, dots or dashes, no spaces.")
        if pw != (body.get("password2") or ""):
            raise ApiError(400, "The two passwords don't match.")
        problem = password_problem(pw)
        if problem:
            raise ApiError(400, problem)
        if load_firm():   # testing: keep the old studio safe in a backup folder, never delete
            old = os.path.join(projects_root(), ".designlab")
            os.replace(old, os.path.join(APP_DIR, "backup-old-studio-" + datetime.now().strftime("%Y%m%d-%H%M%S")))
            save_json(SESSIONS_FILE, {})   # everyone signs in again
        root = default_root()
        os.makedirs(os.path.join(root, ".designlab"), exist_ok=True)
        cfg["projects_root"] = store_root(root)
        save_json(CONFIG_FILE, cfg)
        salt, digest = hash_password(pw)
        recovery = "-".join(secrets.token_hex(2).upper() for _ in range(4))
        rsalt, rhash = hash_password(recovery)
        firm = {"firm": d["firm"], "created": now_iso(), "code": act["code"], "kind": d.get("kind") or "designer",
                "profession": d["profession"], "city": d["city"], "address": d["address"],
                "phone": d["phone"], "email": norm_email(d["email"]),
                "recovery": {"salt": rsalt, "hash": rhash},
                "cloud": {"url": act["url"], "code": act["code"], "key": vault.lock(vault.reveal(act["key"])), "linked": now_iso(), "firm_name": d["firm"]},
                "users": [{"id": uid, "name": d["name"], "role": "owner", "salt": salt, "hash": digest,
                           "profession": d["profession"], "designation": d["designation"] or ("Owner / Proprietor" if d.get("kind") == "vendor" else "Principal"),
                           "phone": d["phone"], "email": norm_email(d["email"]), "status": "active", "added": now_iso()}]}
        save_json(firm_file(), firm)
        cfg.pop("pending", None)
        save_json(CONFIG_FILE, cfg)
        cloud_sync_users(firm)
        security_log("studio registered, owner account created", uid, self.client_address[0])
        tok = session_new(uid, True)
        return {"token": tok, "name": d["name"], "firm": d["firm"], "recovery_code": recovery}

    def studio_login(self, body):
        firm = load_firm()
        if not firm:
            raise ApiError(409, "This computer isn't registered yet. Tap Register.")
        ident = (body.get("user_id") or "").strip()
        u = find_user(firm, ident)
        key = ("user:" + u["id"]) if u else ident.lower()   # lock the person, however they type their sign-in
        mins = locked_out(key)
        if mins:
            security_log("sign-in blocked (too many wrong tries)", ident, self.client_address[0])
            raise ApiError(429, f"Too many wrong tries. Please wait {mins} minute{'s' if mins != 1 else ''} and try again.")
        if u:
            _, digest = hash_password(body.get("password") or "", u["salt"])
            if hmac.compare_digest(digest, u["hash"]):
                if u.get("status") == "pending":
                    raise ApiError(403, "Your account is waiting for the studio owner to approve it.")
                if u.get("status") == "disabled":
                    raise ApiError(403, "This account has been switched off by the studio owner.")
                if u.get("demo_until") and u["demo_until"] < now_iso():
                    raise ApiError(403, "Your 3-day Design Lab demo has ended. Thank you for trying it! To get Design Lab for your studio, contact Design Lab.")
                FAILS.pop(key, None)
                tok = session_new(u["id"], body.get("remember", True) is not False)
                security_log("signed in", u["id"], self.client_address[0])
                return {"token": tok, "name": u["name"], "firm": firm.get("firm"), "role": u.get("role")}
        FAILS.setdefault(key, []).append(time.time())
        security_log("wrong password or user", ident, self.client_address[0])
        time.sleep(0.6)
        left = LOCK_TRIES - len(FAILS.get(key, []))
        raise ApiError(401, "That user ID, phone or email and password don't match."
                       + (f" {left} tr{'ies' if left != 1 else 'y'} left before a {LOCK_MINUTES}-minute lock." if 0 < left <= 2 else ""))

    def recover(self, body):
        firm = load_firm()
        if not firm or not firm.get("recovery"):
            raise ApiError(400, "Recovery isn't available.")
        ident = (body.get("user_id") or "").strip()
        key = "recover:" + ident.lower()
        mins = locked_out(key)
        if mins:
            raise ApiError(429, f"Too many wrong tries. Please wait {mins} minutes.")
        u = find_user(firm, ident)
        code = (body.get("code") or "").strip().upper()
        _, h = hash_password(code, firm["recovery"]["salt"])
        if not u or u.get("role") != "owner" or not hmac.compare_digest(h, firm["recovery"]["hash"]):
            FAILS.setdefault(key, []).append(time.time())
            security_log("failed password recovery", ident, self.client_address[0])
            time.sleep(0.6)
            raise ApiError(401, "That owner sign-in and recovery code don't match.")
        pw = body.get("password") or ""
        if pw != (body.get("password2") or ""):
            raise ApiError(400, "The two passwords don't match.")
        problem = password_problem(pw)
        if problem:
            raise ApiError(400, problem)
        u["salt"], u["hash"] = hash_password(pw)
        save_json(firm_file(), firm)
        session_end(uid=u["id"])
        FAILS.pop(key, None)
        FAILS.pop("user:" + u["id"], None)   # recovery also lifts a sign-in lock
        security_log("owner password reset with recovery code", u["id"], self.client_address[0])
        return {"ok": True}

    def create_project(self, body, user):
        proj = new_project(body, user)
        return {"project": public_project(proj, full=True)}

    def project_action(self, proj, action, sub, body, user, firm):
        pdir = proj["_dir"]
        if action == "update":
            for k in ("name", "client", "address"):
                if k in body:
                    proj[k] = str(body[k]).strip()
            save_project(proj)
        elif action == "contacts":
            had_client = any(contact_kind(c) == "client" and c.get("name") for c in proj.get("contacts", []))
            proj["contacts"] = [clean_contact(c) for c in body.get("contacts", [])
                                if c.get("name") or c.get("phone") or c.get("company")]
            add_log(proj, "contacts", f"Project card updated ({len(proj['contacts'])} people)")
            save_project(proj)
            book.learn(proj["contacts"])
            clients = [c["name"] for c in proj["contacts"] if c["kind"] == "client" and c["name"]]
            if clients and not had_client:
                assistant.notify(f"Client **{', '.join(clients)}** added to **{proj['name']}**.")
                assistant.report("client", "Client added", proj["name"], ", ".join(clients))
        elif action == "rooms":
            proj["rooms"] = [
                {"id": r.get("id") or secrets.token_hex(3), "name": str(r.get("name", "")).strip()[:40] or "Room",
                 "x": float(r.get("x", 0.5)), "y": float(r.get("y", 0.5))}
                for r in body.get("rooms", [])
            ]
            save_project(proj)
        elif action == "layout":
            data = self.decode_file(body)
            ext = os.path.splitext(body.get("name", "layout.jpg"))[1].lower() or ".jpg"
            if ext not in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
                raise ApiError(400, "Use a JPG or PNG image of the plan for the layout.")
            target = os.path.join(pdir, "01 Drawings", "Plans", "Design Lab layout" + ext)
            with open(target, "wb") as f:
                f.write(data)
            proj["layout"] = os.path.relpath(target, pdir).replace("\\", "/")
            proj["layout_v"] = int(time.time())
            try:
                proj["layout_ratio"] = max(0.2, min(5.0, float(body.get("ratio") or 0))) or None
            except (TypeError, ValueError):
                proj["layout_ratio"] = None
            add_log(proj, "layout", "Layout plan added for the Site view")
            save_project(proj)
        elif action == "notes":
            text = (body.get("text") or "").strip()
            if not text:
                raise ApiError(400, "The note is empty.")
            note = {"id": secrets.token_hex(4), "time": now_iso(), "by": user["name"],
                    "room": (body.get("room") or "").strip(), "kind": body.get("kind") or "note", "text": text[:4000]}
            proj["notes"].append(note)
            add_log(proj, "note", f"{note['kind'].capitalize()} — {note['room'] or 'General'}: {text[:70]}")
            save_project(proj)
        elif action == "files":
            return {"files": binbox.list_files(proj, str(body.get("folder") or ""))}
        elif action == "remove":
            return binbox.remove(proj, user, body)
        elif action == "bin":
            return {"bin": binbox.bin_list(proj)}
        elif action == "restore":
            return binbox.restore(proj, user, str(body.get("id", "")))
        elif action == "bin-empty":
            return binbox.empty(proj, user, firm)
        elif action == "replace":
            return binbox.replace(proj, user, body)
        elif action == "gallery":
            if gallery.scan(proj):
                save_project(proj)
            fn = {"add": lambda: gallery.add(proj, user["name"], body), "move": lambda: gallery.move(proj, user["name"], body),
                  "share": lambda: gallery.share(proj, user["name"], body), "comment": lambda: gallery.comment(proj, user["name"], body),
                  "remove": lambda: gallery.remove(proj, user, body), "link-new": lambda: gallery.link_new(proj, user["name"], body),
                  "link-on": lambda: gallery.link_off(proj, user["name"], body),
                  "link-set": lambda: gallery.link_set(proj, user["name"], body)}.get(sub or "")
            if sub and not fn:
                raise ApiError(404, "Unknown request.")
            res = None
            if fn:
                res = fn()
                proj = find_project(proj["id"])
            return {"result": res, "items": gallery.view(proj), "links": gallery.links(proj), "share_base": share_base(),
                    "client_folders": gallery.CLIENT_FOLDERS,
                    "rooms": [r.get("name") for r in proj.get("rooms", []) if r.get("name")],
                    "team": [{"id": u["id"], "name": u["name"]} for u in firm.get("users", []) if u.get("status") == "active"]}
        elif action == "drawings":
            fn = {"rooms": lambda: drawings.set_rooms(proj, user["name"], body), "copy": lambda: drawings.save_copy(proj, user["name"], body),
                  "correct": lambda: drawings.correct(proj, user, body), "update": lambda: drawings.update(proj, user, body),
                  "signoff": lambda: drawings.signoff_send(proj, user, body)}.get(sub or "")
            if sub and not fn:
                raise ApiError(404, "Unknown request.")
            if fn:
                fn()
                proj = find_project(proj["id"])
            st = drawings.state(proj)
            st["team"] = [u["name"] for u in firm.get("users", []) if u.get("status") == "active"]
            return st
        elif action == "moodboard":
            mb = proj.setdefault("moodboard", {"words": "", "images": []})
            mdir = os.path.join(pdir, "09 Mood Board")
            os.makedirs(mdir, exist_ok=True)
            if "words" in body:
                mb["words"] = str(body.get("words") or "")[:1500]
            for d in (body.get("add") or [])[:12]:
                m = re.match(r"^data:image/(jpeg|png|webp);base64,(.+)$", d or "", re.S)
                if not m:
                    continue
                name = os.path.basename(unique_path(os.path.join(mdir, f"mood {datetime.now().strftime('%Y%m%d %H%M%S')} {secrets.token_hex(2)}.{'jpg' if m.group(1) == 'jpeg' else m.group(1)}")))
                with open(os.path.join(mdir, name), "wb") as f:
                    f.write(base64.b64decode(m.group(2)))
                mb["images"].append(name)
            if body.get("remove") in mb["images"]:
                mb["images"].remove(body["remove"])     # the file stays in the folder; only the board forgets it
            save_project(proj)
            return {"moodboard": mb}
        elif action == "moodboard-share":
            mb = proj.get("moodboard") or {}
            imgs = []
            for name in (mb.get("images") or [])[:6]:
                fp = os.path.join(pdir, "09 Mood Board", name)
                if os.path.isfile(fp) and os.path.getsize(fp) < 3_000_000:
                    ext = os.path.splitext(name)[1].lower()
                    mime = {".png": "image/png", ".webp": "image/webp"}.get(ext, "image/jpeg")
                    with open(fp, "rb") as f:
                        imgs.append(f"data:{mime};base64," + base64.b64encode(f.read()).decode())
            if not imgs:
                raise ApiError(400, "Add a few pictures to the mood board first.")
            hdr = {"X-User-Id": urllib.parse.quote(user["id"]), "X-User-Name": urllib.parse.quote(user["name"]), "X-User-Role": user.get("role", "")}
            try:
                r = cloud_call(firm, "/api/studio/courtyard/post", {"type": "moodboard", "title": str(body.get("title") or f"Looking for: {proj['name']}")[:120],
                               "text": str(body.get("text") or mb.get("words") or "")[:2000], "images": imgs, "city": body.get("city") or ""},
                               headers=hdr, timeout=40)
            except CloudError as e:
                raise ApiError(e.status or 503, e.message)
            add_log(proj, "courtyard", f"Mood board shared in The Courtyard by {user['name']}")
            save_project(proj)
            return {"ok": True, "note": r.get("note", "")}
        elif action == "meeting":
            # whole meeting spoken into the phone (keyboard mic / voice typing) -> points for the MOM
            text = (body.get("text") or "").strip()
            if len(text) < 3:
                raise ApiError(400, "Nothing was recorded. Speak or type the meeting first.")
            room = (body.get("room") or "").strip()
            stamp = datetime.now().strftime("%Y-%m-%d %H%M")
            mdir = os.path.join(pdir, "04 MOM", "Meeting recordings")
            os.makedirs(mdir, exist_ok=True)
            with open(unique_path(os.path.join(mdir, f"{stamp} meeting notes.txt")), "w", encoding="utf-8") as f:
                f.write(text)
            audio = body.get("audio") or ""
            if audio.startswith("data:"):
                ext = ".m4a" if "mp4" in audio[:40] or "m4a" in audio[:40] else ".webm"
                with open(unique_path(os.path.join(mdir, f"{stamp} meeting audio{ext}")), "wb") as f:
                    f.write(base64.b64decode(audio.split(",", 1)[1]))
            points = meeting_points(text)
            for kind, pt in points:
                proj["notes"].append({"id": secrets.token_hex(4), "time": now_iso(), "by": user["name"], "room": room,
                                      "kind": kind, "text": pt[:1000], "from": "meeting"})
            add_log(proj, "note", f"Meeting recorded by {user['name']}: {len(points)} points")
            save_project(proj)
            return {"points": len(points), "project": public_project(find_project(proj["id"]), full=True)}
        elif action == "photos":
            data = self.decode_file(body)
            room = safe_name(body.get("room") or "General", "General")
            ext = os.path.splitext(body.get("name", "photo.jpg"))[1].lower()
            ext = ext if ext in IMAGE_EXT else ".jpg"
            day_dir = os.path.join(pdir, "03 Site Photos", today_iso())
            os.makedirs(day_dir, exist_ok=True)
            target = unique_path(os.path.join(day_dir, f"{room} {datetime.now().strftime('%H%M%S')}{ext}"))
            with open(target, "wb") as f:
                f.write(data)
            rel = os.path.relpath(target, pdir).replace("\\", "/")
            proj["notes"].append({"id": secrets.token_hex(4), "time": now_iso(), "by": user["name"],
                                  "room": body.get("room") or "", "kind": "photo", "text": body.get("caption") or "",
                                  "file": rel})
            add_log(proj, "photo", f"Photo filed — {body.get('room') or 'General'}")
            save_project(proj)
            return {"file": rel, "project": public_project(proj, full=True)}
        elif action == "snags":
            if sub:  # update an existing snag
                for s in proj["snags"]:
                    if s["id"] == sub:
                        if body.get("status") == "closed":
                            s["status"] = "closed"
                            s["closed"] = now_iso()
                            s["closed_by"] = user["name"]
                            add_log(proj, "snag", f"Snag closed — {s.get('room') or 'General'}: {s['text'][:60]}")
                        elif body.get("status") == "open":
                            s["status"] = "open"
                save_project(proj)
            else:
                text = (body.get("text") or "").strip()
                if not text:
                    raise ApiError(400, "Describe the snag.")
                snag = {"id": secrets.token_hex(4), "time": now_iso(), "by": user["name"], "status": "open",
                        "room": (body.get("room") or "").strip(), "text": text[:600],
                        "owner": (body.get("owner") or "").strip(), "due": (body.get("due") or "").strip()}
                proj["snags"].append(snag)
                add_log(proj, "snag", f"Snag raised — {snag['room'] or 'General'}: {text[:60]}")
                self.write_snag_list(proj)
                save_project(proj)
        elif action == "events":
            if sub == "delete":
                return binbox.remove(proj, user, {"kind": "event", "id": body.get("id")})
            else:
                title = (body.get("title") or "").strip()
                if not title or not body.get("date"):
                    raise ApiError(400, "A meeting or reminder needs a title and a date.")
                ev = {"id": secrets.token_hex(4), "title": title[:120], "date": body["date"],
                      "time": (body.get("time") or "").strip(), "kind": body.get("kind") or "meeting",
                      "by": user["name"]}
                proj["events"].append(ev)
                add_log(proj, "event", f"{ev['kind'].capitalize()} set for {pretty_date(ev['date'])} {ev['time']}: {title[:50]}")
            save_project(proj)
        elif action == "mom":
            day = body.get("date") or today_iso()
            if sub == "save":
                text = (body.get("text") or "").strip()
                if not text:
                    raise ApiError(400, "The MOM is empty.")
                existing = next((m for m in proj["moms"] if m["date"] == day), None)
                if existing:  # same day's MOM edited again: overwrite, no new charge
                    with open(os.path.join(pdir, existing["file"]), "w", encoding="utf-8") as f:
                        f.write(text)
                    existing["saved"] = now_iso()
                    save_project(proj)
                    return {"file": existing["file"], "charged": False}
                charge = cloud_charge(firm, "site_mom", user["id"], proj["name"])
                target = unique_path(os.path.join(pdir, "04 MOM", f"MOM {day}.txt"))
                with open(target, "w", encoding="utf-8") as f:
                    f.write(text)
                rel = os.path.relpath(target, pdir).replace("\\", "/")
                proj["moms"].insert(0, {"date": day, "file": rel, "saved": now_iso(), "by": user["name"]})
                add_log(proj, "mom", f"MOM for {pretty_date(day)} saved to 04 MOM"
                        + (f" (Site Bot, Rs {charge['firm']['balance']:.0f} left in wallet)" if charge else ""))
                save_project(proj)
                return {"file": rel, "charged": bool(charge)}
            text, to = build_mom(proj, day, firm)
            return {"text": text, "to": to, "date": day}
        elif action == "sort":
            report = sort_project(proj, f"Folder Bot (run by {user['name']})")
            proj = find_project(proj["id"])
            return {"report": report, "project": public_project(proj, full=True)}
        elif action == "ai-sort":
            return ai_sort_inbox(firm, user, proj)
        elif action == "undo-sort":
            report = undo_last_sort(proj)
            proj = find_project(proj["id"])
            return {"report": report, "project": public_project(proj, full=True)}
        elif action == "open":
            if not self.is_main():
                raise ApiError(400, "Folders open on the studio computer. From here, ask your assistant to sort or find files.")
            target = os.path.normpath(os.path.join(pdir, body.get("folder") or ""))
            if not target.startswith(os.path.normpath(pdir)):
                raise ApiError(403, "Not allowed.")
            if not hasattr(os, "startfile"):
                raise ApiError(400, "Opening folders works on the studio computer (Windows).")
            os.startfile(target)  # type: ignore[attr-defined]
            return {"ok": True}
        else:
            raise ApiError(404, "Unknown request.")
        return {"project": public_project(find_project(proj["id"]), full=True)}

    # -------- client link (no password: a private link for one project)
    def client_api(self, tok, act, body):
        proj, link = gallery.by_token(tok)
        if not proj:
            time.sleep(0.4)
            raise ApiError(404, "This link isn't working. Please ask your designer for a new one.")
        who = link["name"] + " (client)"
        if act == "":
            for l in proj.get("client_links", []):
                if l["token"] == tok:
                    l["last_seen"] = now_iso()
            gallery.scan(proj)
            save_project(proj)
            firm = load_firm() or {}
            signs = [dict(v, key=k) for k, v in (proj.get("signoffs") or {}).items()]
            signs.sort(key=lambda x: (x["status"] != "waiting", x.get("sent", "")), reverse=False)
            return {"firm": firm.get("firm", ""), "project": proj["name"], "client": link["name"], "address": proj.get("address", ""),
                    "items": gallery.view(proj, for_client=True), "rooms": [r.get("name") for r in proj.get("rooms", []) if r.get("name")],
                    "signoffs": signs, "folders": link.get("folders") or [], "files": gallery.client_files(proj, link),
                    "expires": link.get("expires", "")}
        now = time.time()
        hits = [t for t in CLIENT_HITS.get(tok, []) if now - t < 60] + [now]
        CLIENT_HITS[tok] = hits
        if len(hits) > 30:
            raise ApiError(429, "Please wait a minute and try again.")
        if act == "upload":
            r = gallery.add(proj, who, body, source="client")
            assistant.notify(f"**{who}** sent {r['added']} picture{'s' if r['added'] != 1 else ''} to **{proj['name']}**'s Gallery"
                             + (f" (sorted into {', '.join(r['rooms'])})" if r["rooms"] else ""))
            return r
        if act == "pick":
            return gallery.pick(proj, who, body)
        if act == "comment":
            it = next((x for x in proj.get("gallery", []) if x["id"] == str(body.get("id")) and x.get("shared")), None)
            if not it:
                raise ApiError(404, "That picture has moved.")
            r = gallery.comment(proj, who, body, source="client")
            assistant.notify(f"**{who}** commented on a picture in **{proj['name']}**: {str(body.get('text'))[:80]}")
            return r
        if act == "signoff":
            return drawings.signoff_reply(proj, who, body)
        raise ApiError(404, "Unknown request.")

    def client_file(self, path):
        # /cfile/<token>/<relative path> : only pictures the studio shared, and drawings sent for sign-off
        parts = path.split("/", 3)
        if len(parts) < 4:
            return self.send_error(404)
        with LOCK:
            proj, link = gallery.by_token(parts[2])
        if not proj:
            return self.send_error(404)
        rel = parts[3]
        ok = any(it["rel"] == rel and it.get("shared") for it in proj.get("gallery", [])) or \
            any(v.get("rel") == rel for v in (proj.get("signoffs") or {}).values())
        if not ok and gallery.client_ok(link, rel):
            full = os.path.normpath(os.path.join(proj["_dir"], rel))
            if inside(proj["_dir"], full) and os.path.isfile(full):
                with LOCK:
                    gallery.log_open(proj, parts[2], rel)
                ok = True
        if not ok:
            return self.send_error(404)
        return self.serve_file(os.path.normpath(os.path.join(proj["_dir"], rel)))

    def dash_here(self, user):
        """'My dashboard' shows only for the owner, on the main computer, where Design Lab's business server runs."""
        if user.get("role") != "owner" or not self.is_main():
            return ""
        try:
            with socket.create_connection(("127.0.0.1", 8800), timeout=0.25):
                return "http://localhost:8800/admin"
        except OSError:
            return ""

    def cloud_status(self, firm):
        cfg = cloud_cfg(firm)
        if not cfg.get("url"):
            return {"connected": False}
        out = {"connected": True, "url": cfg["url"], "code": cfg.get("code"), "linked": cfg.get("linked")}
        try:
            r = cloud_call(firm, "/api/studio/wallet")
            out.update({"online": True, "firm": r["firm"], "bots": r.get("bots", []), "pricing": r.get("pricing", {}),
                        "spend": r.get("spend", [])})
        except CloudError as e:
            out.update({"online": False, "error": e.message})
        return out

    def write_snag_list(self, proj):
        lines = [f"SNAG LIST — {proj['name']}", f"Updated {datetime.now().strftime('%d %b %Y %H:%M')}", ""]
        for s in proj["snags"]:
            mark = "[x]" if s.get("status") == "closed" else "[ ]"
            extra = " — " + s["owner"] if s.get("owner") else ""
            due = f" (by {pretty_date(s['due'])})" if s.get("due") else ""
            lines.append(f"{mark} {s.get('room') or 'General'}: {s['text']}{extra}{due}")
        with open(os.path.join(proj["_dir"], "05 Snags", "Snag list.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    @staticmethod
    def decode_file(body):
        data = body.get("data") or ""
        if "," in data[:100]:
            data = data.split(",", 1)[1]
        try:
            return base64.b64decode(data)
        except (ValueError, TypeError):
            raise ApiError(400, "The file could not be read.")


CLIENT_HITS = {}
import vault      # noqa: E402  (keys locked on disk)
import binbox     # noqa: E402  (remove, bin, replace)
import records    # noqa: E402  (business records, private pages, capture)
import assistant  # noqa: E402  (studio assistant: separate file, can change on its own)
import book       # noqa: E402  (vendors & contractors list)
import demo       # noqa: E402  (the shared demo copy)
import gallery    # noqa: E402  (project gallery + client links)
import drawings   # noqa: E402  (site plans and corrections)
import team       # noqa: E402  (invitations, Courtyard access, profile, usage)
assistant.S = book.S = records.S = demo.S = binbox.S = gallery.S = drawings.S = team.S = sys.modules[__name__]
book_search = book.search


def main():
    mimetypes.add_type("text/javascript", ".js")
    mimetypes.add_type("text/css", ".css")
    threading.Thread(target=bot_loop, daemon=True).start()
    if DEMO:
        demo.seed()
    try:
        httpd = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError:
        print(f"\n  Design Lab is already running (port {PORT} is busy).")
        print(f"  Open http://localhost:{PORT} in your browser.\n")
        return
    print("")
    print("  ==============================================")
    print("   DESIGN LAB  v" + VERSION + "  — studio server is running")
    print("  ==============================================")
    print(f"   On this computer:  http://localhost:{PORT}")
    for url in lan_addresses():
        print(f"   On your phone (same Wi-Fi):  {url}")
    print(f"   Projects folder:  {projects_root() or default_root()}")
    print("")
    print("   Keep this window open while you use Design Lab.")
    print("   To stop: click this window and press Ctrl+C.")
    print("")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Design Lab stopped.\n")


if __name__ == "__main__":
    main()
