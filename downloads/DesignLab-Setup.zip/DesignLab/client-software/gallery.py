"""
Design Lab - Project Gallery and client access.

Folder: <project>/10 Gallery
    For selection/        options the studio puts up for the client to choose from
    Selected/             what the client (or the studio) has chosen
    Reference images/     pictures for reference
    Rooms/<room>/         pictures sorted by room (the Gallery Bot puts client pictures here)
    Random/               pictures the bot could not place yet

The client gets a private link (no password) for one project: they can see what the
studio shares, choose, comment, send pictures from their phone and sign off drawings.
A link can be switched off at any time.
"""
import base64
import os
import re
import secrets
import shutil
import threading
from datetime import datetime

S = None
ROOT = "10 Gallery"
BUCKETS = {"selection": "For selection", "selected": "Selected", "reference": "Reference images"}
IMG = (".jpg", ".jpeg", ".png", ".webp", ".gif")
MAX_UPLOAD = 12
MAX_BYTES = 12 * 1024 * 1024

# words people use -> room name the bot files under (project's own room names are checked first)
ROOM_WORDS = [
    ("Master bedroom", ("master bed", "master room", "mbr", "parents room", "parents' room")),
    ("Kids' room", ("kids", "kid's", "children", "child room", "son's room", "daughter's room", "bachcho")),
    ("Guest room", ("guest",)),
    ("Bedroom", ("bedroom", "bed room", "bed ", "wardrobe", "sone ka kamra")),
    ("Kitchen", ("kitchen", "modular", "rasoi", "chimney", "hob", "pantry")),
    ("Dining", ("dining", "dinning", "crockery")),
    ("Living room", ("living", "hall", "drawing room", "lounge", "tv unit", "sofa", "baithak")),
    ("Bathroom", ("bath", "toilet", "washroom", "wc", "vanity", "shower")),
    ("Balcony", ("balcony", "terrace", "deck", "sit-out", "sitout")),
    ("Puja room", ("puja", "pooja", "mandir", "temple")),
    ("Study", ("study", "office", "work from home", "desk")),
    ("Entrance", ("foyer", "entrance", "entry", "main door", "shoe")),
]
SUBJECTS = [
    ("Lighting", ("light", "lamp", "chandelier", "pendant", "profile")),
    ("Flooring", ("floor", "tile", "marble", "wooden floor", "vinyl")),
    ("Furniture", ("sofa", "chair", "table", "bed", "furniture", "wardrobe")),
    ("Colours", ("colour", "color", "paint", "shade")),
    ("Curtains", ("curtain", "blind", "drape")),
    ("Wallpaper", ("wallpaper", "texture", "panel")),
]


def _gdir(pdir):
    return os.path.join(pdir, ROOT)


def ensure(pdir):
    for sub in list(BUCKETS.values()) + ["Rooms", "Random"]:
        os.makedirs(os.path.join(_gdir(pdir), sub), exist_ok=True)


def folder_for(bucket, room):
    if bucket in BUCKETS:
        return f"{ROOT}/{BUCKETS[bucket]}"
    if room:
        return f"{ROOT}/Rooms/{S.safe_name(room, 'Room')}"
    return f"{ROOT}/Random"


def bucket_of(rel):
    parts = rel.split("/")
    if len(parts) < 3:
        return "random", ""
    for k, v in BUCKETS.items():
        if parts[1] == v:
            return k, ""
    if parts[1] == "Rooms" and len(parts) >= 4:
        return "room", parts[2]
    return "random", ""


def guess(text, proj):
    """Gallery Bot (word matching): room and subject from the client's words / file name."""
    t = " " + re.sub(r"[_\-.]+", " ", (text or "").lower()) + " "
    room = ""
    for r in proj.get("rooms") or []:
        n = (r.get("name") or "").strip().lower()
        if n and n in t:
            room = r["name"]
            break
    if not room:
        for name, words in ROOM_WORDS:
            if any(w in t for w in words):
                room = name
                break
    subject = next((name for name, words in SUBJECTS if any(w in t for w in words)), "")
    return room, subject


def scan(proj):
    """Keep the gallery list in step with the folder: files people drop in by hand appear, files removed disappear."""
    pdir = proj["_dir"]
    ensure(pdir)
    items = proj.setdefault("gallery", [])
    known = {it["rel"] for it in items}
    changed = False
    for b, dirs, files in os.walk(_gdir(pdir)):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for f in files:
            if f.startswith(".") or not f.lower().endswith(IMG):
                continue
            rel = os.path.relpath(os.path.join(b, f), pdir).replace("\\", "/")
            if rel in known:
                continue
            bucket, room = bucket_of(rel)
            items.append({"id": secrets.token_hex(5), "rel": rel, "bucket": bucket, "room": room, "subject": "",
                          "source": "team", "by": "Added in the folder", "time": datetime.fromtimestamp(os.path.getmtime(os.path.join(b, f))).isoformat(timespec="seconds"),
                          "caption": "", "shared": bucket in ("selection", "selected"), "pick": "", "comments": []})
            changed = True
    keep = [it for it in items if os.path.isfile(os.path.join(pdir, it["rel"]))]
    if len(keep) != len(items):
        proj["gallery"] = keep
        changed = True
    return changed


def _save_image(pdir, folder, name, data_url):
    m = re.match(r"^data:image/(jpeg|jpg|png|webp|gif);base64,(.+)$", data_url or "", re.S)
    if not m:
        return None
    raw = base64.b64decode(m.group(2))
    if len(raw) > MAX_BYTES:
        return None
    ext = ".jpg" if m.group(1) in ("jpeg", "jpg") else "." + m.group(1)
    stem = S.safe_name(os.path.splitext(os.path.basename(name or ""))[0], "") or "picture"
    stem = f"{datetime.now().strftime('%Y-%m-%d %H%M%S')} {stem[:50]}"
    d = os.path.join(pdir, *folder.split("/"))
    os.makedirs(d, exist_ok=True)
    full = S.unique_path(os.path.join(d, stem + ext))
    with open(full, "wb") as f:
        f.write(raw)
    return os.path.relpath(full, pdir).replace("\\", "/")


def add(proj, who, body, source="team"):
    pdir = proj["_dir"]
    ensure(pdir)
    caption = str(body.get("caption") or "").strip()[:300]
    bucket = body.get("bucket") if body.get("bucket") in ("selection", "selected", "reference", "room", "sort") else "sort"
    room = str(body.get("room") or "").strip()[:40]
    added, to_ai = [], []
    for im in (body.get("images") or [])[:MAX_UPLOAD]:
        b, r, subject = bucket, room, ""
        if b == "sort":
            gr, subject = guess(caption + " " + str(im.get("name") or ""), proj)
            b, r = "room", (room or gr)
        rel = _save_image(pdir, folder_for(b, r), im.get("name"), im.get("data"))
        if not rel:
            continue
        it = {"id": secrets.token_hex(5), "rel": rel, "bucket": b, "room": r if b == "room" else room, "subject": subject,
              "source": source, "by": who, "time": S.now_iso(), "caption": caption,
              "shared": source == "client" or b in ("selection", "selected"), "pick": "", "comments": []}
        proj.setdefault("gallery", []).append(it)
        added.append(it)
        if b == "room" and not it["room"] and caption:
            to_ai.append(it["id"])
    if not added:
        raise S.ApiError(400, "Choose one or more pictures (JPG or PNG, up to 12 MB each).")
    sorted_n = sum(1 for it in added if it["room"])
    S.add_log(proj, "gallery", f"{who} added {len(added)} picture{'s' if len(added) != 1 else ''} to the Gallery"
              + (f" — Gallery Bot sorted {sorted_n} into rooms" if bucket == "sort" else ""))
    S.save_project(proj)
    if to_ai:
        threading.Thread(target=_ai_sort, args=(proj["id"], to_ai, caption), daemon=True).start()
    return {"added": len(added), "sorted": sorted_n, "rooms": sorted({it["room"] for it in added if it["room"]})}


def _ai_sort(pid, ids, caption):
    """Words didn't place it: ask the Gallery Bot (AI, if the studio has it switched on). Quietly skipped otherwise."""
    try:
        firm = S.load_firm()
        proj = S.find_project(pid)
        names = [r.get("name", "") for r in (proj.get("rooms") or []) if r.get("name")] or [n for n, _ in ROOM_WORDS]
        rooms = ", ".join(names)
        r = S.ai_bot(firm, {"id": "gallery-bot"}, "gallery",
                     f"The client sent a picture with these words: \"{caption}\". Rooms in this home: {rooms}. "
                     "Reply with only the room name from the list, or Random.", proj["name"])
        ans = (r.get("answer") or r.get("text") or "").strip().strip(".").strip()
        ans = next((n for n in names if n.lower() == ans.lower()), "")
        if not r.get("ai") or not ans:
            return
        with S.LOCK:
            proj = S.find_project(pid)
            for it in proj.get("gallery", []):
                if it["id"] in ids and not it["room"]:
                    _move(proj, it, "room", ans)
            S.add_log(proj, "gallery", f"Gallery Bot (AI) put {len(ids)} picture{'s' if len(ids) != 1 else ''} in {ans}")
            S.save_project(proj)
    except Exception:
        pass


def _move(proj, it, bucket, room):
    pdir = proj["_dir"]
    folder = folder_for(bucket, room)
    src = os.path.join(pdir, it["rel"])
    d = os.path.join(pdir, *folder.split("/"))
    os.makedirs(d, exist_ok=True)
    if os.path.dirname(os.path.normpath(src)) != os.path.normpath(d):
        dst = S.unique_path(os.path.join(d, os.path.basename(src)))
        shutil.move(src, dst)
        it["rel"] = os.path.relpath(dst, pdir).replace("\\", "/")
    it["bucket"] = bucket
    it["room"] = room


def _item(proj, iid):
    it = next((x for x in proj.get("gallery", []) if x["id"] == str(iid)), None)
    if not it:
        raise S.ApiError(404, "That picture has moved or been removed.")
    return it


def move(proj, who, body):
    it = _item(proj, body.get("id"))
    bucket = body.get("bucket") if body.get("bucket") in ("selection", "selected", "reference", "room") else it["bucket"]
    room = str(body.get("room") if "room" in body else it.get("room") or "").strip()[:40]
    _move(proj, it, bucket, room)
    if bucket == "selected":
        it["shared"] = True
    S.add_log(proj, "gallery", f"{who} moved a picture to {BUCKETS.get(bucket) or room or 'Random'}")
    S.save_project(proj)
    return {"ok": True}


def share(proj, who, body):
    it = _item(proj, body.get("id"))
    it["shared"] = bool(body.get("on"))
    S.save_project(proj)
    return {"ok": True}


def comment(proj, who, body, source="team"):
    it = _item(proj, body.get("id"))
    text = str(body.get("text") or "").strip()[:600]
    if not text:
        raise S.ApiError(400, "Write a comment first.")
    it.setdefault("comments", []).append({"by": who, "text": text, "time": S.now_iso(), "source": source})
    S.add_log(proj, "gallery", f"{who} commented on a picture: {text[:60]}")
    S.save_project(proj)
    return {"ok": True}


def pick(proj, who, body):
    """Client: 'I like this' (moves to Selected) or 'Not for me'."""
    it = _item(proj, body.get("id"))
    if not it.get("shared"):
        raise S.ApiError(404, "That picture has moved or been removed.")
    p = body.get("pick") if body.get("pick") in ("yes", "no", "") else ""
    it["pick"] = p
    if p == "yes" and it["bucket"] == "selection":
        _move(proj, it, "selected", it.get("room", ""))
    elif p != "yes" and it["bucket"] == "selected" and it.get("source") != "client":
        _move(proj, it, "selection", it.get("room", ""))
    S.add_log(proj, "gallery", f"{who} {'chose' if p == 'yes' else 'said no to' if p == 'no' else 'un-marked'} a picture"
              + (f" ({it.get('room')})" if it.get("room") else ""))
    if p:
        S.assistant.notify(f"**{who}** {'chose' if p == 'yes' else 'said no to'} a picture in **{proj['name']}**'s Gallery.")
    S.save_project(proj)
    return {"ok": True}


def remove(proj, user, body):
    it = _item(proj, body.get("id"))
    r = S.binbox.remove(proj, user, {"kind": "file", "rel": it["rel"]})
    proj = S.find_project(proj["id"])
    proj["gallery"] = [x for x in proj.get("gallery", []) if x["id"] != it["id"]]
    S.save_project(proj)
    return r


def view(proj, for_client=False):
    items = proj.get("gallery", [])
    if for_client:
        items = [it for it in items if it.get("shared")]
    out = []
    for it in sorted(items, key=lambda x: x["time"], reverse=True):
        x = {k: it.get(k) for k in ("id", "rel", "bucket", "room", "subject", "source", "by", "time", "caption", "shared", "pick", "comments")}
        x["folder"] = BUCKETS.get(it["bucket"]) or (("Rooms / " + it["room"]) if it.get("room") else "Random")
        out.append(x)
    return out


# ---------------------------------------------------------------- client links

def links(proj):
    return [{k: v for k, v in l.items()} for l in proj.get("client_links", [])]


def link_new(proj, who, body):
    name = str(body.get("name") or "").strip()[:60]
    if not name:
        clients = [c.get("name") for c in proj.get("contacts", []) if S.contact_kind(c) == "client" and c.get("name")]
        name = clients[0] if clients else (proj.get("client") or "Client")
    tok = secrets.token_urlsafe(18)
    proj.setdefault("client_links", []).append({"token": tok, "name": name, "by": who, "created": S.now_iso(), "on": True, "last_seen": ""})
    S.add_log(proj, "client", f"{who} made a client link for {name}")
    S.save_project(proj)
    return {"token": tok, "links": links(proj)}


def link_off(proj, who, body):
    for l in proj.get("client_links", []):
        if l["token"] == body.get("token"):
            l["on"] = bool(body.get("on"))
    S.add_log(proj, "client", f"{who} {'switched on' if body.get('on') else 'switched off'} a client link")
    S.save_project(proj)
    return {"links": links(proj)}


# ---------------------------------------------------------------- folders a client may see (read-only)
CLIENT_FOLDERS = ["01 Drawings", "02 3D", "03 Site Photos", "04 MOM", "05 Snags", "07 Client Docs", "09 Mood Board"]
CLIENT_NEVER = ("01 Drawings/Superseded",)          # old drawings never go to a client by mistake
CLIENT_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".pdf", ".dwg", ".dxf", ".skp", ".obj", ".fbx", ".glb", ".gltf", ".3ds",
              ".mp4", ".mov", ".m4v", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt"}


def link_set(proj, who, body):
    """Choose which folders a client link opens, and until when."""
    for l in proj.get("client_links", []):
        if l["token"] == body.get("token"):
            l["folders"] = [f for f in CLIENT_FOLDERS if f in (body.get("folders") or [])]
            exp = str(body.get("expires") or "")[:10]
            l["expires"] = exp if re.match(r"^\d{4}-\d{2}-\d{2}$", exp) else ""
            S.add_log(proj, "client", f"{who} set {l['name']}'s link to show: {', '.join(l['folders']) or 'pictures and drawings only'}"
                      + (f" (until {l['expires']})" if l["expires"] else ""))
    S.save_project(proj)
    return {"links": links(proj)}


def client_ok(link, rel):
    rel = rel.replace("\\", "/")
    if any(rel == n or rel.startswith(n + "/") for n in CLIENT_NEVER):
        return False
    if any(part.startswith(".") for part in rel.split("/")):
        return False
    if os.path.splitext(rel)[1].lower() not in CLIENT_EXT:
        return False
    return any(rel.startswith(f + "/") for f in (link.get("folders") or []) if f in CLIENT_FOLDERS)


def client_files(proj, link):
    out = []
    for top in link.get("folders") or []:
        base = os.path.join(proj["_dir"], top)
        if top not in CLIENT_FOLDERS or not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            dirs[:] = sorted(d for d in dirs if not d.startswith("."))
            for n in sorted(files):
                full = os.path.join(root, n)
                rel = os.path.relpath(full, proj["_dir"]).replace(os.sep, "/")
                if not client_ok(link, rel) or not S.inside(proj["_dir"], full):
                    continue
                try:
                    st = os.stat(full)
                except OSError:
                    continue
                out.append({"rel": rel, "name": n, "folder": os.path.dirname(rel), "size": st.st_size,
                            "time": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds")})
                if len(out) >= 600:
                    return out
    return out


def log_open(proj, tok, rel):
    for l in proj.get("client_links", []):
        if l["token"] == tok:
            l.setdefault("opened", []).insert(0, {"time": S.now_iso(), "rel": rel})
            l["opened"] = l["opened"][:100]
    S.save_project(proj)


def by_token(tok):
    """Find the project and link for a client link. None if wrong or switched off."""
    if not tok or len(tok) < 16:
        return None, None
    for d in S.project_dirs():
        p = S.load_project(d)
        for l in (p or {}).get("client_links", []):
            if secrets.compare_digest(l["token"], tok):
                live = l.get("on") and not (l.get("expires") and l["expires"] < S.today_iso())
                return (p, l) if live else (None, None)
    return None, None
