"""
Design Lab - remove, bin and replace (for everything inside a project).

Nothing is deleted straight away: removed files and items go to the project's bin
(<project>/.designlab/bin) and can be restored for 30 days. After 30 days they are cleared;
the owner (or people the owner allows) can empty the bin earlier.
"Replace" puts a new drawing in place; the old one moves to 01 Drawings/Superseded.
"""
import base64
import os
import re
import secrets
import shutil
from datetime import datetime, timedelta

S = None
KEEP_DAYS = 30
ITEM_KINDS = {"note": "notes", "snag": "snags", "event": "events", "room": "rooms"}
IMG = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic")


def _bin_dir(pdir):
    return os.path.join(pdir, ".designlab", "bin")


def _index(pdir):
    return os.path.join(_bin_dir(pdir), "bin.json")


def _load(pdir):
    return S.load_json(_index(pdir), [])


def _save(pdir, items):
    os.makedirs(_bin_dir(pdir), exist_ok=True)
    S.save_json(_index(pdir), items)


def _safe_rel(pdir, rel):
    full = os.path.normpath(os.path.join(pdir, rel or ""))
    if not full.startswith(os.path.normpath(pdir) + os.sep) or os.sep + ".designlab" in full:
        raise S.ApiError(403, "Not allowed.")
    return full


def purge(pdir):
    """Clear what has been in the bin for more than 30 days."""
    items = _load(pdir)
    cut = (datetime.now() - timedelta(days=KEEP_DAYS)).isoformat(timespec="seconds")
    keep = []
    for it in items:
        if it["time"] < cut:
            if it.get("stored"):
                try:
                    os.remove(os.path.join(_bin_dir(pdir), it["stored"]))
                except OSError:
                    pass
        else:
            keep.append(it)
    if len(keep) != len(items):
        _save(pdir, keep)
    return keep


def list_files(proj, folder):
    pdir = proj["_dir"]
    base = _safe_rel(pdir, folder)
    out = []
    if os.path.isdir(base):
        for b, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for f in files:
                if f.startswith("."):
                    continue
                full = os.path.join(b, f)
                rel = os.path.relpath(full, pdir).replace("\\", "/")
                out.append({"rel": rel, "name": f, "folder": os.path.relpath(b, pdir).replace("\\", "/"),
                            "size": os.path.getsize(full), "time": datetime.fromtimestamp(os.path.getmtime(full)).isoformat(timespec="seconds"),
                            "image": f.lower().endswith(IMG), "superseded": "/Superseded" in rel})
    out.sort(key=lambda x: (x["superseded"], x["folder"], x["name"].lower()))
    return out


def remove(proj, user, body):
    pdir = proj["_dir"]
    kind = body.get("kind")
    items = purge(pdir)
    entry = {"id": secrets.token_hex(5), "time": S.now_iso(), "by": user["name"], "kind": kind}
    if kind == "file":
        src = _safe_rel(pdir, body.get("rel"))
        if not os.path.isfile(src):
            raise S.ApiError(404, "That file has already moved.")
        stored = entry["id"] + "__" + os.path.basename(src)
        os.makedirs(_bin_dir(pdir), exist_ok=True)
        shutil.move(src, os.path.join(_bin_dir(pdir), stored))
        entry.update({"stored": stored, "rel": os.path.relpath(src, pdir).replace("\\", "/"), "title": os.path.basename(src)})
        S.add_log(proj, "bin", f"{user['name']} removed “{entry['title']}” (in the bin for {KEEP_DAYS} days)")
    elif kind in ITEM_KINDS:
        lst = proj.get(ITEM_KINDS[kind], [])
        it = next((x for x in lst if str(x.get("id")) == str(body.get("id"))), None)
        if not it:
            raise S.ApiError(404, "Already removed.")
        lst.remove(it)
        entry.update({"data": it, "title": it.get("text") or it.get("title") or it.get("name") or kind})
        S.add_log(proj, "bin", f"{user['name']} removed a {kind}: {str(entry['title'])[:60]}")
    elif kind == "layout":
        if not proj.get("layout"):
            raise S.ApiError(404, "There is no site plan.")
        entry.update({"data": {"layout": proj.get("layout"), "layout_ratio": proj.get("layout_ratio"), "rooms": proj.get("rooms", [])},
                      "title": "Site plan and its rooms"})
        proj["layout"] = None
        proj["rooms"] = []
        S.add_log(proj, "bin", f"{user['name']} removed the site plan")
    else:
        raise S.ApiError(400, "Can't remove that.")
    items.insert(0, entry)
    _save(pdir, items)
    S.save_project(proj)
    return {"removed": entry["title"], "bin": len(items)}


def bin_list(proj):
    items = purge(proj["_dir"])
    return [{k: v for k, v in it.items() if k != "data"} | {"until": (datetime.fromisoformat(it["time"]) + timedelta(days=KEEP_DAYS)).strftime("%Y-%m-%d")}
            for it in items]


def restore(proj, user, iid):
    pdir = proj["_dir"]
    items = purge(pdir)
    it = next((x for x in items if x["id"] == iid), None)
    if not it:
        raise S.ApiError(404, "Not in the bin any more.")
    if it["kind"] == "file":
        dst = S.unique_path(os.path.join(pdir, it["rel"]))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(os.path.join(_bin_dir(pdir), it["stored"]), dst)
    elif it["kind"] in ITEM_KINDS:
        proj.setdefault(ITEM_KINDS[it["kind"]], []).append(it["data"])
    elif it["kind"] == "layout":
        proj.update(it["data"])
    items.remove(it)
    _save(pdir, items)
    S.add_log(proj, "bin", f"{user['name']} brought back “{str(it['title'])[:60]}” from the bin")
    S.save_project(proj)
    return {"restored": it["title"]}


def empty(proj, user, firm):
    if not (user.get("role") == "owner" or user["id"] in (firm.get("private_access") or [])):
        raise S.ApiError(403, "Only the studio owner (or someone they allow) can empty the bin.")
    pdir = proj["_dir"]
    items = _load(pdir)
    for it in items:
        if it.get("stored"):
            try:
                os.remove(os.path.join(_bin_dir(pdir), it["stored"]))
            except OSError:
                pass
    _save(pdir, [])
    S.add_log(proj, "bin", f"{user['name']} emptied the bin ({len(items)} items removed for good)")
    S.save_project(proj)
    S.security_log(f"bin emptied in {proj['name']}", user["id"])
    return {"emptied": len(items)}


def replace(proj, user, body):
    """New version of a file: the old one goes to Superseded (drawings) or the bin (anything else)."""
    pdir = proj["_dir"]
    old = _safe_rel(pdir, body.get("rel"))
    if not os.path.isfile(old):
        raise S.ApiError(404, "That file has moved.")
    m = re.match(r"^data:[\w/+.\-]*;base64,(.+)$", body.get("data") or "", re.S)
    if not m:
        raise S.ApiError(400, "Choose the new file.")
    name = os.path.basename(str(body.get("name") or "")).strip() or os.path.basename(old)
    S.safe_ext(name)                       # never save a file that could run a program
    folder = os.path.dirname(old)
    rel_old = os.path.relpath(old, pdir).replace("\\", "/")
    if rel_old.startswith("01 Drawings/"):
        sup = os.path.join(pdir, "01 Drawings", "Superseded")
        os.makedirs(sup, exist_ok=True)
        stamp = datetime.now().strftime("%Y-%m-%d")
        stem, ext = os.path.splitext(os.path.basename(old))
        shutil.move(old, S.unique_path(os.path.join(sup, f"{stem} (replaced {stamp}){ext}")))
        where = "Superseded"
    else:
        remove(proj, user, {"kind": "file", "rel": rel_old})
        proj = S.find_project(proj["id"])
        where = "the bin"
    dst = S.unique_path(os.path.join(folder, name))
    with open(dst, "wb") as f:
        f.write(base64.b64decode(m.group(1)))
    S.add_log(proj, "drawing" if where == "Superseded" else "bin",
              f"{user['name']} replaced “{os.path.basename(rel_old)}” with “{os.path.basename(dst)}” (old one in {where})")
    S.save_project(proj)
    return {"new": os.path.relpath(dst, pdir).replace("\\", "/"), "old_went_to": where}
